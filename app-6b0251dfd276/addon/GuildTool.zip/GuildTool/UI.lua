-- GuildTool : fenêtre principale, styles, menus, glisser-déposer, fenêtre de copie
local _, ns = ...

ns.W, ns.H, ns.SIDE_W = 1400, 820, 262
ns.TOP_H, ns.TABS_H = 42, 34

-- Palette « Discord Glass » (identique à Bridge/web/style.css)
local C = {
    bg = { 0.118, 0.122, 0.141 }, head = { 0.137, 0.141, 0.161 }, panel = { 0.165, 0.173, 0.200 },
    side = { 0.145, 0.149, 0.173 }, slot = { 0.192, 0.200, 0.231 }, hover = { 0.227, 0.239, 0.278 },
    input = { 0.184, 0.192, 0.220 }, border = { 0.220, 0.227, 0.263 }, text = { 0.925, 0.929, 0.945 },
    mute = { 0.604, 0.620, 0.663 }, accent = { 0.435, 0.486, 1 }, ok = { 0.247, 0.749, 0.498 },
    red = { 1, 0.42, 0.42 }, white = { 1, 1, 1 },
}
ns.C = C

-- Palette dérivée de la couleur de base (gris « Discord » par défaut) : appliquée à la création de la fenêtre
local PALETTE = { head = 0.022, side = 0.03, panel = 0.055, input = 0.075, slot = 0.085, border = 0.115, hover = 0.125 }
-- couleur de base : barres (onglets, barre indicateur de chaque onglet) et boutons (fond, survol) ; le fond de la
-- fenêtre, les panneaux, cases et bordures gardent les teintes de la couleur par défaut
local FROM_BASE = { head = true, input = true, hover = true }
function ns.ApplyPalette(hex)
    local b = ns.Hex((hex or "#1e1f24"):gsub("#", ""))
    local d = ns.Hex("1e1f24")
    C.bg[1], C.bg[2], C.bg[3] = d[1], d[2], d[3]
    for name, f in pairs(PALETTE) do
        local s = FROM_BASE[name] and b or d
        C[name][1], C[name][2], C[name][3] = s[1] + (1 - s[1]) * f, s[2] + (1 - s[2]) * f, s[3] + (1 - s[3]) * f
    end
end

local FONT = {
    [400] = "Interface\\AddOns\\GuildTool\\media\\Figtree-Regular.ttf",
    [600] = "Interface\\AddOns\\GuildTool\\media\\Figtree-SemiBold.ttf",
    [700] = "Interface\\AddOns\\GuildTool\\media\\Figtree-Bold.ttf",
}
FONT[500] = FONT[400]
ns.FONT = FONT

-- Police Figtree, sinon police du jeu (un SetFont raté ne doit jamais casser la fenêtre)
function ns.SetFont(fs, size, weight)
    local ok, done = pcall(fs.SetFont, fs, FONT[weight or 400] or FONT[400], size, "")
    if not (ok and done ~= false) then fs:SetFont(STANDARD_TEXT_FONT, size, "") end
end

---------------------------------------------------------------------------
-- Helpers de construction
---------------------------------------------------------------------------
-- Nom Forever « Prénom Nom » : le nom de famille plus discret (gris, normal, 1 point plus petit), dans un second
-- texte collé au prénom (une ligne de texte ne change pas de taille en cours) ; maxW = largeur maxi des deux.
-- Rend le dernier texte affiché (pour y accrocher ce qui suit).
-- short (compos, liste) : seulement l'initiale du nom de famille (« Sundance P. »)
function ns.SetName(fs, display, maxW, short)
    display = tostring(display or "")
    local first, rest = display:match("^(%S+)%s+(.+)$")
    -- 1re lettre UTF-8 (octet de tête + octets de suite)
    if rest and short then rest = (rest:match("^[\1-\127\194-\244][\128-\191]*") or rest:sub(1, 1)) .. "." end
    fs:SetWidth(0)
    fs:SetText(first or display)
    if maxW and fs:GetStringWidth() > maxW then fs:SetWidth(maxW) end
    local sur = fs.sur
    if not rest then
        if sur then sur:Hide() end
        return fs
    end
    if not sur then
        local layer = fs:GetDrawLayer()   -- (GetDrawLayer rend aussi un sous-niveau : ne pas le passer en modèle)
        sur = fs:GetParent():CreateFontString(nil, layer)
        sur:SetJustifyH("LEFT")
        sur:SetWordWrap(false)
        fs.sur = sur
    end
    local _, size = fs:GetFont()
    ns.SetFont(sur, math.max(6, math.floor((size or 12) + 0.5) - 1), 400)
    sur:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
    sur:SetText(rest)
    sur:SetWidth(0)
    sur:ClearAllPoints()
    sur:SetPoint("BOTTOMLEFT", fs, "BOTTOMRIGHT", 4, 0)
    if maxW then
        local room = maxW - fs:GetStringWidth() - 4
        if room < 12 then sur:Hide() return fs end
        if sur:GetStringWidth() > room then sur:SetWidth(room) end
    end
    sur:Show()
    return sur
end

-- « Show History » des listes du titre : icône (parchemin + plume) et couleur au survol (bleu ciel 26, 209, 255)
ns.MEDIA_PATH = "Interface\\AddOns\\GuildTool\\media\\"
ns.HISTORY_ICON = "Interface\\AddOns\\GuildTool\\media\\history"
ns.HISTORY_HOVER = { 26 / 255, 209 / 255, 1 }

-- Triangle plein lissé (comme les flèches de l'exe) : dir = "down", "up", "left", "right"
local TRI = "Interface\\AddOns\\GuildTool\\media\\tri"
local TRI_ROT = { down = 0, left = -math.pi / 2, up = math.pi, right = math.pi / 2 }
function ns.Triangle(parent, dir, size)
    local t = parent:CreateTexture(nil, "OVERLAY")
    t:SetTexture(TRI)
    t:SetSize(size or 12, size or 12)
    t:SetRotation(TRI_ROT[dir or "down"] or 0)
    t:SetVertexColor(0.85, 0.86, 0.9)
    return t
end

-- Cache le nom de famille quand le texte sert à autre chose (« Empty »…)
function ns.ClearName(fs)
    if fs.sur then fs.sur:Hide() end
    fs:SetWidth(0)
end

function ns.Text(parent, size, weight, color, layer)
    local fs = parent:CreateFontString(nil, layer or "OVERLAY")
    ns.SetFont(fs, size, weight)
    local c = color or C.text
    fs:SetTextColor(c[1], c[2], c[3], c[4] or 1)
    fs:SetJustifyH("LEFT")
    fs:SetWordWrap(false)
    return fs
end

function ns.Tex(parent, color, layer, alpha)
    local t = parent:CreateTexture(nil, layer or "BACKGROUND")
    t:SetColorTexture(color[1], color[2], color[3], alpha or color[4] or 1)
    return t
end

function ns.Fill(frame, color, alpha)
    local t = ns.Tex(frame, color, "BACKGROUND", alpha)
    t:SetAllPoints()
    frame.bg = t
    return t
end

-- Bordure 1 px (4 textures)
function ns.Border(frame, color, alpha)
    local e = {}
    for i, p in ipairs({ { "TOPLEFT", "TOPRIGHT", 0, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", 0, 1 }, { "TOPLEFT", "BOTTOMLEFT", 1, 0 }, { "TOPRIGHT", "BOTTOMRIGHT", 1, 0 } }) do
        local t = ns.Tex(frame, color, "BORDER", alpha)
        t:SetPoint(p[1]) t:SetPoint(p[2])
        if p[3] == 1 then t:SetWidth(1) else t:SetHeight(1) end
        e[i] = t
    end
    frame.edges = e
    return e
end

-- Bords à 1 pixel réel quelle que soit l'échelle (sinon une ligne de bord peut tomber entre deux pixels et disparaître)
function ns.PixelEdges(frame)
    if not (frame.edges and PixelUtil and PixelUtil.GetNearestPixelSize) then return end
    local px = PixelUtil.GetNearestPixelSize(1, frame:GetEffectiveScale(), 1)
    for i, t in ipairs(frame.edges) do
        if i <= 2 then t:SetHeight(px) else t:SetWidth(px) end
    end
end

function ns.SetBorderColor(frame, color, alpha)
    for _, t in ipairs(frame.edges) do t:SetColorTexture(color[1], color[2], color[3], alpha or 1) end
end

-- Couleur du surlignage des onglets (Settings), lue à la création de la fenêtre
C.hl = { 0.435, 0.486, 1 }
function ns.ApplyHighlight(hex)
    local c = ns.Hex((hex or "#6f7cff"):gsub("#", ""))
    C.hl[1], C.hl[2], C.hl[3] = c[1], c[2], c[3]
end

-- Sélections et survols : fondu vers le bas + liseré, couleur de surbrillance (Settings > Highlight)
local HL_TEX = {}
local function paintSelection(g, l, a)
    g:SetGradient("VERTICAL", CreateColor(a[1], a[2], a[3], 0.22), CreateColor(a[1], a[2], a[3], 0))
    l:SetColorTexture(a[1], a[2], a[3], 1)
end

function ns.Selection(frame, lineH, color)
    local g = frame:CreateTexture(nil, "BACKGROUND", nil, 1)
    g:SetAllPoints()
    g:SetColorTexture(1, 1, 1, 1)
    local a = color or C.hl
    local l = ns.Tex(frame, a, "ARTWORK")
    l:SetPoint("BOTTOMLEFT") l:SetPoint("BOTTOMRIGHT")
    l:SetHeight(lineH or 2)
    paintSelection(g, l, a)
    if a == C.hl then HL_TEX[#HL_TEX + 1] = { g, l } end
    local sel = { g, l }
    frame.sel = sel
    ns.ShowSelection(frame, false)
    return sel
end

-- Bordures à la couleur de surbrillance (fenêtre Settings…) : recolorées avec les sélections
local HL_BORDERS = {}
function ns.HighlightBorder(frame)
    HL_BORDERS[#HL_BORDERS + 1] = frame
    ns.SetBorderColor(frame, C.hl)
end

-- Recolore toutes les sélections (dégradé animé entre les deux couleurs de surbrillance)
function ns.RepaintHighlight()
    for _, s in ipairs(HL_TEX) do paintSelection(s[1], s[2], C.hl) end
    for _, f in ipairs(HL_BORDERS) do ns.SetBorderColor(f, C.hl) end
end

local hlTicker = CreateFrame("Frame")
hlTicker.elapsed = 0
hlTicker:SetScript("OnUpdate", function(self, dt)
    self.elapsed = self.elapsed + dt
    if self.elapsed < 0.06 then return end
    self.elapsed = 0
    local a = ns.db and ns.db.appearance
    if not (a and a.hlGrad and ns.frame and ns.frame:IsShown()) then return end
    local x, y = ns.Hex((a.hl or "#6f7cff"):gsub("#", "")), ns.Hex((a.hl2 or "#3fc7eb"):gsub("#", ""))
    local k = (1 - math.cos(GetTime() / 6 * 2 * math.pi)) / 2
    for i = 1, 3 do C.hl[i] = x[i] + (y[i] - x[i]) * k end
    ns.RepaintHighlight()
end)

function ns.ShowSelection(frame, on)
    for _, t in ipairs(frame.sel) do t:SetShown(on) end
end

-- Bouton plat avec texte
function ns.Button(parent, text, w, h, primary)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    ns.Fill(b, primary and C.accent or C.input)
    ns.Border(b, primary and C.accent or C.border)
    b.label = ns.Text(b, 11.5, 600, primary and C.white or C.text)
    b.label:SetPoint("CENTER")
    b.label:SetText(text)
    b:SetScript("OnEnter", function(self) if not primary then self.bg:SetColorTexture(C.hover[1], C.hover[2], C.hover[3]) end end)
    b:SetScript("OnLeave", function(self) if not primary then self.bg:SetColorTexture(C.input[1], C.input[2], C.input[3]) end end)
    return b
end

-- Bouton carré à icône (comme Sync / Settings de l'appli) : cadre, icône blanc cassé, bordure Highlight au survol
function ns.IconBox(parent, icon, tip, w, h)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w or 32, h or 26)
    ns.Fill(b, C.input)
    ns.Border(b, C.border)
    b.icon = b:CreateTexture(nil, "OVERLAY")
    b.icon:SetSize(16, 16)
    b.icon:SetPoint("CENTER")
    b.icon:SetTexture(icon)
    b.icon:SetVertexColor(0.91, 0.9, 0.88)
    b:SetScript("OnEnter", function(self)
        ns.SetBorderColor(self, C.hl)
        self.bg:SetColorTexture(C.hover[1], C.hover[2], C.hover[3])
        if tip then ns.TipOwner(self) GameTooltip:SetText(ns.L(tip), 1, 1, 1) GameTooltip:Show() end
    end)
    b:SetScript("OnLeave", function(self)
        ns.SetBorderColor(self, C.border)
        self.bg:SetColorTexture(C.input[1], C.input[2], C.input[3])
        GameTooltip:Hide()
    end)
    return b
end

-- Petit bouton icône texte (@, ✕, +)
function ns.IconButton(parent, glyph, size, tip)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(size, size)
    b.hl = ns.Fill(b, C.hover)
    b.hl:Hide()
    b.label = ns.Text(b, 12, 700, C.mute)
    b.label:SetPoint("CENTER", 0, 0)
    b.label:SetText(glyph)
    b:SetScript("OnEnter", function(self)
        self.hl:Show() self.label:SetTextColor(1, 1, 1)
        if tip then ns.TipOwner(self) GameTooltip:SetText(tip, 1, 1, 1) GameTooltip:Show() end
    end)
    b:SetScript("OnLeave", function(self)
        self.hl:Hide() self.label:SetTextColor(C.mute[1], C.mute[2], C.mute[3]) GameTooltip:Hide()
    end)
    return b
end

function ns.Hex(hex)
    if not hex then return C.mute end
    return { tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255 }
end

function ns.ClassColor(class) return ns.Hex(ns.CLASS_COLOR[class or ""]) end

-- Ctrl + molette sur le fond d'une fenêtre (pas sur un élément interactif) : échelle de 50 à 150 %, coin haut-droit
-- fixe (la fenêtre grandit vers le bas et la gauche) ; set(valeur, point) enregistre
-- Plus grand zoom : la fenêtre prend toute la largeur de l'écran ; sa hauteur est alors capée à celle de l'écran (proportions
-- de l'écran), et revient à sa hauteur normale (f.baseH) en dézoomant. f.noCap : pas de cap (plein écran de /tlc) ;
-- f.onCap() : appelée quand la hauteur change (mise en page de la fenêtre)
function ns.WheelScale(f, get, set)
    f.baseH = f.baseH or f:GetHeight()
    local function maxScale() return UIParent:GetWidth() / math.max(1, f:GetWidth()) end
    function f.capToScreen()
        if f.noCap then return end
        local h = math.min(f.baseH or f:GetHeight(), UIParent:GetHeight() / f:GetScale())
        if math.abs(f:GetHeight() - h) > 0.5 then
            f:SetHeight(h)
            if f.onCap then f.onCap() end
        end
    end
    -- écran plus petit qu'à l'enregistrement de l'échelle : ramenée au plus grand zoom permis
    f:HookScript("OnShow", function()
        if f:GetScale() > maxScale() then f:SetScale(maxScale()) end
        f.capToScreen()
    end)
    f.wheelScale = function(d)
        local v = math.max(0.5, math.min(maxScale(), math.floor((get() + d * 0.05) * 20 + 0.5) / 20))
        local s0, right, top = f:GetEffectiveScale(), f:GetRight(), f:GetTop()
        f:SetScale(v)
        local pt
        if right and top then
            local s1, ps = f:GetEffectiveScale(), UIParent:GetEffectiveScale()
            local x = (right * s0 - UIParent:GetRight() * ps) / s1
            local y = (top * s0 - UIParent:GetTop() * ps) / s1
            f:ClearAllPoints()
            f:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", x, y)
            pt = { "TOPRIGHT", x, y }
        end
        f.capToScreen()
        set(v, pt)
    end
    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel", function(self, d) if IsControlKeyDown() then self.wheelScale(d) end end)
end
-- molette reçue par une zone de défilement : avec Ctrl, échelle de sa fenêtre
function ns.WheelScaleFrom(frame, d)
    local p = frame
    while p do
        if p.wheelScale then p.wheelScale(d) return true end
        p = p:GetParent()
    end
    return false
end

-- Scroll vertical avec molette + barre fine draggable
function ns.ScrollArea(parent)
    local sf = CreateFrame("ScrollFrame", nil, parent)
    local child = CreateFrame("Frame", nil, sf)
    child:SetSize(1, 1)
    sf:SetScrollChild(child)
    sf.child = child
    local thumb = CreateFrame("Frame", nil, sf)
    thumb:SetWidth(5)
    ns.Fill(thumb, { 0.29, 0.30, 0.345 })
    thumb:EnableMouse(true)
    sf.thumb = thumb
    function sf:UpdateThumb()
        local range, h = self:GetVerticalScrollRange(), self:GetHeight()
        if range <= 0 then thumb:Hide() return end
        local th = math.max(30, h * h / (h + range))
        thumb:SetHeight(th)
        thumb:ClearAllPoints()
        thumb:SetPoint("TOPRIGHT", self, "TOPRIGHT", -1, -(h - th) * (self:GetVerticalScroll() / range))
        thumb:Show()
    end
    function sf:ScrollTo(v)
        local range = self:GetVerticalScrollRange()
        self:SetVerticalScroll(math.max(0, math.min(range, v)))
        self:UpdateThumb()
    end
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(self, d)
        if IsControlKeyDown() and ns.WheelScaleFrom(self, d) then return end
        self:ScrollTo(self:GetVerticalScroll() - d * 60)
    end)
    sf:SetScript("OnScrollRangeChanged", function(self) self:UpdateThumb() end)
    thumb:SetScript("OnMouseDown", function(self)
        local _, y0 = GetCursorPosition()
        local v0 = sf:GetVerticalScroll()
        self:SetScript("OnUpdate", function()
            local _, y = GetCursorPosition()
            local scale = sf:GetEffectiveScale()
            local h, range = sf:GetHeight(), sf:GetVerticalScrollRange()
            local th = self:GetHeight()
            if h - th > 0 then sf:ScrollTo(v0 + (y0 - y) / scale * range / (h - th)) end
        end)
    end)
    thumb:SetScript("OnMouseUp", function(self) self:SetScript("OnUpdate", nil) end)
    return sf
end

---------------------------------------------------------------------------
-- Menu contextuel / liste déroulante (un seul, réutilisé)
---------------------------------------------------------------------------
-- Infobulles : en bas à droite de la fenêtre de l'élément survolé (/two, /tlc, Settings…) ; élément surtout dans la
-- moitié droite de sa fenêtre : en bas à gauche. Hors d'une fenêtre de l'addon : ancrage habituel à droite.
function ns.TipOwner(owner)
    -- fenêtre = l'ancêtre posé sur UIParent (mini-carte : ancrage habituel)
    local win = owner
    while win and win.GetParent and win:GetParent() and win:GetParent() ~= UIParent do win = win:GetParent() end
    if not (win and win.GetParent and win:GetParent() == UIParent) or win == Minimap or win == MinimapCluster then
        GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
        return
    end
    GameTooltip:SetOwner(owner, "ANCHOR_NONE")
    GameTooltip:ClearAllPoints()
    local cx = owner:GetCenter()
    local l, r = win:GetLeft(), win:GetRight()
    -- (coordonnées à l'échelle de chacun : comparées en pixels écran)
    local right = cx and l and r and (cx * owner:GetEffectiveScale()) > ((l + r) / 2 * win:GetEffectiveScale())
    if right then GameTooltip:SetPoint("BOTTOMLEFT", win, "BOTTOMLEFT", 12, 12)
    else GameTooltip:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -12, 12) end
end

function ns:OpenMenu(anchor, items, width)
    local m = self.menu
    if not m then
        m = CreateFrame("Frame", nil, UIParent)
        m:SetFrameStrata("FULLSCREEN_DIALOG")
        m:SetClampedToScreen(true)
        ns.Fill(m, { 0.09, 0.094, 0.11 })
        ns.Border(m, C.border)
        m.buttons = {}
        -- clic ailleurs = fermeture
        local catcher = CreateFrame("Button", nil, UIParent)
        catcher:SetAllPoints(UIParent)
        catcher:SetFrameStrata("FULLSCREEN")
        catcher:RegisterForClicks("AnyUp")
        catcher:SetScript("OnClick", function() m:Hide() end)
        catcher:Hide()
        m.catcher = catcher
        m:SetScript("OnHide", function() catcher:Hide() end)
        -- menu ouvert au survol (autoAnchor) : se referme 0,5 s après que la souris a quitté l'ancre et le menu
        m:SetScript("OnUpdate", function(self)
            local a = self.autoAnchor
            if not a then return end
            if self:IsMouseOver() or a:IsMouseOver() then self.outSince = nil
            else
                self.outSince = self.outSince or GetTime()
                if GetTime() - self.outSince > 0.5 then self:Hide() end
            end
        end)
        self.menu = m
    end
    m.autoAnchor, m.outSince = nil, nil
    local fit = width == "fit"
    width = (not fit and width) or math.max(anchor:GetWidth(), 160)
    m:SetScale((self.frame or anchor):GetScale() * ((self.frame and 1) or (anchor:GetEffectiveScale() / anchor:GetScale() / UIParent:GetEffectiveScale())))
    for i, item in ipairs(items) do
        local b = m.buttons[i]
        if not b then
            b = CreateFrame("Button", nil, m)
            b:SetHeight(22)
            b.hl = ns.Fill(b, C.hover)
            b.hl:Hide()
            b.label = ns.Text(b, 12, 400)
            b.label:SetPoint("RIGHT", -8, 0)
            b.icon = b:CreateTexture(nil, "ARTWORK")
            b.icon:SetSize(14, 14)
            b.icon:SetPoint("LEFT", 9, 0)
            -- item.hover = couleur au survol (texte en gras)
            b:SetScript("OnEnter", function(self)
                self.hl:Show()
                local h = self.item and self.item.hover
                if h then
                    ns.SetFont(self.label, 12, 700)
                    self.label:SetTextColor(h[1], h[2], h[3])
                    self.icon:SetVertexColor(h[1], h[2], h[3])
                end
            end)
            b:SetScript("OnLeave", function(self)
                self.hl:Hide()
                if self.item and self.item.hover then
                    ns.SetFont(self.label, 12, 400)
                    self.label:SetTextColor(self.c[1], self.c[2], self.c[3])
                    self.icon:SetVertexColor(self.c[1], self.c[2], self.c[3])
                end
            end)
            m.buttons[i] = b
        end
        b.item = item
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", 1, -1 - (i - 1) * 22)
        b:SetPoint("TOPRIGHT", -1, -1 - (i - 1) * 22)
        ns.SetFont(b.label, 12, 400)
        b.label:SetText(item.text)
        -- item.icon : petite icône devant le texte, teintée comme lui
        b.label:ClearAllPoints()
        -- item.atlas : icône du jeu en couleur (pas teintée) ; repli sur item.icon si l'atlas n'existe pas dans ce client
        local atlas = item.atlas and C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(item.atlas) and item.atlas
        local hasIcon = atlas or item.icon
        b.label:SetPoint("LEFT", hasIcon and (atlas and 30 or 28) or 10, 0)
        b.label:SetPoint("RIGHT", -8, 0)
        b.icon:SetShown(hasIcon ~= nil)
        b.icon:SetTexCoord(0, 1, 0, 1)
        local isz = item.iconSize or (atlas and 18 or 14)
        if atlas then b.icon:SetAtlas(atlas) elseif item.icon then b.icon:SetTexture(item.icon) end
        b.icon:SetSize(isz, isz)
        local c = item.checked and C.accent or (item.color or C.text)
        b.c = c
        b.label:SetTextColor(c[1], c[2], c[3])
        -- item.noTint : icône d'objet en couleurs d'origine (pas teintée comme le texte)
        if atlas or item.noTint then b.icon:SetVertexColor(1, 1, 1) else b.icon:SetVertexColor(c[1], c[2], c[3]) end
        -- item.keep : le menu reste ouvert (la fonction le remplit à nouveau)
        b:SetScript("OnClick", function()
            if item.keep then if item.func then item.func() end return end
            m:Hide() if item.func then item.func() end ns:Refresh()
        end)
        b:Show()
    end
    for i = #items + 1, #m.buttons do m.buttons[i]:Hide() end
    -- largeur « fit » : juste assez pour la ligne la plus longue
    if fit then
        local wmax = 0
        for i = 1, #items do wmax = math.max(wmax, m.buttons[i].label:GetStringWidth() + (items[i].icon and 18 or 0)) end
        width = math.max(120, math.ceil(wmax) + 24)
    end
    m:SetSize(width, #items * 22 + 2)
    m:ClearAllPoints()
    m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
    m.catcher:Show()
    m:Show()
end

-- Bouton déroulant : petit libellé + valeur + flèche
function ns.Dropdown(parent, label, width, getItems)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, 26)
    ns.Fill(b, C.input)
    ns.Border(b, C.border)
    local l = ns.Text(b, 9.5, 600, C.mute)
    l:SetPoint("LEFT", 9, 0)
    l:SetText(strupper(label))
    b.value = ns.Text(b, 12, 500)
    b.value:SetPoint("LEFT", l, "RIGHT", 7, 0)
    b.value:SetPoint("RIGHT", -20, 0)
    local arrow = ns.Triangle(b, "down", 13)
    arrow:SetVertexColor(0.7, 0.7, 0.75)
    arrow:SetPoint("RIGHT", -4, 0)
    b:SetScript("OnClick", function(self) ns:OpenMenu(self, getItems()) end)
    b:SetScript("OnEnter", function(self) ns.SetBorderColor(self, C.accent) end)
    b:SetScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) end)
    return b
end

---------------------------------------------------------------------------
-- Liste sous le titre de la barre (lockouts de Loots, compos d'Assigns), même rendu que l'appli :
-- lignes « date - date » aux tirets alignés (une ligne sans dates, « All lockouts », centrée sur les tirets),
-- ou nom + détail à droite ; choisie = cadre et dégradé dorés, lockout actuel = fond Highlight, passé = gris ;
-- « Show History » (icône) en tête. items : { left, right | text, count, sel, now, old, hist, func, keep }
-- Refermée quand la souris s'en éloigne (0,5 s) ; défile au-delà de 14 lignes.
---------------------------------------------------------------------------
local TP_ROW, TP_GOLD = 28, { 1, 0.82, 0.25 }
local function tpRow(p, i)
    local b = p.rows[i]
    if b then return b end
    b = CreateFrame("Button", nil, p.sf.child)
    b:SetHeight(TP_ROW - 2)
    b.bg = ns.Tex(b, C.white, "BACKGROUND", 0)
    b.bg:SetAllPoints()
    b.gold = b:CreateTexture(nil, "BACKGROUND", nil, 1)
    b.gold:SetAllPoints()
    b.gold:SetColorTexture(1, 1, 1, 1)
    b.gold:SetGradient("VERTICAL", CreateColor(TP_GOLD[1], TP_GOLD[2], TP_GOLD[3], 0.45), CreateColor(TP_GOLD[1], TP_GOLD[2], TP_GOLD[3], 0.1))
    ns.Border(b, C.border)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(15, 15)
    b.left = ns.Text(b, 12, 700)
    b.dash = ns.Text(b, 12, 700)
    b.right = ns.Text(b, 12, 700)
    b.text = ns.Text(b, 12, 700)
    b.count = ns.Text(b, 10.5, 600, C.mute)
    b.count:SetPoint("RIGHT", -8, 0)
    b.count:SetJustifyH("RIGHT")
    b.count:SetWordWrap(false)
    b.year = ns.Text(b, 9, 600, C.mute)
    b.year:SetPoint("RIGHT", -8, 0)
    b:SetScript("OnEnter", function(f) ns.SetBorderColor(f, f.item.hist and C.border or C.accent, f.item.hist and 0 or 1) if f.item.hist then f:Paint(true) end end)
    b:SetScript("OnLeave", function(f) f:Paint(false) end)
    b:SetScript("OnClick", function(f)
        local it = f.item
        if not it.keep then p:Hide() end
        if it.func then it.func() end
        if not it.keep then ns:Refresh() end
    end)
    function b:Paint(hover)
        local it = self.item
        if it.hist then
            local c = hover and (ns.HISTORY_HOVER or C.hl) or C.mute
            ns.SetFont(self.text, 12, hover and 700 or 500)
            self.text:SetTextColor(c[1], c[2], c[3])
            self.icon:SetVertexColor(c[1], c[2], c[3])
            ns.SetBorderColor(self, C.border, 0)
            return
        end
        ns.SetBorderColor(self, it.sel and TP_GOLD or C.border, it.sel and 1 or 0)
    end
    p.rows[i] = b
    return b
end
function ns:TitlePicker(anchor, items, titleFS)
    local p = self.titlePick
    if not p then
        p = CreateFrame("Frame", nil, self.frame)
        p:SetFrameStrata("DIALOG")
        p:EnableMouse(true)
        ns.Fill(p, { 0.09, 0.094, 0.11 }, 0.97)
        ns.Border(p, C.border)
        local sf = ns.ScrollArea(p)
        sf:SetPoint("TOPLEFT", 6, -6)
        sf:SetPoint("BOTTOMRIGHT", -6, 6)
        p.sf, p.rows = sf, {}
        p.m = ns.Text(p, 12, 700)
        p.m:Hide()
        p:SetScript("OnUpdate", function(f)
            if f:IsMouseOver() or (f.anchor and f.anchor:IsMouseOver()) then f.out = nil
            else
                f.out = f.out or GetTime()
                if GetTime() - f.out > 0.5 then f:Hide() end
            end
        end)
        p:SetScript("OnHide", function(f) f.out = nil end)
        self.titlePick = p
    end
    p.anchor = anchor
    -- largeurs : dates de part et d'autre du tiret, textes seuls, détails à droite
    local m, PADL = p.m, 10
    local maxL, maxR, maxT, maxC, dashed, dashW = 0, 0, 0, 0, false, 0
    local function w(text, size, weight)
        ns.SetFont(m, size, weight)
        m:SetText(text or "")
        return m:GetStringWidth()
    end
    dashW = w("-", 12, 700)
    for _, it in ipairs(items) do
        if it.left then
            dashed = true
            maxL, maxR = math.max(maxL, w(it.left, 12, 700)), math.max(maxR, w(it.right, 12, 700))
        elseif it.hist then
            maxT = math.max(maxT, w(it.text, 12, 500) + 22)
        else
            maxT = math.max(maxT, w(it.text, 12, 700))
        end
        local yw = it.year and (w(tostring(it.year), 9, 600) + 6) or 0
        if (it.count and it.count ~= "") or it.year then maxC = math.max(maxC, math.min(150, w(it.count or "", 10.5, 600)) + yw) end
    end
    local dashX = PADL + maxL + 6 + dashW / 2
    local rowW
    if dashed then
        -- une ligne sans dates est centrée sur les tirets : assez de place des deux côtés
        local half = math.max(dashW / 2 + 6 + maxR + (maxC > 0 and 14 + maxC + 8 or 8), maxT / 2 + 8)
        dashX = math.max(dashX, PADL + maxT / 2)
        rowW = dashX + half
    else
        rowW = PADL + maxT + (maxC > 0 and 16 + maxC or 0) + 8
    end
    local firstX
    local selY = 0
    for i, it in ipairs(items) do
        local b = tpRow(p, i)
        b.item = it
        b:SetWidth(rowW)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", 2, -(i - 1) * TP_ROW)
        local c = it.sel and TP_GOLD or (it.old and C.mute) or C.text
        b.left:SetShown(it.left ~= nil) b.dash:SetShown(it.left ~= nil) b.right:SetShown(it.left ~= nil)
        b.text:SetShown(it.left == nil)
        b.icon:SetShown(it.hist and true or false)
        b.text:ClearAllPoints()
        if it.left then
            ns.SetFont(b.left, 12, 700) ns.SetFont(b.dash, 12, 700) ns.SetFont(b.right, 12, 700)
            b.left:SetText(it.left) b.dash:SetText("-") b.right:SetText(it.right)
            b.dash:ClearAllPoints() b.dash:SetPoint("CENTER", b, "LEFT", dashX, 0)
            b.left:ClearAllPoints() b.left:SetPoint("RIGHT", b.dash, "LEFT", -6, 0)
            b.right:ClearAllPoints() b.right:SetPoint("LEFT", b.dash, "RIGHT", 6, 0)
            for _, fs in ipairs({ b.left, b.dash, b.right }) do fs:SetTextColor(c[1], c[2], c[3]) end
            firstX = firstX or (dashX - 6 - dashW / 2 - w(it.left, 12, 700))
        elseif it.hist then
            b.icon:SetTexture(ns.HISTORY_ICON)
            b.text:SetPoint("LEFT", b.icon, "RIGHT", 7, 0)
            b.text:SetText(it.text)
        else
            ns.SetFont(b.text, 12, 700)
            if dashed then b.text:SetPoint("CENTER", b, "LEFT", dashX, 0) else b.text:SetPoint("LEFT", PADL, 0) end
            b.text:SetText(it.text)
            b.text:SetTextColor(c[1], c[2], c[3])
        end
        -- détail à droite (titre de l'event, coupé au besoin), puis l'année d'une compo d'une autre année
        ns.SetFont(b.year, 9, 600)
        b.year:SetText(it.year and tostring(it.year) or "")
        local yw = it.year and (b.year:GetStringWidth() + 6) or 0
        ns.SetFont(b.count, 10.5, 600)
        b.count:SetText(it.count or "")
        b.count:ClearAllPoints()
        b.count:SetPoint("RIGHT", -8 - yw, 0)
        b.count:SetWidth(math.max(10, math.min(150, maxC - yw)) + 2)
        b.gold:SetShown(it.sel and true or false)
        b.bg:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], it.now and 0.28 or 0)
        b:Paint(false)
        b:Show()
        if it.sel then selY = (i - 1) * TP_ROW end
    end
    -- « Show History » commence où commence la date de la 1re ligne
    for i, it in ipairs(items) do
        if it.hist then p.rows[i].icon:ClearAllPoints() p.rows[i].icon:SetPoint("LEFT", dashed and (firstX or PADL) or PADL, 0) end
    end
    for i = #items + 1, #p.rows do p.rows[i]:Hide() end
    p.sf.child:SetWidth(rowW + 4)
    p.sf.child:SetHeight(#items * TP_ROW + 4)
    p:SetSize(rowW + 22, math.min(#items * TP_ROW + 12, 14 * TP_ROW))
    p:ClearAllPoints()
    -- tirets sous celui du titre (« 28/10 - Mount Hyjal ») ; titre sans tiret : sous son centre
    local tl = titleFS and (titleFS:GetText() or ""):match("^(.-) %- ")
    if dashed and tl then
        local x = w(tl .. " ", 14, 700) + w("-", 14, 700) / 2
        p:SetPoint("TOPLEFT", titleFS, "BOTTOMLEFT", x - 8 - dashX, -10)
    elseif dashed then p:SetPoint("TOPLEFT", anchor, "BOTTOM", -(8 + dashX), -4)
    else p:SetPoint("TOP", anchor, "BOTTOM", 0, -4) end
    p:Show()
    C_Timer.After(0, function() p.sf:ScrollTo(selY - 4 * TP_ROW) end)
end
