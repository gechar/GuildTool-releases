-- GuildTool : distribution du loot de raid (/tlc)
-- Liste des objets échangeables (texte bleu « You may trade this item… ») des sacs du maître du butin, envoyée au
-- raid par le chat addon ; chaque joueur annonce son intention (Bis, Up+, Up, O-Spec, PvP, Mog) + note ; les
-- officiers suggèrent un joueur (cadre de leur couleur), le maître du butin fait rouler / retire / attribue,
-- l'objet est échangé tout seul au trade et rangé dans la base des attributions (lue par l'exe).
local _, ns = ...
local C = ns.C
local L = function(...) return ns.L(...) end

-- ce client range les fonctions d'objets dans C_Item (plus de GetItemInfo global)
local GetItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
local GetItemIcon = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
local PREFIX = "GuildToolLC"
local KINDS = { { "bis", "Bis" }, { "upp", "Up+" }, { "up", "Up" }, { "os", "Off Spec" }, { "pvp", "PvP" }, { "mog", "Mog" } }
-- couleur de chaque réponse : en-tête et bande de sa colonne
local KIND_COLOR = { bis = { 1, 0.62, 0.2 }, upp = { 0.3, 0.85, 0.45 }, up = { 0.35, 0.65, 1 }, os = { 0.72, 0.5, 1 },
                     pvp = { 1, 0.38, 0.38 }, mog = { 1, 0.5, 0.8 } }
local OS_W, KIND_W, HEAD_H = 84, 50, 22
local KIND_LABEL = { de = "Disenchant", vendor = "Vendor" }
for _, k in ipairs(KINDS) do KIND_LABEL[k[1]] = k[2] end
-- colonne SR (réservations softres.it) devant BIS quand l'interrupteur SoftRes est allumé ; colonnes plus étroites
KIND_COLOR.sr = { 0.3, 0.85, 0.85 }
local SR_COLS = { { "sr", "SR" } }
for _, k in ipairs(KINDS) do SR_COLS[#SR_COLS + 1] = k end
local function columns() return ns:SROn() and SR_COLS or KINDS end
-- couleurs des officiers (choisies au hasard, distinctes) : bleu, rouge, vert, jaune, violet, turquoise
local OFF_COLORS = { { 0.31, 0.56, 0.97 }, { 1, 0.35, 0.35 }, { 0.27, 0.83, 0.51 }, { 1, 0.84, 0.25 }, { 0.70, 0.49, 0.95 }, { 0.25, 0.85, 0.85 } }
local GOLD, REDDISH = { 1, 0.82, 0.25 }, { 0.85, 0.3, 0.3 }
local MEDIA = "Interface\\AddOns\\GuildTool\\media\\"
local W, H, ROW_H, NAME_H, COL_W = 1000, 640, 36, 18, 150

local lc = {}          -- fenêtre
ns.lc = lc
-- placement des colonnes : x du bord gauche de la 1re (dans la liste), largeur, échelle de la police des noms.
-- Colonnes de 150 tant qu'elles tiennent ; sinon marges gauche / droite réduites (5 px au moins) puis colonnes
-- plus étroites, la police des noms baissant d'autant (le contenu des colonnes reste le même)
local function colLayout()
    local n = #columns()
    -- largeur utile de la liste (barre de défilement de 5 px à droite comprise)
    local sw = lc.win and lc.win.scroll and lc.win.scroll:GetWidth()
    local inner = ((sw and sw > 0) and sw or ((lc.win and lc.win:GetWidth()) or 1000) - 3) - 6
    local cw = math.min(150, math.floor((inner - 10 + 4) / n))
    -- colonnes centrées : même marge à gauche et à droite (la dernière bande s'arrête 4 px avant le bord de sa colonne)
    return math.max(5, math.floor((inner - n * cw + 4) / 2)), cw, cw / 150
end
local BG_CROP = {}     -- partie de l'image de fond affichée (coordonnées), pour l'image floutée des barres
-- apparence de /tlc, indépendante de la fenêtre principale : image de fond, opacités
local AP_DEF = { bg = true, bgAlpha = 0.6, barAlpha = 1, colAlpha = 0.08, itemTone = 0.5, itemAlpha = 0.92, itemBlur = 0,
                 itemScale = 1, nameSize = 11, pendAlpha = 0.22, tradeScale = 1, showEq = true, showEP = true }
local function lootAp()
    ns.db.ui.lootAp = ns.db.ui.lootAp or {}
    local a, g = ns.db.ui.lootAp, type(ns.db.guildLootAp) == "table" and ns.db.guildLootAp or {}
    for k, v in pairs(AP_DEF) do
        if a[k] == nil then if g[k] ~= nil then a[k] = g[k] else a[k] = v end end
    end
    if type(a.pendColor) ~= "table" then
        local c = type(g.pendColor) == "table" and g.pendColor or { 1, 0.78, 0.25 }
        a.pendColor = { c[1], c[2], c[3] }
    end
    return a
end

---------------------------------------------------------------------------
-- Données (GuildToolDB.loot) : objets, réactions, suggestions, jets, ouverture, couleurs, historique
---------------------------------------------------------------------------
local function db()
    local d = ns.db.loot
    if not d then
        d = { items = {}, reactions = {}, sugg = {}, rolls = {}, open = false, openT = 0, colors = {} }
        ns.db.loot = d
    end
    ns.db.lootHistory = ns.db.lootHistory or {}
    return d
end
local function me() return ns:MyName() end
-- exemplaire « fini » (échangé, fenêtre d'échange passée, ou vu il y a plus de 3 h) : seul sur sa ligne, jamais
-- regroupé avec un nouveau loot du même objet (ses réactions ne passent pas au nouveau)
local function stale(it)
    return it.traded or (it.tradeEnd and it.tradeEnd < time()) or (not it.tradeEnd and time() - (it.t or 0) > 4 * 3600)
end
local function groupKey(it)
    if stale(it) then return "S" .. tostring(it.key) end
    return (it.link and it.link:match("item:[%-%d:]+")) or ("id" .. tostring(it.id))
end
-- temps restant réduit : « 1h », « 34m », secondes sous 2 min
-- temps restant affiché : durée de la ligne bleue, sinon estimée (fenêtre d'échange de 4 h après le loot)
local TRADE_WINDOW = 4 * 3600
local BLUE = { 0.44, 0.78, 1 }   -- couleur de la ligne « You may trade this item… » de l'infobulle
local function tradeEndOf(it) return it.tradeEnd or ((it.t or time()) + TRADE_WINDOW) end
-- texte coupé à n caractères (UTF-8), « … » à la fin
local function truncChars(s, n)
    s = s or ""
    local out, count = "", 0
    for ch in s:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
        count = count + 1
        if count > n then return out .. "…" end
        out = out .. ch
    end
    return out
end
local function fmtLeft(s)
    if not s or s <= 0 then return "" end
    if s >= 3600 then return math.floor(s / 3600) .. "h" end
    if s >= 120 then return math.floor(s / 60) .. "m" end
    return math.floor(s) .. "s"
end
-- groupe de l'objet « key » : ses exemplaires (le 1er, le plus ancien, porte les réactions)
local function groupOf(key)
    local d = db()
    local rep = d.items[key]
    if not rep then return nil end
    local gk, out = groupKey(rep), {}
    for _, x in pairs(d.items) do if groupKey(x) == gk then out[#out + 1] = x end end
    table.sort(out, function(a, b) if (a.t or 0) ~= (b.t or 0) then return (a.t or 0) < (b.t or 0) end return a.key < b.key end)
    return out
end
local function ownsGroup(key)
    for _, x in ipairs(groupOf(key) or {}) do if x.owner == me() then return true end end
    return false
end
local function first(n) return n and (n:match("^(%S+)") or n) or "" end
local function short(sender) return first(((sender or ""):gsub("%-.*$", ""))) end
-- nom affiché dans /tlc : prénom + initiale du 2e nom (« Pexing T. »)
local function shortName(n)
    local a, rest = tostring(n or ""):match("^(%S+)%s+(.+)$")
    if not a then return tostring(n or "") end
    return a .. " " .. (rest:match("^[\1-\127\194-\244][\128-\191]*") or rest:sub(1, 1)) .. "."
end
-- officier / GM : liste de l'exe (officiers et droits temporaires) ; sans liste, rang de guilde (0 = GM, 1 = officier)
local function iAmOfficer()
    if ns:IsOfficer(me()) or (IsGuildLeader and IsGuildLeader()) then return true end
    if next(ns.db.officers or {}) then return false end
    local _, _, rank = GetGuildInfo("player")
    return rank ~= nil and rank <= 1
end
local function isOfficer(name) return ns:IsOfficer(name) or (name == me() and iAmOfficer()) end

-- classe d'un joueur du raid (par son prénom)
local function classOf(name)
    local f = first(name)
    for i = 1, GetNumGroupMembers() do
        local unit = IsInRaid() and ("raid" .. i) or (i == 1 and "player" or "party" .. (i - 1))
        if first(UnitName(unit)) == f then return select(2, UnitClass(unit)), unit end
    end
    if f == first(me()) then return select(2, UnitClass("player")), "player" end
end

-- icône de la spé principale d'un joueur (inscription à l'Event Class Raid-Helper, envoyée par l'exe)
local function mainSpecIcon(name, class)
    local ms = ns.db.mainSpecs or {}
    local spec = ms[name]
    if not spec then
        local f = first(name)
        for n, s in pairs(ms) do if first(n) == f then spec = s break end end
    end
    return spec and ns:SpecIcon({ class = class, spec = spec }) or nil
end
-- icône de la spé d'un joueur pour ce raid : sa place dans une compo de la semaine, sinon sa spé connue
local function raidSpecIcon(name, class)
    local week = ns.db.weeks and ns.db.weeks[tostring(ns:WeekStart(time()))]
    local f = first(name)
    for _, comp in ipairs(week and week.comps or {}) do
        for _, n in pairs(comp.c or {}) do
            if type(n) == "string" and first(n) == f then
                local u = ns:CompUnit(comp, n)
                return ns:SpecIcon({ class = u.class or class, spec = u.spec })
            end
        end
    end
    local spec = ns.db.specs and ns.db.specs[name]
    if not spec then
        for n, s in pairs(ns.db.specs or {}) do if first(n) == f then spec = s break end end
    end
    return spec and ns:SpecIcon({ class = class, spec = spec }) or nil
end

---------------------------------------------------------------------------
-- Chat addon : messages découpés, canal du raid (ou du groupe), réponses en chuchotement
---------------------------------------------------------------------------
local function channel() return IsInRaid() and "RAID" or IsInGroup() and "PARTY" or nil end
local msgId = 0
local function send(kind, data, target)
    local ch = target and "WHISPER" or channel()
    if not ch then return end
    local text = ns.Serialize({ k = kind, n = me(), d = data })
    msgId = msgId + 1
    local total = math.max(1, math.ceil(#text / 220))
    for i = 1, total do
        local part = ("%d\t%d/%d\t%s"):format(msgId, i, total, text:sub((i - 1) * 220 + 1, i * 220))
        C_Timer.After(0.15 * (i - 1), function() C_ChatInfo.SendAddonMessage(PREFIX, part, ch, target) end)
    end
end
local onData
local pendingParts = {}
local function onChunk(msg, sender)
    local id, n, total, part = msg:match("^(%d+)\t(%d+)/(%d+)\t(.*)$")
    if not id then return end
    n, total = tonumber(n), tonumber(total)
    local k = sender .. ":" .. id
    local p = pendingParts[k]
    if not p or n == 1 then p = { parts = {} } pendingParts[k] = p end
    p.parts[n] = part
    for i = 1, total do if not p.parts[i] then return end end
    pendingParts[k] = nil
    local data = ns.Deserialize(table.concat(p.parts))
    -- le nom annoncé doit être celui de l'expéditeur réel
    if type(data) == "table" and data.k and data.n and first(data.n) == short(sender) then onData(data.k, data.n, data.d or {}, sender) end
end

---------------------------------------------------------------------------
-- Scan des sacs : objets échangeables (fenêtre de 2 h des loots de raid)
---------------------------------------------------------------------------
local tip = CreateFrame("GameTooltip", "GuildToolLootTip", nil, "GameTooltipTemplate")
tip:SetOwner(WorldFrame, "ANCHOR_NONE")
local TRADE_PAT = BIND_TRADE_TIME_REMAINING and ("^" .. BIND_TRADE_TIME_REMAINING:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%%s", ".+")) or "You may trade this item"
local function bagSlots(bag)
    return (C_Container and C_Container.GetContainerNumSlots or GetContainerNumSlots)(bag) or 0
end
local function bagLink(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        return info and info.hyperlink, info and info.iconFileID
    end
    return GetContainerItemLink(bag, slot)
end
local function itemGuid(bag, slot, link)
    if C_Item and C_Item.GetItemGUID and ItemLocation then
        local ok, g = pcall(C_Item.GetItemGUID, ItemLocation:CreateFromBagAndSlot(bag, slot))
        if ok and g then return g end
    end
    return link .. "@" .. bag .. ":" .. slot
end
-- lignes de l'infobulle (texte gauche / droit) ; tradable = ligne bleue de fenêtre d'échange
local function scanTooltip(bag, slot)
    tip:ClearLines()
    tip:SetOwner(WorldFrame, "ANCHOR_NONE")
    tip:SetBagItem(bag, slot)
    local lines, tradable, tline = {}, false, nil
    for i = 1, tip:NumLines() do
        local l, r = _G["GuildToolLootTipTextLeft" .. i], _G["GuildToolLootTipTextRight" .. i]
        local lt, rt = l and l:GetText(), r and r:IsShown() and r:GetText()
        if lt and lt:find(TRADE_PAT) then tradable, tline = true, lt end
        if lt then lines[#lines + 1] = rt and (lt .. "\t" .. rt) or lt end
    end
    return tradable, lines, tline
end
-- durée de la ligne bleue (« … for the next 1 hour 59 min ») en secondes : nombres suivis de h / m / s
local function tradeSeconds(line)
    if not line then return nil end
    local s, found = 0, false
    for n, u in line:gmatch("(%d+)%s*(%a+)") do
        local c = strlower(u):sub(1, 1)
        local k = c == "h" and 3600 or c == "m" and 60 or c == "s" and 1 or nil
        if k then s, found = s + tonumber(n) * k, true end
    end
    return found and s or nil
end

---------------------------------------------------------------------------
-- Boss des loots : cible morte ouverte (ou fin de rencontre récente) comparée aux boss du raid (Settings > Phases) ;
-- épique sans boss connu = « Trash » ; liste des loots vus par boss (GuildToolDB.bossLoot, lue par l'exe)
---------------------------------------------------------------------------
local lootSrc, lastBoss = {}, nil
-- raid (PHASES) de la zone : nom ou abrégé contenu dans le nom de la zone (ou l'inverse)
function ns.LootZoneRaid(zone)
    if not zone or zone == "" then return nil end
    local z = strlower(zone)
    for _, ph in ipairs(ns.PHASES) do
        for _, r in ipairs(ph.raids or {}) do
            for _, n in ipairs({ r.name or "", r.short or "" }) do
                n = strlower(n)
                if n ~= "" and (z:find(n, 1, true) or n:find(z, 1, true)) then return r end
            end
        end
    end
end
local function knownBoss(raid, name)
    if not (raid and name) then return nil end
    local n = strlower(name)
    for _, b in ipairs(raid.bosses or {}) do if b.name and strlower(b.name) == n then return b.name end end
end
local function addBossLoot(raidKey, boss, id)
    if not (raidKey and boss and id) then return end
    ns.db.bossLoot = ns.db.bossLoot or {}
    local r = ns.db.bossLoot[raidKey] or {}
    ns.db.bossLoot[raidKey] = r
    r[boss] = r[boss] or {}
    if not r[boss][tostring(id)] then r[boss][tostring(id)] = time() end
end
local function onLootOpened()
    local raid = ns.LootZoneRaid((GetInstanceInfo()))
    if not raid then return end
    local src = UnitExists("target") and UnitIsDead("target") and not UnitIsPlayer("target") and UnitName("target")
    local boss = knownBoss(raid, src) or (lastBoss and time() - lastBoss.t < 300 and knownBoss(raid, lastBoss.name))
    if not boss then return end
    for i = 1, GetNumLootItems() do
        local link = GetLootSlotLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        local q = link and select(3, GetItemInfo(link))
        if id and (q or 0) >= 2 then
            lootSrc[id] = { boss = boss, t = time() }
            addBossLoot(raid.key, boss, id)
        end
    end
end
-- boss d'un nouveau loot échangeable : celui où on l'a ramassé, sinon « Trash » s'il est épique
local function sourceOf(id, q)
    local raid = ns.LootZoneRaid((GetInstanceInfo()))
    local s = id and lootSrc[id]
    if s and time() - s.t < 7200 then return s.boss, raid and raid.key end
    if raid and id and (q or 0) >= 4 then addBossLoot(raid.key, "Trash", id) return "Trash", raid.key end
    return nil, raid and raid.key
end

local lastSig
function ns:LootScan(announce)
    if not ns.db then return end
    local d, owner, seen, inBag = db(), me(), {}, {}
    d.removed = d.removed or {}
    for bag = 0, NUM_BAG_SLOTS or 4 do
        for slot = 1, bagSlots(bag) do
            local link = bagLink(bag, slot)
            if link then
                local tradable, lines, tline = scanTooltip(bag, slot)
                local gk = itemGuid(bag, slot, link)
                inBag[gk] = true
                local it0 = d.items[gk]
                if it0 and it0.manual then it0.bag, it0.slot, it0.tt = bag, slot, lines seen[gk] = true end
                if tradable and not d.removed[gk] then
                    local key = gk
                    seen[key] = true
                    local it = d.items[key]
                    if not it then
                        local name, _, q, _, _, _, _, _, _, icon = GetItemInfo(link)
                        it = { key = key, owner = owner, link = link, id = tonumber(link:match("item:(%d+)")), t = time(),
                               name = name, q = q, icon = icon, zone = (GetInstanceInfo()) }
                        it.boss, it.raid = sourceOf(it.id, q)
                        d.items[key] = it
                        -- jamais les réactions d'un ancien objet (même clé) : chaque loot repart de zéro
                        d.reactions[key], d.sugg[key], d.rolls[key] = nil, nil, nil
                    end
                    -- durée de la ligne bleue lue une seule fois, ensuite décompte
                    if not it.tradeEnd or it.tradeEst or lc.rescanTrade then
                        local s = tradeSeconds(tline)
                        if s then it.tradeEnd, it.tradeEst = time() + s, nil
                        elseif not it.tradeEnd then it.tradeEnd, it.tradeEst = (it.t or time()) + TRADE_WINDOW, true end
                    end
                    it.bag, it.slot, it.tt = bag, slot, lines
                end
            end
        end
    end
    lc.rescanTrade = nil
    -- mes objets sortis des sacs : échangés (attribués) ou plus là
    for key, it in pairs(d.items) do
        if it.owner == owner and not seen[key] then
            if it.attrib and not it.traded then it.traded = true it.tradedT = time() send("T", { key = key })
            elseif not it.attrib then d.items[key] = nil end
        end
    end
    -- liste envoyée au raid quand elle change (ou sur demande)
    local mine, sig = {}, {}
    for key, it in pairs(d.items) do
        if it.owner == owner then
            mine[key] = { link = it.link, id = it.id, t = it.t, attrib = it.attrib, traded = it.traded, zone = it.zone,
                          boss = it.boss, left = it.tradeEnd and (it.tradeEnd - time()) or nil }
            sig[#sig + 1] = key .. tostring(it.attrib) .. tostring(it.traded)
        end
    end
    table.sort(sig)
    sig = table.concat(sig, ",")
    if announce or sig ~= lastSig then lastSig = sig send("L", { items = mine }) end
    if lc.win and lc.win:IsShown() then ns:LootRefresh() end
    if ns.LootTradeFill then ns:LootTradeFill() end
end

---------------------------------------------------------------------------
-- Réception
---------------------------------------------------------------------------

-- X : Loot Dealer, objets équipés des réactions, EP (une seule table : moins d'upvalues dans les grosses fonctions)
local X = {}
-- maître du butin du jeu (mode « Master Loot »), sinon nil
function X.gameML()
    local method, partyID, raidID = (GetLootMethod or function() end)()
    if method ~= "master" then return nil end
    if raidID then return (UnitName("raid" .. raidID)) end
    if partyID then return (UnitName(partyID == 0 and "player" or ("party" .. partyID))) end
end
-- Loot Dealer (choisi par les officiers) : tenu pour maître du butin. Avec lui ou le maître du butin du jeu, seuls
-- leurs objets sont dans la liste de tous ; ceux des autres joueurs ne vont que dans la liste du Loot Dealer
function X.dealer() local d = ns.db.loot return d and d.dealer or nil end
function X.isPublic(owner)
    local dl, ml = X.dealer(), X.gameML()
    if not dl and not ml then return true end
    local f = first(owner)
    return (dl ~= nil and first(dl) == f) or (ml ~= nil and first(ml) == f)
end
function X.iAmDealer() local dl = X.dealer() return dl ~= nil and first(dl) == first(me()) end
-- emplacements d'équipement d'un objet (bague, bijou, arme à une main : deux)
local INV_SLOTS = { INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_CLOAK = { 15 },
    INVTYPE_CHEST = { 5 }, INVTYPE_ROBE = { 5 }, INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 }, INVTYPE_WAIST = { 6 },
    INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 }, INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 },
    INVTYPE_WEAPON = { 16, 17 }, INVTYPE_2HWEAPON = { 16, 17 }, INVTYPE_WEAPONMAINHAND = { 16 }, INVTYPE_WEAPONOFFHAND = { 17 },
    INVTYPE_SHIELD = { 17 }, INVTYPE_HOLDABLE = { 17 }, INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 },
    INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 } }
local itemInstant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
function X.equipLoc(link)
    if not (link and itemInstant) then return nil end
    local _, _, _, loc = itemInstant(link)
    return loc
end
-- mes objets équipés à la place d'un loot (chaînes « item:… », "" = emplacement vide) ; nil : pas un équipement
function X.myEquipped(link)
    local slots = INV_SLOTS[X.equipLoc(link) or ""]
    if not slots then return nil end
    local out = {}
    for i, s in ipairs(slots) do
        local l = GetInventoryItemLink("player", s)
        out[i] = l and l:match("item:[%-%d:]+") or ""
    end
    -- arme à deux mains : la main gauche ne compte que si elle est occupée
    if X.equipLoc(link) == "INVTYPE_2HWEAPON" and out[2] == "" then out[2] = nil end
    return out
end
-- stats d'un objet lues dans son infobulle (même lecture que l'exe, bis_item_stats : poids de la Bislist)
local EQUIP_PATS = {
    { "critical strike with spells by ([%d%.]+)%%", { "SpellCritRating" } },
    { "chance to hit with spells by ([%d%.]+)%%", { "SpellHitRating" } },
    { "chance to get a critical strike by ([%d%.]+)%%", { "CritRating" } },
    { "chance to hit by ([%d%.]+)%%", { "HitRating" } },
    { "damage and healing done by magical spells and effects by up to (%d+)", { "SpellDamage", "Healing" } },
    { "healing done by magical spells and effects by up to (%d+)", { "Healing" } },
    { "healing done by up to (%d+)", { "Healing" } },
    { "damage done by magical spells and effects by up to (%d+)", { "SpellDamage" } },
    { "^%+(%d+) [Rr]anged [Aa]ttack [Pp]ower", { "Rap" } },
    { "^%+(%d+) Attack Power", { "Ap" } },
    { "Restores (%d+) mana per 5 sec", { "Mp5" } },
    { "attack speed by ([%d%.]+)%%", { "HasteRating" } },
    { "[Hh]aste[^%d]*([%d%.]+)", { "HasteRating" } },
    { "dodged or parried by ([%d%.]+)%%", { "ExpertiseRating" } },
    { "[Ee]xpertise[^%d]*([%d%.]+)", { "ExpertiseRating" } },
}
local PRIMARY = { Strength = true, Agility = true, Stamina = true, Intellect = true, Spirit = true }
local statCache = {}
function X.stats(link)
    local key = link and link:match("item:[%-%d:]+")
    if not key then return nil end
    if statCache[key] then return statCache[key] end
    tip:ClearLines()
    tip:SetOwner(WorldFrame, "ANCHOR_NONE")
    tip:SetHyperlink(key)
    local st, ranged, dps = {}, false, 0
    local function add(k, v) st[k] = (st[k] or 0) + v end
    for i = 2, tip:NumLines() do
        local fs = _G["GuildToolLootTipTextLeft" .. i]
        local raw = fs and fs:GetText()
        if raw then
            raw = strtrim(raw)
            local n, s = raw:match("^%+(%d+) (%a+)%.?$")
            if raw == "Ranged" or raw == "Thrown" then ranged = true
            elseif raw:match("^%(([%d%.]+) damage per second%)$") then dps = tonumber(raw:match("^%(([%d%.]+)")) or 0
            elseif n and PRIMARY[s] then add(s, tonumber(n))
            elseif raw:match("^%+(%d+) (%a+) Resistance%.?$") then
                local v, r = raw:match("^%+(%d+) (%a+) Resistance")
                add(r .. "Resistance", tonumber(v))
            elseif raw:match("^%+(%d+) [Tt]?o? ?All Resistances") then
                local v = tonumber(raw:match("^%+(%d+)"))
                for _, r in ipairs({ "Fire", "Nature", "Frost", "Shadow", "Arcane" }) do add(r .. "Resistance", v) end
            elseif raw:match("^(%d+) Armor$") then add("Armor", tonumber(raw:match("^(%d+)")))
            elseif raw:match("^Equip:") then
                local line = raw:gsub("^Equip:%s*", "")
                for _, p in ipairs(EQUIP_PATS) do
                    local v = line:match(p[1])
                    if v then for _, k in ipairs(p[2]) do add(k, tonumber(v) or 0) end break end
                end
            end
        end
    end
    if dps > 0 then add(ranged and "RangedDps" or "MeleeDps", dps) end
    -- objet pas encore chargé (infobulle vide) : relu plus tard
    if tip:NumLines() > 1 then statCache[key] = st end
    return st
end
-- spé d'un joueur pour ce raid (place dans une compo de la semaine), sinon principale, sinon connue ; sans chiffre
-- final de Raid-Helper (« Protection1 »)
function X.specName(name)
    local f = first(name)
    local week = ns.db.weeks and ns.db.weeks[tostring(ns:WeekStart(time()))]
    local s
    for _, comp in ipairs(week and week.comps or {}) do
        for _, n in pairs(comp.c or {}) do
            if not s and type(n) == "string" and first(n) == f then s = ns:CompUnit(comp, n).spec end
        end
    end
    for _, t in ipairs({ ns.db.mainSpecs or {}, ns.db.specs or {} }) do
        if not s then
            s = t[name]
            if not s then for n, x in pairs(t) do if first(n) == f then s = x break end end end
        end
    end
    return s and (tostring(s):gsub("%d+$", "")) or nil
end
-- différence d'EP entre un loot et ce que le joueur porte à sa place (poids de la Bislist de sa spé ; spé Off Spec
-- choisie si c'est sa réaction) : texte coloré « +12.5 » / « -3 », nil sans poids ou sans objets équipés envoyés
function X.epText(p, cls, rx, link)
    local W = ns.db.bisEP
    if not (W and cls and link and rx.eq) then return nil end
    local s = rx.k == "os" and rx.spec or X.specName(p)
    local w = s and W[cls .. ":" .. s]
    if not w then for _, sp in ipairs(ns.SPECS[cls] or {}) do w = w or W[cls .. ":" .. sp[1]] end end
    if not (w and next(w)) then return nil end
    local function ep(l)
        if not l or l == "" then return 0 end
        local e = 0
        for k, v in pairs(X.stats(l) or {}) do e = e + (tonumber(w[k]) or 0) * v end
        return e
    end
    local base
    if X.equipLoc(link) == "INVTYPE_2HWEAPON" then base = ep(rx.eq[1]) + ep(rx.eq[2])
    else for _, l in ipairs(rx.eq) do local e = ep(l) if not base or e < base then base = e end end end
    local diff = math.floor((ep(link) - (base or 0)) * 10 + 0.5) / 10
    if diff == 0 then return "|cff9a9aa2±0|r" end
    return (diff > 0 and "|cff4cd964+" or "|cffff5a5a-") .. tostring(math.abs(diff)):gsub("%.0$", "") .. "|r"
end

local function setReaction(key, name, r)
    local d = db()
    d.reactions[key] = d.reactions[key] or {}
    local cur = d.reactions[key][name]
    -- jamais effacée par une info vide ; la plus récente gagne
    if r and r.k and (not cur or (r.t or 0) >= (cur.t or 0)) then d.reactions[key][name] = r end
end

onData = function(kind, from, data, sender)
    local d = db()
    if kind == "L" then
        -- liste d'objets du maître du butin : il fait foi pour ses propres sacs
        for key, it in pairs(d.items) do
            if it.owner == from and not data.items[key] and not it.attrib then d.items[key] = nil end
        end
        for key, x in pairs(data.items or {}) do
            if not d.items[key] then d.reactions[key], d.sugg[key], d.rolls[key] = nil, nil, nil end
            local it = d.items[key] or { key = key, owner = from, t = x.t }
            it.link, it.id, it.owner, it.zone, it.boss = x.link, x.id, from, x.zone or it.zone, x.boss or it.boss
            if x.left then it.tradeEnd = time() + x.left end
            if x.attrib then it.attrib = x.attrib end
            if x.traded then it.traded = true end
            local name, _, q, _, _, _, _, _, _, icon = GetItemInfo(x.link or "")
            it.name, it.q, it.icon = name or it.name, q or it.q, icon or it.icon
            d.items[key] = it
        end
    elseif kind == "R" then
        if d.open or isOfficer(from) then setReaction(data.key, from, data.r) end
    elseif kind == "O" then
        -- ouverture des réactions : officiers et Loot Dealer
        if (isOfficer(from) or (d.dealer and first(d.dealer) == first(from))) and (data.t or 0) >= (d.openT or 0) then
            d.open, d.openT = data.open and true or false, data.t or time()
        end
    elseif kind == "WR" then
        -- réaction tirée de la wishlist d'un joueur par le Loot Dealer (ou un officier) ; le joueur la corrige ensuite
        if (isOfficer(from) or (d.dealer and first(d.dealer) == first(from))) and data.key and data.player and data.r then
            setReaction(data.key, data.player, data.r)
        end
    elseif kind == "S" then
        if isOfficer(from) then
            d.sugg[data.key] = d.sugg[data.key] or {}
            local s = d.sugg[data.key][data.player] or {}
            s[from] = data.on and true or nil
            d.sugg[data.key][data.player] = next(s) and s or nil
            if data.color then d.colors[from] = data.color end
        end
    elseif kind == "C" then
        if isOfficer(from) then for n, c in pairs(data.colors or {}) do d.colors[n] = c end end
    elseif kind == "RQ" and from == me() then
        -- ma propre demande (renvoyée par le chat addon) : déjà faite par ns:LootRoll
    elseif kind == "RR" and from == me() then
        -- mes propres résultats (maître du butin) : déjà rangés par onSystem
    elseif kind == "RQ" then
        -- demande de jet : jets « attendus » (rouge) ; popup si je suis dans la liste
        d.rolls[data.key] = d.rolls[data.key] or {}
        d.rollAll = d.rollAll or {}
        d.rollAll[data.key] = {}
        for _, p in ipairs(data.players or {}) do
            if not d.rolls[data.key][p] then d.rolls[data.key][p] = -1 end
            if p == me() then ns:LootRollPopup(data.key, (data.sr or {})[p]) end
        end
    elseif kind == "RR" then
        d.rolls[data.key] = d.rolls[data.key] or {}
        -- plusieurs jets (SoftRes réservé plusieurs fois) : le meilleur compte, chacun gardé pour la colonne SR
        if (data.roll or 0) > 0 then
            d.rollAll = d.rollAll or {}
            d.rollAll[data.key] = d.rollAll[data.key] or {}
            if data.reset then d.rolls[data.key][data.player], d.rollAll[data.key][data.player] = nil, nil end
            d.rolls[data.key][data.player] = math.max(data.roll, d.rolls[data.key][data.player] or 0)
            local l = d.rollAll[data.key][data.player] or {}
            l[#l + 1] = data.roll
            d.rollAll[data.key][data.player] = l
        end
    elseif kind == "RM" then
        for _, p in ipairs(data.players or {}) do
            if d.reactions[data.key] then d.reactions[data.key][p] = nil end
            if d.rolls[data.key] then d.rolls[data.key][p] = nil end
            if d.sugg[data.key] then d.sugg[data.key][p] = nil end
        end
    elseif kind == "A" then
        local it = d.items[data.key]
        if it then it.attrib, it.attribT = data.player, data.t end
        -- les officiers rangent l'attribution dans leur base (l'exe enlève les doublons)
        if iAmOfficer() and data.record then
            local h, dup = ns.db.lootHistory, false
            -- déjà rangée : attribution changée (nouveau joueur)
            for _, r in ipairs(h) do if r.key == data.record.key then dup = true r.to, r.kind = data.record.to, data.record.kind break end end
            if not dup then h[#h + 1] = data.record end
        end
    elseif kind == "X" then
        -- objet retiré de la liste par un officier (le porteur ne le remet plus)
        if isOfficer(from) then
            local it = d.items[data.key]
            if it and it.owner == me() then d.removed = d.removed or {} d.removed[data.key] = true end
            d.items[data.key] = nil
        end
    elseif kind == "T" then
        local it = d.items[data.key]
        if it then it.traded, it.tradedT = true, time() end
        if ns.LootTradeFill then ns:LootTradeFill() end
    elseif kind == "V" then
        if isOfficer(from) and (data.t or 0) >= (d.showAllT or 0) then d.showAll, d.showAllT = data.on and true or false, data.t or time() end
    elseif kind == "LD" then
        -- Loot Dealer choisi par un officier
        if isOfficer(from) and (data.t or 0) >= (d.dealerT or 0) then d.dealer, d.dealerT = data.name, data.t or time() end
    elseif kind == "G" then
        -- le Loot Dealer demande un de mes objets : à lui donner (/tlc trade, déposé tout seul à l'échange)
        local it = d.items[data.key]
        if it and it.owner == me() and not it.attrib and not it.traded and d.dealer and first(d.dealer) == first(from) then
            it.give = from
            print("|cff6f7cffGuildTool|r: " .. L("{0} (Loot Dealer) asks for {1}: trade it to them (/tlc trade).", from, it.link or it.name or "?"))
            ns:LootTradeShow()
        end
    elseif kind == "PUSH" then
        if from ~= me() then
            ns:LootPushPopup(from)
            if sender then send("PA", { n = data.n }, sender) end
        end
    elseif kind == "PA" then
        if lc.pushAck then lc.pushAck.got[from] = data.n or 0 end
    elseif kind == "UP" then
        -- un joueur arrive (client prêt) : les officiers et les porteurs d'objets lui renvoient l'état connu
        if from ~= me() and sender and (iAmOfficer() or next(d.items)) then ns:LootSendState(sender) end
        if from ~= me() then ns:LootScan(true) end
    elseif kind == "ST" then
        -- état envoyé par un officier : ajoute ce qui manque / plus récent, n'efface rien
        for key, x in pairs(data.items or {}) do
            if not d.items[key] then d.items[key] = x end
            local it = d.items[key]
            if x.attrib then it.attrib = x.attrib end
            if x.traded then it.traded = true end
        end
        for key, list in pairs(data.reactions or {}) do for n, r in pairs(list) do setReaction(key, n, r) end end
        for key, list in pairs(data.sugg or {}) do
            d.sugg[key] = d.sugg[key] or {}
            for p, offs in pairs(list) do d.sugg[key][p] = d.sugg[key][p] or {} for o in pairs(offs) do d.sugg[key][p][o] = true end end
        end
        for key, list in pairs(data.rolls or {}) do
            d.rolls[key] = d.rolls[key] or {}
            for p, v in pairs(list) do if v and v > (d.rolls[key][p] or -2) then d.rolls[key][p] = v end end
        end
        if (data.openT or 0) > (d.openT or 0) then d.open, d.openT = data.open, data.openT end
        if (data.showAllT or 0) > (d.showAllT or 0) then d.showAll, d.showAllT = data.showAll, data.showAllT end
        if (data.dealerT or 0) > (d.dealerT or 0) then d.dealer, d.dealerT = data.dealer, data.dealerT end
        for n, c in pairs(data.colors or {}) do d.colors[n] = d.colors[n] or c end
    end
    -- réactions ouvertes / posées depuis les wishlists : mon roll de wishlist envoyé (fenêtre ouverte ou non)
    if (kind == "O" or kind == "WR" or kind == "ST") and X.autoWish then X.autoWish() end
    if lc.win and lc.win:IsShown() then ns:LootRefresh() end
end

function ns:LootSendState(target)
    local d = db()
    local items = {}
    for key, it in pairs(d.items) do
        items[key] = { key = key, owner = it.owner, link = it.link, id = it.id, t = it.t, attrib = it.attrib, traded = it.traded,
                       name = it.name, q = it.q, icon = it.icon, boss = it.boss, tradeEnd = it.tradeEnd }
    end
    send("ST", { items = items, reactions = d.reactions, sugg = d.sugg, rolls = d.rolls, open = d.open, openT = d.openT, colors = d.colors,
                showAll = d.showAll, showAllT = d.showAllT, dealer = d.dealer, dealerT = d.dealerT }, target)
end

---------------------------------------------------------------------------
-- Actions
---------------------------------------------------------------------------
local myNote = {}
-- roll de ma wishlist pour un objet (perso joué), sinon nil
local function myWish(id)
    if not (id and ns.WishOf) then return nil end
    for _, x in ipairs(ns:WishOf(me())) do if tonumber(x.id) == tonumber(id) then return x.k end end
end
-- (Loot Dealer, sinon un officier s'il n'y en a pas) réactions ouvertes : réaction de chaque joueur du groupe tirée de
-- sa wishlist (base de la guilde), envoyée au raid (« WR », marquée w) ; une fois par objet et par joueur
local dealerWish = {}
function X.dealerWishFill()
    local d = db()
    if not (d.open and (X.iAmDealer() or (not X.dealer() and iAmOfficer()))) then return end
    local inGroup = {}
    for i = 1, GetNumGroupMembers() do
        local unit = IsInRaid() and ("raid" .. i) or (i == 1 and "player" or "party" .. (i - 1))
        local n = UnitName(unit)
        if n then inGroup[first(n)] = select(2, UnitClass(unit)) end
    end
    for name in pairs(ns.db.wishlistsImp or {}) do
        local cls = inGroup[first(name)]
        if cls and first(name) ~= first(me()) then
            for key, it in pairs(d.items) do
                if not it.attrib and not it.traded and not dealerWish[key .. "|" .. name] and not (d.reactions[key] and d.reactions[key][name]) then
                    for _, x in ipairs(ns:WishOf(name)) do
                        if tonumber(x.id) == tonumber(it.id) then
                            dealerWish[key .. "|" .. name] = true
                            local r = { k = x.k, t = time(), c = cls, w = true }
                            setReaction(key, name, r)
                            send("WR", { key = key, player = name, r = r })
                            break
                        end
                    end
                end
            end
        end
    end
end
-- wishlist : mon roll posé tout seul (une fois par objet) quand les réactions sont ouvertes et que je n'ai pas réagi ;
-- réaction posée par le Loot Dealer depuis ma wishlist (w) : remplacée par la mienne (son copie a pu être en retard),
-- retirée si l'objet n'est plus dans ma wishlist
local wishDone = {}
local function autoWishReact()
    local d = db()
    if not d.open then return end
    X.dealerWishFill()
    for key, it in pairs(d.items or {}) do
        local cur = d.reactions[key] and d.reactions[key][me()]
        if not it.attrib and ((not wishDone[key] and not cur) or (cur and cur.w)) then
            local k = myWish(it.id)
            if k or (cur and cur.w) then
                wishDone[key] = true
                local r = { k = k or "none", note = myNote[key], t = math.max(time(), (cur and cur.t or 0) + 1),
                            c = select(2, UnitClass("player")), eq = X.myEquipped(it.link) }
                setReaction(key, me(), r)
                send("R", { key = key, r = r })
            end
        end
    end
end
X.autoWish = autoWishReact
function ns:LootReact(key, kind, spec)
    local d = db()
    if not d.open then return end
    local cur = d.reactions[key] and d.reactions[key][me()]
    if cur and cur.k == kind and (kind ~= "os" or cur.spec == spec) then kind, spec = "none", nil end
    local r = { k = kind, spec = spec, note = myNote[key] or (d.reactions[key] and d.reactions[key][me()] and d.reactions[key][me()].note), t = time(),
                c = select(2, UnitClass("player")), eq = X.myEquipped(d.items[key] and d.items[key].link) }
    setReaction(key, me(), r)
    send("R", { key = key, r = r })
    self:LootRefresh()
end
function ns:LootSetNote(key, note)
    myNote[key] = note
    local r = db().reactions[key] and db().reactions[key][me()]
    if r and r.note ~= note then
        local copy = {}
        for k, v in pairs(r) do copy[k] = v end
        copy.note, copy.t = note, time()
        setReaction(key, me(), copy)
        send("R", { key = key, r = copy })
    end
end
function ns:LootSetOpen(on)
    if not (iAmOfficer() or X.iAmDealer()) then return end
    local d = db()
    d.open, d.openT = on, time()
    send("O", { open = on, t = d.openT })
    -- Loot Dealer : réactions des joueurs tirées de leurs wishlists tout de suite
    if on then autoWishReact() end
    self:LootRefresh()
end
local function myColor()
    local d = db()
    if d.colors[me()] then return d.colors[me()] end
    local used = {}
    for _, c in pairs(d.colors) do used[c] = true end
    local free = {}
    for i = 1, #OFF_COLORS do if not used[i] then free[#free + 1] = i end end
    d.colors[me()] = #free > 0 and free[math.random(#free)] or math.random(#OFF_COLORS)
    return d.colors[me()]
end
-- (officiers) Loot Dealer : joueur du raid tenu pour maître du butin (nil = aucun)
function ns:LootSetDealer(name)
    if not iAmOfficer() then return end
    local d = db()
    d.dealer, d.dealerT = name, time()
    send("LD", { name = name, t = d.dealerT })
    self:LootRefresh()
end
-- menu du Loot Dealer : joueurs du groupe (couleur de classe), « None » en tête
function ns:LootDealerItems()
    local items, cur, names = {}, X.dealer(), {}
    items[1] = { text = L("None"), checked = cur == nil, func = function() ns:LootSetDealer(nil) end }
    for i = 1, GetNumGroupMembers() do
        local unit = IsInRaid() and ("raid" .. i) or (i == 1 and "player" or "party" .. (i - 1))
        local n = UnitName(unit)
        if n then names[#names + 1] = { n = n, c = select(2, UnitClass(unit)) } end
    end
    if #names == 0 then names[1] = { n = UnitName("player"), c = select(2, UnitClass("player")) } end
    table.sort(names, function(a, b) return a.n < b.n end)
    for _, x in ipairs(names) do
        items[#items + 1] = { text = x.n, checked = cur ~= nil and first(cur) == first(x.n), color = ns.ClassColor(x.c),
                              func = function() ns:LootSetDealer(x.n) end }
    end
    return items
end
-- (Loot Dealer) demande au porteur de lui donner l'objet : ajouté à /tlc trade (à recevoir), retiré de sa liste
function ns:LootAskGive(key)
    local it = db().items[key]
    if not (it and X.iAmDealer()) then return end
    it.ask = true
    send("G", { key = key }, first(it.owner))
    self:LootTradeShow()
    self:LootRefresh()
end
-- échange avec un joueur du groupe (à portée)
function ns:LootTradeWith(name)
    local _, unit = classOf(name)
    if unit and unit ~= "player" and CheckInteractDistance(unit, 2) then InitiateTrade(unit)
    elseif unit then UIErrorsFrame:AddMessage(L("{0} is too far to trade.", name), 1, 0.42, 0.42) end
end
function ns:LootSuggest(key, player)
    if not iAmOfficer() then return end
    local d = db()
    d.sugg[key] = d.sugg[key] or {}
    local s = d.sugg[key][player] or {}
    local on = not s[me()]
    s[me()] = on or nil
    d.sugg[key][player] = next(s) and s or nil
    send("S", { key = key, player = player, on = on, color = myColor() })
    self:LootRefresh()
end
function ns:LootRoll(key, players)
    local d = db()
    d.rolls[key] = d.rolls[key] or {}
    d.rollAll = d.rollAll or {}
    d.rollAll[key] = {}
    for _, p in ipairs(players) do d.rolls[key][p] = -1 end
    -- SoftRes : un jet par réservation de l'objet (réservé 3 fois = 3 jets, le meilleur compte)
    local it, sr = d.items[key], {}
    lc.rollKey, lc.rollWait = key, {}
    for _, p in ipairs(players) do
        local n = ns:SRCount(it and it.id, p)
        if n > 1 then sr[p] = n end
        lc.rollWait[first(p)] = { p = p, left = n }
    end
    send("RQ", { key = key, players = players, sr = next(sr) and sr or nil })
    for _, p in ipairs(players) do if p == me() then self:LootRollPopup(key, sr[p]) end end
    self:LootRefresh()
end
-- Add rolls : jets 1-100 tirés ici à la place des joueurs (un par réservation SoftRes), envoyés au raid comme des jets
-- normaux et annoncés dans le chat du raid (transparence)
function ns:LootAddRolls(key, players)
    local d = db()
    local it = d.items[key]
    d.rolls[key] = d.rolls[key] or {}
    d.rollAll = d.rollAll or {}
    d.rollAll[key] = {}
    local parts = {}
    for _, p in ipairs(players) do
        local list = {}
        for _ = 1, ns:SRCount(it and it.id, p) do list[#list + 1] = math.random(1, 100) end
        local best = 0
        -- 1er jet : « reset » (les jets précédents de ce joueur sur l'objet sont oubliés chez les autres)
        for i, v in ipairs(list) do if v > best then best = v end send("RR", { key = key, player = p, roll = v, reset = i == 1 or nil }) end
        d.rolls[key][p] = best
        d.rollAll[key][p] = list
        parts[#parts + 1] = p .. " " .. table.concat(list, "/")
    end
    if lc.rollKey == key and lc.rollWait then for _, p in ipairs(players) do lc.rollWait[first(p)] = nil end end
    local ch = channel()
    if ch and #parts > 0 then SendChatMessage(("%s rolls (1-100): %s"):format(it and (it.link or it.name) or "?", table.concat(parts, ", ")), ch) end
    self:LootRefresh()
end
function ns:LootRemove(key, players)
    onData("RM", me(), { key = key, players = players })
    send("RM", { key = key, players = players })
end
-- attribution : annonce au raid, base des attributions, échange tenté tout de suite
function ns:LootAttrib(key, player, kind)
    local d = db()
    local it
    local re
    for _, x in ipairs(groupOf(key) or {}) do
        if x.owner == me() and not x.attrib then it = x end
    end
    if not it then
        for _, x in ipairs(groupOf(key) or {}) do
            if x.owner == me() and x.attrib and x.attrib ~= player
               and (not re or (re.traded and not x.traded) or ((x.attribT or 0) > (re.attribT or 0) and not x.traded == not re.traded)) then re = x end
        end
        it = re
    end
    if not it then return end
    local r = d.reactions[key] and d.reactions[key][player]
    if kind then r = { k = kind } end
    it.vendor = kind == "vendor" or nil
    local same = {}
    for n, x in pairs(d.reactions[key] or {}) do if r and x.k == r.k and n ~= player then same[#same + 1] = n end end
    table.sort(same)
    local record = { key = it.key, id = it.id, name = it.name, link = it.link, tt = it.tt, t = time(), to = player, by = me(),
                     kind = r and r.k, spec = r and r.k == "os" and r.spec or nil, same = same, zone = it.zone, boss = it.boss, raid = it.raid }
    it.attrib, it.attribT = player, record.t
    local h, dup = ns.db.lootHistory, false
    for _, x in ipairs(h) do if x.key == it.key then dup = true x.to, x.kind, x.same = player, record.kind, same break end end
    if not dup then h[#h + 1] = record end
    -- attribution changée : la base de la guilde (exe) suit la modification
    if re then
        ns.db.lootEdits = ns.db.lootEdits or {}
        ns.db.lootEdits["g:" .. tostring(it.key)] = { to = player, t = time() }
        if lc.reopen then lc.reopen[key] = nil end
    end
    send("A", { key = it.key, player = player, t = record.t, record = record })
    local ch = channel()
    if ch then SendChatMessage(("%s -> %s%s"):format(it.link or it.name or "?", player, r and KIND_LABEL[r.k] and (" (" .. KIND_LABEL[r.k] .. ")") or ""), ch) end
    lastSig = nil
    self:LootScan()
    if not it.vendor then self:LootTrade(it.key) self:LootTradeShow() end
end
-- échange : ouvre la fenêtre de trade avec le joueur ; l'objet y est déposé dès qu'elle s'ouvre
function ns:LootTrade(key)
    local it
    for _, x in ipairs(groupOf(key) or {}) do
        if x.owner == me() and x.attrib and not x.traded and not x.vendor then it = x break end
    end
    if not it then return end
    local _, unit = classOf(it.attrib)
    if unit and unit ~= "player" and CheckInteractDistance(unit, 2) then InitiateTrade(unit)
    elseif unit then UIErrorsFrame:AddMessage(L("{0} is too far to trade.", it.attrib), 1, 0.42, 0.42) end
end
local function fillTrade()
    local target = first(UnitName("NPC"))
    if not target then return end
    local d, n = db(), 0
    for key, it in pairs(d.items) do
        local to = it.attrib or it.give
        if it.owner == me() and to and not it.traded and first(to) == target then
            for bag = 0, NUM_BAG_SLOTS or 4 do
                for slot = 1, bagSlots(bag) do
                    local link = bagLink(bag, slot)
                    if link and itemGuid(bag, slot, link) == key then
                        n = n + 1
                        for i = 1, (MAX_TRADABLE_ITEMS or 6) do
                            if not GetTradePlayerItemLink(i) then
                                ClearCursor()
                                local pick = C_Container and C_Container.PickupContainerItem or PickupContainerItem
                                pick(bag, slot)
                                ClickTradeButton(i)
                                break
                            end
                        end
                    end
                end
            end
        end
    end
end

---------------------------------------------------------------------------
-- Jets : popup pour les joueurs demandés ; le maître du butin lit les résultats
---------------------------------------------------------------------------
-- n : nombre de jets permis (objet réservé n fois en SoftRes) ; le bouton Roll reste jusqu'au dernier
function ns:LootRollPopup(key, n)
    local it = db().items[key]
    local p = lc.popup
    if not p then
        p = CreateFrame("Frame", nil, UIParent)
        p:SetSize(320, 96)
        p:SetPoint("TOP", 0, -180)
        p:SetFrameStrata("DIALOG")
        ns.Fill(p, C.bg, 0.97)
        ns.Border(p, C.hl)
        p.icon = p:CreateTexture(nil, "ARTWORK")
        p.icon:SetSize(36, 36)
        p.icon:SetPoint("TOPLEFT", 12, -12)
        p.name = ns.Text(p, 13, 700)
        p.name:SetPoint("LEFT", p.icon, "RIGHT", 10, 0)
        p.name:SetPoint("RIGHT", -12, 0)
        p.roll = ns.Button(p, L("Roll"), 140, 26, true)
        p.roll:SetPoint("BOTTOMLEFT", 12, 10)
        p.roll:SetScript("OnClick", function()
            RandomRoll(1, 100)
            p.left = (p.left or 1) - 1
            if p.left <= 0 then p:Hide() else p.roll.label:SetText(L("Roll") .. " (" .. p.left .. ")") end
        end)
        p.pass = ns.Button(p, L("Pass"), 140, 26)
        p.pass:SetPoint("BOTTOMRIGHT", -12, 10)
        p.pass:SetScript("OnClick", function() p:Hide() end)
        lc.popup = p
    end
    if PixelUtil then
        PixelUtil.SetSize(p, 320, 96)
        PixelUtil.SetPoint(p, "TOP", UIParent, "TOP", 0, -180)
    end
    ns.PixelEdges(p)
    p.icon:SetTexture(it and it.icon or 134400)
    ns.SetFont(p.name, 13, 700)
    p.name:SetText(it and (it.link or it.name) or "?")
    p.left = math.max(1, tonumber(n) or 1)
    p.roll.label:SetText(L("Roll") .. (p.left > 1 and (" (" .. p.left .. ")") or ""))
    p:Show()
end
local ROLL_PAT = RANDOM_ROLL_RESULT and ("^" .. RANDOM_ROLL_RESULT:gsub("([%(%)%.%-])", "%%%1"):gsub("%%s", "(.+)"):gsub("%%d", "(%%d+)") .. "$")
local function onSystem(msg)
    if not (ROLL_PAT and lc.rollKey and lc.rollWait) then return end
    local who, roll, lo, hi = msg:match(ROLL_PAT)
    roll, lo, hi = tonumber(roll), tonumber(lo), tonumber(hi)
    if not who or lo ~= 1 or hi ~= 100 then return end
    local w = lc.rollWait[first(who)]
    if not w then return end
    -- jets attendus de ce joueur (un par réservation SoftRes)
    w.left = (w.left or 1) - 1
    if w.left <= 0 then lc.rollWait[first(who)] = nil end
    local full = w.p
    local d = db()
    d.rolls[lc.rollKey] = d.rolls[lc.rollKey] or {}
    local cur = d.rolls[lc.rollKey][full] or 0
    d.rolls[lc.rollKey][full] = math.max(roll, cur)
    d.rollAll = d.rollAll or {}
    d.rollAll[lc.rollKey] = d.rollAll[lc.rollKey] or {}
    local l = d.rollAll[lc.rollKey][full] or {}
    l[#l + 1] = roll
    d.rollAll[lc.rollKey][full] = l
    send("RR", { key = lc.rollKey, player = full, roll = roll })
    if lc.win and lc.win:IsShown() then ns:LootRefresh() end
end

---------------------------------------------------------------------------
-- Fenêtre
---------------------------------------------------------------------------
local function countDropped(id)
    local n = 0
    -- base de la guilde (exe) + mes attributions arrivées depuis le dernier Import
    for _, r in ipairs(ns.db.lootHistory or {}) do if r.id == id and (r.t or 0) > (ns.db.lootT or 0) then n = n + 1 end end
    return n + ((ns.db.lootCounts or {})[id] or (ns.db.lootCounts or {})[tostring(id)] or 0)
end

local function createWindow()
    local f = CreateFrame("Frame", "GuildToolLootFrame", UIParent)
    f:SetSize(W, ns.db.ui.lootH or H)
    f:SetFrameStrata("HIGH")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:SetScale(ns.db.ui.lootScale or ns.db.ui.scale or 1)
    local p = ns.db.ui.lootPoint
    if p then f:SetPoint(p[1], UIParent, p[1], p[2], p[3]) else f:SetPoint("CENTER") end
    ns.Fill(f, C.bg)
    ns.Border(f, { 0.204, 0.212, 0.243 })
    tinsert(UISpecialFrames, "GuildToolLootFrame")
    -- fond propre à /tlc (media/bg_tlc, image 1643 x 957) ; réglages propres (bouton Settings)
    local bg = f:CreateTexture(nil, "BACKGROUND", nil, 1)
    bg:SetPoint("TOPLEFT", 1, -1)
    bg:SetPoint("BOTTOMRIGHT", -1, 1)
    bg:SetTexture(MEDIA .. "bg_tlc")
    -- découpée aux proportions de la fenêtre (pas étirée), coin bas-droit gardé
    function f.cropBg()
        local src, win = 1643 / 957, (f:GetWidth() - 2) / (f:GetHeight() - 2)
        if win < src then BG_CROP[1], BG_CROP[2], BG_CROP[3], BG_CROP[4] = 1 - win / src, 1, 0, 1
        else BG_CROP[1], BG_CROP[2], BG_CROP[3], BG_CROP[4] = 0, 1, 1 - src / win, 1 end
        bg:SetTexCoord(BG_CROP[1], BG_CROP[2], BG_CROP[3], BG_CROP[4])
    end
    f.bgImg = bg
    f.cropBg()

    -- barre du haut : titre, croix (déplacement)
    local top = CreateFrame("Frame", nil, f)
    top:SetPoint("TOPLEFT", 1, -1)
    top:SetPoint("TOPRIGHT", -1, -1)
    top:SetHeight(ns.TOP_H)
    f.topFill = ns.Fill(top, C.head, 0)   -- transparente : le fond de la fenêtre passe dessous
    top:EnableMouse(true)
    top:RegisterForDrag("LeftButton")
    top:SetScript("OnDragStart", function() if not lc.full then f:StartMoving() end end)
    -- double-clic : plein écran (même échelle : textes et icônes gardent leur taille) / taille d'avant
    top:SetScript("OnMouseDown", function(self, btn)
        if btn ~= "LeftButton" then return end
        local t = GetTime()
        if t - (self.lastClick or 0) < 0.35 then self.lastClick = 0 ns:LootFullscreen() else self.lastClick = t end
    end)
    top:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        local point, _, _, x, y = f:GetPoint()
        ns.db.ui.lootPoint = { point, x, y }
    end)
    local tl = ns.Tex(top, C.border, "ARTWORK")
    tl:SetPoint("BOTTOMLEFT") tl:SetPoint("BOTTOMRIGHT") tl:SetHeight(1)
    f.title = ns.Text(top, 15, 700, C.white)
    f.title:SetPoint("LEFT", 14, 0)
    local close = ns.IconButton(top, "×", 24)
    close:SetPoint("RIGHT", -10, 0)
    close:SetScript("OnClick", function() f:Hide() end)

    -- barre d'indicateur : Scan, ouverture des réactions (officiers), couleurs des officiers
    local sub = CreateFrame("Frame", nil, f)
    sub:SetPoint("TOPLEFT", top, "BOTTOMLEFT")
    sub:SetPoint("TOPRIGHT", top, "BOTTOMRIGHT")
    sub:SetHeight(ns.TABS_H)
    f.subFill = ns.Fill(sub, C.head)   -- même barre que la fenêtre principale
    local sl = ns.Tex(sub, C.border, "ARTWORK")
    sl:SetPoint("BOTTOMLEFT") sl:SetPoint("BOTTOMRIGHT") sl:SetHeight(1)
    f.scan = ns.Button(sub, L("Scan"), 80, 24)
    f.scan:SetPoint("LEFT", 10, 0)
    f.scan:SetScript("OnClick", function() lastSig = nil ns:LootScan(true) end)
    -- ajout à la main d'objets des sacs (même sans la ligne bleue) : liste triée, plusieurs choix, « Add N »
    f.add = CreateFrame("Button", nil, sub)
    f.add:SetSize(110, 24)
    -- PUSH : envoie la liste au raid, chaque joueur reçoit une fenêtre pour l'ouvrir
    f.push = ns.Button(sub, "PUSH", 70, 24)
    f.push:SetPoint("LEFT", f.scan, "RIGHT", 8, 0)
    f.push:SetScript("OnClick", function() ns:LootPush() end)
    f.add:SetPoint("LEFT", f.push, "RIGHT", 8, 0)
    ns.Fill(f.add, C.input)
    ns.Border(f.add, C.border)
    f.add.label = ns.Text(f.add, 11.5, 600)
    f.add.label:SetPoint("CENTER")
    f.add:SetScript("OnEnter", function(self) if lc.pick and next(lc.pick) then self.bg:SetColorTexture(0.2, 0.55, 0.3) end ns.SetBorderColor(self, C.hl) end)
    f.add:SetScript("OnLeave", function() ns:LootAddButton() end)
    f.add:SetScript("OnClick", function()
        if lc.pick and next(lc.pick) then ns:LootAddPicked() else ns:LootBagList() end
    end)
    -- Loot Dealer (officiers / admins / GM) : joueur du raid tenu pour maître du butin ; les autres le voient seulement
    f.dealer = ns.Dropdown(sub, L("Loot Dealer"), 170, function() return ns:LootDealerItems() end)
    f.dealer:SetHeight(24)
    f.dealer:SetPoint("LEFT", f.add, "RIGHT", 8, 0)
    f.dealer:SetScript("OnClick", function(self) if iAmOfficer() then ns:OpenMenu(self, ns:LootDealerItems()) end end)
    f.dealer:HookScript("OnEnter", function(self)
        ns.TipOwner(self)
        GameTooltip:SetText(L("Loot Dealer"), 1, 1, 1)
        GameTooltip:AddLine(L("Counts as the master looter: holds the loot and attributes it. The tradeable loot of the other players is only listed for him."), 0.8, 0.8, 0.8, true)
        if not iAmOfficer() then GameTooltip:AddLine(L("Only the officers can change it."), 1, 0.42, 0.42, true) end
        GameTooltip:Show()
    end)
    f.dealer:HookScript("OnLeave", function() GameTooltip:Hide() end)
    -- nombre d'objets : dans la barre du titre, à droite du titre (la barre d'indicateur est pleine)
    f.info = ns.Text(top, 11, 500, C.mute)
    f.info:SetPoint("LEFT", f.title, "RIGHT", 14, 0)
    f.info:SetWordWrap(false)
    -- interrupteur (officiers) : réactions ouvertes / fermées (même interrupteur que les Settings)
    f.sw = CreateFrame("Button", nil, sub)
    f.sw:SetSize(170, 24)
    f.sw:SetPoint("RIGHT", -110, 0)
    ns.Fill(f.sw, C.input)
    ns.Border(f.sw, C.border)
    f.sw.track = ns.Tex(f.sw, C.border, "ARTWORK")
    f.sw.track:SetSize(30, 16)
    f.sw.track:SetPoint("LEFT", 8, 0)
    f.sw.knob = ns.Tex(f.sw, C.mute, "OVERLAY")
    f.sw.knob:SetSize(12, 12)
    f.sw.label = ns.Text(f.sw, 11, 600)
    f.sw.label:SetPoint("LEFT", f.sw.track, "RIGHT", 8, 0)
    f.sw:SetScript("OnClick", function() ns:LootSetOpen(not db().open) end)
    -- SoftRes (à gauche de « Reactions open ») : interrupteur (colonne SR) et case où coller le CSV de softres.it ;
    -- la case garde sa taille (texte coupé), le CSV est lu au collage ; heure d'export en gris au-dessus
    f.srBox = CreateFrame("EditBox", nil, sub)
    f.srBox:SetSize(110, 22)
    f.srBox:SetPoint("RIGHT", f.sw, "LEFT", -8, 0)
    f.srBox:SetMultiLine(true)
    f.srBox:SetAutoFocus(false)
    f.srBox:SetMaxLetters(0)
    f.srBox:SetFont(ns.FONT[400], 10, "")
    f.srBox:SetTextInsets(5, 5, 4, 0)
    f.srBox:SetClipsChildren(true)
    ns.Fill(f.srBox, C.input)
    ns.Border(f.srBox, C.border)
    f.srBox.ph = ns.Text(f.srBox, 10, 400, C.mute)
    f.srBox.ph:SetPoint("LEFT", 6, 0)
    f.srBox.ph:SetPoint("RIGHT", -4, 0)
    f.srBox.ph:SetWordWrap(false)
    f.srBox:SetScript("OnEscapePressed", function(self) self:SetText("") self:ClearFocus() end)
    f.srBox:SetScript("OnEditFocusLost", function(self)
        -- collage en cours de lecture : le texte reste jusqu'à la fin
        if GetTime() - (self.pasteT or 0) > 0.3 then self:SetText("") end
        ns:LootSoftResBar()
    end)
    f.srBox:SetScript("OnTextChanged", function(self, user)
        self.ph:SetShown(self:GetText() == "")
        if not user then return end
        -- collage : lu une fois tout le texte arrivé
        self.pasteT = GetTime()
        C_Timer.After(0.2, function()
            if GetTime() - (self.pasteT or 0) < 0.19 then return end
            local text = self:GetText()
            if text == "" then return end
            if ns:SRSetCSV(text) then
                self:SetText("") self:ClearFocus()
            else
                UIErrorsFrame:AddMessage(L("Not a softres.it CSV export."), 1, 0.42, 0.42)
            end
            ns:LootRefresh()
        end)
    end)
    f.srBox:SetScript("OnEnter", function(self)
        ns.SetBorderColor(self, C.hl)
        ns.TipOwner(self)
        GameTooltip:SetText(L("Paste the CSV export of softres.it here (Ctrl+V)."), 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    f.srBox:SetScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) GameTooltip:Hide() end)
    f.sr = CreateFrame("Button", nil, sub)
    f.sr:SetSize(96, 24)
    f.sr:SetPoint("RIGHT", f.srBox, "LEFT", -6, 0)
    ns.Fill(f.sr, C.input)
    ns.Border(f.sr, C.border)
    f.sr.track = ns.Tex(f.sr, C.border, "ARTWORK")
    f.sr.track:SetSize(30, 16)
    f.sr.track:SetPoint("LEFT", 8, 0)
    f.sr.knob = ns.Tex(f.sr, C.mute, "OVERLAY")
    f.sr.knob:SetSize(12, 12)
    f.sr.label = ns.Text(f.sr, 11, 600)
    f.sr.label:SetPoint("LEFT", f.sr.track, "RIGHT", 8, 0)
    f.sr:SetScript("OnClick", function() ns:SRToggle() ns:LootRefresh() end)
    f.srTime = ns.Text(sub, 9.5, 500, C.mute)
    f.srTime:SetPoint("BOTTOM", f.sr, "TOP", 0, 1)
    f.srTime:SetPoint("LEFT", f.sr, "LEFT", 0, 0)
    f.srTime:SetPoint("RIGHT", f.srBox, "RIGHT", 0, 0)
    f.srTime:SetJustifyH("LEFT")
    f.srTime:SetWordWrap(false)
    -- couleurs des officiers
    f.pal = CreateFrame("Button", nil, sub)
    f.pal:SetSize(90, 24)
    f.pal:SetPoint("RIGHT", -10, 0)
    ns.Fill(f.pal, C.input)
    ns.Border(f.pal, C.border)
    f.pal.icon = f.pal:CreateTexture(nil, "ARTWORK")
    f.pal.icon:SetSize(16, 16)
    f.pal.icon:SetPoint("LEFT", 8, 0)
    f.pal.icon:SetTexture(MEDIA .. "palette")
    f.pal.label = ns.Text(f.pal, 11, 600)
    f.pal.label:SetPoint("LEFT", f.pal.icon, "RIGHT", 6, 0)
    f.pal:SetScript("OnClick", function() ns:LootColorsWindow() end)
    -- survol : bordure de la couleur Highlight (comme « Add item »)
    for _, b in ipairs({ f.scan, f.push, f.sw, f.pal, f.sr }) do
        b:HookScript("OnEnter", function(self) ns.SetBorderColor(self, C.hl) end)
        b:HookScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) end)
    end
    f.push:HookScript("OnEnter", function(self) if ns.LootPushTooltip then ns.LootPushTooltip(self) end end)
    f.push:HookScript("OnLeave", function() GameTooltip:Hide() end)

    -- échelle : Ctrl + molette sur le fond de la fenêtre (coin haut-droit fixe)
    ns.WheelScale(f, function() return ns.db.ui.lootScale or ns.db.ui.scale or 1 end, function(v, pt)
        ns.db.ui.lootScale = v
        if pt then ns.db.ui.lootPoint = pt end
    end)
    f.onCap = function() f.cropBg() ns:LootPlaceStripes() ns:LootRefresh() end
    -- temps restants des objets (ligne bleue) : décompte chaque seconde
    f:SetScript("OnUpdate", function(self, el)
        self.tick = (self.tick or 0) + el
        if self.tick < 1 then return end
        self.tick = 0
        for _, list in ipairs({ self.rows or {}, self.held or {} }) do
            for _, r in ipairs(list) do
                if r:IsShown() then r.timer:SetText(r.tradeEnd and fmtLeft(r.tradeEnd - time()) or "") end
            end
        end
    end)

    -- Settings (apparence de cette fenêtre) : bouton carré à icône comme dans l'appli
    f.gear = ns.IconBox(top, MEDIA .. "gear", "Settings")
    f.gear:SetPoint("RIGHT", close, "LEFT", -10, 0)
    f.gear:SetScript("OnClick", function() ns:LootSettings() end)

    -- en-têtes : une fois en haut, couleur de chaque réponse ; triangle = replier les réactions de tous les objets
    local hd = CreateFrame("Frame", nil, f)
    hd:SetPoint("TOPLEFT", sub, "BOTTOMLEFT", 0, 0)
    hd:SetPoint("TOPRIGHT", sub, "BOTTOMRIGHT", 0, 0)
    hd:SetHeight(HEAD_H)
    f.hdFill = ns.Fill(hd, C.head, 0)
    f.allTri = CreateFrame("Button", nil, hd)
    f.allTri:SetSize(20, 20)
    f.allTri:SetPoint("LEFT", 8, 0)
    f.allTri.t = ns.Triangle(f.allTri, "down", 12)
    f.allTri.t:SetPoint("CENTER")
    f.allTri:SetScript("OnClick", function()
        lc.collapsed = lc.collapsed or {}
        local any = false
        for _, it in pairs(db().items) do if not lc.collapsed[it.key] then any = true break end end
        for _, it in pairs(db().items) do lc.collapsed[it.key] = any or nil end
        ns:LootRefresh()
    end)
    -- (placées à chaque rafraîchissement : colonne SR en plus selon l'interrupteur SoftRes)
    f.heads, f.hd = {}, hd
    for i = 1, #SR_COLS do f.heads[i] = ns.Text(hd, 10.5, 700) end

    local sf = ns.ScrollArea(f)
    sf:SetPoint("TOPLEFT", hd, "BOTTOMLEFT", 0, -4)
    sf:SetPoint("BOTTOMRIGHT", -2, 4)
    sf.child:SetWidth(W - 10)
    f.scroll = sf
    sf:HookScript("OnVerticalScroll", function() ns:LootUpdateBlur() end)
    -- bandes des colonnes : derrière les cadres des objets, devant l'image de fond
    f.stripes = {}
    for i = 1, #SR_COLS do f.stripes[i] = sf.child:CreateTexture(nil, "BACKGROUND") end
    -- clic ailleurs dans la fenêtre : listes ouvertes refermées
    f.catcher = CreateFrame("Button", nil, f)
    f.catcher:SetAllPoints(f)
    f.catcher:SetFrameLevel(f:GetFrameLevel() + 30)
    f.catcher:SetScript("OnClick", function() ns:LootCloseLists() end)
    f.catcher:Hide()
    f.add:SetFrameLevel(f:GetFrameLevel() + 35)   -- « Add N » reste cliquable, liste ouverte
    f.grow = CreateFrame("Button", nil, f)
    f.grow:SetSize(44, 12)
    f.grow:SetPoint("BOTTOM", 0, 1)
    f.grow:SetFrameLevel(f:GetFrameLevel() + 32)
    for i = 0, 1 do
        local l = ns.Tex(f.grow, C.mute, "OVERLAY")
        l:SetSize(26, 1.5)
        l:SetPoint("CENTER", 0, 2 - i * 4)
        f.grow["l" .. i] = l
    end
    f.grow:SetScript("OnEnter", function(self)
        self.l0:SetColorTexture(1, 1, 1) self.l1:SetColorTexture(1, 1, 1)
        ns.TipOwner(self)
        GameTooltip:SetText(L("Hold and drag: window height"), 1, 1, 1)
        GameTooltip:Show()
    end)
    f.grow:SetScript("OnLeave", function(self)
        self.l0:SetColorTexture(C.mute[1], C.mute[2], C.mute[3]) self.l1:SetColorTexture(C.mute[1], C.mute[2], C.mute[3])
        GameTooltip:Hide()
    end)
    f.grow:SetScript("OnMouseDown", function(self)
        -- ancré en haut à gauche pendant le changement (le haut ne bouge pas)
        local s, ps = f:GetEffectiveScale(), UIParent:GetEffectiveScale()
        local x, y = f:GetLeft(), (f:GetTop() * s - UIParent:GetTop() * ps) / s
        f:ClearAllPoints()
        f:SetPoint("TOPLEFT", UIParent, "TOPLEFT", x, y)
        ns.db.ui.lootPoint = { "TOPLEFT", x, y }
        local _, cy0 = GetCursorPosition()
        local h0 = f:GetHeight()
        self:SetScript("OnUpdate", function()
            if not IsMouseButtonDown("LeftButton") then
                self:SetScript("OnUpdate", nil)
                ns.db.ui.lootH = math.floor(f:GetHeight() + 0.5)
                f.baseH = ns.db.ui.lootH
                ns:LootRefresh()
                return
            end
            local _, cy = GetCursorPosition()
            f:SetHeight(math.max(300, math.min(1400, h0 + (cy0 - cy) / s)))
            f.cropBg()
            ns:LootPlaceStripes()
        end)
    end)
    f.rows = {}
    f.empty = ns.Text(sf.child, 12, 500, C.mute)
    f.empty:SetPoint("TOPLEFT", 14, -14)
    f:Hide()
    lc.win = f
    return f
end

-- plein écran de /tlc : la fenêtre couvre l'écran à la même échelle (rien n'est agrandi) ; à nouveau = taille et
-- place d'avant ; pas de déplacement ni de changement de hauteur en plein écran
function ns:LootFullscreen()
    local f = lc.win
    if not f then return end
    if lc.full then
        local s = lc.full
        lc.full = nil
        f:ClearAllPoints()
        f:SetSize(s.w, s.h)
        f:SetPoint(s.p[1], UIParent, s.p[3], s.p[4], s.p[5])
    else
        local p1, _, p3, x, y = f:GetPoint()
        lc.full = { w = f:GetWidth(), h = f:GetHeight(), p = { p1, nil, p3, x, y } }
        local k = f:GetScale()
        f:ClearAllPoints()
        f:SetSize(UIParent:GetWidth() / k, UIParent:GetHeight() / k)
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
    f.scroll.child:SetWidth(f:GetWidth() - 10)
    f.grow:SetShown(not lc.full)
    -- plein écran : la hauteur n'est pas capée (elle est déjà celle de l'écran)
    f.noCap = lc.full ~= nil
    f.cropBg()
    self:LootRefresh()
end

-- bouton plat réutilisé dans les lignes
local function flatButton(parent, w, h)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    ns.Fill(b, C.input)
    ns.Border(b, C.border)
    b.label = ns.Text(b, 11, 600)
    b.label:SetPoint("CENTER")
    b:SetScript("OnEnter", function(self) if self:IsEnabled() then ns.SetBorderColor(self, C.hl) end
        if self.tipText then ns.TipOwner(self) GameTooltip:SetText(self.tipText, 1, 1, 1, 1, true) GameTooltip:Show() end end)
    b:SetScript("OnLeave", function(self) ns.SetBorderColor(self, self.on and C.hl or C.border) GameTooltip:Hide() end)
    return b
end

-- nom d'un joueur sous une colonne : jet, note courte / icône de note, sélection, suggestions
local function nameButton(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(COL_W - 6, NAME_H - 2)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b.bg = ns.Fill(b, C.slot, 0)
    b.edges = nil
    ns.Border(b, C.border, 0)
    b.roll = ns.Text(b, 10.5, 700, GOLD)
    b.roll:SetPoint("LEFT", 3, 0)
    b.spec = b:CreateTexture(nil, "ARTWORK")
    b.spec:SetSize(13, 13)
    b.ospec = b:CreateTexture(nil, "ARTWORK")
    b.ospec:SetSize(13, 13)
    b.ospec:SetPoint("RIGHT", -3, 0)
    b.name = ns.Text(b, 11, 600)
    -- note calée à droite de la zone du nom (courte : texte, sinon icône au survol)
    b.note = ns.Text(b, 10, 400, C.mute)
    b.note:SetPoint("RIGHT", -4, 0)
    b.noteIcon = b:CreateTexture(nil, "ARTWORK")
    b.noteIcon:SetSize(11, 11)
    b.noteIcon:SetPoint("RIGHT", -4, 0)
    b.noteIcon:SetTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Up")
    -- différence d'EP et objets équipés à la place du loot (infobulle au survol, clics passés au nom)
    b.ep = ns.Text(b, 9.5, 700)
    b.eqIcons = {}
    for i = 1, 2 do
        local e = CreateFrame("Frame", nil, b)
        e:SetSize(13, 13)
        e.tex = e:CreateTexture(nil, "ARTWORK")
        e.tex:SetAllPoints()
        e.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        if e.EnableMouseMotion then e:EnableMouseMotion(true) else e:EnableMouse(true) end
        if e.SetPropagateMouseClicks then e:SetPropagateMouseClicks(true) end
        e:SetScript("OnEnter", function(self)
            if self.link then ns.TipOwner(self) GameTooltip:SetHyperlink(self.link) GameTooltip:Show() end
        end)
        e:SetScript("OnLeave", function() GameTooltip:Hide() end)
        b.eqIcons[i] = e
    end
    b.dots = {}
    for i = 1, 4 do
        local t = b:CreateTexture(nil, "OVERLAY")
        t:SetSize(5, 5)
        t:SetPoint("TOPRIGHT", -2 - (i - 1) * 6, -2)
        b.dots[i] = t
    end
    b:SetScript("OnEnter", function(self)
        if self.fullNote and self.fullNote ~= "" then
            ns.TipOwner(self)
            GameTooltip:SetText(self.player, 1, 1, 1)
            GameTooltip:AddLine(self.fullNote, 0.8, 0.8, 0.8, true)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnClick", function(self, btn)
        local key, player = self.key, self.player
        local isML = ownsGroup(key)
        if btn == "LeftButton" then
            if IsAltKeyDown() and isML then ns:LootAttrib(key, player)
            elseif IsControlKeyDown() and isML then
                -- sélection multiple dans les listes d'un seul objet : un nom d'un autre objet repart de zéro
                lc.sel = lc.sel or {}
                for k2 in pairs(lc.sel) do if k2 ~= key then lc.sel[k2] = nil end end
                lc.sel[key] = lc.sel[key] or {}
                lc.sel[key][player] = not lc.sel[key][player] or nil
                ns:LootRefresh()
            elseif iAmOfficer() then ns:LootSuggest(key, player) end
        elseif isML then
            local sel = {}
            for p in pairs((lc.sel or {})[key] or {}) do sel[#sel + 1] = p end
            if #sel == 0 then sel = { player } end
            table.sort(sel)
            ns:LootPlayersMenu(self, key, sel, player)
        end
    end)
    return b
end

-- Menu du maître du butin pour des joueurs d'un objet : Attrib (un seul joueur), Roll, Add rolls (jets tirés à leur
-- place), Remove, Compare looting ; sel = joueurs (sans doublon), player = joueur cliqué (Attrib)
function ns:LootPlayersMenu(anchor, key, sel, player)
    local n = #sel > 1 and (" (" .. #sel .. ")") or ""
    local done = function() if lc.sel then lc.sel[key] = nil end end
    local items = {}
    player = player or (#sel == 1 and sel[1])
    if player then
        items[#items + 1] = { text = L("Attrib") .. " · " .. player, atlas = "plunderstorm-icon-trophy", iconSize = 24, icon = MEDIA .. "menu_trophy", func = function() ns:LootAttrib(key, player) end }
    end
    items[#items + 1] = { text = L("Roll") .. n, atlas = "lootroll-rollicon-yourolled-need", iconSize = 24, icon = MEDIA .. "menu_dice", func = function() ns:LootRoll(key, sel) done() end }
    items[#items + 1] = { text = L("Add rolls") .. n, icon = MEDIA .. "menu_dice", func = function() ns:LootAddRolls(key, sel) done() end }
    items[#items + 1] = { text = L("Remove") .. n, atlas = "lootroll-toast-icon-pass-up", icon = MEDIA .. "menu_noentry", func = function() ns:LootRemove(key, sel) done() end }
    -- loots de ces persos côte à côte : fenêtre principale, onglet Loots, vue Player
    items[#items + 1] = { text = L("Compare looting") .. n, func = function() ns:LootCompare(sel) end }
    ns:OpenMenu(anchor, items, 200)
end

local function lootRow(parent)
    local r = CreateFrame("Button", nil, parent)
    r:SetHeight(ROW_H)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r.head = CreateFrame("Frame", nil, r)
    r.head:SetPoint("TOPLEFT")
    r.head:SetPoint("TOPRIGHT")
    r.head:SetHeight(ROW_H)
    r.headFill = ns.Fill(r.head, C.panel, 0.92)
    r.blur = r.head:CreateTexture(nil, "BACKGROUND", nil, -7)
    r.blur:SetAllPoints()
    r.blur:SetTexture(MEDIA .. "bg_tlc_blur")
    r.blur:Hide()
    r.pend = r.head:CreateTexture(nil, "BACKGROUND", nil, 3)
    r.pend:SetAllPoints()
    r.pend:Hide()
    ns.Border(r.head, C.border)
    -- triangle : replier / déplier les réactions de cet objet
    r.tri = CreateFrame("Button", nil, r.head)
    r.tri:SetSize(18, 24)
    r.tri:SetPoint("LEFT", 2, 0)
    r.tri.t = ns.Triangle(r.tri, "down", 11)
    r.tri.t:SetPoint("CENTER")
    r.tri:SetScript("OnClick", function()
        if r.attributed then
            lc.reopen = lc.reopen or {}
            lc.reopen[r.key] = not lc.reopen[r.key] or nil
        else
            lc.collapsed = lc.collapsed or {}
            lc.collapsed[r.key] = not lc.collapsed[r.key] or nil
        end
        ns:LootRefresh()
    end)
    -- ×N : déjà attribué N fois dans la guilde ; clic = qui l'a reçu
    r.hist = CreateFrame("Button", nil, r.head)
    r.hist:SetSize(30, 24)
    r.hist:SetPoint("LEFT", 20, 0)
    r.hist.text = ns.Text(r.hist, 11, 700, C.mute)
    r.hist.text:SetPoint("RIGHT", -2, 0)
    r.hist:SetScript("OnEnter", function(self) self.text:SetTextColor(1, 1, 1) end)
    r.hist:SetScript("OnLeave", function(self) self.text:SetTextColor(C.mute[1], C.mute[2], C.mute[3]) end)
    r.hist:SetScript("OnClick", function(self) ns:LootReceivedBy(self, r.key, r.itemId) end)
    r.icon = r.head:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(28, 28)
    r.icon:SetPoint("LEFT", 52, 0)
    r.timer = ns.Text(r.head, 11, 700, BLUE)
    r.timer:SetPoint("RIGHT", r.icon, "LEFT", -5, 0)
    r.iconBtn = CreateFrame("Frame", nil, r.head)
    r.iconBtn:SetAllPoints(r.icon)
    r.iconBtn:EnableMouse(true)
    r.iconBtn:SetScript("OnEnter", function(self)
        if r.link then ns.TipOwner(self) GameTooltip:SetHyperlink(r.link) GameTooltip:Show() end
    end)
    r.iconBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r.name = ns.Text(r.head, 12.5, 700)
    r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
    -- exemplaires du même objet : « X2 » en blanc, 25 % plus grand que le nom
    r.count = ns.Text(r.head, 15.5, 700, C.white)
    r.count:SetPoint("LEFT", r.name, "RIGHT", 8, 0)
    r.owner = ns.Text(r.head, 10, 400, C.mute)
    r.owner:SetPoint("LEFT", r.count, "RIGHT", 8, 0)
    -- réactions + note (à droite)
    r.note = CreateFrame("EditBox", nil, r.head)
    r.note:SetSize(130, 22)
    r.note:SetPoint("RIGHT", -34, 0)
    -- croix tout à droite : objet retiré de la liste
    r.drop = ns.IconButton(r.head, "×", 22, L("Remove from the list"))
    r.drop:SetPoint("RIGHT", -6, 0)
    r.drop:SetScript("OnClick", function() ns:LootDrop(r.key) end)
    r.note:SetAutoFocus(false)
    r.note:SetFontObject(ChatFontNormal)
    r.note:SetTextInsets(6, 6, 0, 0)
    ns.Fill(r.note, C.input)
    ns.Border(r.note, C.border)
    r.note.ph = ns.Text(r.note, 11, 400, C.mute)
    r.note.ph:SetPoint("LEFT", 6, 0)
    r.note:SetScript("OnTextChanged", function(self) self.ph:SetShown(self:GetText() == "") end)
    r.note:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    r.note:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    r.note:SetScript("OnEditFocusLost", function(self) ns:LootSetNote(r.key, self:GetText()) end)
    r.kinds = {}
    local x = -172
    for i = #KINDS, 1, -1 do
        local k = KINDS[i]
        local bw = k[1] == "os" and OS_W or KIND_W
        local b = flatButton(r.head, bw, 22)
        b:SetPoint("RIGHT", x, 0)
        x = x - bw - 4
        b.kind = k[1]
        b:SetScript("OnClick", function(self)
            if self.kind == "os" then r.osOpen = not r.osOpen ns:LootRefresh()
            else ns:LootReact(r.key, self.kind) end
        end)
        r.kinds[k[1]] = b
    end
    r.hist:ClearAllPoints()
    r.hist:SetPoint("RIGHT", r.kinds.bis, "LEFT", -8, 0)
    r.boss = ns.Text(r.head, 10.5, 600, C.mute)
    r.boss:SetPoint("RIGHT", r.hist, "LEFT", -6, 0)
    -- spés de ma classe (O-Spec) : petits boutons à la place de « O-Spec »
    r.specs = {}
    for i = 1, 4 do
        local b = flatButton(r.head, 20, 24)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetSize(18, 18)
        b.icon:SetPoint("CENTER")
        b:SetScript("OnClick", function(self) r.osOpen = false ns:LootReact(r.key, "os", self.spec) end)
        r.specs[i] = b
    end
    r.winner = ns.Text(r.head, 12.5, 700)
    r.winner:SetPoint("RIGHT", -34, 0)
    r.state = ns.Text(r.head, 10.5, 500, C.mute)
    r.state:SetPoint("RIGHT", r.winner, "LEFT", -10, 0)
    -- colonnes (en-têtes une seule fois en haut de la liste) ; triangle au-dessus de chacune (maître du butin) :
    -- clic = toute la colonne sélectionnée (comme Ctrl + clic), sans défaire la sélection des autres colonnes ;
    -- clic droit = menu Attrib / Roll / Add rolls / Remove pour toute la colonne
    r.cols, r.colTri = {}, {}
    for ci, k in ipairs(SR_COLS) do
        r.cols[k[1]] = {}
        local t = CreateFrame("Button", nil, r)
        t:SetSize(COL_W - 6, 13)
        t:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        t.t = ns.Triangle(t, "down", 11)
        t.t:SetPoint("CENTER")
        t:SetScript("OnEnter", function(s) s.t:SetVertexColor(1, 1, 1) end)
        t:SetScript("OnLeave", function(s) s.t:SetVertexColor(C.mute[1], C.mute[2], C.mute[3]) end)
        t:SetScript("OnClick", function(s, btn)
            local key = r.key
            if btn == "RightButton" then
                -- joueurs de la colonne, sans doublon (SR réservé plusieurs fois)
                local seen, sel = {}, {}
                for _, p in ipairs(s.names or {}) do if not seen[p] then seen[p] = true sel[#sel + 1] = p end end
                if #sel > 0 and ownsGroup(key) then ns:LootPlayersMenu(s, key, sel) end
                return
            end
            lc.sel = lc.sel or {}
            for k2 in pairs(lc.sel) do if k2 ~= key then lc.sel[k2] = nil end end
            lc.sel[key] = lc.sel[key] or {}
            local all = #(s.names or {}) > 0
            for _, p in ipairs(s.names or {}) do if not lc.sel[key][p] then all = false end end
            for _, p in ipairs(s.names or {}) do lc.sel[key][p] = not all or nil end
            ns:LootRefresh()
        end)
        t:Hide()
        r.colTri[ci] = t
    end
    -- clic : échange (objet attribué) ; clic droit sur l'objet : Désenchanter / Vendre (maître du butin)
    -- clic sur la barre : replier / déplier (objet attribué : échange) ; clic droit : Désenchanter / Vendre
    r:SetScript("OnClick", function(self, btn)
        if btn == "RightButton" then ns:LootItemMenu(r.name, r.key)
        elseif r.attributed then ns:LootTrade(r.key)
        elseif r.head:IsMouseOver() then
            lc.collapsed = lc.collapsed or {}
            lc.collapsed[r.key] = not lc.collapsed[r.key] or nil
            ns:LootRefresh()
        end
    end)
    return r
end

-- une ligne par objet (exemplaires regroupés) : attribués pas encore échangés, puis à attribuer, puis échangés
local function sortedItems()
    local by, list = {}, {}
    for _, it in pairs(db().items) do
        local gk = groupKey(it)
        if not by[gk] then by[gk] = true list[#list + 1] = groupOf(it.key) end
    end
    local out = {}
    for _, g in ipairs(list) do
        local rep = g[1]
        local e = { rep = rep, items = g, free = 0, winners = {}, pending = false, live = false }
        for _, x in ipairs(g) do
            if x.attrib then e.winners[#e.winners + 1] = x.attrib if not x.traded then e.pending = true end
            else e.free = e.free + 1 end
            if not x.traded and not x.hidden then
                e.live = true
                if x.tradeEnd and (not e.tradeEnd or x.tradeEnd < e.tradeEnd) then e.tradeEnd = x.tradeEnd end
            end
        end
        -- Loot Dealer ou maître du butin du jeu : leurs objets seulement (sauf déjà attribués)
        if e.live and (X.isPublic(rep.owner) or #e.winners > 0) then out[#out + 1] = e end
    end
    table.sort(out, function(a, b)
        -- objets de ma wishlist (perso joué) en haut de la liste
        local wa, wb = myWish(a.rep.id) and 0 or 1, myWish(b.rep.id) and 0 or 1
        if wa ~= wb then return wa < wb end
        local x, y = a.tradeEnd or math.huge, b.tradeEnd or math.huge
        if x ~= y then return x < y end
        return (a.rep.t or 0) < (b.rep.t or 0)
    end)
    return out
end

function ns:LootRefresh()
    local f = lc.win
    if not f then return end
    autoWishReact()
    local d = db()
    local officer = iAmOfficer()
    ns.SetFont(f.title, 15, 700)
    f.title:SetText((ns.db.guildTitle or "TWO") .. " Loot Council")
    ns.SetFont(f.scan.label, 11.5, 600) f.scan.label:SetText(L("Scan"))
    ns.SetFont(f.push.label, 11.5, 700) f.push.label:SetText("PUSH")
    local ap = lootAp()
    local sc, tone = ap.itemScale, self:LootItemColor()
    local list = sortedItems()
    ns.SetFont(f.info, 11, 500)
    f.info:SetText(L("{0} item(s)", #list) .. (channel() and "" or ("  ·  " .. L("not in a group: nothing is sent"))))
    -- interrupteur : réactions ouvertes (vert) / fermées
    f.sw:SetShown(officer or X.iAmDealer())
    f.sw.knob:ClearAllPoints()
    f.sw.knob:SetPoint(d.open and "RIGHT" or "LEFT", f.sw.track, d.open and "RIGHT" or "LEFT", d.open and -2 or 2, 0)
    local tc, kc = d.open and C.accent or C.border, d.open and C.white or C.mute
    f.sw.track:SetColorTexture(tc[1], tc[2], tc[3])
    f.sw.knob:SetColorTexture(kc[1], kc[2], kc[3])
    ns.SetFont(f.sw.label, 11, 600)
    f.sw.label:SetText(L(d.open and "Reactions open" or "Reactions closed"))
    f.pal:SetShown(officer)
    self:LootAddButton()
    ns.SetFont(f.pal.label, 11, 600) f.pal.label:SetText(L("Off"))
    self:LootApplyAppearance()
    local COLS = columns()
    local L0, CW, FK = colLayout()
    for i, t in ipairs(f.heads) do
        local k = COLS[i]
        t:SetShown(k ~= nil)
        if k then
            local c = KIND_COLOR[k[1]]
            ns.SetFont(t, 10.5, 700)
            t:SetText(strupper(L(k[2])))
            t:SetTextColor(c[1], c[2], c[3])
            t:ClearAllPoints()
            t:SetPoint("CENTER", f.hd, "LEFT", L0 + (i - 1) * CW + (CW - 4) / 2, 0)
        end
    end
    self:LootSoftResBar()
    local myClass = select(2, UnitClass("player"))
    local seeAll = officer or d.showAll
    local y = self:LootHeldList(6)
    ns.SetFont(f.dealer.value, 12, 600)
    local dl = X.dealer()
    local dc = dl and ns.ClassColor((classOf(dl))) or C.mute
    f.dealer.value:SetText(dl and first(dl) or L("None"))
    f.dealer.value:SetTextColor(dc[1], dc[2], dc[3])
    for i, e in ipairs(list) do
        local it = e.rep
        local r = f.rows[i] or lootRow(f.scroll.child)
        f.rows[i] = r
        r.key, r.link, r.itemId, r.tradeEnd = it.key, it.link, it.id, e.tradeEnd
        ns.SetFont(r.timer, 11 * math.max(0.8, sc), 700)
        r.timer:SetText(e.tradeEnd and fmtLeft(e.tradeEnd - time()) or "")
        -- attribué, pas encore échangé : barre dorée (couleur et opacité dans Settings)
        local pc = ap.pendColor
        r.pend:SetColorTexture(pc[1], pc[2], pc[3], ap.pendAlpha)
        r.pend:SetShown(e.pending)
        -- barre de l'objet : couleur sombre / claire, opacité, taille (icône, nom, boutons, note)
        r.headFill:SetColorTexture(tone[1], tone[2], tone[3], ap.itemAlpha)
        local rh = math.floor(ROW_H * sc + 0.5)
        r.head:SetHeight(rh)
        r.icon:SetSize(28 * sc, 28 * sc)
        local x = -34 - (130 * sc + 8)
        r.note:SetSize(130 * sc, 22 * sc)
        for ki = #KINDS, 1, -1 do
            local k = KINDS[ki][1]
            local bw = (k == "os" and OS_W or KIND_W) * sc
            local b = r.kinds[k]
            b:SetSize(bw, 22 * sc)
            b:ClearAllPoints()
            b:SetPoint("RIGHT", x, 0)
            x = x - bw - 4
        end
        -- attribué : replié, sauf re-déplié avec le triangle (changer l'attribution)
        local collapsed
        if e.free == 0 then collapsed = not (lc.reopen or {})[it.key] else collapsed = (lc.collapsed or {})[it.key] end
        r.tri.t:SetRotation(collapsed and math.pi / 2 or 0)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 6, -y)
        r:SetPoint("RIGHT", f.scroll.child, "RIGHT", -6, 0)
        r.icon:SetTexture(it.icon or (it.id and GetItemIcon and GetItemIcon(it.id)) or 134400)
        local qc = ITEM_QUALITY_COLORS and it.q and ITEM_QUALITY_COLORS[it.q] or { r = 1, g = 1, b = 1 }
        ns.SetFont(r.name, 12.5 * sc, 700)
        r.name:SetWordWrap(false)
        r.name:SetWidth(1000)
        r.name:SetText(it.name or it.link or "?")
        r.name:SetWidth(math.min(r.name:GetStringWidth() + 2, 300 * sc))
        r.name:SetTextColor(qc.r, qc.g, qc.b)
        -- exemplaires (« X2 ») et attributions précédentes (×N, à gauche de l'icône)
        ns.SetFont(r.count, 12.5 * sc * 1.25, 700)
        r.count:SetText(#e.items > 1 and ("X" .. #e.items) or "")
        local n = it.id and countDropped(it.id) or 0
        ns.SetFont(r.hist.text, 11 * math.max(0.8, sc), 700)
        r.hist.text:SetText(n > 0 and ("×" .. n) or "")
        r.hist:SetWidth(n > 0 and r.hist.text:GetStringWidth() + 6 or 1)
        r.hist:SetShown(n > 0)
        -- boss où l'objet est tombé
        ns.SetFont(r.boss, 10.5 * math.max(0.8, sc), 600)
        r.boss:SetText(it.boss and L(it.boss) or "")
        ns.SetFont(r.owner, 10, 400)
        -- attribués parmi plusieurs exemplaires : noms à la suite
        local partial = #e.winners > 0 and e.free > 0
        local wn = {}
        for wi, n in ipairs(e.winners) do wn[wi] = shortName(n) end
        r.owner:SetText(partial and ("→ " .. table.concat(wn, ", ")) or (it.owner ~= me() and shortName(it.owner) or ""))
        local attributed = e.free == 0
        r.attributed = attributed
        if attributed and lc.histWin and lc.histWin:IsShown() and lc.histKey == it.key then lc.histWin:Hide() end
        r.drop:SetShown(it.owner == me() or officer)
        r.tri:SetShown(true)
        for _, b in pairs(r.kinds) do b:SetShown(not attributed) end
        r.note:SetShown(not attributed)
        for _, b in ipairs(r.specs) do b:Hide() end
        ns.SetFont(r.winner, 12.5, 700)
        ns.SetFont(r.state, 10.5, 500)
        if attributed then
            local wc = ns.ClassColor((classOf(e.winners[1])))
            r.winner:SetText(table.concat(wn, ", "))
            r.winner:SetTextColor(wc[1], wc[2], wc[3])
            r.state:SetText(L(not e.pending and "traded" or (ownsGroup(it.key) and "click to trade" or "not traded yet")))
        else
            r.winner:SetText("") r.state:SetText("")
            local mine = d.reactions[it.key] and d.reactions[it.key][me()]
            for k, b in pairs(r.kinds) do
                ns.SetFont(b.label, 11, 600)
                b.label:SetText(KIND_LABEL[k])
                b.on = mine and mine.k == k
                ns.SetBorderColor(b, b.on and C.hl or C.border)
                b.bg:SetColorTexture(b.on and C.hl[1] * 0.35 or C.input[1], b.on and C.hl[2] * 0.35 or C.input[2], b.on and C.hl[3] * 0.35 or C.input[3])
                b:SetEnabled(d.open)
                b:SetAlpha(d.open and 1 or 0.4)
            end
            -- Off Spec : boutons de spé de ma classe à la place du bouton
            if r.osOpen and d.open then
                r.kinds.os:Hide()
                local specs = ns.SPECS[myClass] or {}
                local w = OS_W * sc / math.max(1, #specs)
                for j, sp in ipairs(specs) do
                    local b = r.specs[j]
                    b:SetSize(w - 2, 24 * sc)
                    b.icon:SetSize(18 * sc, 18 * sc)
                    b:ClearAllPoints()
                    b:SetPoint("LEFT", r.kinds.os, "LEFT", (j - 1) * w, 0)
                    b.spec = sp[1]
                    b.tipText = sp[1]
                    b.icon:SetTexture(ns:SpecIcon({ class = myClass }, sp[1]) or "Interface\\Icons\\INV_Misc_QuestionMark")
                    b:Show()
                end
            end
            if not r.note:HasFocus() then r.note:SetText(myNote[it.key] or (mine and mine.note) or "") end
            ns.SetFont(r.note.ph, 11, 400)
            r.note.ph:SetText(L("note"))
            r.note.ph:SetShown(r.note:GetText() == "")
        end
        -- colonnes de réactions (repliées une fois l'objet attribué)
        local maxN = 0
        local rolls, sugg, sel = d.rolls[it.key] or {}, officer and d.sugg[it.key] or {}, (lc.sel or {})[it.key] or {}
        local best = 0
        for _, v in pairs(rolls) do if v > best then best = v end end
        local rollAll = (d.rollAll or {})[it.key] or {}
        for ci, k in ipairs(COLS) do
            local names = {}
            local isSR = k[1] == "sr"
            if not collapsed then
                if isSR then
                    -- SR : un nom par réservation (réservé deux fois = deux lignes)
                    names = ns:SRItem(it.id)
                else
                    -- joueurs (pas officiers) : seulement leur réaction, sauf si un officier montre les listes à tous
                    for p, rx in pairs(d.reactions[it.key] or {}) do
                        if rx.k == k[1] and (seeAll or p == me()) then names[#names + 1] = p end
                    end
                    table.sort(names)
                end
            end
            local col = r.cols[k[1]]
            local occ = {}
            for j, p in ipairs(names) do
                local b = col[j] or nameButton(r)
                col[j] = b
                b:SetSize(CW - 6, math.max(NAME_H, ap.nameSize * FK + 7) - 2)
                local rx = (d.reactions[it.key] or {})[p] or {}
                if isSR then rx = { c = rx.c } end
                b.key, b.player, b.fullNote = it.key, p, rx.note
                b:ClearAllPoints()
                b:SetPoint("TOPLEFT", L0 - 6 + (ci - 1) * CW, -rh - 14 - (j - 1) * math.max(NAME_H, ap.nameSize * FK + 7))
                local cc = ns.ClassColor(rx.c or classOf(p))
                -- SR réservé plusieurs fois : chaque ligne montre son jet (1er jet, 2e jet…)
                occ[p] = (occ[p] or 0) + 1
                local rv = rolls[p]
                if isSR and rollAll[p] then rv = rollAll[p][occ[p]] or (rv == -1 and -1 or nil) end
                ns.SetFont(b.roll, 10.5 * FK, 700)
                b.roll:SetText(rv and rv > 0 and tostring(rv) or "")
                -- jet, spé du joueur pour ce raid, nom ; à droite : spé Off Spec choisie, note à sa gauche
                local x0 = (rv and rv > 0) and math.floor(24 * FK) or 3
                b.spec:SetSize(13 * FK, 13 * FK)
                local pcls = rx.c or classOf(p)
                local ricon = mainSpecIcon(p, pcls) or raidSpecIcon(p, pcls)
                -- « +EP » puis objets équipés du même emplacement (deux : bague, bijou, arme à une main)
                local ept = ap.showEP and X.epText(p, pcls, rx, it.link) or nil
                b.ep:SetShown(ept ~= nil)
                if ept then
                    ns.SetFont(b.ep, 9.5 * FK, 700)
                    b.ep:SetText(ept)
                    b.ep:ClearAllPoints()
                    b.ep:SetPoint("LEFT", x0, 0)
                    x0 = x0 + math.ceil(b.ep:GetStringWidth()) + 3
                end
                for ei, e in ipairs(b.eqIcons) do
                    local l = ap.showEq and rx.eq and rx.eq[ei]
                    l = l ~= "" and l or nil
                    e.link = l
                    e:SetShown(l ~= nil)
                    if l then
                        e:SetSize(13 * FK, 13 * FK)
                        e.tex:SetTexture(select(5, itemInstant(l)) or 134400)
                        e:ClearAllPoints()
                        e:SetPoint("LEFT", x0, 0)
                        x0 = x0 + math.floor(15 * FK)
                    end
                end
                b.spec:ClearAllPoints()
                b.spec:SetPoint("LEFT", x0, 0)
                b.spec:SetShown(ricon ~= nil)
                if ricon then b.spec:SetTexture(ricon) x0 = x0 + math.floor(16 * FK) end
                local oicon = rx.k == "os" and rx.spec and ns:SpecIcon({ class = rx.c or classOf(p) }, rx.spec)
                b.ospec:SetShown(oicon ~= nil and oicon ~= false)
                if oicon then b.ospec:SetTexture(oicon) end
                local rx0 = oicon and 18 or 4
                b.note:ClearAllPoints() b.note:SetPoint("RIGHT", -rx0, 0)
                b.noteIcon:ClearAllPoints() b.noteIcon:SetPoint("RIGHT", -rx0, 0)
                ns.SetFont(b.name, ap.nameSize * FK, 600)
                b.name:ClearAllPoints()
                b.name:SetPoint("LEFT", x0, 0)
                local note = rx.note or ""
                ns.SetName(b.name, p, CW - 6 - x0 - rx0 - (#note > 0 and 18 or 2), true)
                b.name:SetTextColor(cc[1], cc[2], cc[3])
                -- note de 2 caractères au plus affichée, sinon icône (survol)
                ns.SetFont(b.note, 10 * FK, 400)
                b.note:SetText(#note > 0 and #note <= 2 and note or "")
                b.noteIcon:SetShown(#note > 2)
                -- fond : meilleur jet doré, jet attendu rougeâtre, sélection (Ctrl + clic)
                local bgc, a = C.slot, 0
                if rv and rv > 0 and rv == best then bgc, a = GOLD, 0.35
                elseif rv == -1 then bgc, a = REDDISH, 0.3 end
                if sel[p] then bgc, a = C.hl, 0.4 end
                b.bg:SetColorTexture(bgc[1], bgc[2], bgc[3], a)
                -- suggestions des officiers : cadre de la couleur du 1er, points pour les autres
                local offs = {}
                for o in pairs(sugg[p] or {}) do offs[#offs + 1] = o end
                table.sort(offs)
                local c1 = offs[1] and OFF_COLORS[d.colors[offs[1]] or 1] or C.border
                ns.SetBorderColor(b, c1, offs[1] and 1 or 0)
                for di, t in ipairs(b.dots) do
                    local o = offs[di]
                    if o then local oc = OFF_COLORS[d.colors[o] or 1] t:SetColorTexture(oc[1], oc[2], oc[3]) end
                    t:SetShown(o ~= nil and #offs > 1)
                end
                b:Show()
            end
            for j = #names + 1, #col do col[j]:Hide() end
            if #names > maxN then maxN = #names end
            local tri = r.colTri[ci]
            tri.names = names
            tri:SetSize(CW - 6, 13)
            tri:ClearAllPoints()
            tri:SetPoint("TOPLEFT", L0 - 6 + (ci - 1) * CW, -rh - 1)
            tri.t:SetVertexColor(C.mute[1], C.mute[2], C.mute[3])
            tri:SetShown(#names > 0 and ownsGroup(it.key))
        end
        -- SoftRes éteint : colonne SR cachée
        for ci = #COLS + 1, #r.colTri do r.colTri[ci]:Hide() end
        if #COLS == #KINDS then for _, b in ipairs(r.cols.sr) do b:Hide() end end
        local hgt = rh + (collapsed and 0 or (14 + math.max(1, maxN) * math.max(NAME_H, ap.nameSize * FK + 7) + 6))
        r:SetHeight(hgt)
        r:Show()
        -- barres repliées : plus serrées
        y = y + hgt + (collapsed and 2 or 6)
    end
    for i = #list + 1, #f.rows do f.rows[i]:Hide() end
    C_Timer.After(0, function() ns:LootUpdateBlur() end)
    ns.SetFont(f.empty, 12, 500)
    f.empty:SetText(#list == 0 and L("No tradeable raid loot yet. Items with the blue « You may trade this item… » line appear here.") or "")
    f.scroll.child:SetHeight(y + 10)
    -- bandes des colonnes : jusqu'au dernier nom, puis fondu
    self:LootPlaceStripes(#list > 0 and y or 0)
end

-- (Loot Dealer) objets échangeables des autres joueurs du raid (hors liste de tous), en tête de liste, pour lui seul :
-- ligne fine (temps restant, icône, objet, porteur, ×) ; clic = demande au porteur (/tlc trade), retirée de la liste
local HELD_H = 14
function ns:LootHeldList(y)
    local f, d = lc.win, db()
    f.held = f.held or {}
    d.heldHidden = d.heldHidden or {}
    local list = {}
    if X.iAmDealer() then
        for key, it in pairs(d.items) do
            if it.owner ~= me() and not X.isPublic(it.owner) and not it.attrib and not it.traded and not it.ask
               and not stale(it) and not d.heldHidden[key] then list[#list + 1] = it end
        end
        table.sort(list, function(a, b) return tradeEndOf(a) < tradeEndOf(b) end)
    end
    if not f.heldHead then
        f.heldHead = ns.Text(f.scroll.child, 10, 600, C.mute)
        f.heldHead:SetJustifyH("LEFT")
    end
    f.heldHead:SetShown(#list > 0)
    if #list == 0 then for _, r in ipairs(f.held) do r:Hide() end return y end
    ns.SetFont(f.heldHead, 10, 600)
    f.heldHead:SetText(L("Tradeable loot held by the raid (only you see this list) · click: ask for it"))
    f.heldHead:ClearAllPoints()
    f.heldHead:SetPoint("TOPLEFT", 10, -y)
    y = y + 14
    for i, it in ipairs(list) do
        local r = f.held[i]
        if not r then
            r = CreateFrame("Button", nil, f.scroll.child)
            r:SetSize(470, HELD_H)
            r.fill = ns.Fill(r, C.panel, 0.75)
            r.hl = r:CreateTexture(nil, "BACKGROUND", nil, 2)
            r.hl:SetAllPoints()
            r.hl:SetColorTexture(C.hl[1], C.hl[2], C.hl[3], 0.25)
            r.hl:Hide()
            r.timer = ns.Text(r, 10, 700, BLUE)
            r.timer:SetPoint("LEFT", 2, 0)
            r.timer:SetWidth(28)
            r.timer:SetJustifyH("RIGHT")
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(HELD_H - 2, HELD_H - 2)
            r.icon:SetPoint("LEFT", 34, 0)
            r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            r.name = ns.Text(r, 11, 600)
            r.name:SetPoint("LEFT", r.icon, "RIGHT", 5, 0)
            r.name:SetWidth(230)
            r.name:SetJustifyH("LEFT")
            r.name:SetWordWrap(false)
            r.who = ns.Text(r, 11, 600)
            r.who:SetPoint("LEFT", r.name, "RIGHT", 6, 0)
            r.who:SetPoint("RIGHT", -20, 0)
            r.who:SetJustifyH("LEFT")
            r.who:SetWordWrap(false)
            r.x = ns.IconButton(r, "×", HELD_H + 2, L("Remove from this list"))
            r.x:SetPoint("RIGHT", 0, 0)
            r.x:SetScript("OnClick", function() local dd = db() dd.heldHidden = dd.heldHidden or {} dd.heldHidden[r.key] = true ns:LootRefresh() end)
            r:SetScript("OnClick", function(self) ns:LootAskGive(self.key) end)
            r:SetScript("OnEnter", function(self)
                self.hl:Show()
                if self.link then
                    ns.TipOwner(self)
                    GameTooltip:SetHyperlink(self.link)
                    GameTooltip:AddLine(L("Click: ask {0} to trade it to you (/tlc trade).", self.ownerName or "?"), 0.44, 0.78, 1, true)
                    GameTooltip:Show()
                end
            end)
            r:SetScript("OnLeave", function(self) self.hl:Hide() GameTooltip:Hide() end)
            f.held[i] = r
        end
        r.key, r.link, r.ownerName, r.tradeEnd = it.key, it.link, first(it.owner), tradeEndOf(it)
        ns.SetFont(r.timer, 10, 700)
        r.timer:SetText(fmtLeft(r.tradeEnd - time()))
        r.icon:SetTexture(it.icon or (it.id and GetItemIcon and GetItemIcon(it.id)) or 134400)
        local qc = ITEM_QUALITY_COLORS and it.q and ITEM_QUALITY_COLORS[it.q] or { r = 1, g = 1, b = 1 }
        ns.SetFont(r.name, 11, 600)
        r.name:SetText(it.name or it.link or "?")
        r.name:SetTextColor(qc.r, qc.g, qc.b)
        local cc = ns.ClassColor((classOf(it.owner)))
        ns.SetFont(r.who, 11, 600)
        r.who:SetText(shortName(it.owner))
        r.who:SetTextColor(cc[1], cc[2], cc[3])
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 6, -y)
        r:Show()
        y = y + HELD_H + 1
    end
    for i = #list + 1, #f.held do f.held[i]:Hide() end
    return y + 6
end

-- cadre refermé 1 s après que la souris l'a quitté (couleurs des officiers, « Received by »)
local function hideWhenLeft(w)
    w:HookScript("OnShow", function(f) f.outT = nil end)
    w:SetScript("OnUpdate", function(f, el)
        if f:IsMouseOver() then f.outT = nil return end
        f.outT = (f.outT or 0) + el
        if f.outT > 1 then f:Hide() end
    end)
end

-- Couleurs des officiers : une ligne par officier connu (couleurs envoyées au raid)
function ns:LootColorsWindow()
    local w = lc.colWin
    if not w then
        w = CreateFrame("Frame", nil, lc.win)
        w:SetFrameLevel(lc.win:GetFrameLevel() + 40)
        w:SetSize(300, 300)
        w:SetPoint("TOPRIGHT", lc.win, "TOPRIGHT", -10, -82)
        w:EnableMouse(true)
        ns.Fill(w, C.bg, 0.97)
        ns.Border(w, C.hl)
        w.title = ns.Text(w, 12.5, 700, C.white)
        w.title:SetPoint("TOPLEFT", 10, -9)
        local close = ns.IconButton(w, "×", 22)
        close:SetPoint("TOPRIGHT", -3, -3)
        close:SetScript("OnClick", function() w:Hide() end)
        w.rows = {}
        hideWhenLeft(w)
        lc.colWin = w
    end
    local d = db()
    local names = {}
    for n in pairs(d.colors) do names[#names + 1] = n end
    if not d.colors[me()] then myColor() names[#names + 1] = me() end
    table.sort(names)
    ns.SetFont(w.title, 12.5, 700)
    w.title:SetText(L("Officer colors"))
    for i, n in ipairs(names) do
        local r = w.rows[i]
        if not r then
            r = CreateFrame("Frame", nil, w)
            r:SetSize(280, 24)
            r.name = ns.Text(r, 11.5, 600)
            r.name:SetPoint("LEFT", 0, 0)
            r.sw = {}
            for ci = 1, #OFF_COLORS do
                local b = CreateFrame("Button", nil, r)
                b:SetSize(18, 18)
                b:SetPoint("RIGHT", -(#OFF_COLORS - ci) * 22, 0)
                b.t = ns.Fill(b, OFF_COLORS[ci])
                ns.Border(b, C.border)
                b.idx = ci
                b:SetScript("OnClick", function(self)
                    d.colors[r.officer] = self.idx
                    send("C", { colors = { [r.officer] = self.idx } })
                    ns:LootColorsWindow()
                    ns:LootRefresh()
                end)
                r.sw[ci] = b
            end
            w.rows[i] = r
        end
        r.officer = n
        r:SetPoint("TOPLEFT", 10, -34 - (i - 1) * 28)
        ns.SetFont(r.name, 11.5, 600)
        r.name:SetText(n)
        for ci, b in ipairs(r.sw) do ns.SetBorderColor(b, d.colors[n] == ci and C.white or C.border) end
        r:Show()
    end
    for i = #names + 1, #w.rows do w.rows[i]:Hide() end
    w:SetHeight(44 + #names * 28)
    ns.LootWatchList(w)
    w:Show()
end

-- « Add item » : verdâtre avec le nombre d'objets choisis
function ns:LootAddButton()
    local b = lc.win and lc.win.add
    if not b then return end
    local n = 0
    for _ in pairs(lc.pick or {}) do n = n + 1 end
    ns.SetFont(b.label, 11.5, 600)
    b.label:SetText(n > 0 and L("Add {0}", n) or L("Add item"))
    if n > 0 then b.bg:SetColorTexture(0.16, 0.36, 0.22) else b.bg:SetColorTexture(C.input[1], C.input[2], C.input[3]) end
    ns.SetBorderColor(b, n > 0 and C.ok or C.border)
end
-- objets des sacs : qualité (légendaire > épique > rare > peu commun > commun), niveau d'objet, niveau requis, nom
local function bagItems()
    local d, out = db(), {}
    for bag = 0, NUM_BAG_SLOTS or 4 do
        for slot = 1, bagSlots(bag) do
            local link = bagLink(bag, slot)
            if link then
                local key = itemGuid(bag, slot, link)
                if not d.items[key] then
                    local name, _, q, ilvl, req, _, _, _, _, icon = GetItemInfo(link)
                    out[#out + 1] = { key = key, bag = bag, slot = slot, link = link, name = name or link, q = q or 1, ilvl = ilvl or 0, req = req or 0, icon = icon }
                end
            end
        end
    end
    table.sort(out, function(a, b)
        if a.q ~= b.q then return a.q > b.q end
        if a.ilvl ~= b.ilvl then return a.ilvl > b.ilvl end
        if a.req ~= b.req then return a.req > b.req end
        return a.name < b.name
    end)
    return out
end
function ns:LootBagList()
    local w = lc.bagList
    if w and w:IsShown() then w:Hide() return end
    if not w then
        w = CreateFrame("Frame", nil, lc.win)
        w:SetFrameLevel(lc.win:GetFrameLevel() + 40)
        w:SetSize(400, 380)
        w:SetPoint("TOPLEFT", lc.win.add, "BOTTOMLEFT", 0, -2)
        w:EnableMouse(true)
        ns.Fill(w, { 0.09, 0.094, 0.11 }, 0.98)
        ns.Border(w, C.hl)
        local sf = ns.ScrollArea(w)
        sf:SetPoint("TOPLEFT", 1, -1)
        sf:SetPoint("BOTTOMRIGHT", -1, 1)
        sf.child:SetWidth(392)
        w.scroll, w.rows = sf, {}
        w:HookScript("OnHide", function() lc.pick = {} ns:LootAddButton() end)
        lc.bagList = w
    end
    local items = bagItems()
    for i, it in ipairs(items) do
        local r = w.rows[i]
        if not r then
            r = CreateFrame("Button", nil, w.scroll.child)
            r:SetSize(390, 22)
            r.hl = ns.Fill(r, C.hl, 0)
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(18, 18)
            r.icon:SetPoint("LEFT", 4, 0)
            r.name = ns.Text(r, 11.5, 600)
            r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
            r.name:SetPoint("RIGHT", -50, 0)
            r.lvl = ns.Text(r, 10.5, 500, C.mute)
            r.lvl:SetPoint("RIGHT", -6, 0)
            r:SetScript("OnEnter", function(self) ns.TipOwner(self) GameTooltip:SetHyperlink(self.it.link) GameTooltip:Show() end)
            r:SetScript("OnLeave", function() GameTooltip:Hide() end)
            r:SetScript("OnClick", function(self)
                lc.pick = lc.pick or {}
                lc.pick[self.it.key] = not lc.pick[self.it.key] and self.it or nil
                self.hl:SetColorTexture(C.hl[1], C.hl[2], C.hl[3], lc.pick[self.it.key] and 0.3 or 0)
                ns:LootAddButton()
            end)
            w.rows[i] = r
        end
        r.it = it
        r:SetPoint("TOPLEFT", 1, -(i - 1) * 22)
        r.icon:SetTexture(it.icon or 134400)
        local qc = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[it.q] or { r = 1, g = 1, b = 1 }
        ns.SetFont(r.name, 11.5, 600)
        r.name:SetText(it.name)
        r.name:SetTextColor(qc.r, qc.g, qc.b)
        ns.SetFont(r.lvl, 10.5, 500)
        r.lvl:SetText(it.ilvl > 0 and ("ilvl " .. it.ilvl) or "")
        r.hl:SetColorTexture(C.hl[1], C.hl[2], C.hl[3], (lc.pick or {})[it.key] and 0.3 or 0)
        r:Show()
    end
    for i = #items + 1, #w.rows do w.rows[i]:Hide() end
    w.scroll.child:SetHeight(#items * 22 + 2)
    w:SetHeight(math.min(380, #items * 22 + 4))
    ns.LootWatchList(w)
    w:Show()
end
function ns:LootAddPicked()
    local d = db()
    for key, it in pairs(lc.pick or {}) do
        d.items[key] = { key = key, owner = me(), link = it.link, id = tonumber(it.link:match("item:(%d+)")), t = time(),
                         name = it.name, q = it.q, icon = it.icon, bag = it.bag, slot = it.slot, manual = true, zone = (GetInstanceInfo()) }
        d.removed = d.removed or {}
        d.removed[key] = nil
    end
    lc.pick = {}
    if lc.bagList then lc.bagList:Hide() end
    self:LootAddButton()
    lastSig = nil
    self:LootScan(true)
end
-- croix d'une ligne : objet retiré de la liste (porteur : retiré de sa liste ; officier : chez tout le monde)
function ns:LootDrop(key)
    local d = db()
    local mine = false
    for _, it in ipairs(groupOf(key) or {}) do
        if it.attrib and not it.traded then
            it.hidden = true
        elseif it.owner == me() then
            d.removed = d.removed or {}
            d.removed[it.key] = true
            d.items[it.key] = nil
            mine = true
        elseif iAmOfficer() then
            d.items[it.key] = nil
            send("X", { key = it.key })
        end
    end
    lastSig = nil
    if mine then self:LootScan(true) else self:LootRefresh() end
end
-- clic droit sur l'objet (maître du butin) : Désenchanter (enchanteurs du raid) / Vendre (au prochain marchand)
local function enchanters()
    local out = {}
    for i = 1, GetNumGroupMembers() do
        local unit = IsInRaid() and ("raid" .. i) or (i == 1 and "player" or "party" .. (i - 1))
        local short = first(UnitName(unit))
        for name, c in pairs(ns.db.chars or {}) do
            if first(name) == short then
                for _, p in ipairs(c.profs or {}) do
                    if p.n == "Enchanting" or p.n == "Enchantement" then out[#out + 1] = name break end
                end
            end
        end
    end
    table.sort(out)
    return out
end
function ns:LootItemMenu(anchor, key)
    local free = false
    for _, x in ipairs(groupOf(key) or {}) do if x.owner == me() and not x.attrib then free = true end end
    if not free then return end
    local function main()
        ns:OpenMenu(anchor, {
            { text = L("Disenchant") .. "  ›", atlas = "lootroll-toast-icon-disenchant-up", icon = MEDIA .. "menu_disenchant", func = function() C_Timer.After(0, function()
                local items = { { text = "‹ " .. L("Back"), func = function() C_Timer.After(0, main) end } }
                for _, n in ipairs(enchanters()) do items[#items + 1] = { text = n, func = function() ns:LootAttrib(key, n, "de") end } end
                if #items == 1 then items[2] = { text = L("No enchanter in the raid"), func = function() end } end
                ns:OpenMenu(anchor, items, 200)
            end) end },
            { text = L("Vendor"), atlas = "lootroll-toast-icon-greed-up", icon = MEDIA .. "menu_coin", func = function() ns:LootAttrib(key, L("Vendor"), "vendor") end },
        }, 200)
    end
    main()
end

-- SoftRes : interrupteur, case du CSV (texte d'aide), heure d'export de la source utilisée (en gris au-dessus)
function ns:LootSoftResBar()
    local f = lc.win
    if not (f and f.sr) then return end
    local on = ns:SROn()
    f.sr.knob:ClearAllPoints()
    f.sr.knob:SetPoint(on and "RIGHT" or "LEFT", f.sr.track, on and "RIGHT" or "LEFT", on and -2 or 2, 0)
    local tc, kc = on and C.accent or C.border, on and C.white or C.mute
    f.sr.track:SetColorTexture(tc[1], tc[2], tc[3])
    f.sr.knob:SetColorTexture(kc[1], kc[2], kc[3])
    ns.SetFont(f.sr.label, 11, 600)
    f.sr.label:SetText("SoftRes")
    local src = ns:SRSource()
    ns.SetFont(f.srTime, 9.5, 500)
    f.srTime:SetText(src and src.label or "")
    ns.SetFont(f.srBox.ph, 10, 400)
    f.srBox.ph:SetText(src and L("{0} reserves", #src.list) or L("Paste CSV"))
    f.srBox.ph:SetShown(f.srBox:GetText() == "")
    -- texte d'info (barre du titre) coupé avant le bouton Settings
    f.info:SetPoint("RIGHT", f.gear, "LEFT", -10, 0)
    f.info:SetJustifyH("LEFT")
end

-- Bandes des colonnes (SR en plus selon l'interrupteur SoftRes) : pleines jusqu'au bas de la liste (yEnd, après le
-- dernier nom), puis fondu vers le transparent sur 90 px au plus, sans dépasser le bas de la fenêtre ; liste plus
-- haute que la fenêtre : pleines jusqu'au bout (défilement)
local function setGradient(t, c, a)
    t:SetColorTexture(1, 1, 1, 1)
    local ok = CreateColor and pcall(t.SetGradient, t, "VERTICAL", CreateColor(c[1], c[2], c[3], 0), CreateColor(c[1], c[2], c[3], a))
    if not ok and t.SetGradientAlpha then t:SetGradientAlpha("VERTICAL", c[1], c[2], c[3], 0, c[1], c[2], c[3], a) end
end
function ns:LootPlaceStripes(yEnd)
    local f, a = lc.win, lootAp()
    if not (f and f.stripes) then return end
    yEnd = yEnd or lc.yEnd or 0
    lc.yEnd = yEnd
    local cols = columns()
    local L0, cw = colLayout()
    local viewH = f.scroll:GetHeight() or 0
    local fadeH = math.max(0, math.min(90, viewH - yEnd - 2))
    f.fades = f.fades or {}
    for i, t in ipairs(f.stripes) do
        local k = cols[i]
        local fd = f.fades[i] or f.scroll.child:CreateTexture(nil, "BACKGROUND")
        f.fades[i] = fd
        t:SetShown(k ~= nil and yEnd > 0)
        fd:SetShown(k ~= nil and yEnd > 0 and fadeH > 4)
        if k then
            local c = KIND_COLOR[k[1]]
            t:SetColorTexture(c[1], c[2], c[3], a.colAlpha)
            t:ClearAllPoints()
            t:SetPoint("TOPLEFT", L0 + (i - 1) * cw, 0)
            t:SetSize(cw - 4, math.max(1, yEnd))
            fd:ClearAllPoints()
            fd:SetPoint("TOPLEFT", t, "BOTTOMLEFT")
            fd:SetSize(cw - 4, math.max(1, fadeH))
            setGradient(fd, c, a.colAlpha)
        end
    end
end

-- Apparence de /tlc (réglages propres) : image de fond, barre d'indicateur, barres des objets, colonnes
function ns:LootApplyAppearance()
    local f, a = lc.win, lootAp()
    if not f then return end
    f.bgImg:SetShown(a.bg)
    f.bgImg:SetAlpha(a.bgAlpha)
    if lc.tradeWin then lc.tradeWin:SetScale(a.tradeScale) end
    f.subFill:SetAlpha(a.barAlpha)
    self:LootPlaceStripes()
    -- triangle du haut : tout replié ?
    local all = next(db().items) ~= nil
    for _, it in pairs(db().items) do if not (lc.collapsed or {})[it.key] then all = false break end end
    f.allTri.t:SetRotation(all and math.pi / 2 or 0)
end
-- couleur des barres d'objets : sombre (0) … claire (1), 0,5 = couleur des panneaux
function ns:LootItemColor()
    local t, p = lootAp().itemTone, C.panel
    if t < 0.5 then local k = t * 2 return { p[1] * k, p[2] * k, p[3] * k } end
    local k = (t - 0.5) * 2
    return { p[1] + (0.46 - p[1]) * k, p[2] + (0.47 - p[2]) * k, p[3] + (0.51 - p[3]) * k }
end
-- image floutée sous chaque barre d'objet (morceau du fond de la fenêtre à cet endroit)
function ns:LootUpdateBlur()
    local f, a = lc.win, lootAp()
    if not (f and f:IsShown()) then return end
    local fl, ft, fw, fh = f:GetLeft(), f:GetTop(), f:GetWidth(), f:GetHeight()
    local u0, u1, v0, v1 = BG_CROP[1] or 0, BG_CROP[2] or 1, BG_CROP[3] or 0, BG_CROP[4] or 1
    for _, r in ipairs(f.rows) do
        local h = r.head
        if r:IsShown() and a.bg and a.itemBlur > 0 and h:GetLeft() and fl then
            local x1, x2 = (h:GetLeft() - fl) / fw, (h:GetRight() - fl) / fw
            local y1, y2 = (ft - h:GetTop()) / fh, (ft - h:GetBottom()) / fh
            r.blur:SetTexCoord(u0 + (u1 - u0) * math.max(0, x1), u0 + (u1 - u0) * math.min(1, x2),
                               v0 + (v1 - v0) * math.max(0, y1), v0 + (v1 - v0) * math.min(1, y2))
            r.blur:SetAlpha(a.bgAlpha * a.itemBlur)
            r.blur:Show()
        else
            r.blur:Hide()
        end
    end
end

-- Curseur des réglages de /tlc (comme ceux de la fenêtre principale) : valeur devant, molette, clic sur le nombre = saisie
local function lootSlider(row, key, lo, hi, st, fmt)
    local s = CreateFrame("Slider", nil, row)
    s:SetOrientation("HORIZONTAL")
    s:SetSize(110, 14)
    s:SetPoint("RIGHT", -4, 0)
    s:SetMinMaxValues(lo, hi)
    s:SetValueStep(st)
    s:SetObeyStepOnDrag(true)
    local track = ns.Tex(s, C.input, "BACKGROUND")
    track:SetPoint("LEFT") track:SetPoint("RIGHT") track:SetHeight(4)
    s.fill = ns.Tex(s, C.accent, "ARTWORK")
    s.fill:SetPoint("LEFT") s.fill:SetHeight(4)
    s:SetThumbTexture("Interface\\Buttons\\WHITE8X8")
    s:GetThumbTexture():SetSize(8, 14)
    local val = ns.Text(row, 12, 600)
    val:SetPoint("RIGHT", s, "LEFT", -8, 0)
    local function show(v)
        ns.SetFont(val, 12, 600)
        val:SetText(fmt(v))
        s.fill:SetWidth(math.max(1, 110 * (v - lo) / (hi - lo)))
    end
    local function apply(v)
        lootAp()[key] = v
        show(v)
        ns:LootApplyAppearance()
        ns:LootRefresh()
    end
    s:SetScript("OnValueChanged", function(_, v, user) show(v) if user then apply(v) end end)
    s:EnableMouseWheel(true)
    s:SetScript("OnMouseWheel", function(self, d)
        self:SetValue(math.max(lo, math.min(hi, self:GetValue() + d * st)))
        apply(self:GetValue())
    end)
    function row:Update() local v = lootAp()[key] s:SetValue(v) show(v) end
    return s
end

-- interrupteur (piste + bouton) comme dans les Settings
local function lootSwitch(parent, onClick)
    local sw = CreateFrame("Button", nil, parent)
    sw:SetSize(30, 16)
    sw:SetPoint("RIGHT", -4, 0)
    sw.track = ns.Tex(sw, C.border, "ARTWORK")
    sw.track:SetAllPoints()
    sw.knob = ns.Tex(sw, C.mute, "OVERLAY")
    sw.knob:SetSize(12, 12)
    sw:SetScript("OnClick", onClick)
    function sw:Paint(on)
        self.knob:ClearAllPoints()
        self.knob:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        local tc, kc = on and C.accent or C.border, on and C.white or C.mute
        self.track:SetColorTexture(tc[1], tc[2], tc[3])
        self.knob:SetColorTexture(kc[1], kc[2], kc[3])
    end
    return sw
end
-- case à cocher d'un réglage booléen de /tlc
local function lootCheck(row, key)
    local b = CreateFrame("Button", nil, row)
    b:SetSize(16, 16)
    b:SetPoint("RIGHT", -4, 0)
    ns.Fill(b, C.input)
    ns.Border(b, C.border)
    b.mark = ns.Tex(b, C.accent, "OVERLAY")
    b.mark:SetPoint("TOPLEFT", 3, -3)
    b.mark:SetPoint("BOTTOMRIGHT", -3, 3)
    b:SetScript("OnClick", function() local a = lootAp() a[key] = not a[key] row:Update() ns:LootRefresh() end)
    b:SetScript("OnEnter", function(self) ns.SetBorderColor(self, C.hl) end)
    b:SetScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) end)
    function row:Update() b.mark:SetShown(lootAp()[key] and true or false) end
    return b
end
-- bouton à confirmer : 1er clic « Confirm » pendant 2 s, 2e clic = action
local function confirmButton(parent, text, w, onConfirm)
    local b = ns.Button(parent, text, w, 24)
    b.text = text
    b:SetScript("OnClick", function(self)
        if not self.armed then
            self.armed = true
            self.label:SetText(L("Confirm"))
            C_Timer.After(2, function() self.armed = nil self.label:SetText(L(self.text)) end)
            return
        end
        self.armed = nil
        onConfirm()
    end)
    return b
end

-- Fenêtre Settings de /tlc : onglets Appearance (apparence de cette fenêtre, réglages par défaut, publication pour la
-- guilde) et Admin (officiers : listes de réactions visibles par tous) ; déplaçable par sa barre de titre
local SET_ROWS = 14
function ns:LootSettings()
    local w = lc.setWin
    if w and w:IsShown() then w:Hide() return end
    if not w then
        w = CreateFrame("Frame", nil, lc.win)
        w:SetFrameLevel(lc.win:GetFrameLevel() + 40)
        w:SetSize(380, 60 + SET_ROWS * 30 + 48)
        w:SetPoint("TOPRIGHT", lc.win, "TOPRIGHT", -40, -ns.TOP_H - 4)
        w:EnableMouse(true)
        w:SetMovable(true)
        w:SetClampedToScreen(true)
        ns.Fill(w, C.bg, 0.97)
        ns.Border(w, C.hl)
        ns.HighlightBorder(w)
        local bar = CreateFrame("Frame", nil, w)
        bar:SetPoint("TOPLEFT", 1, -1)
        bar:SetPoint("TOPRIGHT", -1, -1)
        bar:SetHeight(28)
        ns.Fill(bar, C.head)
        bar:EnableMouse(true)
        bar:RegisterForDrag("LeftButton")
        bar:SetScript("OnDragStart", function() w:StartMoving() end)
        bar:SetScript("OnDragStop", function() w:StopMovingOrSizing() end)
        w.title = ns.Text(bar, 12.5, 700, C.white)
        w.title:SetPoint("LEFT", 10, 0)
        local close = ns.IconButton(bar, "×", 22, L("Close (Esc)"))
        close:SetPoint("RIGHT", -3, 0)
        close:SetScript("OnClick", function() w:Hide() end)
        -- onglets
        w.tabs, w.pages = {}, {}
        for i, key in ipairs({ "ap", "admin" }) do
            local b = ns.Button(w, L(key == "ap" and "Appearance" or "Admin"), 100, 22)
            b:SetPoint("TOPLEFT", 10 + (i - 1) * 104, -33)
            b:SetScript("OnClick", function() lc.setTab = key ns:LootSettingsFill() end)
            b:HookScript("OnLeave", function(self) ns.SetBorderColor(self, (lc.setTab or "ap") == key and C.hl or C.border) end)
            w.tabs[key] = b
            local pg = CreateFrame("Frame", nil, w)
            pg:SetPoint("TOPLEFT", 0, -60)
            pg:SetPoint("BOTTOMRIGHT", 0, 0)
            pg.n = 0
            w.pages[key] = pg
        end
        w.rows = {}
        local function row(pg, label)
            local r = CreateFrame("Frame", nil, pg)
            r:SetPoint("TOPLEFT", 10, -pg.n * 30)
            r:SetPoint("TOPRIGHT", -10, -pg.n * 30)
            r:SetHeight(28)
            r.label = ns.Text(r, 12, 600)
            r.label:SetPoint("LEFT", 0, 0)
            r.text = label
            pg.n = pg.n + 1
            w.rows[#w.rows + 1] = r
            return r
        end
        local ap = w.pages.ap
        -- image de fond : interrupteur comme dans les Settings
        w.sw = lootSwitch(row(ap, "Background image"), function()
            local a = lootAp() a.bg = not a.bg ns:LootSettingsFill() ns:LootApplyAppearance() ns:LootUpdateBlur()
        end)
        local pct = function(v) return math.floor(v * 100 + 0.5) .. "%" end
        lootSlider(row(ap, "Background opacity"), "bgAlpha", 0, 1, 0.05, pct)
        lootSlider(row(ap, "Indicator bar opacity"), "barAlpha", 0, 1, 0.05, pct)
        lootSlider(row(ap, "Item bars: dark / light"), "itemTone", 0, 1, 0.05, pct)
        lootSlider(row(ap, "Item bars opacity"), "itemAlpha", 0, 1, 0.05, pct)
        lootSlider(row(ap, "Item bars blurred"), "itemBlur", 0, 1, 0.05, pct)
        lootSlider(row(ap, "Item bars size"), "itemScale", 0.5, 1.5, 0.05, pct)
        lootSlider(row(ap, "Names text size"), "nameSize", 9, 15, 0.5, function(v) return tostring(v) end)
        lootSlider(row(ap, "Columns opacity"), "colAlpha", 0, 0.4, 0.02, pct)
        -- objets attribués pas encore échangés : couleur (sélecteur de couleur du jeu) et opacité
        local rc = row(ap, "Not traded color")
        local swc = CreateFrame("Button", nil, rc)
        swc:SetSize(44, 16)
        swc:SetPoint("RIGHT", -4, 0)
        swc.t = ns.Fill(swc, { 1, 1, 1 })
        ns.Border(swc, C.border)
        swc:SetScript("OnClick", function() ns:LootPickColor() end)
        w.swc = swc
        lootSlider(row(ap, "Not traded opacity"), "pendAlpha", 0, 1, 0.05, pct)
        -- taille de la fenêtre /tlc trade
        lootSlider(row(ap, "Trade window size"), "tradeScale", 0.5, 1.5, 0.05, pct)
        -- réactions : objets équipés à la place du loot, différence d'EP (poids de la Bislist)
        lootCheck(row(ap, "Equipped items next to the names"), "showEq")
        lootCheck(row(ap, "EP difference next to the names"), "showEP")
        -- réglages par défaut (ceux publiés par la guilde, sinon ceux d'origine) ; publication (officiers) : écrite au
        -- /reload, l'exe l'envoie à la guilde à sa synchro et elle devient les réglages par défaut de tous
        w.def = ns.Button(ap, L("Default settings"), 150, 24)
        w.def:SetPoint("BOTTOMLEFT", 10, 12)
        w.def:SetScript("OnClick", function()
            ns.db.ui.lootAp = {}
            lootAp()
            ns:LootSettingsFill() ns:LootApplyAppearance() ns:LootRefresh()
        end)
        w.pub = confirmButton(ap, "Publish guild settings", 180, function()
            GuildToolDB.publishReq = GuildToolDB.publishReq or {}
            GuildToolDB.publishReq.tlc = time()
            ReloadUI()
        end)
        w.pub:SetPoint("BOTTOMRIGHT", -10, 12)
        -- Admin : listes de réactions visibles par les joueurs (sinon chacun ne voit que la sienne)
        local adm = w.pages.admin
        w.swAll = lootSwitch(row(adm, "Show the reaction lists to everyone"), function() ns:LootSetShowAll(not db().showAll) end)
        w.admNote = ns.Text(adm, 10.5, 400, C.mute)
        w.admNote:SetPoint("TOPLEFT", 10, -36)
        w.admNote:SetPoint("TOPRIGHT", -10, -36)
        w.admNote:SetWordWrap(true)
        w.admNote:SetJustifyH("LEFT")
        lc.setWin = w
    end
    ns.LootWatchList(w)
    w:Show()
    self:LootSettingsFill()
end
function ns:LootSettingsFill()
    local w, a = lc.setWin, lootAp()
    if not w then return end
    local officer = iAmOfficer()
    if not officer then lc.setTab = "ap" end
    local tab = lc.setTab or "ap"
    ns.SetFont(w.title, 12.5, 700)
    w.title:SetText(L("Loot window settings"))
    for key, b in pairs(w.tabs) do
        ns.SetFont(b.label, 11.5, 600)
        b.label:SetText(L(key == "ap" and "Appearance" or "Admin"))
        ns.SetBorderColor(b, tab == key and C.hl or C.border)
        local c = tab == key and C.white or C.mute
        b.label:SetTextColor(c[1], c[2], c[3])
        w.pages[key]:SetShown(tab == key)
    end
    w.tabs.admin:SetShown(officer)
    for _, r in ipairs(w.rows) do
        ns.SetFont(r.label, 12, 600)
        r.label:SetText(L(r.text))
        if r.Update then r:Update() end
    end
    local pc = a.pendColor
    w.swc.t:SetColorTexture(pc[1], pc[2], pc[3])
    w.sw:Paint(a.bg)
    w.swAll:Paint(db().showAll)
    for _, b in ipairs({ w.def, w.pub }) do
        ns.SetFont(b.label, 11.5, 600)
        if not b.armed then b.label:SetText(L(b.text or "Default settings")) end
    end
    w.pub:SetShown(officer)
    ns.SetFont(w.admNote, 10.5, 400)
    w.admNote:SetText(L("Off: each player only sees his own reaction (the officers see everything)."))
end
-- (officiers) listes de réactions visibles par tous ou non : envoyé au raid
function ns:LootSetShowAll(on)
    if not iAmOfficer() then return end
    local d = db()
    d.showAll, d.showAllT = on and true or false, time()
    send("V", { on = d.showAll, t = d.showAllT })
    self:LootSettingsFill()
    self:LootRefresh()
end

-- couleur des objets attribués pas encore échangés : sélecteur de couleur du jeu (Annuler = couleur d'avant)
function ns:LootPickColor()
    local a = lootAp()
    local old = { a.pendColor[1], a.pendColor[2], a.pendColor[3] }
    local function apply(r, g, b)
        a.pendColor = { r, g, b }
        ns:LootSettingsFill()
        ns:LootRefresh()
    end
    local function picked() apply(ColorPickerFrame:GetColorRGB()) end
    local function cancel() apply(old[1], old[2], old[3]) end
    if ColorPickerFrame.SetupColorPickerAndShow then
        ColorPickerFrame:SetupColorPickerAndShow({ r = old[1], g = old[2], b = old[3], hasOpacity = false,
                                                   swatchFunc = picked, cancelFunc = cancel })
    else
        ColorPickerFrame.hasOpacity = false
        ColorPickerFrame.func, ColorPickerFrame.cancelFunc = picked, cancel
        ColorPickerFrame:SetColorRGB(old[1], old[2], old[3])
        ColorPickerFrame:Hide()
        ColorPickerFrame:Show()
    end
end

-- Objets attribués pas encore échangés (/tlc trade) : temps restant, objet, receveur, Trade / oublier
function ns:LootTradeWindow()
    local w = lc.tradeWin
    if w and w:IsShown() then w:Hide() return end
    if not w then
        w = CreateFrame("Frame", "GuildToolLootTrades", UIParent)
        w:SetSize(456, 100)
        w:SetPoint("CENTER", 0, 140)
        -- devant /tlc (strate HIGH) : sinon cachée derrière quand elle s'ouvre
        w:SetFrameStrata("DIALOG")
        w:SetToplevel(true)
        w:SetClampedToScreen(true)
        w:EnableMouse(true)
        w:SetMovable(true)
        w:SetScale(lootAp().tradeScale)
        tinsert(UISpecialFrames, "GuildToolLootTrades")
        ns.Fill(w, C.bg, 0.97)
        ns.Border(w, C.hl)
        local bar = CreateFrame("Frame", nil, w)
        bar:SetPoint("TOPLEFT", 1, -1)
        bar:SetPoint("TOPRIGHT", -1, -1)
        bar:SetHeight(28)
        ns.Fill(bar, C.head)
        bar:EnableMouse(true)
        bar:RegisterForDrag("LeftButton")
        bar:SetScript("OnDragStart", function() w:StartMoving() end)
        bar:SetScript("OnDragStop", function() w:StopMovingOrSizing() end)
        w.title = ns.Text(bar, 12.5, 700, C.white)
        w.title:SetPoint("LEFT", 10, 0)
        local close = ns.IconButton(bar, "×", 22, L("Close (Esc)"))
        close:SetPoint("RIGHT", -3, 0)
        close:SetScript("OnClick", function() w:Hide() end)
        w.empty = ns.Text(w, 11.5, 500, C.mute)
        w.empty:SetPoint("TOPLEFT", 12, -42)
        w.rows = {}
        w:SetScript("OnUpdate", function(self, el)
            self.tick = (self.tick or 0) + el
            if self.tick < 1 then return end
            self.tick = 0
            for _, r in ipairs(self.rows) do
                if r:IsShown() then r.timer:SetText(r.tradeEnd and fmtLeft(r.tradeEnd - time()) or "") end
            end
        end)
        lc.tradeWin = w
    end
    w:Show()
    self:LootTradeFill()
    if not w:IsShown() then print("|cff6f7cffGuildTool|r: " .. L("Every attributed item has been traded.")) end
end
-- ouvre /tlc trade (sans la refermer si elle est déjà ouverte)
function ns:LootTradeShow()
    if lc.tradeWin and lc.tradeWin:IsShown() then self:LootTradeFill() else self:LootTradeWindow() end
end
function ns:LootTradeFill()
    local w = lc.tradeWin
    if not (w and w:IsShown()) then return end
    -- mes objets attribués / à donner au Loot Dealer ; (Loot Dealer) objets demandés à leur porteur, à recevoir
    local list = {}
    for _, it in pairs(db().items) do
        if not it.traded and not it.vendor and ((it.owner == me() and (it.attrib or it.give)) or (it.ask and it.owner ~= me())) then
            list[#list + 1] = it
        end
    end
    if #list == 0 then w:Hide() return end
    table.sort(list, function(a, b) return (a.tradeEnd or math.huge) < (b.tradeEnd or math.huge) end)
    ns.SetFont(w.title, 12.5, 700)
    w.title:SetText(L("Not traded yet"))
    for i, it in ipairs(list) do
        local r = w.rows[i]
        if not r then
            r = CreateFrame("Button", nil, w)
            r:SetHeight(28)
            r.fill = ns.Fill(r, C.panel, 0.9)
            ns.Border(r, C.border)
            r:SetScript("OnClick", function(self) ns:LootTradeWith(self.target) end)
            r:SetScript("OnEnter", function(self) ns.SetBorderColor(self, C.hl) end)
            r:SetScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) end)
            r.timer = ns.Text(r, 11, 700, BLUE)
            r.timer:SetPoint("LEFT", 4, 0)
            r.timer:SetWidth(28)
            r.timer:SetJustifyH("RIGHT")
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(22, 22)
            r.icon:SetPoint("LEFT", 38, 0)
            r.name = ns.Text(r, 11.5, 700)
            r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
            r.name:SetWidth(178)
            r.name:SetJustifyH("LEFT")
            r.name:SetWordWrap(false)
            r.to = ns.Text(r, 11.5, 700)
            r.to:SetPoint("LEFT", r.name, "RIGHT", 6, 0)
            r.to:SetWidth(170)
            r.to:SetJustifyH("LEFT")
            r.to:SetWordWrap(false)
            r.forget = ns.IconButton(r, "×", 22, L("Forget (the attribution stays in the database)"))
            r.forget:SetPoint("RIGHT", -4, 0)
            r.forget:SetScript("OnClick", function()
                local it = db().items[r.key]
                -- don / demande oubliés : l'objet reste ; attribution : oubliée (elle reste dans la base)
                if it and it.give and not it.attrib then it.give = nil elseif it and it.ask then it.ask = nil else db().items[r.key] = nil end
                ns:LootTradeFill() ns:LootRefresh()
            end)
            w.rows[i] = r
        end
        local incoming = it.owner ~= me()
        r.key, r.tradeEnd, r.target = it.key, tradeEndOf(it), incoming and it.owner or (it.attrib or it.give)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 8, -36 - (i - 1) * 30)
        r:SetPoint("TOPRIGHT", -8, -36 - (i - 1) * 30)
        ns.SetFont(r.timer, 11, 700)
        r.timer:SetText(fmtLeft(r.tradeEnd - time()))
        r.timer:SetTextColor(BLUE[1], BLUE[2], BLUE[3])
        r.icon:SetTexture(it.icon or (it.id and GetItemIcon and GetItemIcon(it.id)) or 134400)
        local qc = ITEM_QUALITY_COLORS and it.q and ITEM_QUALITY_COLORS[it.q] or { r = 1, g = 1, b = 1 }
        ns.SetFont(r.name, 11.5, 700)
        r.name:SetText(truncChars(it.name or "?", 26))
        r.name:SetTextColor(qc.r, qc.g, qc.b)
        local cc = ns.ClassColor((classOf(r.target)))
        ns.SetFont(r.to, 11.5, 700)
        r.to:SetText((incoming and "← " or "→ ") .. truncChars(shortName(r.target), 26) .. ((it.give and not it.attrib and not incoming) and " |cff9a9aa2(Loot Dealer)|r" or ""))
        r.to:SetTextColor(cc[1], cc[2], cc[3])
        r:Show()
    end
    for i = #list + 1, #w.rows do w.rows[i]:Hide() end
    ns.SetFont(w.empty, 11.5, 500)
    w.empty:SetText(#list == 0 and L("Every attributed item has been traded.") or "")
    w:SetHeight(44 + math.max(1, #list) * 30)
end

-- Historique d'un objet (clic sur ×N) : qui l'a reçu et quand ; fermé à l'attribution de l'objet
function ns:LootReceivedBy(anchor, key, id)
    local w = lc.histWin
    if w and w:IsShown() and lc.histKey == key then w:Hide() return end
    if not w then
        w = CreateFrame("Frame", nil, lc.win)
        w:SetFrameLevel(lc.win:GetFrameLevel() + 45)
        w:SetWidth(220)
        w:EnableMouse(true)
        ns.Fill(w, C.bg, 0.97)
        ns.Border(w, C.hl)
        w.title = ns.Text(w, 11.5, 700, C.white)
        w.title:SetPoint("TOPLEFT", 8, -7)
        w.title:SetPoint("RIGHT", -26, 0)
        local close = ns.IconButton(w, "×", 18)
        close:SetPoint("TOPRIGHT", -2, -2)
        close:SetScript("OnClick", function() w:Hide() end)
        w.text = ns.Text(w, 11.5, 600)
        w.text:SetPoint("TOPLEFT", 8, -26)
        w.text:SetWidth(204)
        w.text:SetWordWrap(true)
        w.text:SetJustifyV("TOP")
        hideWhenLeft(w)
        lc.histWin = w
    end
    ns.LootWatchList(w)
    local lines = {}
    for _, r in ipairs(ns.LootRecords and ns:LootRecords() or {}) do
        if r.id == id then
            local c = ns.ClassColor(ns.db.roster and ns.db.roster[r.to] and ns.db.roster[r.to].c)
            lines[#lines + 1] = ("|cff9a9ea9%s|r  |cff%02x%02x%02x%s|r"):format(date("%d/%m", r.t or 0), c[1] * 255, c[2] * 255, c[3] * 255, r.to or "?")
        end
    end
    lc.histKey = key
    w:ClearAllPoints()
    w:SetPoint("TOPRIGHT", anchor, "TOPLEFT", -4, 0)
    ns.SetFont(w.title, 11.5, 700)
    w.title:SetText(L("Received by"))
    ns.SetFont(w.text, 11.5, 600)
    w.text:SetText(#lines > 0 and table.concat(lines, "\n") or ("|cff9a9ea9" .. L("Nobody yet.") .. "|r"))
    w:SetHeight(34 + math.max(1, #lines) * 15)
    w:Show()
end

-- PUSH reçu : popup « Loot Council has been pushed » (See / croix / Échap), comme la liste de Raid Comps
function ns:LootPushPopup(from)
    local p = lc.pushPop
    if not p then
        p = CreateFrame("Frame", "GuildToolLootPush", UIParent)
        p:SetSize(300, 104)
        p:SetPoint("TOP", 0, -150)
        p:SetFrameStrata("DIALOG")
        p:EnableMouse(true)
        tinsert(UISpecialFrames, "GuildToolLootPush")
        local ap = ns.db.appearance or {}
        p.blur = p:CreateTexture(nil, "BACKGROUND", nil, -7)
        p.blur:SetAllPoints()
        p.blur:SetTexture(MEDIA .. "bg_window_blur")
        p.fill = ns.Fill(p, C.side)
        ns.Border(p, C.hl)
        p.title = ns.Text(p, 13, 700, C.white)
        p.title:SetPoint("TOP", 0, -18)
        p.from = ns.Text(p, 11, 500, C.mute)
        p.from:SetPoint("TOP", p.title, "BOTTOM", 0, -4)
        local close = ns.IconButton(p, "×", 22)
        close:SetPoint("TOPRIGHT", -3, -3)
        close:SetScript("OnClick", function() p:Hide() end)
        p.see = ns.Button(p, L("See"), 120, 26, true)
        p.see:SetPoint("BOTTOM", 0, 12)
        p.see:SetScript("OnClick", function() p:Hide() if not (lc.win and lc.win:IsShown()) then ns:ToggleLoot() end end)
        lc.pushPop = p
    end
    -- apparence de la liste de Raid Comps : List/Tab Blurred et opacité
    local ap = ns.db.appearance or {}
    p.blur:SetShown(ap.bg and (ap.listGlass or 0) > 0)
    p.blur:SetAlpha((ap.bgAlpha or 0.6) * (ap.listGlass or 0))
    p.fill:SetAlpha(math.max(0.35, ap.tabsAlpha or 1))
    ns.SetFont(p.title, 13, 700)
    p.title:SetText(L("Loot Council has been pushed"))
    if PixelUtil then
        PixelUtil.SetSize(p, 300, 104)
        PixelUtil.SetPoint(p, "TOP", UIParent, "TOP", 0, -150)
    end
    ns.PixelEdges(p)
    ns.SetFont(p.from, 11, 500)
    p.from:SetText(from or "")
    ns.SetFont(p.see.label, 11.5, 600)
    p.see.label:SetText(L("See"))
    p:Show()
end
function ns:LootPush()
    lastSig = nil
    self:LootScan(true)
    self:LootSendState()
    local n = 0
    for _, it in pairs(db().items) do if it.owner == me() and not it.traded then n = n + 1 end end
    lc.pushAck = { t = time(), n = n, got = {} }
    send("PUSH", { n = n })
end
-- survol de PUSH : joueurs du groupe qui n'ont pas répondu au dernier envoi
local function pushTooltip(b)
    local a = lc.pushAck
    if not a then return end
    local missing = {}
    for i = 1, GetNumGroupMembers() do
        local unit = IsInRaid() and ("raid" .. i) or (i == 1 and "player" or "party" .. (i - 1))
        local name = UnitName(unit)
        if name and first(name) ~= first(me()) then
            local ok = false
            for p in pairs(a.got) do if first(p) == first(name) then ok = true break end end
            if not ok then missing[#missing + 1] = name end
        end
    end
    table.sort(missing)
    ns.TipOwner(b)
    GameTooltip:SetText(L("Push · {0}", date("%H:%M", a.t)), 1, 1, 1)
    if #missing == 0 then
        GameTooltip:AddLine(L("Everyone received it."), 0.3, 0.85, 0.45)
    else
        GameTooltip:AddLine(L("{0} player(s) did not receive it:", #missing), 1, 0.42, 0.42)
        for _, p in ipairs(missing) do GameTooltip:AddLine(p, 0.85, 0.85, 0.85) end
    end
    GameTooltip:Show()
end
ns.LootPushTooltip = pushTooltip

-- listes ouvertes (objets des sacs, couleurs, réglages) : refermées par un clic ailleurs dans la fenêtre
function ns:LootCloseLists()
    for _, w in ipairs({ lc.bagList, lc.colWin, lc.setWin, lc.histWin }) do if w then w:Hide() end end
    if lc.win then lc.win.catcher:Hide() end
    if lc.out then lc.out:Hide() end
end
-- clic en dehors de la fenêtre (écran) : listes refermées aussi
local function outCatcher()
    if not lc.out then
        local c = CreateFrame("Button", nil, UIParent)
        c:SetAllPoints(UIParent)
        c:SetFrameStrata("MEDIUM")
        c:SetFrameLevel(500)
        c:RegisterForClicks("AnyUp")
        c:SetScript("OnClick", function() ns:LootCloseLists() end)
        c:Hide()
        lc.out = c
    end
    return lc.out
end
local function watchList(w)
    if not w or w.watched then return end
    w.watched = true
    w:HookScript("OnShow", function() lc.win.catcher:Show() outCatcher():Show() end)
    w:HookScript("OnHide", function()
        local open = false
        for _, x in ipairs({ lc.bagList, lc.colWin, lc.setWin, lc.histWin }) do if x and x:IsShown() then open = true end end
        if not open then lc.win.catcher:Hide() outCatcher():Hide() end
    end)
end
ns.LootWatchList = watchList

function ns:ToggleLoot()
    if not ns.db then return end
    local f = lc.win or createWindow()
    if f:IsShown() then f:Hide() return end
    f:Show()
    lastSig = nil
    self:LootScan(true)
    self:LootRefresh()
    C_Timer.After(0.05, function() ns:LootRefresh() end)   -- polices pas toujours prêtes au premier affichage
end

---------------------------------------------------------------------------
-- Événements
---------------------------------------------------------------------------
SLASH_GUILDTOOLLC1 = "/tlc"
SlashCmdList.GUILDTOOLLC = function(msg)
    if strlower(strtrim(msg or "")) == "trade" then ns:LootTradeWindow() else ns:ToggleLoot() end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("CHAT_MSG_SYSTEM")
ev:RegisterEvent("BAG_UPDATE_DELAYED")
ev:RegisterEvent("TRADE_SHOW")
ev:RegisterEvent("TRADE_CLOSED")
ev:RegisterEvent("MERCHANT_SHOW")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("LOOT_OPENED")
ev:RegisterEvent("ENCOUNTER_END")
local scanTimer, wasGrouped
ev:SetScript("OnEvent", function(_, event, a1, a2, a3, a4, a5)
    if not ns.db then return end
    if event == "PLAYER_ENTERING_WORLD" then
        C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
        -- vieux objets oubliés (échangés ou attribués depuis plus de 6 h) retirés
        local d, now = db(), time()
        for key, it in pairs(d.items) do
            -- attribués pas encore échangés (les miens) : gardés jusqu'à l'échange (ou oubliés dans /tlc trade)
            local keep = it.owner == me() and it.attrib and not it.traded and not it.vendor
            if not keep and ((it.traded and now - (it.tradedT or it.t or 0) > 6 * 3600) or now - (it.t or 0) > 12 * 3600) then
                d.items[key], d.reactions[key], d.sugg[key], d.rolls[key] = nil, nil, nil, nil
            end
        end
        -- temps d'échange des objets (ligne bleue) relu au prochain scan : il s'écoule aussi hors ligne
        lc.rescanTrade = true
        -- client prêt : signal « UP » au raid, les officiers renvoient l'état connu
        C_Timer.After(4, function() if channel() then send("UP", {}) end ns:LootScan(true) end)
    elseif event == "GROUP_ROSTER_UPDATE" then
        local g = IsInGroup()
        if g and not wasGrouped then C_Timer.After(2, function() send("UP", {}) end) end
        wasGrouped = g
    elseif event == "CHAT_MSG_ADDON" then
        if a1 == PREFIX then onChunk(a2, a4) end
    elseif event == "CHAT_MSG_SYSTEM" then
        onSystem(a1)
    elseif event == "LOOT_OPENED" then
        onLootOpened()
    elseif event == "ENCOUNTER_END" then
        -- a5 : réussite (ENCOUNTER_END id, nom, difficulté, taille, réussite)
        if a5 == 1 then lastBoss = { name = a2, t = time() } end
    elseif event == "BAG_UPDATE_DELAYED" then
        if scanTimer then scanTimer:Cancel() end
        scanTimer = C_Timer.NewTimer(0.5, function() scanTimer = nil ns:LootScan() end)
    elseif event == "TRADE_SHOW" then
        C_Timer.After(0.2, fillTrade)
    elseif event == "MERCHANT_SHOW" then
        -- objets attribués « Vendre » : vendus au marchand
        for key, it in pairs(db().items) do
            if it.owner == me() and it.vendor and not it.traded then
                for bag = 0, NUM_BAG_SLOTS or 4 do
                    for slot = 1, bagSlots(bag) do
                        local link = bagLink(bag, slot)
                        if link and itemGuid(bag, slot, link) == key then
                            local use = C_Container and C_Container.UseContainerItem or UseContainerItem
                            use(bag, slot)
                        end
                    end
                end
            end
        end
        C_Timer.After(1.5, function() ns:LootScan() end)
    elseif event == "TRADE_CLOSED" then
        C_Timer.After(1.5, function() ns:LootScan() end)
    end
end)
