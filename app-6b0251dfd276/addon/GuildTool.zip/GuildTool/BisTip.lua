-- GuildTool : infobulle des objets de raid — en bas, l'EP de chaque spé de la classe jouée (poids de la Bislist de
-- l'exe) et le meilleur set Bis qui contient l'objet (Bis avant Bis 2…) ; rien si la Bislist ne connaît pas l'objet.
-- Données : Import.lua « bisTip » = { [objet] = { [CLASSE] = { { s = spé, e = EP, b = set }, … } } } (exe _bis_tip).
local _, ns = ...
local L = function(...) return ns.L(...) end

local function itemId(tt, data)
    if data and data.id then return data.id end
    local _, link = tt:GetItem()
    return link and tonumber(link:match("item:(%d+)"))
end

local function addLines(tt, data)
    if not (ns.db and ns.db.bisTip) or tt.gtBisDone then return end
    local id = itemId(tt, data)
    local _, cls = UnitClass("player")
    local rows = id and ns.db.bisTip[tostring(id)] and ns.db.bisTip[tostring(id)][cls]
    if not rows or #rows == 0 then return end
    tt.gtBisDone = true
    tt:AddLine(" ")
    tt:AddLine("Guild Tool · Bislist", 0.435, 0.486, 1)
    for _, r in ipairs(rows) do
        local right = (r.e and (r.e .. " EP") or "") .. (r.b and ((r.e and "  ·  " or "") .. r.b) or "")
        tt:AddDoubleLine(L(r.s), right, 0.8, 0.8, 0.8, r.b and 1 or 0.85, r.b and 0.82 or 0.85, r.b and 0.25 or 0.85)
    end
    tt:Show()
end

-- client moderne : TooltipDataProcessor ; sinon OnTooltipSetItem
if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data) if tt and tt.AddLine then addLines(tt, data) end end)
else
    for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
        if tt then
            tt:HookScript("OnTooltipSetItem", function(t) addLines(t) end)
        end
    end
end
-- une seule fois par affichage
for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
    if tt then tt:HookScript("OnTooltipCleared", function(t) t.gtBisDone = nil end) end
end
