-- GuildTool : page Members (tous les persos de la guilde, métiers, équipement, loot RCLootCouncil)
local _, ns = ...
local C = ns.C

local ROW_H, HEAD_H, DETAIL_H, PAD = 26, 24, 392, 10
local CLASS_ICONS = "Interface\\TargetingFrame\\UI-Classes-Circles"

---------------------------------------------------------------------------
-- Données
---------------------------------------------------------------------------
-- Nom affiché sur Discord (Raid-Helper) de chaque tag : le plus récent
local function discordNames()
    local names, when = {}, {}
    for _, ev in ipairs(ns.db.events) do
        for _, s in ipairs(ev.signups or {}) do
            local tag = ns:ResolveTag(s)
            if tag and s.n and (ev.start or 0) >= (when[tag] or 0) then names[tag], when[tag] = s.n, ev.start or 0 end
        end
    end
    return names
end

ns.DiscordNames = discordNames

-- Spés vues dans les inscriptions importées, par perso (un seul passage)
local function signupSpecs()
    local out = {}
    for _, ev in ipairs(ns.db.events) do
        for _, su in ipairs(ev.signups or {}) do
            if su.s and su.st ~= "absence" then
                local char = ns:SignupChar(su, ns:ResolveTag(su))
                if char then
                    out[char] = out[char] or {}
                    table.insert(out[char], su.s)
                end
            end
        end
    end
    return out
end

-- Jusqu'à 2 spés connues : choix manuel, historique des inscriptions (exe), inscriptions importées
local function knownSpecs(name, fromSignups)
    local out, seen = {}, {}
    local function add(s)
        if s and not seen[s] and #out < 2 then seen[s] = true out[#out + 1] = s end
    end
    add(ns.db.specs[name])
    for _, s in ipairs((ns.db.charSpecs or {})[name] or {}) do add(s) end
    add((ns.db.importSpecs or {})[name])
    for _, s in ipairs(fromSignups[name] or {}) do add(s) end
    return out
end

-- Spés relevées dans les talents (arbre le plus rempli de chaque spé de talents, l'active d'abord, sans doublon)
local function talentSpecs(class, info)
    local names, out, seen = ns.TALENT_SPECS[class or ""], {}, {}
    if not names then return out end
    local specs = {}
    for _, s in ipairs((info or {}).talents or {}) do
        if s.active then table.insert(specs, 1, s) else specs[#specs + 1] = s end
    end
    for _, s in ipairs(specs) do
        local best, bi = 0, nil
        for ti, tt in ipairs(s.tabs or {}) do if (tt.p or 0) > best then best, bi = tt.p, ti end end
        local spec = bi and names[bi]
        if spec and not seen[spec] and #out < 2 then seen[spec] = true out[#out + 1] = spec end
    end
    return out
end

function ns:MembersUnits()
    local list, dn, fromSignups = {}, discordNames(), signupSpecs()
    local main = self.db.mainSpecs or {}
    for name, r in pairs(self.db.roster) do
        -- anciennes versions : infos rangées sous le prénom seul (« Sundance » pour « Sundance Pal »)
        local info = self.db.chars[name] or self.db.chars[name:match("^(%S+)") or name]
        -- spé de référence (tri, loot...) : Event Class (exe), sinon spé connue ; spés affichées : celles des talents
        local detected = talentSpecs(r.c, info)
        local spec = main[name] or knownSpecs(name, fromSignups)[1] or detected[1]
        list[#list + 1] = {
            name = name, display = name, class = r.c, level = r.l or 0, tag = r.tag, discord = r.tag and dn[r.tag],
            specs = #detected > 0 and detected or { spec }, spec = spec, role = ns.RoleOf(r.c, spec), info = info,
        }
    end
    return list
end

---------------------------------------------------------------------------
-- Volet de détails : équipement + historique de loot
---------------------------------------------------------------------------
local function qualityColor(q)
    local c = q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
    if c then return c.r, c.g, c.b end
    return 1, 1, 1
end

local attFrame   -- présence : défini plus bas
-- icône d'objet avec cadre de la couleur de sa qualité (visible à toutes les échelles)
local function qualityIcon(b)
    b.qbg = b:CreateTexture(nil, "BACKGROUND")
    b.qbg:SetAllPoints()
    b.qbg:SetColorTexture(0.22, 0.23, 0.26, 1)
    b.tex = b:CreateTexture(nil, "ARTWORK")
    b.tex:SetPoint("TOPLEFT", 1, -1)
    b.tex:SetPoint("BOTTOMRIGHT", -1, 1)
    b.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
end
local function setQuality(b, q)
    if q then
        local r, g, bl = qualityColor(q)
        b.qbg:SetColorTexture(r, g, bl, 1)
    else
        b.qbg:SetColorTexture(0.22, 0.23, 0.26, 1)
    end
end

local function createDetail(parent)
    local d = CreateFrame("Frame", nil, parent)
    d:SetHeight(DETAIL_H)
    ns.Fill(d, C.panel, 0.9)
    ns.Border(d, C.border)
    d.gearTitle = ns.Text(d, 10, 700, C.mute)
    d.gearTitle:SetPoint("TOPLEFT", 12, -10)
    -- équipement disposé comme la fenêtre de personnage
    local SZ, STEP, RIGHT_X = 28, 31, 202
    local pos = {}
    for i, slot in ipairs(ns.GEAR_LEFT) do pos[slot] = { 12, -28 - (i - 1) * STEP } end
    for i, slot in ipairs(ns.GEAR_RIGHT) do pos[slot] = { RIGHT_X, -28 - (i - 1) * STEP } end
    local bx = 12 + (RIGHT_X + SZ - 12 - 3 * STEP) / 2
    for i, slot in ipairs(ns.GEAR_BOTTOM) do pos[slot] = { bx + (i - 1) * STEP, -28 - 8 * STEP - 4 } end
    d.gear = {}
    for i, slot in ipairs(ns.GEAR_SLOTS) do
        local b = CreateFrame("Button", nil, d)
        b:SetSize(SZ, SZ)
        b:SetPoint("TOPLEFT", pos[slot][1], pos[slot][2])
        qualityIcon(b)
        b.slot = slot
        b:SetScript("OnEnter", function(self)
            if not self.itemID then return end
            ns.TipOwner(self)
            GameTooltip:SetItemByID(self.itemID)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", GameTooltip_Hide)
        d.gear[i] = b
    end
    -- note entre les deux colonnes (là où serait le personnage)
    d.gearNote = ns.Text(d, 10.5, 400, C.mute)
    d.gearNote:SetPoint("TOP", d, "TOPLEFT", (12 + SZ + RIGHT_X) / 2, -120)
    d.gearNote:SetWidth(RIGHT_X - 12 - SZ - 16)
    d.gearNote:SetWordWrap(true)
    d.gearNote:SetJustifyH("CENTER")
    -- sets du gestionnaire d'équipement (à droite de l'équipement)
    d.setsTitle = ns.Text(d, 10, 700, C.mute)
    d.setsTitle:SetPoint("TOPLEFT", 270, -10)
    local ss = ns.ScrollArea(d)
    ss:SetPoint("TOPLEFT", 266, -26)
    ss:SetPoint("BOTTOMLEFT", 266, 8)
    ss:SetWidth(222)
    ss.child:SetWidth(214)
    d.sets, d.setRows = ss, {}
    -- talents seulement : Spec 1 / Spec 2 (plus d'historique RCLootCouncil)
    d.tabs = {}
    for i, key in ipairs({ 1, 2 }) do
        local b = CreateFrame("Button", nil, d)
        b:SetHeight(16)
        b.label = ns.Text(b, 15, 700, C.mute)
        b.label:SetPoint("LEFT")
        b.small = ns.Text(b, 7.5, 700, C.mute)
        b.role = b:CreateTexture(nil, "ARTWORK")
        b.role:SetSize(16, 16)
        b.role:SetPoint("RIGHT", b.label, "LEFT", -5, 0)
        b.small:SetPoint("LEFT", b.label, "RIGHT", 4, -1)
        b.line = ns.Tex(b, C.hl, "ARTWORK")
        b.line:SetPoint("BOTTOMLEFT", 0, -2) b.line:SetPoint("BOTTOMRIGHT", 0, -2) b.line:SetHeight(2)
        b.key = key
        b:SetScript("OnClick", function(self) ns.memberSpec = self.key ns:RefreshMembers() end)
        d.tabs[i] = b
    end
    d.tabs[1]:SetPoint("TOPLEFT", 534, -14)
    d.tabs[2]:SetPoint("LEFT", d.tabs[1], "RIGHT", 18, 0)
    for _, b in ipairs(d.tabs) do b:SetHeight(20) end
    d.noSpec2 = ns.Text(d, 10, 500, C.mute)
    d.noSpec2:SetPoint("LEFT", d.tabs[2], "RIGHT", 12, 0)
    local sf = ns.ScrollArea(d)
    sf:SetPoint("TOPLEFT", 502, -26)
    sf:SetPoint("BOTTOMRIGHT", -8, 8)
    sf.child:SetWidth(860)
    d.loot = sf
    d.lines = {}
    d.empty = ns.Text(sf.child, 11, 400, C.mute)
    d.empty:SetPoint("TOPLEFT", 4, -4)
    d.talents = CreateFrame("Frame", nil, d)
    d.talents:SetPoint("TOPLEFT", 512, -38)
    d.talents:SetPoint("BOTTOMRIGHT", -222, 8)
    d.talents.cells, d.talents.heads, d.talents.trees = {}, {}, {}
    d.talents.head = ns.Text(d.talents, 10, 700, C.mute)
    d.talents.head:SetPoint("TOPLEFT", 2, -2)
    d.talents.empty = ns.Text(d.talents, 11, 400, C.mute)
    d.talents.empty:SetPoint("TOPLEFT", 4, -4)
    -- présence (à droite)
    d.att = attFrame(d)
    d.att:SetPoint("TOPRIGHT", -16, -8)
    d.att:SetHeight(300)
    -- cadre des talents : même opacité / flou que la présence (Settings > Char details opac/blur)
    d.tpanel = CreateFrame("Frame", nil, d)
    d.tpanel:SetPoint("TOPLEFT", 502, -8)
    d.tpanel:SetSize(400, 200)
    d.tpanel:SetFrameLevel(d:GetFrameLevel() + 1)
    d.tpanel.fill = ns.Fill(d.tpanel, C.panel, 0.22)
    ns.Border(d.tpanel, C.border)
    d.talents:SetFrameLevel(d.tpanel:GetFrameLevel() + 1)
    for _, b in ipairs(d.tabs) do b:SetFrameLevel(d.tpanel:GetFrameLevel() + 2) end
    -- image de fond choisie par le joueur pour ce perso (envoyée depuis l'appli) ; case « Hide picture » (autres joueurs)
    d.pic = d:CreateTexture(nil, "BACKGROUND", nil, 2)
    d.pic:SetAllPoints()
    d.pic:Hide()
    -- version floutée (écrite par l'exe) mélangée à la nette : « Custom Background opac/blur »
    d.picBlur = d:CreateTexture(nil, "BACKGROUND", nil, 3)
    d.picBlur:SetAllPoints()
    d.picBlur:Hide()
    local hb = CreateFrame("Button", nil, d)
    hb:SetSize(110, 18)
    hb:SetPoint("BOTTOMLEFT", 12, 8)
    hb.box = ns.Tex(hb, C.input, "ARTWORK")
    hb.box:SetSize(12, 12)
    hb.box:SetPoint("LEFT", 0, 0)
    hb.edges = ns.Border(hb, C.border, 0)
    hb.check = ns.Tex(hb, C.hl, "OVERLAY")
    hb.check:SetSize(8, 8)
    hb.check:SetPoint("CENTER", hb.box, "CENTER")
    hb.label = ns.Text(hb, 10, 600, C.mute)
    hb.label:SetPoint("LEFT", hb.box, "RIGHT", 6, 0)
    hb:SetScript("OnClick", function(self)
        ns.db.ui.hideCharImg = ns.db.ui.hideCharImg or {}
        ns.db.ui.hideCharImg[self.char] = not ns.db.ui.hideCharImg[self.char] or nil
        ns:RefreshMembers()
    end)
    d.picHide = hb
    return d
end

-- rôle de chaque arbre de talents (ordre de la fenêtre de talents)
local TREE_ROLE = { WARRIOR = { "Melee", "Melee", "Tank" }, PALADIN = { "Healer", "Tank", "Melee" }, HUNTER = { "Ranged", "Ranged", "Ranged" },
    ROGUE = { "Melee", "Melee", "Melee" }, PRIEST = { "Healer", "Healer", "Ranged" }, SHAMAN = { "Ranged", "Melee", "Healer" },
    MAGE = { "Ranged", "Ranged", "Ranged" }, WARLOCK = { "Ranged", "Ranged", "Ranged" }, DRUID = { "Ranged", "Tank", "Healer" } }

-- Sets : nom puis icônes des objets, ordre logique : tête, cou, épaules, dos, torse, poignets, mains, taille, jambes,
-- pieds ; à la ligne : cou | anneaux | bijoux | armes (0 = petit écart, -1 = ligne suivante)
local SET_ORDER = { 1, 3, 15, 5, 9, 10, 6, 7, 8, -1, 2, 0, 11, 12, 0, 13, 14, 0, 16, 17, 18 }
local function setRow(d, i)
    local r = d.setRows[i]
    if not r then
        r = CreateFrame("Frame", nil, d.sets.child)
        r.name = ns.Text(r, 11.5, 600)
        r.name:SetPoint("TOPLEFT", 2, 0)
        r.icons = {}
        d.setRows[i] = r
    end
    r:Show()
    return r
end

local function fillSets(d, u)
    local sets = (u.info or {}).sets or {}
    d.setsTitle:SetText(strupper(ns.L("Equipment sets")) .. "  ·  " .. #sets)
    local y = 0
    for i, s in ipairs(sets) do
        local r = setRow(d, i)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, -y)
        r:SetPoint("TOPRIGHT", 0, -y)
        r.name:SetText(s.n or "?")
        local k, x, line = 0, 0, 0
        for _, slot in ipairs(SET_ORDER) do
            local id = slot > 0 and s.g and s.g[slot]
            if slot == 0 then x = x + (x > 0 and 8 or 0)
            elseif slot == -1 then line, x = 1, 0
            end
            if id then
                k = k + 1
                local b = r.icons[k]
                if not b then
                    b = CreateFrame("Button", nil, r)
                    b:SetSize(19, 19)
                    qualityIcon(b)
                    b:SetScript("OnEnter", function(self) ns.TipOwner(self) GameTooltip:SetItemByID(self.itemID) GameTooltip:Show() end)
                    b:SetScript("OnLeave", GameTooltip_Hide)
                    r.icons[k] = b
                end
                b.itemID = id
                local _, q, icon = ns:ItemInfo(id)
                b.tex:SetTexture(icon or 134400)
                setQuality(b, q or 1)
                b:ClearAllPoints()
                b:SetPoint("TOPLEFT", x, -16 - line * 20)
                x = x + 20
                b:Show()
            end
        end
        for j = k + 1, #r.icons do r.icons[j]:Hide() end
        local h = 18 + (line + 1) * 20 + 6
        r:SetHeight(h)
        y = y + h
    end
    for i = #sets + 1, #d.setRows do d.setRows[i]:Hide() end
    if #sets == 0 then
        local r = setRow(d, 1)
        r:SetPoint("TOPLEFT") r:SetPoint("TOPRIGHT") r:SetHeight(40)
        r.name:SetText(ns.L(u.info and "No equipment set saved (character frame, equipment manager)." or "No data yet: this player has not logged in with Guild Tool."))
        r.name:SetWidth(210)
        r.name:SetWordWrap(true)
        for _, b in ipairs(r.icons) do b:Hide() end
        y = 40
    end
    d.sets.child:SetHeight(math.max(y, 1))
    d.sets:ScrollTo(0)
end

-- Talents d'une spé : 3 arbres en cadres (fond de la fenêtre de talents du jeu, opacité réglable dans Settings ; teinte de
-- la classe sinon), grille de 4 colonnes, icône + rang dans chaque case
local CELL, GAP = 31, 4
local TREE_BG = {
    WARRIOR = { "WarriorArms", "WarriorFury", "WarriorProtection" }, PALADIN = { "PaladinHoly", "PaladinProtection", "PaladinCombat" },
    HUNTER = { "HunterBeastMastery", "HunterMarksmanship", "HunterSurvival" }, ROGUE = { "RogueAssassination", "RogueCombat", "RogueSubtlety" },
    PRIEST = { "PriestDiscipline", "PriestHoly", "PriestShadow" }, SHAMAN = { "ShamanElementalCombat", "ShamanEnhancement", "ShamanRestoration" },
    MAGE = { "MageArcane", "MageFire", "MageFrost" }, WARLOCK = { "WarlockCurses", "WarlockSummoning", "WarlockDestruction" },
    DRUID = { "DruidBalance", "DruidFeralCombat", "DruidRestoration" },
}
local function talentCell(t, i)
    local c = t.cells[i]
    if not c then
        c = CreateFrame("Button", nil, t)
        c:SetSize(CELL, CELL)
        c:SetFrameLevel(t:GetFrameLevel() + 3)
        -- cadre : fond coloré sous l'icône rentrée d'un pixel (visible à toutes les échelles)
        c.qbg = c:CreateTexture(nil, "BACKGROUND")
        c.qbg:SetAllPoints()
        c.tex = c:CreateTexture(nil, "ARTWORK")
        c.tex:SetPoint("TOPLEFT", 1, -1)
        c.tex:SetPoint("BOTTOMRIGHT", -1, 1)
        c.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        c.rank = ns.Text(c, 8.5, 700, C.white)
        c.rank:SetPoint("BOTTOMRIGHT", 0, 0)
        c:SetScript("OnEnter", function(self)
            ns.TipOwner(self)
            GameTooltip:SetText(self.tname or "?", 1, 1, 1)
            GameTooltip:AddLine(("%d / %d"):format(self.r or 0, self.m or 0), 0.8, 0.8, 0.8)
            GameTooltip:Show()
        end)
        c:SetScript("OnLeave", GameTooltip_Hide)
        t.cells[i] = c
    end
    c:Show()
    return c
end
-- cadre d'un arbre : fond (4 morceaux de la fenêtre de talents), teinte de la classe, bordure, titre
local function treeFrame(t, i)
    local f = t.trees[i]
    if f then return f end
    f = CreateFrame("Frame", nil, t)
    f.tint = ns.Tex(f, C.white, "BACKGROUND", 0.1)
    f.tint:SetAllPoints()
    f.bg = {}
    for k, p in ipairs({ { "TopLeft", 0, 0, 0.8, 2 / 3 }, { "TopRight", 0.8, 0, 0.2, 2 / 3 }, { "BottomLeft", 0, 2 / 3, 0.8, 1 / 3 }, { "BottomRight", 0.8, 2 / 3, 0.2, 1 / 3 } }) do
        local tx = f:CreateTexture(nil, "BACKGROUND", nil, 1)
        tx.part, tx.x, tx.y, tx.w, tx.h = p[1], p[2], p[3], p[4], p[5]
        f.bg[k] = tx
    end
    f.shade = ns.Tex(f, { 0, 0, 0 }, "BACKGROUND", 0.35)
    f.shade:SetDrawLayer("BACKGROUND", 2)
    f.shade:SetAllPoints()
    ns.Border(f, { 0.25, 0.26, 0.3 })
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetSize(16, 16)
    f.icon:SetPoint("TOPLEFT", 8, -6)
    f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    f.title = ns.Text(f, 11.5, 700, C.white)
    f.title:SetPoint("LEFT", f.icon, "RIGHT", 6, 0)
    f.arrows, f.heads = {}, {}
    t.trees[i] = f
    return f
end

-- Place des talents relevés : référence de Wowhead (TalentRef.lua, par n° de sort : arbre, rangée, colonne,
-- prérequis) ; le jeu garde des nœuds fantômes hors de la grille (doublons d'anciens talents) : un seul talent par
-- case (le plus avancé), talents inconnus de la référence à leur place relevée (au-delà de maxRow : ignorés).
-- -> { { n, icon, p, cells = { { tal, row, col, req = { rangée, colonne } } } } } x3
local function placeTalents(cls, tabs, maxRow)
    local ref = ns.TALENT_REF and ns.TALENT_REF[cls]
    local out = {}
    for i = 1, ref and 3 or #tabs do
        local tr = ref and ref.trees[i]
        out[i] = { n = tr and tr[1] or (tabs[i] and tabs[i].n) or "?", icon = tr and tr[2], p = 0, byCell = {}, cells = {} }
    end
    for ti, tab in ipairs(tabs) do
        for _, tal in ipairs(tab.t or {}) do
            local pos = ref and tal.s and ref.s[tal.s]
            local tree = pos and pos[1] or ti
            local row, col = pos and pos[2] or tal.row, pos and pos[3] or tal.col
            local o = out[tree]
            if o and row and row <= maxRow then
                local k = row * 10 + (col or 1)
                local cur = o.byCell[k]
                if not cur or (cur.tal.r or 0) < (tal.r or 0) then
                    o.byCell[k] = { tal = tal, row = row, col = col or 1, req = pos and pos[5] and { pos[5], pos[6] } or nil }
                end
            end
        end
    end
    for _, o in ipairs(out) do
        for _, c in pairs(o.byCell) do o.cells[#o.cells + 1] = c o.p = o.p + (c.tal.r or 0) end
    end
    return out
end

-- Flèches des prérequis (comme la fenêtre de talents) : de la case du prérequis vers le talent, à l'horizontale puis
-- à la verticale ; dorées une fois le talent pris
local function drawArrows(f, cells)
    local at = {}
    for _, c in ipairs(cells) do at[c.row * 10 + c.col] = c end
    local nl, nh = 0, 0
    local function line(x1, y1, x2, y2, on)
        nl = nl + 1
        local l = f.arrows[nl] or f:CreateLine(nil, "ARTWORK")
        f.arrows[nl] = l
        l:SetThickness(3)
        local col = on and { 1, 0.82, 0.48, 0.9 } or { 0.8, 0.8, 0.8, 0.5 }
        l:SetColorTexture(col[1], col[2], col[3], col[4])
        l:SetStartPoint("TOPLEFT", f, x1, y1)
        l:SetEndPoint("TOPLEFT", f, x2, y2)
        l:Show()
    end
    local function head(x, y, dir, on)
        nh = nh + 1
        local h = f.heads[nh] or ns.Triangle(f, "down", 9)
        f.heads[nh] = h
        h:SetDrawLayer("ARTWORK", 2)
        h:SetRotation(dir == "right" and math.pi / 2 or dir == "left" and -math.pi / 2 or 0)
        if on then h:SetVertexColor(1, 0.82, 0.48) else h:SetVertexColor(0.8, 0.8, 0.8) end
        h:ClearAllPoints()
        h:SetPoint("CENTER", f, "TOPLEFT", x, y)
        h:Show()
    end
    local half, step = CELL / 2, CELL + GAP
    local cx = function(col) return 8 + (col - 1) * step + half end
    local cy = function(row) return -26 - (row - 1) * step - half end
    for _, c in ipairs(cells) do
        if c.req and at[c.req[1] * 10 + c.req[2]] then
            local rr, rc = c.req[1], c.req[2]
            local on = (c.tal.r or 0) > 0
            local x1, y1, x2, y2 = cx(rc), cy(rr), cx(c.col), cy(c.row)
            if rr == c.row then
                local dx = x2 > x1 and half or -half
                line(x1 + dx, y1, x2 - dx - (x2 > x1 and 4 or -4), y2, on)
                head(x2 - dx - (x2 > x1 and 2 or -2), y2, x2 > x1 and "right" or "left", on)
            elseif rc == c.col then
                line(x1, y1 - half, x2, y2 + half + 4, on)
                head(x2, y2 + half + 2, "down", on)
            else
                local dx = x2 > x1 and half or -half
                line(x1 + dx, y1, x2, y1, on)
                line(x2, y1, x2, y2 + half + 4, on)
                head(x2, y2 + half + 2, "down", on)
            end
        end
    end
    for i = nl + 1, #f.arrows do f.arrows[i]:Hide() end
    for i = nh + 1, #f.heads do f.heads[i]:Hide() end
end

-- arbres vides de la classe (tous les talents à 0, icônes et noms lus dans le jeu) : talents pas encore relevés
local function emptySpec(cls)
    local ref = ns.TALENT_REF and ns.TALENT_REF[cls]
    if not ref then return nil end
    local tabs = {}
    for i, tr in ipairs(ref.trees) do tabs[i] = { n = tr[1], t = {} } end
    for s, pos in pairs(ref.s) do
        local name, icon
        if C_Spell and C_Spell.GetSpellInfo then
            local info = C_Spell.GetSpellInfo(s)
            if info then name, icon = info.name, info.iconID end
        elseif GetSpellInfo then
            local nm, _, ic = GetSpellInfo(s)
            name, icon = nm, ic
        end
        local list = tabs[pos[1]].t
        list[#list + 1] = { s = s, r = 0, m = pos[4] or 1, n = name or "?", i = icon, row = pos[2], col = pos[3] }
    end
    return { active = true, empty = true, tabs = tabs }
end

local function fillTalents(d, u, sel)
    d.tpanel:SetSize(math.max(300, d.tpanel:GetWidth()), 80)
    local t = d.talents
    local specs = (u.info or {}).talents or {}
    local spec = specs[sel]
    -- talents pas encore relevés (perso vu par les autres, joueur sans Guild Tool) : arbres vides de sa classe
    if not spec and sel == 1 and not next(specs) then spec = emptySpec(u.class) end
    local n = 0
    local TREE_W = 4 * CELL + 3 * GAP + 16
    local a = ns.db.appearance or {}
    -- teinte des arbres : couleur de la classe ; prêtre : blanc cassé, moins lumineux
    local tc = u.class == "PRIEST" and { 0.73, 0.71, 0.65 } or ns.ClassColor(u.class)
    if spec then
        local pts = {}
        for _, tt in ipairs(spec.tabs or {}) do pts[#pts + 1] = tt.p or 0 end
        -- au-dessus : les points par arbre (le n° de spé est déjà sur l'onglet) ; arbres vides : pas encore relevés
        t.head:SetText(spec.empty and ns.L("Talents not read yet: this player has not logged in with Guild Tool.") or "")
        -- places de la référence Wowhead ; talents fantômes (hors grille) ignorés (rangée > 9 ; Forever : 7 rangées)
        local placed = placeTalents(u.class, spec.tabs or {}, 9)
        local rows = 7
        for _, tt in ipairs(placed) do for _, c in ipairs(tt.cells) do rows = math.max(rows, c.row) end end
        local treeH = 28 + rows * (CELL + GAP) + 6
        for ti, tt in ipairs(placed) do
            local f = treeFrame(t, ti)
            f:ClearAllPoints()
            f:SetPoint("TOPLEFT", (ti - 1) * (TREE_W + 8), -16)
            f:SetSize(TREE_W, treeH)
            -- dégradé de la couleur de la classe (comme l'appli), réglé par « Talent background »
            local tb = a.talentBg or 0.35
            f.tint:SetColorTexture(1, 1, 1, 1)
            f.tint:SetGradient("VERTICAL", CreateColor(tc[1], tc[2], tc[3], tb * 0.18), CreateColor(tc[1], tc[2], tc[3], tb * 0.7))
            for _, tx in ipairs(f.bg) do tx:Hide() end
            ns.SetFont(f.title, 11.5, 700)
            f.title:SetText((tt.n or "?") .. "  |cffffd27a" .. (tt.p or 0) .. "|r")
            -- icône de la spé devant son nom
            f.icon:SetShown(tt.icon ~= nil)
            if tt.icon then f.icon:SetTexture("Interface\\Icons\\" .. tt.icon) end
            f.title:ClearAllPoints()
            if tt.icon then f.title:SetPoint("LEFT", f.icon, "RIGHT", 6, 0) else f.title:SetPoint("TOPLEFT", 8, -7) end
            f:Show()
            drawArrows(f, tt.cells)
            for _, pc in ipairs(tt.cells) do
                local tal = pc.tal
                n = n + 1
                local c = talentCell(t, n)
                c:ClearAllPoints()
                c:SetPoint("TOPLEFT", f, "TOPLEFT", 8 + (pc.col - 1) * (CELL + GAP), -26 - (pc.row - 1) * (CELL + GAP))
                c.tex:SetTexture(tal.i or 134400)
                c.tex:SetDesaturated((tal.r or 0) == 0)
                c.tex:SetAlpha((tal.r or 0) == 0 and 0.45 or 1)
                ns.SetFont(c.rank, 8.5, 700)
                if (tal.r or 0) > 0 then local fp, fs = c.rank:GetFont() c.rank:SetFont(fp, fs, "OUTLINE") end
                c.rank:SetText((tal.r or 0) .. "/" .. (tal.m or 0))
                local bc = (tal.r or 0) == 0 and { 0.25, 0.26, 0.3 } or (tal.r == tal.m and { 1, 0.82, 0.25 } or { 0.37, 0.83, 0.55 })
                c.qbg:SetColorTexture(bc[1], bc[2], bc[3], 1)
                c.tname, c.r, c.m = tal.n, tal.r, tal.m
            end
        end
        for i = #placed + 1, #t.trees do t.trees[i]:Hide() end
        -- cadre englobant : juste autour des onglets et des arbres
        local nt = #placed
        d.tpanel:SetSize(20 + nt * TREE_W + math.max(0, nt - 1) * 8, 30 + 16 + treeH + 12)
        d.att:SetHeight(d.tpanel:GetHeight())
    else
        t.head:SetText("")
        for _, f in ipairs(t.trees) do f:Hide() end
    end
    for i = n + 1, #t.cells do t.cells[i]:Hide() end
    ns.SetFont(t.empty, 11, 400)
    t.empty:SetText(n == 0 and ns.L("No talents yet: this player has not logged in with Guild Tool.") or "")
end

-- Présence : raids 20 joueurs des compos validées où le perso est placé, au jour de leur event ; un mois à la fois
-- (flèches, molette), du mois du premier raid au mois actuel ; jours de raid en doré
function ns:AttendanceIndex()
    local out = {}
    for _, w in pairs(self.db.weeks or {}) do
        for _, comp in ipairs(w.comps or {}) do
            local raid
            for _, ph in ipairs(ns.PHASES) do for _, r in ipairs(ph.raids or {}) do if r.key == comp.raid then raid = r end end end
            local ev = comp.valid and not comp.deleted and raid and raid.size == 20 and comp.event and self:EventById(comp.event)
            if ev and ev.start then
                local seen = {}
                for _, name in pairs(comp.c or {}) do
                    if type(name) == "string" and not seen[name] then
                        seen[name] = true
                        out[name] = out[name] or {}
                        table.insert(out[name], { t = ev.start, id = comp.id })
                    end
                end
            end
        end
    end
    return out
end
-- Phases (présence) : une phase commence le vendredi du lockout de son premier raid enregistré ; la précédente
-- s'arrête ce jour-là (exclu)
function ns:AttendancePhaseRange(pi)
    local first = {}
    for _, w in pairs(self.db.weeks or {}) do
        for _, comp in ipairs(w.comps or {}) do
            local ev = comp.valid and not comp.deleted and comp.event and self:EventById(comp.event)
            if ev and ev.start then
                for k, ph in ipairs(ns.PHASES) do
                    for _, r in ipairs(ph.raids or {}) do
                        if r.key == comp.raid and (not first[k] or ev.start < first[k]) then first[k] = ev.start end
                    end
                end
            end
        end
    end
    local function start(k)
        if k == 1 then return -math.huge end
        return first[k] and (self:WeekStart(first[k]) + 2 * 86400) or nil
    end
    local s = start(pi)
    if not s then return nil end
    for k = pi + 1, #ns.PHASES do local n = start(k) if n then return s, n end end
    return s, math.huge
end
-- phase = nil : toutes (colonne Attendance, tri) ; le sélecteur de phase du détail (ns.attPhase) ne vaut que pour le détail
function ns:AttendanceOf(u, phase)
    self.attIdx = self.attIdx or self:AttendanceIndex()
    local lo, hi = -math.huge, math.huge
    if phase then
        lo, hi = self:AttendancePhaseRange(phase)
        if not lo then lo, hi = 1, 0 end
    end
    local mine = {}
    for _, x in ipairs(self.attIdx[u.name] or {}) do if x.t >= lo and x.t < hi then mine[#mine + 1] = x end end
    local ids, total = {}, 0
    for n, r in pairs(self.db.roster or {}) do
        if n == u.name or (u.tag and r.tag == u.tag) then
            for _, x in ipairs(self.attIdx[n] or {}) do
                if x.t >= lo and x.t < hi and not ids[x.id] then ids[x.id] = true total = total + 1 end
            end
        end
    end
    return mine, #mine, math.max(total, #mine), self.attIdx[u.name] or {}
end
attFrame = function(d)
    local f = CreateFrame("Frame", nil, d)
    f:SetSize(198, 1)
    f.fill = ns.Fill(f, C.panel, 0.22)
    ns.Border(f, C.border)
    f.title = ns.Text(f, 10, 700, C.mute)
    f.title:SetPoint("TOPLEFT", 8, -8)
    f.sub = ns.Text(f, 9, 500, C.mute)
    f.sub:SetPoint("TOPLEFT", 8, -22)
    -- phase des compteurs (cet onglet seulement) : petite roulette, « All » après la dernière
    local function allIdx() return #ns.PHASES + 1 end
    f.phLabel = ns.Text(f, 8.5, 700, C.mute)
    f.phLabel:SetPoint("TOPLEFT", 8, -32)
    f.phBtns = {}
    function f:PhaseButtons()
        local x = 8 + self.phLabel:GetStringWidth() + 8
        for i = 1, allIdx() do
            local b = self.phBtns[i]
            if not b then
                b = CreateFrame("Button", nil, self)
                b:SetHeight(18)
                b.bg = ns.Fill(b, C.input, 0.8)
                b.edges = ns.Border(b, C.border)
                b.label = ns.Text(b, 10, 700, C.mute)
                b.label:SetPoint("CENTER")
                b:SetScript("OnClick", function(s) ns.attPhase = s.p < allIdx() and s.p or nil ns:RefreshMembers() end)
                b:SetScript("OnEnter", function(s) if not s.on then ns.SetBorderColor(s, C.hl) end end)
                b:SetScript("OnLeave", function(s) if not s.on then ns.SetBorderColor(s, C.border) end end)
                self.phBtns[i] = b
            end
            b.p = i
            b.on = (ns.attPhase or allIdx()) == i
            ns.SetFont(b.label, 10, 700)
            b.label:SetText(i == allIdx() and ns.L("All") or tostring(i))
            b:SetWidth(math.max(20, b.label:GetStringWidth() + 10))
            b:ClearAllPoints()
            b:SetPoint("TOPLEFT", x, -28)
            x = x + b:GetWidth() + 3
            -- choisi : fond blanc, texte sombre
            if b.on then
                b.bg:SetColorTexture(1, 1, 1, 1)
                b.label:SetTextColor(0.09, 0.09, 0.11)
                ns.SetBorderColor(b, C.white)
            else
                b.bg:SetColorTexture(C.input[1], C.input[2], C.input[3], 0.8)
                b.label:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
                ns.SetBorderColor(b, C.border)
            end
            b:Show()
        end
        for i = allIdx() + 1, #self.phBtns do self.phBtns[i]:Hide() end
    end
    f.month = ns.Text(f, 11.5, 700, C.white)
    f.month:SetPoint("TOP", 0, -64)
    for i, dir in ipairs({ -1, 1 }) do
        local b = ns.IconButton(f, dir < 0 and "<" or ">", 20)
        b:SetPoint(dir < 0 and "TOPLEFT" or "TOPRIGHT", dir < 0 and 4 or -4, -60)
        b:SetScript("OnClick", function() ns:AttendanceStep(dir) end)
        f["nav" .. i] = b
    end
    f.cells = {}
    for i = 1, 42 do
        local c = CreateFrame("Frame", nil, f)
        c:SetSize(24, 18)
        c:SetPoint("TOPLEFT", 8 + ((i - 1) % 7) * 26, -84 - math.floor((i - 1) / 7) * 21)
        c.bg = ns.Tex(c, C.white, "BACKGROUND", 0.03)
        c.bg:SetAllPoints()
        c.label = ns.Text(c, 9.5, 600, C.mute)
        c.label:SetPoint("CENTER")
        f.cells[i] = c
    end
    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel", function(_, dl) ns:AttendanceStep(-dl) end)
    return f
end
function ns:AttendanceStep(dir)
    local u = self.attUnit
    if not u then return end
    self.attMonth = self.attMonth or {}
    local _, _, _, list = self:AttendanceOf(u)
    local now = date("*t")
    local cur = self.attMonth[u.name] or (now.year * 12 + now.month - 1)
    local first = cur
    for _, x in ipairs(list) do local t = date("*t", x.t) first = math.min(first, t.year * 12 + t.month - 1) end
    self.attMonth[u.name] = math.max(first, math.min(now.year * 12 + now.month - 1, cur + dir))
    self:RefreshMembers()
end
local function fillAttendance(d, u)
    local f = d.att
    ns.attUnit = u
    local _, n, total, list = ns:AttendanceOf(u, ns.attPhase)
    ns.SetFont(f.title, 10, 700)
    f.title:SetText(strupper(ns.L("Attendance")) .. "   |cffffd27a" .. n .. "|r  |cff9a9ea9(" .. total .. ")|r")
    f.sub:SetText("")
    ns.SetFont(f.phLabel, 8.5, 700)
    f.phLabel:SetText(strupper(ns.L("Phase")))
    f:PhaseButtons()
    local now = date("*t")
    local m = (ns.attMonth or {})[u.name] or (now.year * 12 + now.month - 1)
    local y, mo = math.floor(m / 12), m % 12 + 1
    ns.SetFont(f.month, 11.5, 700)
    f.month:SetText(ns.MonthLong(mo) .. " " .. y)
    local days = {}
    for _, x in ipairs(list) do days[date("%Y%m%d", x.t)] = true end
    -- mois alternés : couleurs des lockouts (Settings > Lockouts)
    local ap = ns.db.appearance or {}
    local mc = ns.Hex(((m % 2 == 0) and (ap.lockA or "#0e0f12") or (ap.lockB or "#34363e")):gsub("#", ""))
    local first = time({ year = y, month = mo, day = 1, hour = 12 })
    local lead = (tonumber(date("%w", first)) + 6) % 7
    local nd = tonumber(date("%d", time({ year = y, month = mo + 1, day = 0, hour = 12 })))
    for i, c in ipairs(f.cells) do
        local day = i - lead
        if day >= 1 and day <= nd then
            local on = days[("%04d%02d%02d"):format(y, mo, day)]
            ns.SetFont(c.label, 9.5, on and 700 or 600)
            c.label:SetText(day)
            if on then
                c.bg:SetColorTexture(1, 0.78, 0.3, 0.9)
                c.label:SetTextColor(0.11, 0.07, 0.02)
            else
                c.bg:SetColorTexture(mc[1], mc[2], mc[3], 0.6)
                c.label:SetTextColor(0.78, 0.79, 0.82)
            end
            c:Show()
        else
            c:Hide()
        end
    end
end

local function lootLine(d, i)
    local l = d.lines[i]
    if not l then
        l = CreateFrame("Button", nil, d.loot.child)
        l:SetHeight(20)
        l.date = ns.Text(l, 10.5, 400, C.mute)
        l.date:SetPoint("LEFT", 4, 0)
        l.icon = l:CreateTexture(nil, "ARTWORK")
        l.icon:SetSize(16, 16)
        l.icon:SetPoint("LEFT", 74, 0)
        l.item = ns.Text(l, 11.5, 600)
        l.item:SetPoint("LEFT", l.icon, "RIGHT", 6, 0)
        l.item:SetWidth(300)
        l.resp = ns.Text(l, 10.5, 400)
        l.resp:SetPoint("LEFT", 400, 0)
        l.resp:SetWidth(170)
        l.boss = ns.Text(l, 10.5, 400, C.mute)
        l.boss:SetPoint("LEFT", 580, 0)
        l.boss:SetPoint("RIGHT", -6, 0)
        l:SetScript("OnEnter", function(self)
            if not self.link then return end
            ns.TipOwner(self)
            GameTooltip:SetHyperlink(self.link)
            GameTooltip:Show()
        end)
        l:SetScript("OnLeave", GameTooltip_Hide)
        d.lines[i] = l
    end
    return l
end

local function fillDetail(d, u)
    local info = u.info or {}
    local gear = info.gear
    d.gearTitle:SetText(strupper(ns.L("Last known gear")))
    for _, b in ipairs(d.gear) do
        local id = gear and gear[b.slot]
        b.itemID = id
        if id then
            local _, q, icon = ns:ItemInfo(id)
            b.tex:SetTexture(icon or 134400)
            b.tex:SetDesaturated(false)
            setQuality(b, q or 1)
        else
            b.tex:SetTexture("Interface\\PaperDoll\\UI-Backpack-EmptySlot")
            b.tex:SetDesaturated(true)
            setQuality(b, nil)
        end
    end
    if gear then
        d.gearNote:SetText(ns.L("Updated {0}", date("%d/%m %H:%M", info.gearT or 0)))
    else
        d.gearNote:SetText(ns.L("No gear data yet: this player has not logged in with Guild Tool."))
    end
    fillSets(d, u)
    -- talents : Spec 1 / Spec 2 (l'active par défaut ; Spec 2 grisé si aucune 2e spé relevée)
    local specs = info.talents or {}
    local cur = ns.memberSpec
    if not (cur and specs[cur]) then
        cur = 1
        for i, s in ipairs(specs) do if s.active then cur = i end end
    end
    for i, b in ipairs(d.tabs) do
        local has = specs[i] ~= nil
        ns.SetFont(b.label, 15, 700)
        b.label:SetText(strupper(ns.L("Spec {0}", i)))
        ns.SetFont(b.small, 7.5, 700)
        b.small:SetText(has and specs[i].active and ("(" .. strupper(ns.L("active")) .. ")") or (not has and ("(" .. strupper(ns.L("none")) .. ")")) or "")
        b:SetWidth(b.label:GetStringWidth() + (b.small:GetText() ~= "" and b.small:GetStringWidth() + 4 or 0))
        local ro
        if has then
            local best, bi = 0, nil
            for ti, tt in ipairs(specs[i].tabs or {}) do if (tt.p or 0) > best then best, bi = tt.p, ti end end
            ro = bi and (TREE_ROLE[u.class or ""] or {})[bi]
        end
        b.role:SetShown(ro ~= nil)
        if ro then b.role:SetTexture(ns.ROLE_ICON[ro]) end
        b:SetEnabled(has)
        local on = has and i == cur
        b.line:SetShown(on)
        local c = on and C.white or (has and C.mute) or { 0.33, 0.34, 0.38 }
        b.label:SetTextColor(c[1], c[2], c[3])
    end
    ns.SetFont(d.noSpec2, 10, 500)
    d.noSpec2:SetText("")
    ns:MemberDetailFrames(d)
    d.loot:Hide()
    d.talents:Show()
    fillTalents(d, u, cur)
    fillAttendance(d, u)
    -- image de fond du perso (joueur), sauf si cachée pour ce perso
    local img = not (ns.db.appearance or {}).charImgOff and (ns.db.charImages or {})[u.name] or nil
    local hidden = (ns.db.ui.hideCharImg or {})[u.name]
    d.pic:SetShown(img ~= nil and not hidden)
    local ia, ib = (ns.db.appearance or {}).charImgA or 0.5, (ns.db.appearance or {}).charImgBlur or 0
    d.picBlur:SetShown(img ~= nil and not hidden and ib > 0)
    if img then
        d.pic:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. img) d.pic:SetAlpha(ia * (1 - ib))
        d.picBlur:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. img .. "_blur") d.picBlur:SetAlpha(ia * ib)
    end
    local mine = (ns.db.myChars or {})[u.name] ~= nil
    d.picHide:SetShown(img ~= nil and not mine)
    d.picHide.char = u.name
    d.picHide.check:SetShown(hidden and true or false)
    ns.SetFont(d.picHide.label, 10, 600)
    d.picHide.label:SetText(ns.L("Hide picture"))
    local loot = {}
    for i, e in ipairs(loot) do
        local l = lootLine(d, i)
        l:ClearAllPoints()
        l:SetPoint("TOPLEFT", 0, -(i - 1) * 20)
        l:SetPoint("TOPRIGHT", 0, -(i - 1) * 20)
        l.link = e.item
        l.date:SetText(e.date or "")
        local name, q, icon = nil, nil, nil
        if e.itemID then name, q, icon = ns:ItemInfo(e.itemID) end
        l.icon:SetTexture(icon or 134400)
        l.item:SetText(e.item or name or "?")
        l.resp:SetText(e.response or "")
        l.boss:SetText((e.boss or "") .. (e.instance and ("  ·  " .. e.instance) or ""))
        l:Show()
    end
    for i = #loot + 1, #d.lines do d.lines[i]:Hide() end
    d.empty:SetText("")
    d.loot.child:SetHeight(math.max(#loot * 20, 1))
    d.loot:ScrollTo(0)
end

---------------------------------------------------------------------------
-- Lignes
---------------------------------------------------------------------------
-- colonnes { titre, x, largeur } : contenu centré sous l'en-tête
local LIST_W = ns.W - 2 - 2 * PAD - 8
local COL = {
    { "Character", 0, 190 }, { "Discord", 198, 150 }, { "Level", 356, 50 }, { "Specs", 414, 70 },
    -- Professions : largeur fixe juste après Attendance (centré sur tout le reste de la ligne, il était trop loin)
    { "Attendance", 492, 90 }, { "Professions", 590, 220 },
}
local function colCenter(i) return COL[i][2] + COL[i][3] / 2 end
-- titre de colonne -> critère de tri (clic = ce critère en tête) ; pas de tri par métiers
local COL_SORT = { "alpha", "discord", "level", "spec", "attendance" }
-- Members : Spec = classe puis spé dans l'ordre de la classe (Holy, Protection, Retribution à la suite) ;
-- Attendance = raids faits, du plus au moins
local function idx(t, v) for i, x in ipairs(t) do if x == v then return i end end return 99 end
local function specRank(u)
    local si = 99
    for i, s in ipairs(ns.SPECS[u.class or ""] or {}) do if s[1] == u.spec then si = i end end
    return idx(ns.CLASS_ORDER, u.class) * 100 + si
end
local MCMP = {
    spec = function(a, b) return specRank(a), specRank(b) end,
    attendance = function(a, b) return -(a.att or 0), -(b.att or 0) end,
}

local function newRow(parent)
    local r = CreateFrame("Button", nil, parent)
    r:SetHeight(ROW_H)
    r.bg = ns.Tex(r, C.white, "BACKGROUND", 0.025)
    r.bg:SetAllPoints()
    -- survol : surbrillance ; clic : ouvre / ferme le détail
    ns.Selection(r, 0)
    r.open = ns.Tex(r, C.accent, "BACKGROUND", 0.12)
    r.open:SetDrawLayer("BACKGROUND", 2)
    r.open:SetAllPoints()
    r.classIcon = r:CreateTexture(nil, "ARTWORK")
    r.classIcon:SetSize(18, 18)
    r.classIcon:SetPoint("LEFT", COL[1][2] + 6, 0)
    r.classIcon:SetTexture(CLASS_ICONS)
    r.name = ns.Text(r, 12, 600)
    r.name:SetPoint("LEFT", r.classIcon, "RIGHT", 7, 0)
    r.discord = ns.Text(r, 11.5, 400)
    r.discord:SetPoint("CENTER", r, "LEFT", colCenter(2), 0)
    r.discord:SetWidth(COL[2][3])
    r.discord:SetJustifyH("CENTER")
    r.level = ns.Text(r, 11.5, 600)
    -- niveau : centré sous « Level », nombres alignés à droite entre eux
    r.level:SetPoint("RIGHT", r, "LEFT", colCenter(3) + 9, 0)
    r.level:SetJustifyH("RIGHT")
    r.specs = {}
    for i = 1, 2 do
        local t = r:CreateTexture(nil, "ARTWORK")
        t:SetSize(18, 18)
        r.specs[i] = t
    end
    r.att = ns.Text(r, 11.5, 700)
    r.att:SetPoint("CENTER", r, "LEFT", colCenter(5), 0)
    r.profs = ns.Text(r, 11.5, 400)
    r.profs:SetPoint("CENTER", r, "LEFT", colCenter(6), 0)
    r:SetScript("OnEnter", function(self) ns.ShowSelection(self, true) end)
    r:SetScript("OnLeave", function(self) ns.ShowSelection(self, false) end)
    r:SetScript("OnClick", function(self)
        local name = self.unit.name
        ns.expanded = ns.expanded ~= name and name or nil
        ns:RefreshMembers()
    end)
    return r
end

local function fillRow(r, u, odd)
    r.unit = u
    r.bg:SetShown(odd)
    r.open:SetShown(ns.expanded == u.name)
    local coords = CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[u.class or ""]
    r.classIcon:SetShown(coords ~= nil)
    if coords then r.classIcon:SetTexCoord(unpack(coords)) end
    local c = ns.ClassColor(u.class)
    r.name:SetTextColor(c[1], c[2], c[3])
    ns.SetName(r.name, u.display, COL[2][2] - COL[1][2] - 40)
    -- nom Discord plus discret
    r.discord:SetText(u.discord or (u.tag and ("@" .. u.tag)) or "")
    if u.discord then r.discord:SetTextColor(0.68, 0.7, 0.74) else r.discord:SetTextColor(C.mute[1], C.mute[2], C.mute[3]) end
    r.level:SetText(u.level)
    local shown = {}
    for i, t in ipairs(r.specs) do
        local icon = u.specs[i] and ns:SpecIcon(u, u.specs[i])
        t:SetShown(icon ~= nil)
        if icon then t:SetTexture(icon) shown[#shown + 1] = t end
    end
    -- icônes de spé centrées dans leur colonne
    for i, t in ipairs(shown) do
        t:ClearAllPoints()
        t:SetPoint("CENTER", r, "LEFT", colCenter(4) + (i - (#shown + 1) / 2) * 22, 0)
    end
    local _, an, at = ns:AttendanceOf(u)
    r.att:SetText(at > 0 and (an .. "  |cff9a9ea9(" .. at .. ")|r") or "|cff9a9ea9-|r")
    local profs = u.info and u.info.profs
    if profs and #profs > 0 then
        local parts = {}
        -- icône du métier à la place de son nom (relevé du jeu, sinon icône connue d'après le nom)
        for _, p in ipairs(profs) do
            local icon = p.i or (ns.PROF_ICON[p.n or ""] and "Interface\\Icons\\" .. ns.PROF_ICON[p.n])
            parts[#parts + 1] = icon and ("|T%s:16:16:0:0:64:64:5:59:5:59|t |cff9a9ea9%d|r"):format(icon, p.r or 0)
                or ("%s |cff9a9ea9%d|r"):format(p.n, p.r or 0)
        end
        r.profs:SetText(table.concat(parts, "    "))
    else
        r.profs:SetText("|cff9a9ea9-|r")
    end
end

---------------------------------------------------------------------------
-- Page
---------------------------------------------------------------------------
function ns:CreateMembers(page)
    local top = CreateFrame("Frame", nil, page)
    top:SetPoint("TOPLEFT", PAD, -PAD)
    top:SetPoint("TOPRIGHT", -PAD, -PAD)
    top:SetHeight(26)
    local sl = ns.Text(top, 9.5, 600, C.mute)
    sl:SetPoint("LEFT", 0, 0)
    sl:SetText(strupper(ns.L("Sort priority · drag to reorder")))
    self.membersChips = ns.ChipBar(top, function() return ns.db.ui.membersOrder end, function() ns:RefreshMembers() end)
    self.membersChips:SetPoint("LEFT", sl, "RIGHT", 12, 0)
    self.membersCount = ns.Text(top, 11, 400, C.mute)
    self.membersCount:SetPoint("RIGHT", 0, 0)

    local head = CreateFrame("Frame", nil, page)
    head:SetPoint("TOPLEFT", PAD, -PAD - 32)
    head:SetPoint("TOPRIGHT", -PAD, -PAD - 32)
    head:SetHeight(HEAD_H)
    ns.Fill(head, C.head, 0.8)
    self.memberColHeads = {}
    for i, col in ipairs(COL) do
        local t = ns.Text(head, 10, 700, C.mute)
        if i == 1 then t:SetPoint("LEFT", col[2] + 6, 0)                                  -- perso : à gauche
        else t:SetPoint("CENTER", head, "LEFT", colCenter(i), 0) end                       -- les autres (niveau compris) : centrés
        t:SetText(strupper(ns.L(col[1])))
        -- clic sur le titre : ce critère passe en tête de la priorité de tri
        local key = COL_SORT[i]
        if key then
            local b = CreateFrame("Button", nil, head)
            b:SetPoint("TOPLEFT", head, "TOPLEFT", col[2], 0)
            b:SetSize(col[3], HEAD_H)
            b:SetScript("OnEnter", function() t:SetTextColor(1, 1, 1) end)
            b:SetScript("OnLeave", function() ns:MemberHeadColors() end)
            b:SetScript("OnClick", function()
                local o = ns.db.ui.membersOrder
                for j = #o, 1, -1 do if o[j] == key then table.remove(o, j) end end
                tinsert(o, 1, key)
                ns:RefreshMembers()
            end)
            self.memberColHeads[#self.memberColHeads + 1] = { t = t, key = key }
        end
    end

    -- fond de la liste : image de fond floutée + voile
    local listBg = CreateFrame("Frame", nil, page)
    listBg:SetPoint("TOPLEFT", PAD, -PAD - 32 - HEAD_H - 2)
    listBg:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    local veil = ns.Tex(listBg, C.bg, "BACKGROUND", 0.55)
    veil:SetAllPoints()
    self.membersVeil = veil
    self.membersBg = listBg
    local sf = ns.ScrollArea(page)
    sf:SetPoint("TOPLEFT", PAD, -PAD - 32 - HEAD_H - 2)
    sf:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    sf.child:SetWidth(ns.W - 2 - 2 * PAD - 8)
    self.membersArea = sf
    self.memberRows, self.memberHeads = {}, {}
    self.memberDetail = createDetail(sf.child)
end

-- titres de colonne : critère de tri en tête en couleur Highlight
function ns:MemberHeadColors()
    local first = self.db.ui.membersOrder[1]
    for _, h in ipairs(self.memberColHeads or {}) do
        local c = h.key == first and C.hl or C.mute
        h.t:SetTextColor(c[1], c[2], c[3])
    end
end

-- cadres des talents et de la présence : opacité et flou (morceau flouté du fond) réglables dans Settings
function ns:MemberDetailFrames(d)
    local a = self:Look()
    for _, f in ipairs({ d.tpanel, d.att }) do
        f.fill:SetColorTexture(C.panel[1], C.panel[2], C.panel[3], a.detAlpha or 0.22)
        if (a.detBlur or 0) > 0 then
            self:BlurBehind(f, -7)
            if f.blurTex and f.blurTex:IsShown() then f.blurTex:SetAlpha((a.bgAlpha or 0.6) * a.detBlur) end
        elseif f.blurTex then f.blurTex:Hide() end
    end
end

function ns:RefreshMembers()
    if not self.membersArea then return end
    self.attIdx = nil
    -- fond de la liste : opacité et flou (Settings > Members Background opac/blur)
    local ap = self:Look()
    self.membersVeil:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], ap.membersAlpha or 0.55)
    self:BlurBehind(self.membersBg)
    local bt = self.membersBg.blurTex
    if bt and bt:IsShown() then bt:SetAlpha((ap.bgAlpha or 0.6) * (ap.membersBlur or 0.6) / 0.6) end
    local order = self.db.ui.membersOrder
    local list = self:MembersUnits()
    for _, u in ipairs(list) do u.att = select(2, self:AttendanceOf(u)) or 0 end
    ns.SortUnits(list, order, MCMP)
    self.membersChips:Layout()
    self:MemberHeadColors()
    local withAddon = 0
    for _, u in ipairs(list) do if u.info then withAddon = withAddon + 1 end end
    self.membersCount:SetText(ns.L("{0} characters · {1} with Guild Tool data", #list, withAddon))
    local child, y, ri = self.membersArea.child, 0, 0
    local detail, shownDetail = self.memberDetail, false
    for i, u in ipairs(list) do
        -- pas de ligne d'en-tête par critère : l'ordre de la liste suffit
        ri = ri + 1
        local r = self.memberRows[ri] or newRow(child)
        self.memberRows[ri] = r
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, -y)
        r:SetPoint("TOPRIGHT", 0, -y)
        fillRow(r, u, i % 2 == 0)
        r:Show()
        y = y + ROW_H
        if self.expanded == u.name then
            detail:ClearAllPoints()
            detail:SetPoint("TOPLEFT", 0, -y)
            detail:SetPoint("TOPRIGHT", 0, -y)
            fillDetail(detail, u)
            detail:Show()
            shownDetail = true
            y = y + DETAIL_H + 4
        end
    end
    for i = ri + 1, #self.memberRows do self.memberRows[i]:Hide() end
    if not shownDetail then detail:Hide() end
    child:SetHeight(math.max(y + 8, 1))
    self.membersArea:UpdateThumb()
end
