-- GuildTool : autofill des compos (miroir exact de Bridge/web/autofill.js)
-- 1. compos équilibrées : autant que les candidats (+ déjà placés) permettent d'en remplir à 80 % ; les autres
--    reçoivent le surplus, une à la fois (pas d'équilibrage sous 80 %)
-- 2. buffs : les étapes de STEPS dans l'ordre, chacune appliquée à toutes les compos équilibrées avant la suivante
--    (une compo qui l'a déjà est sautée) ; options « ou » : la 1re compo prend la 1re option, les suivantes les autres ;
--    parmi les persos possibles, tanks et heals d'abord, puis par statut ; « Autofill Buffs » s'arrête là
-- 3. remplissage : tanks et heals requis, puis les dps (statut : Signed > Late > Tentative > Bench), puis les
--    tanks / heals en surplus, en équilibrant les classes entre les compos, puis les présences incertaines (Late,
--    Tentative, Bench : deux démonistes Late = un par compo), puis la compo la moins remplie ; le reste dans les
--    compos suivantes. Les joueurs déjà placés restent (Autofill complète, ne remplace pas)
-- 4. groupes : préférence de l'étape qui a choisi le perso, sinon heals 4, Shadow / Balance 4 > 3, tanks 1,
--    mêlées et chasseurs 2 > 1, casters 3 > 4 (sans Shadow / Balance) > 1 > 2 ; chamans dans des groupes distincts
local _, ns = ...

local TANKS = 2
local HEALS = { [10] = 2, [20] = 4, [40] = 8 }
local STATUS = { primary = 0, late = 1, tentative = 2, bench = 3 }

-- comparaison lexicographique de deux listes de nombres
local function less(a, b)
    for i = 1, #a do
        if a[i] ~= b[i] then return a[i] < b[i] end
    end
    return false
end

-- tri stable : l'ordre d'origine départage
local function stableSort(list, key)
    local idx = {}
    for i, u in ipairs(list) do idx[u] = i end
    table.sort(list, function(a, b)
        local ka, kb = key(a), key(b)
        if ka ~= kb then return ka < kb end
        return idx[a] < idx[b]
    end)
end

local function filter(list, f)
    local out = {}
    for _, u in ipairs(list) do if f(u) then out[#out + 1] = u end end
    return out
end

local function roleKey(u)
    if u.role == "Tank" then return "Tank" elseif u.role == "Healer" then return "Healer" end
    return "Dps"
end

local MIN_FILL = 0.8

local function isC(c) return function(u) return u.class == c end end
local function isS(c, ...)
    local specs = { ... }
    return function(u)
        if u.class ~= c then return false end
        for _, s in ipairs(specs) do if u.spec == s then return true end end
        return false
    end
end
local function any(list, t)
    for _, u in ipairs(list) do if t(u) then return true end end
    return false
end
local function count(list, t)
    local n = 0
    for _, u in ipairs(list) do if t(u) then n = n + 1 end end
    return n
end

-- Étapes des buffs / debuffs de raid (= AF_STEPS de autofill.js). need(compo) = l'étape manque ; opts = persos possibles
-- (t) et groupes voulus (g : liste, fonction du perso, ou nil = groupe par défaut) ; split = options « ou » réparties
local WAR, SHA, PRI, DRU, MAG, LOCK, ROG, HUN, PAL = isC("WARRIOR"), isC("SHAMAN"), isC("PRIEST"), isC("DRUID"), isC("MAGE"),
    isC("WARLOCK"), isC("ROGUE"), isC("HUNTER"), isC("PALADIN")
local FERALS, BAL, RSHAM, SPRI = isS("DRUID", "Feral", "Guardian"), isS("DRUID", "Balance"), isS("SHAMAN", "Restoration"), isS("PRIEST", "Shadow")
local STEPS = {
    { need = function(c) return not any(c, WAR) end, opts = { { t = WAR } } },                                  -- Battle Shout (+ Sunder)
    { need = function(c) return not any(c, FERALS) end,                                                         -- Leader of the Pack
      opts = { { t = FERALS, g = function(u) return u.role == "Tank" and { 1 } or { 2 } end } } },
    { need = function(c) return not any(c, BAL) end, opts = { { t = BAL, g = { 3, 4 } } } },                    -- Moonkin Aura
    { need = function(c) return not any(c, RSHAM) end, opts = { { t = RSHAM, g = { 4 } } } },                   -- Mana Tide (+ Mana Spring)
    { need = function(c) return count(c, SHA) < 1 end, opts = { { t = SHA, g = { 4, 1, 2, 3 } } } },            -- Strength of Earth, Flametongue, Windfury
    { need = function(c) return count(c, SHA) < 2 end, opts = { { t = SHA, g = { 1, 4, 2, 3 } } } },            -- Grace of Air
    { need = function(c) return count(c, SHA) < 3 end, opts = { { t = SHA, g = { 2 } } } },                     -- Tranquil Air + Mana Spring
    { need = function(c) return count(c, SHA) < 4 end, opts = { { t = SHA, g = { 3 } } } },                     -- Tranquil Air + Mana Spring
    { need = function(c) return not any(c, PRI) end, opts = { { t = PRI, g = { 4, 3 } } } },                    -- Fortitude + Spirit
    { need = function(c) return not any(c, SPRI) end, opts = { { t = SPRI, g = { 4, 3 } } } },                  -- Dark Inspiration + Vampiric Embrace (groupe)
    { need = function(c) return not any(c, DRU) end,                                                            -- Gift of the Wild
      opts = { { t = DRU, g = function(u) return u.spec == "Restoration" and { 4, 3 } or nil end } } },
    { need = function(c) return not any(c, MAG) end, opts = { { t = MAG, g = { 3, 4, 2 } } } },                 -- Arcane Brilliance
    { need = function(c) return not any(c, LOCK) end, opts = { { t = LOCK, g = { 3, 4, 2 } } } },               -- Curse of the Elements
    { need = function(c) return not any(c, WAR) and not any(c, ROG) end, split = true,                          -- Sunder / Expose Armor
      opts = { { t = WAR }, { t = ROG } } },
    { need = function(c) return not any(c, DRU) end,                                                            -- Faerie Fire
      opts = { { t = BAL, g = { 3, 4 } }, { t = isS("DRUID", "Guardian") }, { t = isS("DRUID", "Feral") }, { t = isS("DRUID", "Restoration"), g = { 4, 3 } } } },
    { need = function(c) return not any(c, SHA) and not any(c, PRI) end, split = true,                          -- Purge / Dispel Magic
      opts = { { t = SHA }, { t = PRI, g = { 4, 3 } } } },
    { need = function(c) return not any(c, HUN) end, opts = { { t = HUN } } },                                  -- Tranquilizing Shot
    { need = function(c) return count(c, PAL) < 1 end, opts = { { t = PAL } } },                                -- Kings + Salvation
    { need = function(c) return count(c, PAL) < 2 end, opts = { { t = PAL } } },                                -- Might
    { need = function(c) return count(c, PAL) < 3 end, opts = { { t = PAL } } },                                -- Wisdom
    { need = function(c) return count(c, PAL) < 4 end, opts = { { t = PAL } } },                                -- Light
}

-- présence incertaine (Late, Tentative, Bench) : répartie entre les compos
local function unsure(u) return u.status == "late" or u.status == "tentative" or u.status == "bench" end

local function roleCount(c, rk)
    local n = 0
    for _, m in ipairs(c) do if roleKey(m) == rk then n = n + 1 end end
    return n
end

local function copy(list)
    local out = {}
    for i, u in ipairs(list) do out[i] = u end
    return out
end

local function removeFrom(list, u)
    for i, x in ipairs(list) do if x == u then table.remove(list, i) return end end
end

-- Résolution des conflits entre compos (= afRepair) : priorités = 1 tank et 1 heal minimum, puis les étapes de buffs
-- dans l'ordre. Déplacement (vers une compo qui a de la place) ou échange de deux persos qui améliore le plus le nombre de
-- compos satisfaisant chaque priorité, comparé priorité par priorité ; on recommence tant qu'un échange améliore.
local REPAIR_STEPS = {
    { need = function(c) return not any(c, function(u) return roleKey(u) == "Tank" end) end },
    { need = function(c) return not any(c, function(u) return roleKey(u) == "Healer" end) end },
}
for _, st in ipairs(STEPS) do REPAIR_STEPS[#REPAIR_STEPS + 1] = st end
local function satOf(c)
    local v = {}
    for j, st in ipairs(REPAIR_STEPS) do v[j] = st.need(c) and 0 or 1 end
    return v
end
local function without(list, x)
    local out = {}
    for _, y in ipairs(list) do if y ~= x then out[#out + 1] = y end end
    return out
end
local function plus(list, x)
    local out = copy(list)
    out[#out + 1] = x
    return out
end
local function repair(bal, size)
    local nst = #REPAIR_STEPS
    for _ = 1, 60 do
        local base = {}
        for i, c in ipairs(bal) do base[i] = satOf(c) end
        local best, bestD = nil, {}
        for j = 1, nst do bestD[j] = 0 end
        local function consider(ci, di, u, v, cNew, dNew)
            local a, b, delta = satOf(cNew), satOf(dNew), {}
            for j = 1, nst do delta[j] = a[j] + b[j] - base[ci][j] - base[di][j] end
            for j = 1, nst do
                if delta[j] ~= bestD[j] then
                    if delta[j] > bestD[j] then best, bestD = { ci = ci, di = di, u = u, v = v }, delta end
                    return
                end
            end
        end
        for ci, c in ipairs(bal) do
            for di, d in ipairs(bal) do
                if ci ~= di then
                    for _, u in ipairs(d) do
                        local dA = without(d, u)
                        if #c < size then consider(ci, di, u, nil, plus(c, u), dA) end
                        for _, v in ipairs(c) do consider(ci, di, u, v, plus(without(c, v), u), plus(dA, v)) end
                    end
                end
            end
        end
        if not best then return end
        local c, d = bal[best.ci], bal[best.di]
        removeFrom(d, best.u)
        c[#c + 1] = best.u
        if best.v then
            removeFrom(c, best.v)
            d[#d + 1] = best.v
        end
    end
end

-- comps = membres déjà placés de chaque compo (ordre chronologique) ; buffsOnly = « Autofill Buffs »
-- -> membres de chaque compo (déjà placés d'abord), prefs = { [perso] = groupes voulus }
function ns.AutofillPlan(candidates, size, comps, buffsOnly)
    local hReq = HEALS[size]
    local roleCap = { Tank = TANKS, Healer = hReq, Dps = size - TANKS - hReq }
    local pool = copy(candidates)
    stableSort(pool, function(u) return STATUS[u.status or ""] or 0 end)
    local out, prefs, total = {}, {}, #pool
    for i, c in ipairs(comps) do out[i] = copy(c) total = total + #c end
    -- compos équilibrées : au moins 80 % de chacune remplissable
    local k = math.max(1, #out)
    while k > 1 and total < math.ceil(k * size * MIN_FILL) do k = k - 1 end

    -- 2. buffs : étape par étape, toutes les compos (jamais sautée faute de place de rôle). Parmi les persos possibles :
    --    rôle encore nécessaire (tank / heal sous le minimum) > dps > tank / heal en surplus (heals jusqu'à 1,5 fois la
    --    normale) > n'importe lequel ; toujours une place laissée pour 1 tank et 1 heal minimum
    local buffCap = { Tank = TANKS, Healer = math.ceil(hReq * 1.5), Dps = size - TANKS - hReq }
    local function fits(c, u)
        local rk = roleKey(u)
        local miss = (rk ~= "Tank" and roleCount(c, "Tank") < 1 and 1 or 0) + (rk ~= "Healer" and roleCount(c, "Healer") < 1 and 1 or 0)
        return size - #c - 1 >= miss
    end
    local function tier(c, u)
        local rk = roleKey(u)
        local n = roleCount(c, rk)
        if rk ~= "Dps" and n < (rk == "Tank" and TANKS or hReq) then return 0 end
        if rk == "Dps" and n < roleCap.Dps then return 1 end
        return n < buffCap[rk] and 2 or 3
    end
    local bal = {}
    for i = 1, math.min(k, #out) do bal[i] = out[i] end
    local function applySteps()
    for _, step in ipairs(STEPS) do
        for ci = 1, math.min(k, #out) do
            local c = out[ci]
            if #c < size and step.need(c) then
                local n = #step.opts
                local first = step.split and math.min(ci, n) or 1
                for j = 0, n - 1 do
                    local o = step.opts[((first - 1 + j) % n) + 1]
                    local pick, pt = nil, 9
                    for _, u in ipairs(pool) do
                        if o.t(u) and fits(c, u) then
                            local t = tier(c, u)
                            if t < pt then pick, pt = u, t end
                        end
                    end
                    if pick then
                        c[#c + 1] = pick
                        removeFrom(pool, pick)
                        local g = o.g
                        if type(g) == "function" then g = g(pick) end
                        if g then prefs[pick] = g end
                        break
                    end
                end
            end
        end
    end
    end
    applySteps()
    if buffsOnly then repair(bal, size) applySteps() end
    if not buffsOnly then
        -- 3a. tanks et heals requis, niveau par niveau : 1 tank puis 1 heal dans chaque compo, puis le 2e de chaque, etc.
        for lvl = 1, math.max(TANKS, hReq) do
            for _, req in ipairs({ { "Tank", TANKS }, { "Healer", hReq } }) do
                if lvl <= req[2] then
                    for i = 1, math.min(k, #out) do
                        local c = out[i]
                        if #c < size and roleCount(c, req[1]) < lvl then
                            for _, u in ipairs(pool) do
                                if roleKey(u) == req[1] then c[#c + 1] = u removeFrom(pool, u) break end
                            end
                        end
                    end
                end
            end
        end
        -- conflits (tank / heal manquant, buff pris ailleurs) : échanges entre compos, puis étapes de nouveau (réserve)
        repair(bal, size)
        applySteps()
        -- 3b. dps puis tanks / heals en surplus : rôle sous son plafond, puis le moins de persos de sa classe, puis
        --     (présence incertaine) le moins de persos de sa classe incertains, puis la compo la moins remplie
        local order = filter(pool, function(u) return roleKey(u) == "Dps" end)
        for _, u in ipairs(filter(pool, function(u) return roleKey(u) ~= "Dps" end)) do order[#order + 1] = u end
        for _, u in ipairs(order) do
            local best, bestKey
            for i = 1, math.min(k, #out) do
                local c = out[i]
                if #c < size then
                    local rk = roleKey(u)
                    local same, sameUnsure = 0, 0
                    for _, m in ipairs(c) do
                        if m.class == u.class then
                            same = same + 1
                            if unsure(m) then sameUnsure = sameUnsure + 1 end
                        end
                    end
                    local key = { roleCount(c, rk) >= roleCap[rk] and 1 or 0, same, unsure(u) and sameUnsure or 0, #c }
                    if not bestKey or less(key, bestKey) then best, bestKey = c, key end
                end
            end
            if best then best[#best + 1] = u removeFrom(pool, u) end
        end
        -- 3c. le reste dans les compos suivantes, une à la fois
        for i = k + 1, #out do
            local c = out[i]
            while #c < size and #pool > 0 do c[#c + 1] = table.remove(pool, 1) end
        end
    end
    return out, prefs
end

local function shadowBal(u) return (u.class == "PRIEST" and u.spec == "Shadow") or (u.class == "DRUID" and u.spec == "Balance") end
local function has(list, v) for _, x in ipairs(list) do if x == v then return true end end return false end

-- groupes voulus d'un perso (1..8), ramenés aux groupes de la compo : 10 joueurs 3 -> 1, 4 -> 2 ; 40 joueurs : + 4
-- chamans Enhancement / Elemental : groupes propres à leur spé, avant ceux de l'étape de buffs
local SHAMAN_GROUPS = { Enhancement = { 2, 1, 3, 4 }, Elemental = { 3, 2, 4, 1 } }
local function groupPrefs(u, members, prefs, G)
    -- raid 10 : pas de règles de groupe des raids 20 (G1 puis G2 ; seuls les chamans sont dispersés)
    if G <= 2 then
        local out = {}
        for g = 1, G do out[g] = g end
        return out
    end
    local p = (u.class == "SHAMAN" and SHAMAN_GROUPS[u.spec or ""]) or (prefs and prefs[u])
    if not p then
        if u.role == "Healer" then p = { 4 }
        elseif shadowBal(u) then p = { 4, 3 }
        elseif u.role == "Tank" then p = { 1 }
        elseif u.class == "HUNTER" or u.role == "Melee" then p = { 2, 1 }
        elseif u.role == "Ranged" then p = any(members, shadowBal) and { 3, 1, 2 } or { 3, 4, 1, 2 }
        else p = { 1, 2, 3, 4 } end
    end
    local out = {}
    for _, g in ipairs(p) do
        local m = G >= 4 and g or ((g - 1) % G) + 1
        if not has(out, m) then out[#out + 1] = m end
    end
    if G > 4 then
        for _, g in ipairs(copy(out)) do if g + 4 <= G and not has(out, g + 4) then out[#out + 1] = g + 4 end end
    end
    for g = 1, G do if not has(out, g) then out[#out + 1] = g end end
    return out
end
-- ordre de placement : persos choisis pour un buff, puis heals, tanks, Shadow / Balance, mêlées, chasseurs, casters
local function placeRank(u, prefs)
    if (prefs and prefs[u]) or (u.class == "SHAMAN" and SHAMAN_GROUPS[u.spec or ""]) then return 0 end
    if u.role == "Healer" then return 1 end
    if u.role == "Tank" then return 2 end
    if shadowBal(u) then return 3 end
    if u.role == "Melee" then return 4 end
    if u.class == "HUNTER" then return 5 end
    return 6
end
-- chamans dispersés au maximum : groupe avec le moins de chamans d'abord (shams(g)), à égalité l'ordre voulu
local function shamanFirst(list, shams)
    local out, n, idx = copy(list), {}, {}
    for i, g in ipairs(out) do n[g], idx[g] = shams(g), i end
    table.sort(out, function(a, b)
        if n[a] ~= n[b] then return n[a] < n[b] end
        return idx[a] < idx[b]
    end)
    return out
end

-- case libre pour un perso ajouté à une compo déjà remplie en partie (Autofill Buffs) : dans un de ses groupes voulus
-- (chaman : groupe sans chaman d'abord) ; bySlot = { [case] = unité } des occupants
local function freeSlot(bySlot, u, size, prefs)
    local G, members = size / 5, {}
    for _, m in pairs(bySlot) do members[#members + 1] = m end
    local list = groupPrefs(u, members, prefs, G)
    if u.class == "SHAMAN" then
        list = shamanFirst(list, function(g)
            local n = 0
            for s = (g - 1) * 5 + 1, g * 5 do if bySlot[s] and bySlot[s].class == "SHAMAN" then n = n + 1 end end
            return n
        end)
    end
    for _, g in ipairs(list) do
        for s = (g - 1) * 5 + 1, g * 5 do if not bySlot[s] then return s end end
    end
end
ns.AutofillFreeSlot = freeSlot

-- Place les nouveaux venus (dans l'ordre placeRank) dans les cases libres de leurs groupes voulus ; bySlot = occupants
-- { [case] = unité }, complété ; retourne { [case] = unité } des nouveaux
local function placeNew(bySlot, newcomers, size, prefs)
    local order, added = copy(newcomers), {}
    stableSort(order, function(u) return placeRank(u, prefs) end)
    for _, u in ipairs(order) do
        local s = freeSlot(bySlot, u, size, prefs)
        if s then bySlot[s] = u added[s] = u end
    end
    return added
end
-- compo vide : { [case] = unité }
ns.AutofillGroups = function(members, size, prefs) return placeNew({}, members, size, prefs) end

-- Autofill de la semaine : compo sélectionnée (et ses sœurs du même event + raid), sinon toutes les compos liées à un
-- event, par groupe (event, raid) dans l'ordre chronologique (en jeu : compos Main seulement) ; un raid 40 est rempli
-- comme un raid 20 pour l'instant (20 places, groupes 1 à 4). Un perso n'est jamais dans deux compos du même raid ; un
-- joueur jamais deux persos dans le même raid d'un même event (même horaire), mais il peut faire le raid 20 puis le
-- raid 10 du même event.
-- Les joueurs déjà placés restent ; buffsOnly (« Autofill Buffs ») : ajoute seulement ceux qui apportent des buffs / debuffs.
function ns:Autofill(buffsOnly)
    if not self:CanEdit() then return end   -- membre sans droits d'officier
    local week, sel = self:GetWeek(), self:Selected()
    local groups, list = {}, {}
    for _, comp in ipairs(week.comps) do
        if comp.event and (not sel or (comp.event == sel.event and comp.raid == sel.raid)) then
            local k = comp.event .. ":" .. comp.raid
            if not groups[k] then
                groups[k] = { event = comp.event, raid = comp.raid, comps = {} }
                list[#list + 1] = groups[k]
            end
            table.insert(groups[k].comps, comp)
        end
    end
    local function start(g) local ev = self:EventById(g.event) return ev and ev.start or 0 end
    stableSort(list, start)

    local filling, used, busy, nComps = {}, {}, {}, 0
    for _, g in ipairs(list) do
        for _, c in ipairs(g.comps) do filling[c] = true nComps = nComps + 1 end
    end
    local function pkOf(u) return u.tag or u.uid or u.name end
    local function mark(comp, name)
        used[comp.raid] = used[comp.raid] or {}
        used[comp.raid][name] = true
        if comp.event then
            local bk = comp.event .. ":" .. comp.raid
            busy[bk] = busy[bk] or {}
            busy[bk][pkOf(self:UnitFor(name))] = true
        end
    end
    -- déjà pris : tous les joueurs déjà placés (Autofill et Autofill Buffs complètent, ne remplacent pas)
    for _, comp in ipairs(week.comps) do
        for _, n in pairs(comp.c) do if type(n) == "string" then mark(comp, n) end end
    end

    local placed, total = 0, 0
    local signed = self:GetUnits().signed
    for _, g in ipairs(list) do
        local raid = self:RaidByKey(g.raid)
        local seen, cands = {}, {}
        local u_, b_ = used[g.raid] or {}, busy[g.event .. ":" .. g.raid] or {}
        for _, u in ipairs(signed) do
            local pk = pkOf(u)
            if u.events[g.event] and not u_[u.name] and not b_[pk] and not seen[pk] then
                seen[pk] = true
                cands[#cands + 1] = u
            end
        end
        total = total + #cands
        -- raid 40 : rempli comme un raid 20 pour l'instant (20 premières places)
        local size = raid.size == 40 and 20 or raid.size
        local current = {}
        for i, comp in ipairs(g.comps) do
            current[i] = {}
            for s = 1, size do
                local n = comp.c[s]
                if type(n) == "string" then current[i][#current[i] + 1] = self:CompUnit(comp, n) end
            end
        end
        local plan, prefs = ns.AutofillPlan(cands, size, current, buffsOnly)
        for i, comp in ipairs(g.comps) do
            -- nouveaux venus dans une case libre de leur groupe voulu, les autres ne bougent pas
            local bySlot, newcomers = {}, {}
            for s = 1, size do
                if type(comp.c[s]) == "string" then bySlot[s] = self:CompUnit(comp, comp.c[s]) end
            end
            local members = plan[i] or {}
            for j = #current[i] + 1, #members do newcomers[#newcomers + 1] = members[j] end
            for s, u in pairs(placeNew(bySlot, newcomers, size, prefs)) do
                comp.c[s] = u.name
                mark(comp, u.name)
                placed = placed + 1
            end
        end
    end
    self:Touch(week)
    print(("|cff6f7cffGuildTool|r: %s placed %d players in %d comp(s), %d left on the bench."):format(buffsOnly and "autofill buffs" or "autofill", placed, nComps, total - placed))
end
