-- GuildTool : outils de l'onglet Loots — recherche (Player : pseudos séparés par des virgules ; Items : nom d'objet +
-- types), menu des réactions (double-clic), ligne « + » pour ajouter une attribution à la main (objet par Maj + clic,
-- perso dans une liste filtrée, réaction, date au clavier ou au calendrier, molette = jour suivant / précédent),
-- « Compare looting » depuis /tlc.
local _, ns = ...
local C = ns.C
local GetItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
local GetItemInfoInstant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
local L = function(...) return ns.L(...) end

local KIND_KEYS = { "bis", "upp", "up", "os", "pvp", "mog", "de", "vendor" }
local KIND_LABEL = { bis = "Bis", upp = "Up+", up = "Up", os = "Off Spec", pvp = "PvP", mog = "Mog", de = "Disenchant", vendor = "Vendor" }
ns.LOOT_KIND_LABEL = KIND_LABEL
ns.LOOT_KIND_COL = { bis = { 1, 0.62, 0.2 }, upp = { 0.3, 0.85, 0.45 }, up = { 0.35, 0.65, 1 }, os = { 0.72, 0.5, 1 },
                     pvp = { 1, 0.38, 0.38 }, mog = { 1, 0.5, 0.8 }, de = { 0.6, 0.62, 0.68 }, vendor = { 0.6, 0.62, 0.68 } }

---------------------------------------------------------------------------
-- Recherche
---------------------------------------------------------------------------
-- types d'objets : classe:sous-classe (GetItemInfoInstant, sans cache), capes = emplacement « dos »
local TYPES = {
    { "cloth", "Cloth", "4:1" }, { "leather", "Leather", "4:2" }, { "mail", "Mail", "4:3" }, { "plate", "Plate", "4:4" },
    { "cloak", "Cloak", "back" }, { "shield", "Shield", "4:6" }, { "axe1", "One-Handed Axes", "2:0" }, { "axe2", "Two-Handed Axes", "2:1" },
    { "mace1", "One-Handed Maces", "2:4" }, { "mace2", "Two-Handed Maces", "2:5" }, { "sword1", "One-Handed Swords", "2:7" },
    { "sword2", "Two-Handed Swords", "2:8" }, { "dagger", "Daggers", "2:15" }, { "fist", "Fist Weapons", "2:13" },
    { "polearm", "Polearms", "2:6" }, { "staff", "Staves", "2:10" }, { "bow", "Bows", "2:2" }, { "gun", "Guns", "2:3" },
    { "crossbow", "Crossbows", "2:18" }, { "wand", "Wands", "2:19" }, { "thrown", "Thrown", "2:16" },
}
local function itemType(id)
    if not (GetItemInfoInstant and id) then return nil end
    local _, _, _, equip, _, cid, sid = GetItemInfoInstant(id)
    if equip == "INVTYPE_CLOAK" then return "cloak" end
    if not cid then return nil end
    local key = cid .. ":" .. (sid or 0)
    for _, t in ipairs(TYPES) do if t[3] == key then return t[1] end end
end
function ns.LootQ(tab) return strtrim((ns.lootQ or {})[tab or ns.lootTab or "all"] or "") end
local function typesOn()
    local out = {}
    for _, t in ipairs(TYPES) do if (ns.lootTypes or {})[t[1]] then out[t[1]] = true end end
    return out, next(out) ~= nil
end
-- vue Items : recherche en cours (nom ou types)
function ns.LootSearching()
    local _, any = typesOn()
    return ns.LootQ("boss") ~= "" or any
end
-- History : joueur (nom Discord ou perso) et types cochés
function ns.LootHistoryMatch(rec, discord)
    local q = strlower(ns.LootQ("all"))
    if q ~= "" and not (strlower(rec.to or ""):find(q, 1, true) or strlower(discord or ""):find(q, 1, true)) then return false end
    local on, any = typesOn()
    return not any or on[itemType(rec.id) or ""] == true
end
function ns.LootItemMatch(id, name)
    local q = strlower(ns.LootQ("boss"))
    if q ~= "" and not strlower(name or ""):find(q, 1, true) then return false end
    local on, any = typesOn()
    return not any or on[itemType(id) or ""] == true
end
-- vue Player : pseudos cherchés (en minuscules), nil si la recherche est vide
function ns.LootPlayerTokens()
    local out = {}
    for tok in ns.LootQ("role"):gmatch("[^,]+") do
        tok = strlower(strtrim(tok))
        if tok ~= "" then out[#out + 1] = tok end
    end
    return #out > 0 and out or nil
end

function ns:CreateLootSearch()
    local sub = self.sub
    local e = CreateFrame("EditBox", nil, sub)
    -- à gauche de l'engrenage (6 + 28 + 8) ; 230 de large, Type compris
    e:SetSize(230, 22)
    e:SetPoint("RIGHT", sub, "RIGHT", -42, 0)
    e:SetAutoFocus(false)
    e:SetFontObject(ChatFontNormal)
    e:SetTextInsets(6, 6, 0, 0)
    ns.Fill(e, C.input)
    ns.Border(e, C.border)
    e.ph = ns.Text(e, 11, 400, C.mute)
    e.ph:SetPoint("LEFT", 7, 0)
    -- recherche appliquée (texte tapé ou nom choisi dans les propositions)
    local function apply(text)
        ns.lootQ = ns.lootQ or {}
        ns.lootQ[ns.lootTab or "all"] = text
        if strtrim(text) == "" then ns.lootSClosed = {} end
        ns:RefreshLootsPage()
    end
    -- Échap : texte effacé (recherche vide) ; Entrée : nom Discord proposé en surbrillance choisi
    e:SetScript("OnEscapePressed", function(s)
        if s:GetText() ~= "" then s:SetText("") apply("") end
        s:ClearFocus()
    end)
    e:SetScript("OnEnterPressed", function(s)
        local sug = ns.lootSug
        local name = sug and sug:IsShown() and sug.names[sug.idx]
        if name then s:SetText(name) apply(name) end
        s:ClearFocus()
    end)
    e:SetScript("OnArrowPressed", function(_, key) ns:LootSugMove(key == "DOWN" and 1 or key == "UP" and -1 or 0) end)
    e:SetScript("OnEditFocusGained", function(s) ns.SetBorderColor(s, C.hl) ns:LootSugFill() end)
    e:SetScript("OnEditFocusLost", function(s)
        ns.SetBorderColor(s, C.border)
        -- un clic sur une proposition passe avant la fermeture
        C_Timer.After(0.2, function() if ns.lootSug and not s:HasFocus() then ns.lootSug:Hide() end end)
    end)
    e:SetScript("OnTextChanged", function(s, user)
        s.ph:SetShown(s:GetText() == "")
        if not user then return end
        apply(s:GetText())
        ns:LootSugFill()
    end)
    e.apply = apply
    e:Hide()
    self.lootsQ = e
    -- types (vue Items) : liste à cocher, plusieurs choix
    local b = ns.Button(sub, "Type", 74, 22)
    b:SetPoint("RIGHT", e, "LEFT", -4, 0)
    -- petit triangle (le caractère ▾ n'existe pas dans la police du jeu)
    b.label:ClearAllPoints()
    b.label:SetPoint("CENTER", -6, 0)
    b.tri = ns.Triangle(b, "down", 8)
    b.tri:SetPoint("LEFT", b.label, "RIGHT", 6, 0)
    b:SetScript("OnClick", function() ns:LootTypeList() end)
    b:Hide()
    self.lootsTypeBtn = b
end
-- Wishlist : propositions de noms Discord sous la recherche (noms des inscriptions Raid-Helper), affinées par le texte ;
-- flèches haut / bas, la 1re en surbrillance, Entrée ou clic = choisie
local SUG_ROWS, SUG_H = 10, 20
function ns:LootSugFill()
    local e = self.lootsQ
    if not e then return end
    local w = self.lootSug
    if (self.lootTab or "all") ~= "wish" or not e:HasFocus() then if w then w:Hide() end return end
    if not w then
        w = CreateFrame("Frame", nil, self.frame)
        w:SetFrameStrata("DIALOG")
        w:SetPoint("TOPLEFT", e, "BOTTOMLEFT", 0, -2)
        w:SetPoint("TOPRIGHT", e, "BOTTOMRIGHT", 0, -2)
        w:EnableMouse(true)
        ns.Fill(w, { 0.09, 0.094, 0.11 }, 0.97)
        ns.Border(w, C.border)
        w.rows = {}
        for i = 1, SUG_ROWS do
            local r = CreateFrame("Button", nil, w)
            r:SetHeight(SUG_H)
            r:SetPoint("TOPLEFT", 2, -2 - (i - 1) * SUG_H)
            r:SetPoint("TOPRIGHT", -2, -2 - (i - 1) * SUG_H)
            r.hl = ns.Fill(r, C.hl, 1)
            r.label = ns.Text(r, 11.5, 600)
            r.label:SetPoint("LEFT", 6, 0)
            r.label:SetPoint("RIGHT", -6, 0)
            r.label:SetJustifyH("LEFT")
            r.label:SetWordWrap(false)
            r:SetScript("OnEnter", function(s) w.idx = s.i ns:LootSugPaint() end)
            r:SetScript("OnClick", function(s)
                local name = w.names[s.i]
                if name then e:SetText(name) e.apply(name) end
                e:ClearFocus()
                w:Hide()
            end)
            w.rows[i] = r
        end
        self.lootSug = w
    end
    local q, seen, names = strlower(strtrim(e:GetText())), {}, {}
    for _, n in pairs(ns.DiscordNames and ns.DiscordNames() or {}) do
        local l = strlower(n)
        if not seen[l] and (q == "" or l:find(q, 1, true)) then seen[l] = true names[#names + 1] = n end
    end
    -- d'abord ceux qui commencent par le texte, puis A-Z
    table.sort(names, function(a, b)
        local pa, pb = strlower(a):sub(1, #q) == q, strlower(b):sub(1, #q) == q
        if pa ~= pb then return pa end
        return strlower(a) < strlower(b)
    end)
    for i = #names, SUG_ROWS + 1, -1 do names[i] = nil end
    w.names, w.idx = names, 1
    if #names == 0 then w:Hide() return end
    w:SetHeight(#names * SUG_H + 4)
    self:LootSugPaint()
    w:Show()
end
function ns:LootSugPaint()
    local w = self.lootSug
    for i, r in ipairs(w.rows) do
        local n = w.names[i]
        r.i = i
        r:SetShown(n ~= nil)
        if n then
            ns.SetFont(r.label, 11.5, 600)
            r.label:SetText(n)
            r.hl:SetAlpha(i == w.idx and 0.3 or 0)
        end
    end
end
function ns:LootSugMove(d)
    local w = self.lootSug
    if not (w and w:IsShown() and #w.names > 0) or d == 0 then return end
    w.idx = (w.idx - 1 + d) % #w.names + 1
    self:LootSugPaint()
end
function ns:LootTypeList()
    local w = self.lootTypeWin
    if w and w:IsShown() then w:Hide() return end
    if not w then
        w = CreateFrame("Frame", nil, self.frame)
        w:SetFrameStrata("DIALOG")
        w:SetSize(200, #TYPES * 20 + 34)
        w:SetPoint("TOPLEFT", self.lootsTypeBtn, "BOTTOMLEFT", 0, -4)
        w:EnableMouse(true)
        ns.Fill(w, { 0.09, 0.094, 0.11 }, 0.97)
        ns.Border(w, C.border)
        w.rows = {}
        for i, t in ipairs(TYPES) do
            local r = CreateFrame("Button", nil, w)
            r:SetSize(192, 20)
            r:SetPoint("TOPLEFT", 4, -4 - (i - 1) * 20)
            r.hl = ns.Fill(r, C.hl, 1)
            r.hl:SetAlpha(0)
            r.ck = ns.Tex(r, C.mute, "ARTWORK")
            r.ck:SetSize(10, 10)
            r.ck:SetPoint("LEFT", 6, 0)
            r.label = ns.Text(r, 11, 600)
            r.label:SetPoint("LEFT", 24, 0)
            r.key, r.text = t[1], t[2]
            r:SetScript("OnEnter", function(s) s.hl:SetAlpha(0.15) end)
            r:SetScript("OnLeave", function(s) s.hl:SetAlpha(0) end)
            r:SetScript("OnClick", function(s)
                ns.lootTypes = ns.lootTypes or {}
                ns.lootTypes[s.key] = not ns.lootTypes[s.key] or nil
                ns:LootTypeFill() ns:RefreshLootsPage()
            end)
            w.rows[i] = r
        end
        w.clear = ns.Button(w, L("Clear"), 192, 22)
        w.clear:SetPoint("BOTTOMLEFT", 4, 4)
        w.clear:SetScript("OnClick", function() ns.lootTypes = {} ns:LootTypeFill() ns:RefreshLootsPage() end)
        -- refermée 0,5 s après que la souris l'a quittée (et le bouton)
        w:SetScript("OnUpdate", function(f)
            if f:IsMouseOver() or ns.lootsTypeBtn:IsMouseOver() then f.out = nil
            else f.out = f.out or GetTime() if GetTime() - f.out > 0.5 then f:Hide() end end
        end)
        self.lootTypeWin = w
    end
    w:Show()
    self:LootTypeFill()
end
function ns:LootTypeFill()
    local w = self.lootTypeWin
    if not w then return end
    for _, r in ipairs(w.rows) do
        local on = (ns.lootTypes or {})[r.key]
        ns.SetFont(r.label, 11, 600)
        r.label:SetText(L(r.text))
        local c = on and C.hl or C.mute
        r.ck:SetColorTexture(c[1], c[2], c[3], on and 1 or 0.6)
    end
    ns.SetFont(w.clear.label, 11, 600)
    w.clear.label:SetText(L("Clear"))
end
-- barre : recherche visible sur les vues Player et Items, texte de la vue affichée
function ns:LootSearchUpdate()
    local e, b = self.lootsQ, self.lootsTypeBtn
    if not e then return end
    local tab = self.lootTab or "all"
    -- Wishlist : recherche d'un joueur (nom Discord) pour les officiers seulement
    local show = self.db.ui.page == "loots" and (tab ~= "wish" or self:MayEdit())
    local typ = show and (tab == "boss" or tab == "all")
    e:SetShown(show)
    b:SetShown(typ)
    -- Type à gauche de la recherche, dans ses 230 ; sélecteur de phase à gauche des deux
    e:SetWidth(typ and 230 - 78 or 230)
    if not show then if self.lootTypeWin then self.lootTypeWin:Hide() end return end
    if not e:HasFocus() then e:SetText((ns.lootQ or {})[tab] or "") end
    ns.SetFont(e.ph, 11, 400)
    e.ph:SetText(L(tab == "role" and "Players: name, name, …" or (tab == "wish" or tab == "all") and "Discord name" or "Search an item"))
    e.ph:SetShown(e:GetText() == "")
    local n = 0
    for _ in pairs(ns.lootTypes or {}) do n = n + 1 end
    ns.SetFont(b.label, 11, 600)
    b.label:SetText(L("Type") .. (n > 0 and (" (" .. n .. ")") or ""))
    ns.SetBorderColor(b, n > 0 and C.hl or C.border)
end

-- /tlc : « Compare looting » = fenêtre principale, onglet Loots, vue Player, ces persos dans la recherche
function ns:LootCompare(names)
    if not (self.frame and self.frame:IsShown()) then self:Toggle() end
    self.lootTab = "role"
    self.lootQ = self.lootQ or {}
    self.lootQ.role = table.concat(names, ", ")
    self:ShowPage("loots")
end

---------------------------------------------------------------------------
-- Réaction d'une attribution (double-clic) : liste des réactions
---------------------------------------------------------------------------
function ns:LootKindMenu(anchor, k)
    local items = {}
    for _, key in ipairs(KIND_KEYS) do
        items[#items + 1] = { text = L(KIND_LABEL[key]), color = ns.LOOT_KIND_COL[key], func = function() ns.LootSetEdit(k, "kind", key) end }
    end
    self:OpenMenu(anchor, items, 140)
end

---------------------------------------------------------------------------
-- Ligne « + » : attribution ajoutée à la main
---------------------------------------------------------------------------
local function editBox(parent, w, ph)
    local e = CreateFrame("EditBox", nil, parent)
    e:SetSize(w, 22)
    e:SetAutoFocus(false)
    e:SetFontObject(ChatFontNormal)
    e:SetTextInsets(6, 6, 0, 0)
    ns.Fill(e, C.input)
    ns.Border(e, C.border)
    e.ph = ns.Text(e, 11, 400, C.mute)
    e.ph:SetPoint("LEFT", 7, 0)
    e.phText = ph
    e:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    e:SetScript("OnEditFocusGained", function(s) ns.SetBorderColor(s, C.hl) end)
    e:SetScript("OnEditFocusLost", function(s) ns.SetBorderColor(s, C.border) end)
    return e
end
local function fmtDate(t) return date("%d/%m/%Y %H:%M", t) end
-- chiffres seuls, mis en forme « jj/mm/aaaa hh:mm » ; heure 20:00 par défaut
local function parseDate(txt)
    local d = (txt or ""):gsub("%D", "")
    if #d < 8 then return nil end
    local day, mon, yr = tonumber(d:sub(1, 2)), tonumber(d:sub(3, 4)), tonumber(d:sub(5, 8))
    local h = #d >= 10 and tonumber(d:sub(9, 10)) or 20
    local mi = #d >= 12 and tonumber(d:sub(11, 12)) or 0
    if mon < 1 or mon > 12 or day < 1 or day > 31 then return nil end
    local t = time({ year = yr, month = mon, day = day, hour = math.min(23, h), min = math.min(59, mi), sec = 0 })
    if tonumber(date("%d", t)) ~= day then return nil end
    return t
end
local function formatDigits(txt)
    local d = (txt or ""):gsub("%D", ""):sub(1, 12)
    local s = d:sub(1, 2)
    if #d > 2 then s = s .. "/" .. d:sub(3, 4) end
    if #d > 4 then s = s .. "/" .. d:sub(5, 8) end
    if #d > 8 then s = s .. " " .. d:sub(9, 10) end
    if #d > 10 then s = s .. ":" .. d:sub(11, 12) end
    return s
end

-- petit calendrier sous le champ de date : clic sur un jour ; molette = jour suivant / précédent
local function createCal(row)
    local cal = CreateFrame("Frame", nil, ns.frame)
    cal:SetFrameStrata("DIALOG")
    cal:SetSize(7 * 28 + 12, 6 * 22 + 40)
    cal:EnableMouse(true)
    ns.Fill(cal, { 0.09, 0.094, 0.11 }, 0.98)
    ns.Border(cal, C.hl)
    cal.head = ns.Text(cal, 12, 700, C.white)
    cal.head:SetPoint("TOP", 0, -8)
    for i, d in ipairs({ -1, 1 }) do
        local b = ns.IconButton(cal, d < 0 and "<" or ">", 20)
        b:SetPoint(d < 0 and "TOPLEFT" or "TOPRIGHT", d < 0 and 4 or -4, -4)
        b:SetScript("OnClick", function()
            local t = date("*t", ns.lootNew.t)
            t.month = t.month + d
            ns:LootNewSetT(time(t))
        end)
        cal["nav" .. i] = b
    end
    cal.days = {}
    for i = 1, 42 do
        local b = CreateFrame("Button", nil, cal)
        b:SetSize(26, 20)
        b:SetPoint("TOPLEFT", 6 + ((i - 1) % 7) * 28, -30 - math.floor((i - 1) / 7) * 22)
        b.bg = ns.Fill(b, C.input, 0.8)
        b.edges = ns.Border(b, C.border, 0)
        b.label = ns.Text(b, 11, 600)
        b.label:SetPoint("CENTER")
        b:SetScript("OnClick", function(s)
            local t = date("*t", ns.lootNew.t)
            t.day = s.day
            ns:LootNewSetT(time(t))
            cal:Hide()
        end)
        b:SetScript("OnEnter", function(s) ns.SetBorderColor(s, C.hl) end)
        b:SetScript("OnLeave", function(s) ns.SetBorderColor(s, s.sel and { 1, 0.82, 0.25 } or C.border, s.sel and 1 or 0) end)
        cal.days[i] = b
    end
    cal:EnableMouseWheel(true)
    cal:SetScript("OnMouseWheel", function(_, d) ns:LootNewSetT(ns.lootNew.t - d * 86400) end)
    cal:SetScript("OnUpdate", function(f)
        if f:IsMouseOver() or row.date:IsMouseOver() or row.date:HasFocus() then f.out = nil
        else f.out = f.out or GetTime() if GetTime() - f.out > 0.8 then f:Hide() end end
    end)
    cal:Hide()
    return cal
end
function ns:LootNewSetT(t)
    local n = self.lootNew
    if not n then return end
    n.t = t
    local row = self.lootsNewRow
    if row and not row.date.typing then row.date:SetText(fmtDate(t)) end
    self:LootCalFill()
end
function ns:LootCalFill()
    local row = self.lootsNewRow
    local cal = row and row.cal
    if not (cal and cal:IsShown() and self.lootNew) then return end
    local cur = date("*t", self.lootNew.t)
    ns.SetFont(cal.head, 12, 700)
    cal.head:SetText(ns.MonthLong(cur.month) .. " " .. cur.year)
    local first = time({ year = cur.year, month = cur.month, day = 1, hour = 12 })
    local lead = (tonumber(date("%w", first)) + 6) % 7
    local days = tonumber(date("%d", time({ year = cur.year, month = cur.month + 1, day = 0, hour = 12 })))
    for i, b in ipairs(cal.days) do
        local d = i - lead
        if d >= 1 and d <= days then
            b.day = d
            b.sel = d == cur.day
            ns.SetFont(b.label, 11, 600)
            b.label:SetText(d)
            local c = b.sel and { 1, 0.82, 0.25 } or C.text
            b.label:SetTextColor(c[1], c[2], c[3])
            ns.SetBorderColor(b, b.sel and { 1, 0.82, 0.25 } or C.border, b.sel and 1 or 0)
            b:Show()
        else
            b:Hide()
        end
    end
end

local function newEditRow(parent)
    local r = CreateFrame("Frame", nil, parent)
    r:SetHeight(34)
    ns.Fill(r, C.panel, 0.9)
    ns.Border(r, C.hl)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(26, 26)
    r.icon:SetPoint("LEFT", 6, 0)
    -- objet : Maj + clic sur un objet (sac, chat…) pendant que le champ est actif ; n° d'objet ou nom (en cache) + Entrée
    r.item = editBox(r, 300, "Shift + click an item (or its ID + Enter)")
    r.item:SetPoint("LEFT", 40, 0)
    r.item:SetScript("OnEnterPressed", function(s)
        local txt = s:GetText() or ""
        local id = tonumber(txt:match("item:(%d+)") or txt:match("^%s*(%d+)%s*$"))
        local link = txt:match("|H(item:[^|]+)|h") and txt
        if not id and txt ~= "" then
            local _, l2 = GetItemInfo(txt)
            if l2 then link, id = l2, tonumber(l2:match("item:(%d+)")) end
        end
        if id then ns:LootNewSetItem(id, link) end
        s:ClearFocus()
    end)
    r.item:SetScript("OnTextChanged", function(s) s.ph:SetShown(s:GetText() == "") end)
    -- perso : liste filtrée au fil de la frappe
    r.to = editBox(r, 180, "Character")
    r.to:SetScript("OnTextChanged", function(s, user)
        s.ph:SetShown(s:GetText() == "")
        if not user then return end
        ns.lootNew.to = nil
        local q = strlower(s:GetText() or "")
        local names = {}
        for n, x in pairs(ns.db.roster or {}) do
            if x and x.c and (q == "" or strlower(n):find(q, 1, true)) then names[#names + 1] = n end
        end
        table.sort(names)
        local items = {}
        for i = 1, math.min(25, #names) do
            local n = names[i]
            items[#items + 1] = { text = n, color = ns.ClassColor(ns.db.roster[n].c), func = function()
                ns.lootNew.to = n
                s:SetText(n)
                local cc = ns.ClassColor(ns.db.roster[n].c)
                s:SetTextColor(cc[1], cc[2], cc[3])
                s:ClearFocus()
            end }
        end
        if #items == 0 then items[1] = { text = L("No character found."), func = function() end } end
        ns:OpenMenu(s, items, 200)
    end)
    r.to:SetScript("OnEnterPressed", function()
        local m = ns.menu
        local b = m and m:IsShown() and m.buttons[1]
        if b and b:IsShown() then b:Click() end
    end)
    -- réaction : liste
    r.kind = ns.Button(r, L("Roll"), 110, 22)
    r.kind:SetScript("OnClick", function(s)
        local items = {}
        for _, key in ipairs(KIND_KEYS) do
            items[#items + 1] = { text = L(KIND_LABEL[key]), color = ns.LOOT_KIND_COL[key], func = function() ns.lootNew.kind = key end }
        end
        ns:OpenMenu(s, items, 140)
    end)
    -- date : chiffres mis en forme au fil de la frappe ; calendrier (molette = jour suivant / précédent)
    r.date = editBox(r, 130, "")
    r.date:SetScript("OnTextChanged", function(s, user)
        if not user then return end
        local f = formatDigits(s:GetText())
        if f ~= s:GetText() then s:SetText(f) s:SetCursorPosition(#f) end
        local t = parseDate(f)
        if t then s.typing = true ns:LootNewSetT(t) s.typing = nil end
    end)
    r.date:SetScript("OnEditFocusGained", function(s)
        ns.SetBorderColor(s, C.hl)
        r.cal:ClearAllPoints()
        r.cal:SetPoint("TOPLEFT", s, "BOTTOMLEFT", 0, -4)
        r.cal:Show()
        ns:LootCalFill()
    end)
    r.date:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
    r.date:EnableMouseWheel(true)
    r.date:SetScript("OnMouseWheel", function(_, d) ns:LootNewSetT(ns.lootNew.t - d * 86400) end)
    r.cal = createCal(r)
    -- ✓ enregistrer, × annuler
    r.ok = ns.Button(r, "OK", 40, 22, true)
    r.ok:SetPoint("RIGHT", -50, 0)
    r.ok:SetScript("OnClick", function() ns:LootNewSave() end)
    r.cancel = ns.IconButton(r, "×", 22, L("Cancel"))
    r.cancel:SetPoint("RIGHT", -16, 0)
    r.cancel:SetScript("OnClick", function() ns.lootNew = nil r.cal:Hide() ns:RefreshLootsPage() end)
    return r
end
function ns:LootNewSetItem(id, link)
    local n = self.lootNew
    if not n then return end
    n.id, n.link = id, link
    local name, l2, q, _, _, _, _, _, _, icon = GetItemInfo(link or id)
    n.name, n.link = name, n.link or l2
    local row = self.lootsNewRow
    if row then
        row.icon:SetTexture(icon or (C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id)) or 134400)
        row.item:SetText(name or ("item " .. id))
        local qc = ITEM_QUALITY_COLORS and q and ITEM_QUALITY_COLORS[q] or { r = 1, g = 1, b = 1 }
        row.item:SetTextColor(qc.r, qc.g, qc.b)
    end
end
-- Maj + clic sur un objet pendant que le champ « objet » est actif
if ChatEdit_InsertLink then
    hooksecurefunc("ChatEdit_InsertLink", function(link)
        local row = ns.lootsNewRow
        if row and row:IsVisible() and row.item:HasFocus() and type(link) == "string" then
            local id = tonumber(link:match("item:(%d+)"))
            if id then ns:LootNewSetItem(id, link) row.item:ClearFocus() end
        end
    end)
end
function ns:LootNewSave()
    local n = self.lootNew
    if not (n and n.id and n.to) then
        UIErrorsFrame:AddMessage(L("Choose an item and a character."), 1, 0.42, 0.42)
        return
    end
    self.db.lootHistory = self.db.lootHistory or {}
    table.insert(self.db.lootHistory, { key = "m" .. time() .. math.random(100, 999), id = n.id, name = n.name, link = n.link, t = n.t,
                                        to = n.to, by = self:MyName(), kind = n.kind, same = {}, manual = true })
    if self.LogPending then self:LogPending(L("Loots") .. " · " .. (n.name or n.id) .. " -> " .. n.to) end
    self.lootNew = nil
    if self.lootsNewRow then self.lootsNewRow.cal:Hide() end
    self:RefreshLootsPage()
end
-- « + » (officiers) ou ligne à remplir, en tête de l'historique ; renvoie la hauteur prise
function ns:LootAddRow(parent, officer, cols)
    if not officer then
        if self.lootsAddBtn then self.lootsAddBtn:Hide() end
        if self.lootsNewRow then self.lootsNewRow:Hide() self.lootsNewRow.cal:Hide() end
        return 0
    end
    if not self.lootsAddBtn then
        local b = CreateFrame("Button", nil, parent)
        b:SetHeight(26)
        ns.Fill(b, C.panel, 0.6)
        ns.Border(b, C.border)
        b.label = ns.Text(b, 16, 700, C.mute)
        b.label:SetPoint("CENTER")
        b:SetScript("OnEnter", function(s) ns.SetBorderColor(s, C.hl) s.label:SetTextColor(1, 1, 1)
            ns.TipOwner(s) GameTooltip:SetText(L("Add an attribution by hand"), 1, 1, 1) GameTooltip:Show() end)
        b:SetScript("OnLeave", function(s) ns.SetBorderColor(s, C.border) s.label:SetTextColor(C.mute[1], C.mute[2], C.mute[3]) GameTooltip:Hide() end)
        b:SetScript("OnClick", function()
            ns.lootNew = { t = time() }
            local row = ns.lootsNewRow
            if row then
                row.item:SetText("") row.to:SetText("") row.icon:SetTexture(134400)
                row.to:SetTextColor(1, 1, 1) row.item:SetTextColor(1, 1, 1)
            end
            ns:RefreshLootsPage()
            if ns.lootsNewRow then ns.lootsNewRow.item:SetFocus() end
        end)
        self.lootsAddBtn = b
        self.lootsNewRow = newEditRow(parent)
    end
    local b, row = self.lootsAddBtn, self.lootsNewRow
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", 0, 0)
    b:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", 0, 0)
    row:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
    ns.SetFont(b.label, 16, 700)
    b.label:SetText("+")
    local n = self.lootNew
    b:SetShown(not n)
    row:SetShown(n ~= nil)
    if not n then row.cal:Hide() return 26 + 3 end
    row.item:SetWidth(cols.nameW + 4)
    row.to:ClearAllPoints() row.to:SetPoint("LEFT", cols.toX, 0)
    row.kind:ClearAllPoints() row.kind:SetPoint("LEFT", cols.kindX, 0)
    row.date:ClearAllPoints() row.date:SetPoint("LEFT", cols.dateX - 6, 0)
    for _, e in ipairs({ row.item, row.to }) do
        ns.SetFont(e.ph, 11, 400)
        e.ph:SetText(L(e.phText))
        e.ph:SetShown(e:GetText() == "")
    end
    ns.SetFont(row.kind.label, 11.5, 600)
    local kc = ns.LOOT_KIND_COL[n.kind or ""] or C.text
    row.kind.label:SetText(n.kind and L(KIND_LABEL[n.kind]) or L("Roll"))
    row.kind.label:SetTextColor(kc[1], kc[2], kc[3])
    if not row.date:HasFocus() then row.date:SetText(fmtDate(n.t)) end
    ns.SetFont(row.ok.label, 11, 700)
    row.ok.label:SetText("OK")
    return 34 + 3
end

---------------------------------------------------------------------------
-- Wishlist (= appli) : par perso, { t, items = { { id, k (roll), t } } } ; mes modifications dans db.wishlist (lues par
-- l'exe, partagées avec le perso), celles de l'appli / de la guilde dans db.wishlistsImp (Import.lua)
---------------------------------------------------------------------------
ns.WISH_KINDS = { "bis", "upp", "up", "os", "pvp", "mog" }
-- mes persos (pas les cachés)
function ns:WishMine()
    local out = {}
    for n, c in pairs(self.db.myChars or {}) do
        if not self:IsHidden(n) then out[#out + 1] = { name = n, class = c.c or (self.db.roster[n] or {}).c } end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end
-- objets de la wishlist d'un perso : ma modification en jeu si elle est plus récente que celle de l'exe
function ns:WishOf(name)
    local mine = (self.db.wishlist or {})[name]
    if mine and (mine.t or 0) > ((self.db.wishlistT or {})[name] or 0) then return mine.items or {} end
    return (self.db.wishlistsImp or {})[name] or {}
end
function ns:WishSet(name, items)
    self.db.wishlist = self.db.wishlist or {}
    self.db.wishlist[name] = { t = time(), items = items }
    if self.LogPending then self:LogPending(L("Wishlist") .. " · " .. name) end
    self:RefreshLootsPage()
end
function ns:WishAdd(name, id, k)
    local out = {}
    for _, x in ipairs(self:WishOf(name)) do if tonumber(x.id) ~= tonumber(id) then out[#out + 1] = x end end
    out[#out + 1] = { id = tonumber(id), k = k or "bis", t = time() }
    self:WishSet(name, out)
end
function ns:WishRemove(name, id)
    local out = {}
    for _, x in ipairs(self:WishOf(name)) do if tonumber(x.id) ~= tonumber(id) then out[#out + 1] = x end end
    self:WishSet(name, out)
end
-- archive retirée (par un officier, pour tout le monde) ; retrait fait ici : lu par l'exe (officier)
function ns:WishArchHidden(name, id)
    local k = name .. "|" .. tostring(id)
    return (self.db.wishArchHideImp or {})[k] or (self.db.wishArchHide or {})[k]
end
function ns:WishArchHide(name, id)
    self.db.wishArchHide = self.db.wishArchHide or {}
    self.db.wishArchHide[name .. "|" .. tostring(id)] = time()
    if self.LogPending then self:LogPending(L("Wishlist") .. " · " .. L("Archives")) end
    self:RefreshLootsPage()
end
function ns:WishHasMine(id)
    for _, c in ipairs(self:WishMine()) do
        for _, x in ipairs(self:WishOf(c.name)) do if tonumber(x.id) == tonumber(id) then return true end end
    end
    return false
end
-- phase d'un objet : celle du raid dont la table le contient (nil = inconnue, jamais archivé)
function ns:WishItemPhase(id)
    for _, src in ipairs({ self.db.bossLootDB or {}, self.db.bossLoot or {} }) do
        for raid, bosses in pairs(src) do
            for _, items in pairs(bosses) do
                if items[tostring(id)] ~= nil or items[tonumber(id)] ~= nil then
                    for pi, ph in ipairs(ns.PHASES) do
                        for _, r in ipairs(ph.raids or {}) do if r.key == raid then return pi end end
                    end
                end
            end
        end
    end
end
-- le perso a reçu l'objet (base des attributions ; anciens noms sans le nom de famille acceptés)
function ns:WishGot(name, id)
    local f = name:match("^(%S+)") or name
    for _, r in ipairs(self:LootRecords()) do
        if tonumber(r.id) == tonumber(id) and (r.to == name or ((r.to or ""):match("^(%S+)") == f)) then return true end
    end
    return false
end

-- Popup de l'étoile (vue Tables) : entrées existantes (×), perso, roll, « Add to wishlist »
function ns:WishPopup(id, anchor)
    local mine = self:WishMine()
    if #mine == 0 then
        UIErrorsFrame:AddMessage(L("No character of yours is known yet: log in with Discord and play them once with Guild Tool."), 1, 0.42, 0.42)
        return
    end
    local p = self.wishPop
    if not p then
        p = CreateFrame("Frame", nil, self.frame)
        p:SetFrameStrata("DIALOG")
        p:SetSize(240, 120)
        p:EnableMouse(true)
        ns.Fill(p, { 0.09, 0.094, 0.11 }, 0.98)
        ns.Border(p, C.hl)
        p.title = ns.Text(p, 12, 700)
        p.title:SetPoint("TOPLEFT", 10, -8)
        p.title:SetWidth(200)
        p.title:SetJustifyH("LEFT")
        p.title:SetWordWrap(false)
        p.close = ns.IconButton(p, "×", 20)
        p.close:SetPoint("TOPRIGHT", -4, -4)
        p.close:SetScript("OnClick", function() p:Hide() end)
        p.lines = {}
        p.char = ns.Button(p, "", 108, 22)
        p.char:SetScript("OnClick", function(b)
            local items = {}
            for _, c in ipairs(ns:WishMine()) do
                items[#items + 1] = { text = c.name, color = ns.ClassColor(c.class), func = function() p.selChar = c.name ns:WishPopupFill() end }
            end
            ns:OpenMenu(b, items, 180)
        end)
        p.kind = ns.Button(p, "", 108, 22)
        p.kind:SetScript("OnClick", function(b)
            local items = {}
            for _, k in ipairs(ns.WISH_KINDS) do
                items[#items + 1] = { text = L(KIND_LABEL[k]), color = ns.LOOT_KIND_COL[k], func = function() p.selKind = k ns:WishPopupFill() end }
            end
            ns:OpenMenu(b, items, 140)
        end)
        p.add = ns.Button(p, "", 220, 24, true)
        p.add:SetScript("OnClick", function()
            p:Hide()
            ns:WishAdd(p.selChar, p.item, p.selKind)
            print(("|cff6f7cffGuildTool|r: %s"):format(L("Added to the wishlist of {0}.", p.selChar)))
        end)
        -- refermée par Échap
        p:EnableKeyboard(true)
        p:SetScript("OnKeyDown", function(f, key)
            if key == "ESCAPE" then f:SetPropagateKeyboardInput(false) f:Hide() else f:SetPropagateKeyboardInput(true) end
        end)
        self.wishPop = p
    end
    p.item = id
    p.selChar = p.selChar or mine[1].name
    local ok = false
    for _, c in ipairs(mine) do if c.name == p.selChar then ok = true end end
    if not ok then p.selChar = mine[1].name end
    p.selKind = p.selKind or "bis"
    p:ClearAllPoints()
    p:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 6, 4)
    p:Show()
    self:WishPopupFill()
end
function ns:WishPopupFill()
    local p = self.wishPop
    if not (p and p:IsShown()) then return end
    local name, _, q = GetItemInfo(p.item)
    local qc = ITEM_QUALITY_COLORS and q and ITEM_QUALITY_COLORS[q] or { r = 1, g = 1, b = 1 }
    ns.SetFont(p.title, 12, 700)
    p.title:SetText(name or ("item " .. p.item))
    p.title:SetTextColor(qc.r, qc.g, qc.b)
    -- entrées existantes de mes persos pour cet objet
    local have = {}
    for _, c in ipairs(self:WishMine()) do
        for _, x in ipairs(self:WishOf(c.name)) do if tonumber(x.id) == tonumber(p.item) then have[#have + 1] = { c = c, x = x } end end
    end
    local y = -30
    for i, h in ipairs(have) do
        local l = p.lines[i]
        if not l then
            l = CreateFrame("Frame", nil, p)
            l:SetSize(220, 20)
            l.name = ns.Text(l, 11.5, 700)
            l.name:SetPoint("LEFT", 0, 0)
            l.kind = ns.Text(l, 11, 600)
            l.kind:SetPoint("LEFT", 120, 0)
            l.del = ns.IconButton(l, "×", 18)
            l.del:SetPoint("RIGHT", 0, 0)
            l.del:SetScript("OnClick", function(b) p:Hide() ns:WishRemove(b.char, p.item) end)
            p.lines[i] = l
        end
        l:ClearAllPoints()
        l:SetPoint("TOPLEFT", 10, y)
        local cc = ns.ClassColor(h.c.class)
        ns.SetFont(l.name, 11.5, 700) l.name:SetText(h.c.name) l.name:SetTextColor(cc[1], cc[2], cc[3])
        local kc = ns.LOOT_KIND_COL[h.x.k] or C.mute
        ns.SetFont(l.kind, 11, 600) l.kind:SetText(L(KIND_LABEL[h.x.k] or h.x.k)) l.kind:SetTextColor(kc[1], kc[2], kc[3])
        l.del.char = h.c.name
        l:Show()
        y = y - 22
    end
    for i = #have + 1, #p.lines do p.lines[i]:Hide() end
    p.char:ClearAllPoints() p.char:SetPoint("TOPLEFT", 10, y - 2)
    p.kind:ClearAllPoints() p.kind:SetPoint("LEFT", p.char, "RIGHT", 4, 0)
    local cls
    for _, c in ipairs(self:WishMine()) do if c.name == p.selChar then cls = c.class end end
    local cc, kc = ns.ClassColor(cls), ns.LOOT_KIND_COL[p.selKind] or C.text
    ns.SetFont(p.char.label, 11, 700) p.char.label:SetText(p.selChar or "?") p.char.label:SetTextColor(cc[1], cc[2], cc[3])
    ns.SetFont(p.kind.label, 11, 700) p.kind.label:SetText(L(KIND_LABEL[p.selKind])) p.kind.label:SetTextColor(kc[1], kc[2], kc[3])
    p.add:ClearAllPoints() p.add:SetPoint("TOPLEFT", 10, y - 30)
    ns.SetFont(p.add.label, 11.5, 700) p.add.label:SetText(L("Add to wishlist"))
    p:SetHeight(-(y - 30) + 32)
end

-- Ligne d'ajout de la vue Wishlist (mes persos) : objet (Maj + clic ou n°), perso, roll, OK
function ns:WishAddRow(parent)
    local r = self.wishNewRow
    if r then return r end
    r = CreateFrame("Frame", nil, parent)
    r:SetHeight(30)
    ns.Fill(r, C.panel, 0.85)
    ns.Border(r, C.hl)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(22, 22)
    r.icon:SetPoint("LEFT", 6, 0)
    r.icon:SetTexture(134400)
    local e = CreateFrame("EditBox", nil, r)
    e:SetSize(240, 22)
    e:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
    e:SetAutoFocus(false)
    e:SetFontObject(ChatFontNormal)
    e:SetTextInsets(6, 6, 0, 0)
    ns.Fill(e, C.input)
    ns.Border(e, C.border)
    e.ph = ns.Text(e, 11, 400, C.mute)
    e.ph:SetPoint("LEFT", 7, 0)
    e:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    e:SetScript("OnEditFocusGained", function(s) ns.SetBorderColor(s, C.hl) end)
    e:SetScript("OnEditFocusLost", function(s) ns.SetBorderColor(s, C.border) end)
    e:SetScript("OnTextChanged", function(s, user)
        s.ph:SetShown(s:GetText() == "")
        if not user then return end
        local id = tonumber(s:GetText():match("^%s*(%d+)%s*$") or s:GetText():match("item:(%d+)") or "")
        if id then ns:WishNewSetItem(id) end
    end)
    r.item = e
    r.char = ns.Button(r, "", 150, 22)
    r.char:SetPoint("LEFT", e, "RIGHT", 8, 0)
    r.char:SetScript("OnClick", function(b)
        local items = {}
        for _, c in ipairs(ns:WishMine()) do
            items[#items + 1] = { text = c.name, color = ns.ClassColor(c.class), func = function() ns.wishNew.char = c.name ns:RefreshLootsPage() end }
        end
        ns:OpenMenu(b, items, 180)
    end)
    r.kind = ns.Button(r, "", 110, 22)
    r.kind:SetPoint("LEFT", r.char, "RIGHT", 6, 0)
    r.kind:SetScript("OnClick", function(b)
        local items = {}
        for _, k in ipairs(ns.WISH_KINDS) do
            items[#items + 1] = { text = L(KIND_LABEL[k]), color = ns.LOOT_KIND_COL[k], func = function() ns.wishNew.k = k ns:RefreshLootsPage() end }
        end
        ns:OpenMenu(b, items, 140)
    end)
    r.ok = ns.Button(r, "OK", 40, 22, true)
    r.ok:SetPoint("RIGHT", -34, 0)
    r.ok:SetScript("OnClick", function()
        local n = ns.wishNew
        if not (n and n.id and n.char) then UIErrorsFrame:AddMessage(L("Choose an item and a character."), 1, 0.42, 0.42) return end
        ns.wishNew = nil
        ns:WishAdd(n.char, n.id, n.k)
    end)
    r.cancel = ns.IconButton(r, "×", 22, L("Cancel"))
    r.cancel:SetPoint("RIGHT", -6, 0)
    r.cancel:SetScript("OnClick", function() ns.wishNew = nil ns:RefreshLootsPage() end)
    self.wishNewRow = r
    return r
end
function ns:WishNewSetItem(id)
    local n = self.wishNew
    if not n then return end
    n.id = id
    local name, _, q, _, _, _, _, _, _, icon = GetItemInfo(id)
    local r = self.wishNewRow
    if r then
        r.icon:SetTexture(icon or (C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id)) or 134400)
        local qc = ITEM_QUALITY_COLORS and q and ITEM_QUALITY_COLORS[q] or { r = 1, g = 1, b = 1 }
        r.item:SetText(name or ("item " .. id))
        r.item:SetTextColor(qc.r, qc.g, qc.b)
    end
end
-- Maj + clic sur un objet pendant que le champ « objet » de la wishlist est actif
if ChatEdit_InsertLink then
    hooksecurefunc("ChatEdit_InsertLink", function(link)
        local r = ns.wishNewRow
        if r and r:IsVisible() and r.item:HasFocus() and type(link) == "string" then
            local id = tonumber(link:match("item:(%d+)"))
            if id then ns:WishNewSetItem(id) r.item:ClearFocus() end
        end
    end)
end
function ns:WishAddRowFill()
    local r, n = self.wishNewRow, self.wishNew
    if not (r and n) then return end
    ns.SetFont(r.item.ph, 11, 400)
    r.item.ph:SetText(L("Shift + click an item (or its ID)"))
    r.item.ph:SetShown(r.item:GetText() == "")
    local cls
    for _, c in ipairs(self:WishMine()) do if c.name == n.char then cls = c.class end end
    local cc, kc = ns.ClassColor(cls), ns.LOOT_KIND_COL[n.k] or C.text
    ns.SetFont(r.char.label, 11, 700) r.char.label:SetText(n.char or L("Character")) r.char.label:SetTextColor(cc[1], cc[2], cc[3])
    ns.SetFont(r.kind.label, 11, 700) r.kind.label:SetText(L(KIND_LABEL[n.k])) r.kind.label:SetTextColor(kc[1], kc[2], kc[3])
    ns.SetFont(r.ok.label, 11, 700) r.ok.label:SetText("OK")
end
