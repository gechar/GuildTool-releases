-- GuildTool : page Raid Comps (compos de la semaine de lockout, groupes, slots, buffs, tuile « + »)
local _, ns = ...
local C = ns.C

local PAD, GAP = 8, 10
local HEADER_H, LINE2_H = 22, 20
local SLOT_H, SLOT_GAP, GROUP_GAP = 21, 3, 6
-- buffs / debuffs de raid : blocs d'icônes sur fond gris (comme les groupes), retour à la ligne si la compo est étroite
local BUF_PAD, BROW_GAP, DEB_GAP = 3, 3, 10
local BPAD = 2   -- marge entre le bord de la compo et les blocs de buffs (plus petite que PAD : plus d'icônes par ligne)
-- Réglages d'apparence (fenêtre d'apparence de Raid Comps) : taille des icônes de raid / de groupe, épaisseur du cadre
-- vert / rouge, intensité de la couleur du cadre et des icônes (1 = normale, 0 = noir)
local function M()
    local a = ns.db and ns.db.appearance or {}
    local ir = math.max(10, math.min(32, tonumber(a.buffSizeR) or 16))
    local ig = math.max(8, math.min(28, tonumber(a.buffSizeG) or 13))
    return { ir = ir, ig = ig, step = ir + 2, browH = ir + 2 * BUF_PAD, th = math.max(1, math.min(4, tonumber(a.buffBorder) or 1)),
             bint = math.max(0, math.min(1, tonumber(a.buffInt) or 1)), iint = math.max(0, math.min(1, tonumber(a.buffIconInt) or 1)) }
end
local LOOK = M()   -- recalculé à chaque rafraîchissement des compos
-- cadre de groupe : ligne du titre (buffs de groupe à droite), séparateur, 5 cases
local function groupHead(m) return math.max(16, m.ig + 4) end
local function groupSlotsY(m) return 4 + groupHead(m) + 6 end
local function groupH(m) return groupSlotsY(m) + 5 * (SLOT_H + SLOT_GAP) - SLOT_GAP + 6 end
local function rbuffH(m, rows) return rows * (m.browH + BROW_GAP) + 3 end
local function compHeight(m, rows) return PAD + HEADER_H + LINE2_H + 4 + rbuffH(m, rows) + 2 * groupH(m) + GROUP_GAP + PAD end
local TILE_BORDER = { 0.29, 0.30, 0.345 }

---------------------------------------------------------------------------
-- Tooltips
---------------------------------------------------------------------------
local STATUS_TEXT = { primary = "Signed", tentative = "Tentative", late = "Late", bench = "Bench" }

function ns:UnitTooltip(owner, u)
    local c = ns.ClassColor(u.class)
    ns.TipOwner(owner)
    GameTooltip:SetText(u.display, c[1], c[2], c[3])
    local cls = ns.CLASS_NAME[u.class or ""] or "Unknown class"
    GameTooltip:AddLine((u.spec and (u.spec:gsub("%d+$", "") .. " ") or "") .. cls, 0.8, 0.8, 0.8)
    if u.tag then GameTooltip:AddLine("@" .. u.tag, 0.55, 0.6, 1)
    else GameTooltip:AddLine("No Discord tag in guild note", 1, 0.5, 0.4) end
    if u.signed then
        local evs = {}
        for id in pairs(u.events or {}) do evs[#evs + 1] = self:EventTitle(id) end
        GameTooltip:AddLine("Raid-Helper: " .. (STATUS_TEXT[u.status] or "Signed") .. " (" .. table.concat(evs, ", ") .. ")", 0.37, 0.83, 0.55, true)
    end
    if u.unlinked and u.tag then
        -- joueur connu mais aucun perso trouvé : dire pourquoi
        GameTooltip:AddLine(("No level %d+ %s with @%s in the guild roster."):format(ns:MinLevel(), cls, u.tag), 1, 0.5, 0.4, true)
        GameTooltip:AddLine(("Lower Min lvl in the top bar, or check the guild note with %s roster."):format(ns:Slash()), 0.6, 0.6, 0.6, true)
    elseif u.unlinked then
        GameTooltip:AddLine("Sign-up \"" .. (u.rhName or "?") .. "\" not linked to a player. Right-click to link.", 1, 0.5, 0.4, true)
    end
    if u.missing then GameTooltip:AddLine("Not in the guild roster anymore", 1, 0.5, 0.4) end
    if u.lock then GameTooltip:AddLine("Locked: already in " .. self:CompLabel(u.lock.comp, u.lock.index) .. " this lockout week.", 1, 0.3, 0.3, true) end
    if u.already then GameTooltip:AddLine(u.already, 1, 0.42, 0.42, true) end
    if u.hint then GameTooltip:AddLine(u.hint, 0.6, 0.6, 0.6, true) end
    GameTooltip:Show()
end

function ns:LockTooltip(owner, lock)
    if not lock then return end
    ns.TipOwner(owner)
    GameTooltip:SetText(ns.L("Locked"), 1, 0.3, 0.3)
    GameTooltip:AddLine(("Already in %s (%s), same lockout week."):format(self:CompLabel(lock.comp, lock.index), self:EventTitle(lock.comp.event)), 0.85, 0.85, 0.85, true)
    GameTooltip:AddLine("Click to go there.", 0.6, 0.6, 0.6)
    GameTooltip:Show()
end

local function spellExists(id)
    if C_Spell and C_Spell.DoesSpellExist then return C_Spell.DoesSpellExist(id) end
    return GetSpellInfo and GetSpellInfo(id) ~= nil
end

-- variante affichée d'un buff / debuff (debuffs : selon la classe qui l'apporte)
local function variant(self) local b = self.buff return self.var and b.vars and b.vars[self.var] or b end

local function buffEnter(self)
    local b, v = self.buff, variant(self)
    ns.TipOwner(self)
    if v.spell and spellExists(v.spell) then
        GameTooltip:SetSpellByID(v.spell)
        GameTooltip:AddLine(" ")
    else
        GameTooltip:SetText(v.name or b.name, 1, 1, 1)
    end
    GameTooltip:AddLine(self.effect or b.effect, 1, 0.82, 0.48)
    if self.on then
        GameTooltip:AddLine("Active", 0.37, 0.83, 0.55)
        GameTooltip:AddLine("Provided by: " .. b.provider, 0.6, 0.62, 0.66, true)
    else
        GameTooltip:AddLine("Missing - brought by: " .. b.provider, 1, 0.48, 0.48, true)
    end
    GameTooltip:Show()
end

-- icône du sort lue dans le jeu (sinon le fichier de Interface\Icons)
local function spellIcon(v)
    local t = v.spell and ((C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(v.spell))
        or (GetSpellTexture and GetSpellTexture(v.spell)))
    return t or ("Interface\\Icons\\" .. v.icon)
end

-- icône toujours en couleur, cadre fin vert (présent) / rouge (absent)
function ns.BuffIcon(parent, buff, size)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(size, size)
    ns.Border(f, C.red)
    f.tex = f:CreateTexture(nil, "ARTWORK")
    f.tex:SetPoint("TOPLEFT", 1, -1)
    f.tex:SetPoint("BOTTOMRIGHT", -1, 1)
    f.tex:SetTexture(spellIcon(buff))
    f.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    f.buff = buff
    f:EnableMouse(true)
    f:SetScript("OnEnter", buffEnter)
    f:SetScript("OnLeave", GameTooltip_Hide)
    return f
end

-- taille, épaisseur du cadre (icône rentrée d'autant), intensité de l'icône
local function styleIcon(f, size, m)
    f:SetSize(size, size)
    local e = f.edges
    e[1]:SetHeight(m.th) e[2]:SetHeight(m.th) e[3]:SetWidth(m.th) e[4]:SetWidth(m.th)
    f.tex:ClearAllPoints()
    f.tex:SetPoint("TOPLEFT", m.th, -m.th)
    f.tex:SetPoint("BOTTOMRIGHT", -m.th, m.th)
    f.tex:SetVertexColor(m.iint, m.iint, m.iint)
end

local function setBuff(icon, on)
    icon.on = on
    local c, k = on and C.ok or C.red, LOOK.bint
    ns.SetBorderColor(icon, { c[1] * k, c[2] * k, c[3] * k })
end
-- debuff : d = { on, v (variante), effect } (ns.RaidDebuffs)
local function setDebuff(icon, d)
    icon.var, icon.effect = d.v, d.effect
    icon.tex:SetTexture(spellIcon(variant(icon)))
    setBuff(icon, d.on)
end

-- Disposition : buffs en lignes (retour à la ligne si besoin) ; debuffs serrés à droite de la dernière ligne de buffs
-- s'il y reste la place (avec un écart), sinon sur une ligne en dessous, à droite.
-- -> { perRow, bufRows, lastN (icônes de la dernière ligne), debW, same, rows }
local function buffFlow(width, nb, nd, m)
    local avail = width - 2 * BPAD
    local perRow = math.max(1, math.floor((avail - 2 * BUF_PAD + 2) / m.step))
    local bufRows = math.max(1, math.ceil(nb / perRow))
    local lastN = nb - (bufRows - 1) * perRow
    local lastW = lastN * m.step - 2 + 2 * BUF_PAD
    local debW = math.min(nd, perRow) * m.step - 2 + 2 * BUF_PAD
    local same = lastW + DEB_GAP + debW <= avail
    local rows = bufRows + (same and 0 or math.ceil(nd / perRow))
    return { perRow = perRow, bufRows = bufRows, lastN = lastN, debW = debW, same = same, rows = rows, avail = avail }
end
-- nombre de lignes réservées pour une largeur (toutes les icônes, même celles cachées quand absentes)
local function buffRows(width, m) return buffFlow(width, #ns.RAID_BUFFS, #ns.RAID_DEBUFFS, m).rows end
-- absents d'abord (serrés à gauche), puis présents, chacun dans l'ordre de la liste
local function absentFirst(list)
    local out = {}
    for _, ic in ipairs(list) do if not ic.on then out[#out + 1] = ic end end
    for _, ic in ipairs(list) do if ic.on then out[#out + 1] = ic end end
    return out
end

---------------------------------------------------------------------------
-- Slots
---------------------------------------------------------------------------
local function slotEnter(self)
    if ns.drag then
        ns.SetBorderColor(self, C.hl, 1)
    elseif self.unit then
        self.bg:SetColorTexture(C.hover[1], C.hover[2], C.hover[3])
        ns:UnitTooltip(self, self.unit)
    end
end

local function slotLeave(self)
    GameTooltip:Hide()
    ns.SetBorderColor(self, C.border, self.unit and 0 or 1)
    if self.unit then self.bg:SetColorTexture(C.slot[1], C.slot[2], C.slot[3]) end
end

local function slotClick(self, button)
    if ns:JustDragged() or not self.unit then return end
    if button == "RightButton" then
        ns:SpecMenu(self, self.unit)
    else
        ns:RemoveAt(self.comp, self.slot)
        ns:Refresh()
    end
end

local function newSlot(parent)
    local s = CreateFrame("Button", nil, parent)
    s:SetHeight(SLOT_H)
    s.bg = ns.Fill(s, C.slot)
    ns.Border(s, C.border)
    s.bar = ns.Tex(s, C.white, "ARTWORK")
    s.bar:SetPoint("TOPLEFT") s.bar:SetPoint("BOTTOMLEFT") s.bar:SetWidth(3)
    s.icon = s:CreateTexture(nil, "ARTWORK")
    s.icon:SetSize(16, 16)
    s.icon:SetPoint("LEFT", 8, 0)
    s.name = ns.Text(s, 12, 600)
    s.name:SetPoint("RIGHT", -6, 0)
    -- cadenas rouge : perso déjà dans ce raid dans une autre compo de la semaine
    s.lockBtn = CreateFrame("Button", nil, s)
    s.lockBtn:SetSize(14, 14)
    s.lockBtn:SetPoint("RIGHT", -4, 0)
    local lt = s.lockBtn:CreateTexture(nil, "OVERLAY")
    lt:SetAllPoints()
    lt:SetTexture("Interface\\LFGFrame\\UI-LFG-ICON-LOCK")
    lt:SetVertexColor(1, 0.3, 0.3)
    s.lockBtn:SetScript("OnClick", function(b) ns:GoToLock(b:GetParent().lock) end)
    s.lockBtn:SetScript("OnEnter", function(b) ns:LockTooltip(b, b:GetParent().lock) end)
    s.lockBtn:SetScript("OnLeave", GameTooltip_Hide)
    s.lockBtn:Hide()
    -- avertissement rouge : le joueur n'est pas inscrit à l'event de la compo
    s.warn = CreateFrame("Frame", nil, s)
    s.warn:SetSize(14, 14)
    local wt = s.warn:CreateTexture(nil, "OVERLAY")
    wt:SetAllPoints()
    wt:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")
    wt:SetVertexColor(1, 0.3, 0.3)
    s.warn:EnableMouse(true)
    s.warn:SetScript("OnEnter", function(b)
        ns.TipOwner(b)
        GameTooltip:SetText(ns.L("Not signed for that event"), 1, 0.3, 0.3)
        GameTooltip:AddLine("This player has no Raid-Helper sign-up for the event of this comp.", 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    s.warn:SetScript("OnLeave", GameTooltip_Hide)
    s.warn:Hide()
    -- surbrillance (navigation depuis un cadenas / « locked »)
    s.glow = s:CreateTexture(nil, "OVERLAY")
    s.glow:SetAllPoints()
    s.glow:SetColorTexture(C.hl[1], C.hl[2], C.hl[3], 0.5)
    s.glow:SetBlendMode("ADD")
    s.glow:Hide()
    s:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    s:RegisterForDrag("LeftButton")
    s:SetScript("OnEnter", slotEnter)
    s:SetScript("OnLeave", slotLeave)
    s:SetScript("OnClick", slotClick)
    s:SetScript("OnDragStart", function(self) if self.unit then ns:BeginDrag(self.unit.name, self.comp, self.slot) end end)
    s:SetScript("OnDragStop", function() ns:EndDrag() end)
    return s
end

local function fillSlot(s, u, lock, notSigned)
    s.unit = u
    s.lock = lock
    s.lockBtn:SetShown(lock ~= nil)
    s.warn:SetShown(notSigned and true or false)
    s.warn:ClearAllPoints()
    s.warn:SetPoint("RIGHT", lock and -20 or -4, 0)
    -- nom ancré à gauche seulement (le nom de famille discret se colle après), largeur maxi selon les icônes à droite
    local right = 6 + (lock and 16 or 0) + (notSigned and 16 or 0)
    s.name:ClearAllPoints()
    if u then
        local c = ns.ClassColor(u.class)
        s.bg:SetColorTexture(C.slot[1], C.slot[2], C.slot[3], 1)
        ns.SetBorderColor(s, C.border, 0)
        s.bar:SetColorTexture(c[1], c[2], c[3])
        s.bar:Show()
        local icon = ns:SpecIcon(u)
        s.icon:SetShown(icon ~= nil)
        if icon then s.icon:SetTexture(icon) end
        local left = icon and 28 or 9
        s.name:SetPoint("LEFT", left, 0)
        s.name:SetTextColor(c[1], c[2], c[3], u.missing and 0.5 or 1)
        local w = s:GetWidth()
        ns.SetName(s.name, u.display, math.max(40, (w > 0 and w or 140) - left - right), true)
        if s.name.sur then s.name.sur:SetAlpha(u.missing and 0.5 or 1) end
    else
        s.bg:SetColorTexture(0, 0, 0, 0.35)
        ns.SetBorderColor(s, C.border, 1)
        s.bar:Hide()
        ns.ClearName(s.name)
        s.name:SetText(ns.L("Empty"))
        s.name:SetTextColor(C.mute[1], C.mute[2], C.mute[3], 0.8)
        s.icon:Hide()
        s.name:SetPoint("LEFT", 9, 0)
    end
end

-- Fait défiler jusqu'à la compo et fait briller le slot pendant 2 s
function ns:ShowSlot(comp, slot)
    local w = self.widgetOf and self.widgetOf[comp]
    if w and w.y then self.compArea:ScrollTo(w.y) end
    for _, s in ipairs(self.activeSlots or {}) do
        if s.comp == comp and s.slot == slot then
            local t0 = GetTime()
            s.glow:Show()
            s:SetScript("OnUpdate", function(self)
                local e = GetTime() - t0
                if e >= 2 then self.glow:Hide() self:SetScript("OnUpdate", nil) return end
                self.glow:SetAlpha(0.35 + 0.65 * math.abs(math.sin(e * math.pi * 2)))
            end)
        end
    end
end

function ns:GoToLock(lock)
    if not lock then return end
    self.db.ui.page = "comps"
    self:Refresh()
    self:ShowSlot(lock.comp, lock.slot)
end

function ns:SlotUnderMouse()
    for _, s in ipairs(self.activeSlots or {}) do
        if s:IsVisible() and s:IsMouseOver() then return s end
    end
end

---------------------------------------------------------------------------
-- Widget de compo
---------------------------------------------------------------------------
local function newGroup(parent)
    local g = CreateFrame("Frame", nil, parent)
    ns.Fill(g, C.panel, 0.82)
    -- titre à gauche, buffs de groupe à droite sur la même ligne (placés par layoutGroup)
    g.title = ns.Text(g, 10, 600, C.mute)
    g.buffs = {}
    for i, b in ipairs(ns.GROUP_BUFFS) do g.buffs[i] = ns.BuffIcon(g, b, 13) end
    g.sep = ns.Tex(g, C.border, "ARTWORK")
    g.sep:SetHeight(1)
    g.slots = {}
    for k = 1, 5 do g.slots[k] = newSlot(g) end
    return g
end

local function layoutGroup(g, m)
    local head = groupHead(m)
    g.title:ClearAllPoints()
    g.title:SetPoint("LEFT", g, "TOPLEFT", 8, -4 - head / 2)
    local n = #g.buffs
    for i, ic in ipairs(g.buffs) do
        styleIcon(ic, m.ig, m)
        ic:ClearAllPoints()
        ic:SetPoint("RIGHT", g, "TOPRIGHT", -6 - (n - i) * (m.ig + 1), -4 - head / 2)
    end
    g.sep:ClearAllPoints()
    g.sep:SetPoint("TOPLEFT", 6, -4 - head - 2) g.sep:SetPoint("TOPRIGHT", -6, -4 - head - 2)
    for k, sl in ipairs(g.slots) do
        local y = -groupSlotsY(m) - (k - 1) * (SLOT_H + SLOT_GAP)
        sl:ClearAllPoints()
        sl:SetPoint("TOPLEFT", 6, y)
        sl:SetPoint("TOPRIGHT", -6, y)
    end
end

-- Menu ▼ : lier la compo à un event de la semaine
local function eventMenu(btn)
    local comp = btn:GetParent().comp
    local items = {}
    for _, ev in ipairs(ns:EventsInWeek(ns:CurrentWeek())) do
        items[#items + 1] = { text = ns:EventLabel(ev), checked = comp.event == ev.id, func = function() ns:SetCompEvent(comp, ev.id) end }
    end
    items[#items + 1] = { text = "No event", color = C.mute, checked = not comp.event, func = function() ns:SetCompEvent(comp, nil) end }
    ns:OpenMenu(btn:GetParent().evArea, items, 300)
end

-- Croix de suppression : grossit autour de son centre (SetTextScale si le client l'a, sinon taille de police)
local function scaleCross(fs, s)
    if fs.SetTextScale then fs:SetTextScale(s) else ns.SetFont(fs, 18 * s, 600) end
end

function ns:NewCompWidget()
    local w = CreateFrame("Frame", nil, self.compArea.child)
    -- fond opaque (le logo de la fenêtre ne doit pas transparaître), image du raid en fondu, voile
    w.base = ns.Tex(w, C.bg, "BACKGROUND")
    w.base:SetDrawLayer("BACKGROUND", -8)
    w.base:SetAllPoints()
    w.img = w:CreateTexture(nil, "BACKGROUND", nil, -7)
    w.img:SetAllPoints()
    w.img:SetAlpha(ns.db.appearance.compAlpha or 0.3)
    w.veil = w:CreateTexture(nil, "BACKGROUND", nil, -6)
    w.veil:SetAllPoints()
    w.veil:SetColorTexture(1, 1, 1, 1)
    w.veil:SetGradient("VERTICAL", CreateColor(C.bg[1], C.bg[2], C.bg[3], 0.82), CreateColor(C.bg[1], C.bg[2], C.bg[3], 0.45))
    w.selGlow = w:CreateTexture(nil, "BACKGROUND", nil, -5)
    w.selGlow:SetAllPoints()
    w.selGlow:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.09)
    ns.Border(w, C.border)
    -- clic sur le fond : sélectionner / désélectionner
    w:EnableMouse(true)
    w:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" and not ns:JustDragged() then ns:Select(self.comp) ns:Refresh() end
    end)

    -- ligne 1 : ▼ event, validation, mentions, suppression
    -- zone du titre (ancre du menu, largeur inchangée) ; seuls la flèche et ~un mot sont cliquables
    w.evArea = CreateFrame("Frame", nil, w)
    w.evArea:SetHeight(HEADER_H)
    w.evArea:SetPoint("TOPLEFT", PAD, -PAD)
    local tri = ns.Triangle(w.evArea, "down", 13)
    tri:SetPoint("LEFT", -1, 0)
    w.title = ns.Text(w.evArea, 13, 700, C.white)
    w.title:SetPoint("LEFT", tri, "RIGHT", 4, 0)
    w.title:SetPoint("RIGHT", 0, 0)
    -- icône Assigns (feuille + crayon) avec les autres boutons, à gauche du V
    w.asg = ns.IconButton(w, "", 20, ns.L("Assigns of this comp"))
    w.asg.tex = w.asg:CreateTexture(nil, "OVERLAY")
    w.asg.tex:SetSize(14, 14)
    w.asg.tex:SetPoint("CENTER")
    w.asg.tex:SetTexture("Interface\\AddOns\\GuildTool\\media\\assign_icon")
    -- en blanc comme le titre
    w.asg.tex:SetVertexColor(1, 1, 1)
    w.asg:SetScript("OnClick", function(b) ns:OpenAssigns(b:GetParent().comp.id) end)
    w.evBtn = CreateFrame("Button", nil, w)
    w.evBtn:SetSize(96, HEADER_H)
    w.evBtn:SetPoint("TOPLEFT", w.evArea, "TOPLEFT", -3, 0)
    w.evBtn.hl = ns.Tex(w.evBtn, C.white, "BACKGROUND", 0.06)
    w.evBtn.hl:SetAllPoints()
    w.evBtn.hl:Hide()
    w.evBtn:SetScript("OnClick", eventMenu)
    w.evBtn:SetScript("OnEnter", function(b)
        b.hl:Show()
        local comp = b:GetParent().comp
        local raid = ns:RaidByKey(comp.raid)
        ns.TipOwner(b)
        GameTooltip:SetText((raid and raid.name or comp.raid) .. " " .. (raid and raid.size or ""), 1, 1, 1)
        GameTooltip:AddLine(ns:EventLabel(comp.event and ns:EventById(comp.event)), 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Click to link this comp to another event of the week.", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    w.evBtn:SetScript("OnLeave", function(b) b.hl:Hide() GameTooltip:Hide() end)

    -- croix 50 % plus grande ; compo avec des joueurs : elle grossit encore et demande un 2e clic
    w.del = ns.IconButton(w, "×", 22, ns.L("Remove this comp"))
    ns.SetFont(w.del.label, 18, 600)
    -- croix en blanc comme le titre (rouge pendant la confirmation)
    w.del.label:SetTextColor(1, 1, 1)
    w.del:HookScript("OnLeave", function(b) if not b.armed then b.label:SetTextColor(1, 1, 1) end end)
    w.del:SetPoint("TOPRIGHT", -PAD + 3, -PAD + 2)
    w.del:SetScript("OnClick", function(b)
        local comp = b:GetParent().comp
        -- seule la croix grossit (agrandie autour de son centre), le bouton et sa surbrillance gardent leur taille
        if next(comp.c) and not b.armed then
            b.armed = true
            scaleCross(b.label, 1.45)
            b.label:SetTextColor(C.red[1], C.red[2], C.red[3])
            C_Timer.After(3, function()
                if b.armed then b.armed = nil scaleCross(b.label, 1) b.label:SetTextColor(1, 1, 1) end
            end)
            return
        end
        b.armed = nil
        ns:DeleteComp(comp)
        ns:Refresh()
    end)
    w.at = ns.IconButton(w, "@", 20, "Copy Discord mentions")
    w.at:SetPoint("RIGHT", w.del, "LEFT", -2, 0)
    w.at:SetScript("OnClick", function(b)
        local comp = b:GetParent().comp
        local text = ns:Mentions(comp)
        if text == "" then text = "(no players with a Discord tag)" end
        ns:ShowCopy(ns:EventTitle(comp.event) .. " mentions", text)
    end)
    -- œil : barré = compo cachée (officiers seulement), ouvert vert = validée (event vert) et visible de tous
    w.valid = CreateFrame("Button", nil, w)
    w.valid:SetSize(20, 20)
    w.valid:SetPoint("RIGHT", w.at, "LEFT", -2, 0)
    w.valid.tex = w.valid:CreateTexture(nil, "ARTWORK")
    w.valid.tex:SetSize(16, 16)
    w.valid.tex:SetPoint("CENTER")
    w.valid:SetScript("OnClick", function(b) ns:ToggleValid(b:GetParent().comp) ns:Refresh() end)
    w.valid:SetScript("OnEnter", function(b)
        local v = b:GetParent().comp.valid
        ns.TipOwner(b)
        GameTooltip:SetText(ns.L(v and "Validated: visible to everyone" or "Hidden: officers only"), 1, 1, 1)
        GameTooltip:AddLine(ns.L(v and "The event is green in the calendar. Click to hide this comp again."
            or "Click to validate this comp and show it to everyone."), 0.7, 0.7, 0.7, true)
        GameTooltip:Show()
    end)
    w.valid:SetScript("OnLeave", GameTooltip_Hide)
    w.asg:SetPoint("RIGHT", w.valid, "LEFT", -2, 0)
    w.evArea:SetPoint("TOPRIGHT", w.asg, "TOPLEFT", -6, -1)

    -- ligne 2 : date / heure de l'event + rôles à droite
    w.date = ns.Text(w, 11, 600, C.mute)
    w.date:SetPoint("TOPLEFT", PAD + 16, -PAD - HEADER_H - 3)
    w.roles = CreateFrame("Frame", nil, w)
    w.roles:SetSize(4 * 30, 18)
    w.roles:SetPoint("TOPRIGHT", -PAD, -PAD - HEADER_H)
    w.roleText = {}
    for i, role in ipairs(ns.ROLE_ORDER) do
        local t = w.roles:CreateTexture(nil, "ARTWORK")
        t:SetTexture(ns.ROLE_ICON[role])
        t:SetSize(16, 16)
        t:SetPoint("LEFT", (i - 1) * 30, 0)
        local n = ns.Text(w.roles, 11, 700)
        n:SetPoint("LEFT", t, "RIGHT", 1, 0)
        w.roleText[role] = n
    end
    w.date:SetPoint("RIGHT", w.roles, "LEFT", -6, 0)

    -- buffs de raid puis debuffs, chacun sur un fond gris comme les groupes (placés par placeBuffs)
    -- fonds : un par ligne de buffs (la dernière peut être plus courte), un pour les debuffs
    local function bg()
        local f = CreateFrame("Frame", nil, w)
        ns.Fill(f, C.panel, 0.82)
        return f
    end
    w.rbBgs, w.dbBg = { bg(), bg(), bg() }, bg()
    w.rbuffs, w.dbuffs = {}, {}
    for i, b in ipairs(ns.RAID_BUFFS) do
        w.rbuffs[i] = ns.BuffIcon(w, b, 16)
        w.rbuffs[i]:SetFrameLevel(w.dbBg:GetFrameLevel() + 1)
    end
    for i, b in ipairs(ns.RAID_DEBUFFS) do
        w.dbuffs[i] = ns.BuffIcon(w, b, 16)
        w.dbuffs[i]:SetFrameLevel(w.dbBg:GetFrameLevel() + 1)
    end
    w.rsep = ns.Tex(w, C.border, "ARTWORK")
    w.rsep:SetHeight(1)
    w.groups = {}
    for g = 1, 8 do w.groups[g] = newGroup(w) end
    return w
end

-- Place les icônes de buffs (seulement celles de vis = { [i] = true }) et de debuffs ; rows = lignes réservées
local function placeBuffs(w, vis, rows)
    local m = LOOK
    local width = w:GetWidth()
    local list = {}
    for i, ic in ipairs(w.rbuffs) do
        ic:SetShown(vis[i] ~= false)
        styleIcon(ic, m.ir, m)
        if vis[i] ~= false then list[#list + 1] = ic end
    end
    list = absentFirst(list)
    -- debuffs : seulement les manquants (un debuff obtenu disparaît)
    local dlist = {}
    for _, ic in ipairs(w.dbuffs) do
        ic:SetShown(not ic.on)
        if not ic.on then dlist[#dlist + 1] = ic end
    end
    local f = buffFlow(width, #list, #dlist, m)
    local y0 = -PAD - HEADER_H - LINE2_H - 4
    local rstep = m.browH + BROW_GAP
    for k, ic in ipairs(list) do
        local r, c = math.floor((k - 1) / f.perRow), (k - 1) % f.perRow
        ic:ClearAllPoints()
        ic:SetPoint("TOPLEFT", BPAD + BUF_PAD + c * m.step, y0 - BUF_PAD - r * rstep)
    end
    for r, bgf in ipairs(w.rbBgs) do
        local n = r < f.bufRows and f.perRow or r == f.bufRows and f.lastN or 0
        bgf:SetShown(n > 0)
        if n > 0 then
            bgf:ClearAllPoints()
            bgf:SetPoint("TOPLEFT", BPAD, y0 - (r - 1) * rstep)
            bgf:SetSize(n * m.step - 2 + 2 * BUF_PAD, m.browH)
        end
    end
    -- debuffs serrés à droite : sur la dernière ligne de buffs, sinon en dessous ; absents à gauche du bloc
    local dx, dr = BPAD + f.avail - f.debW, f.same and (f.bufRows - 1) or f.bufRows
    for k, ic in ipairs(dlist) do
        styleIcon(ic, m.ir, m)
        local r, c = math.floor((k - 1) / f.perRow), (k - 1) % f.perRow
        ic:ClearAllPoints()
        ic:SetPoint("TOPLEFT", dx + BUF_PAD + c * m.step, y0 - BUF_PAD - (dr + r) * rstep)
    end
    local drows = math.ceil(#dlist / f.perRow)
    w.dbBg:SetShown(#dlist > 0)
    w.dbBg:ClearAllPoints()
    w.dbBg:SetPoint("TOPLEFT", dx, y0 - dr * rstep)
    w.dbBg:SetSize(f.debW, drows * rstep - BROW_GAP)
    w.rsep:ClearAllPoints()
    w.rsep:SetPoint("TOPLEFT", PAD, y0 - rbuffH(m, rows) + 2)
    w.rsep:SetPoint("TOPRIGHT", -PAD, y0 - rbuffH(m, rows) + 2)
end

local function layoutComp(w, raid, width, height, rows)
    local L = ns.LAYOUT[raid.size]
    w:SetSize(width, height)
    w.rows = rows
    -- image recadrée au format du cadre
    local a = width / height
    if raid.aspect and a < raid.aspect then
        local fw = a / raid.aspect
        w.img:SetTexCoord(0.5 - fw / 2, 0.5 + fw / 2, 0, 1)
    elseif raid.aspect then
        local fh = raid.aspect / a
        w.img:SetTexCoord(0, 1, 0.5 - fh / 2, 0.5 + fh / 2)
    end
    w.img:SetTexture(raid.bg and ("Interface\\AddOns\\GuildTool\\media\\" .. raid.bg) or nil)
    local m = LOOK
    local gh = groupH(m)
    local y = -PAD - HEADER_H - LINE2_H - 4 - rbuffH(m, rows)
    local ng = raid.size / 5
    local gw = (width - 2 * PAD - (L.gcols - 1) * GROUP_GAP) / L.gcols
    for g, gf in ipairs(w.groups) do
        if g <= ng then
            local col, row = (g - 1) % L.gcols, math.floor((g - 1) / L.gcols)
            gf:ClearAllPoints()
            gf:SetSize(gw, gh)
            gf:SetPoint("TOPLEFT", PAD + col * (gw + GROUP_GAP), y - row * (gh + GROUP_GAP))
            layoutGroup(gf, m)
            gf:Show()
        else
            gf:Hide()
        end
    end
end

local function fillComp(self, w, comp, index)
    local raid = self:RaidByKey(comp.raid) or self:GetPhase().raids[1]
    w.comp = comp
    w.title:SetText(self:EventTitle(comp.event))
    w.del.armed = nil
    scaleCross(w.del.label, 1)
    w.del.label:SetTextColor(1, 1, 1)
    local ev = comp.event and self:EventById(comp.event)
    -- jour en 3 lettres devant la date (« Wed 03/10 - 20:00 »)
    w.date:SetText(ev and ev.start and (ns.DayShort(ev.start) .. " " .. date("%d/%m - %H:%M", ev.start)) or "")
    w.title:SetTextColor(comp.event and 1 or C.mute[1], comp.event and 1 or C.mute[2], comp.event and 1 or C.mute[3])
    local selected = self.db.ui.selected == comp.id
    ns.SetBorderColor(w, selected and C.hl or C.border)
    w.selGlow:SetColorTexture(C.hl[1], C.hl[2], C.hl[3], 0.09)
    w.selGlow:SetShown(selected)
    w.valid.tex:SetTexture(ns.MEDIA_PATH .. (comp.valid and "eye" or "eye_off"))
    local ec = comp.valid and C.ok or C.red
    w.valid.tex:SetVertexColor(ec[1], ec[2], ec[3])
    w.valid:SetAlpha(1)
    local all, roles, count = {}, { Tank = 0, Healer = 0, Melee = 0, Ranged = 0 }, 0
    for g = 1, raid.size / 5 do
        local gf, members = w.groups[g], {}
        gf.title:SetText(strupper(ns.L("Group")) .. " " .. g)
        for k = 1, 5 do
            local slot = (g - 1) * 5 + k
            local name = comp.c[slot]
            local u = name and self:CompUnit(comp, name)
            local s = gf.slots[k]
            s.comp, s.slot = comp, slot
            local lock = name and self:LockoutOf(name, comp.raid, comp)
            if u then u.lock = lock end
            fillSlot(s, u, lock, name and comp.event and not self:SignedFor(comp.event, name, u.tag))
            self.activeSlots[#self.activeSlots + 1] = s
            if u then
                members[#members + 1] = u
                all[#all + 1] = u
                count = count + 1
                if u.role and roles[u.role] then roles[u.role] = roles[u.role] + 1 end
            end
        end
        local on = ns.GroupBuffs(members)
        -- buffs de groupe : seulement les manquants, serrés à droite du titre
        local miss = {}
        for i, b in ipairs(ns.GROUP_BUFFS) do
            setBuff(gf.buffs[i], on[b.key])
            gf.buffs[i]:SetShown(not on[b.key])
            if not on[b.key] then miss[#miss + 1] = gf.buffs[i] end
        end
        local head = groupHead(LOOK)
        for k, ic in ipairs(miss) do
            ic:ClearAllPoints()
            ic:SetPoint("RIGHT", gf, "TOPRIGHT", -6 - (#miss - k) * (LOOK.ig + 1), -4 - head / 2)
        end
    end
    for role, n in pairs(roles) do w.roleText[role]:SetText(n) end
    -- buffs de raid (Trueshot Aura cachée sans chasseur Beastmastery / Survival), puis debuffs
    local ron, vis = ns.RaidBuffs(all), {}
    for i, b in ipairs(ns.RAID_BUFFS) do
        setBuff(w.rbuffs[i], ron[b.key])
        -- seulement les buffs MANQUANTS (un buff obtenu disparaît)
        vis[i] = not ron[b.key] and not b.hideOff
    end
    local don = ns.RaidDebuffs(all)
    for i, b in ipairs(ns.RAID_DEBUFFS) do setDebuff(w.dbuffs[i], don[b.key] or {}) end
    placeBuffs(w, vis, w.rows or 1)
end

---------------------------------------------------------------------------
-- Tuile « + » : survol = un bouton par raid de la phase ; puis un bouton par event de la semaine
---------------------------------------------------------------------------
local GLASS_OFFSETS = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } }

local function bigText(parent)
    local g = { main = parent:CreateFontString(nil, "OVERLAY"), halo = {} }
    for i = 1, 4 do g.halo[i] = parent:CreateFontString(nil, "ARTWORK") end
    function g:Set(text, size)
        for _, fs in ipairs({ self.main, unpack(self.halo) }) do
            fs:SetFont(ns.FONT[700], size, "")
            fs:SetText(text)
        end
        self.main:SetTextColor(1, 1, 1, 0.34)
        for _, fs in ipairs(self.halo) do fs:SetTextColor(0, 0, 0, 0.32) end -- contour fin, légèrement sombre
    end
    function g:Place(point, x, y)
        self.main:ClearAllPoints()
        self.main:SetPoint(point, x, y)
        for i, fs in ipairs(self.halo) do
            fs:ClearAllPoints()
            fs:SetPoint(point, x + GLASS_OFFSETS[i][1], y + GLASS_OFFSETS[i][2])
        end
    end
    function g:Show(on)
        self.main:SetShown(on)
        for _, fs in ipairs(self.halo) do fs:SetShown(on) end
    end
    return g
end

local function tileButton(tile, i)
    local b = tile.buttons[i]
    if not b then
        b = CreateFrame("Button", nil, tile)
        b.solid = ns.Fill(b, C.input, 0.9)
        -- image du raid (morceaux de la tuile au survol)
        b.img = b:CreateTexture(nil, "BACKGROUND", nil, 1)
        b.img:SetAllPoints()
        b.veil = b:CreateTexture(nil, "BACKGROUND", nil, 2)
        b.veil:SetAllPoints()
        b.veil:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], 0.55)
        ns.Border(b, C.border)
        ns.Selection(b, 0)
        b.label = ns.Text(b, 13, 700)
        b.label:SetPoint("LEFT", 12, 0)
        b.label:SetPoint("RIGHT", -12, 0)
        -- grandes lettres « verre » : texte blanc translucide + liseré doux (4 copies décalées)
        b.bigName, b.bigNum = bigText(b), bigText(b)
        b:SetScript("OnEnter", function(self)
            ns.ShowSelection(self, true) ns.SetBorderColor(self, C.hl)
            self.veil:SetAlpha(0.45)
        end)
        b:SetScript("OnLeave", function(self)
            ns.ShowSelection(self, false) ns.SetBorderColor(self, C.border)
            self.veil:SetAlpha(1)
        end)
        tile.buttons[i] = b
    end
    return b
end

-- Découpe la tuile en morceaux égaux empilés : items = { { text, func, color, raid } }
local function stackButtons(tile, items, top)
    local w = tile:GetWidth()
    local h = (tile:GetHeight() - top - 1) / #items
    for i, it in ipairs(items) do
        local b = tileButton(tile, i)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", 1, -top - (i - 1) * h)
        b:SetPoint("TOPRIGHT", -1, -top - (i - 1) * h)
        b:SetHeight(h - 1)
        b.label:SetText(it.text)
        b.label:SetJustifyH(it.raid and "CENTER" or "LEFT")
        b.label:SetTextColor(it.color and it.color[1] or 1, it.color and it.color[2] or 1, it.color and it.color[3] or 1)
        local raid = it.raid
        b.solid:SetShown(not raid)
        b.img:SetShown(raid ~= nil)
        b.veil:SetShown(raid ~= nil)
        local full = raid and (raid.full or raid.bg)
        if full then
            -- image entière du raid (pas la découpe des compos), recadrée au format du morceau
            local ra = raid.fullAspect or raid.aspect or 1.5
            b.img:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. full)
            local a = (w - 2) / (h - 1)
            if a < ra then
                local fw = a / ra
                b.img:SetTexCoord(0.5 - fw / 2, 0.5 + fw / 2, 0, 1)
            else
                local fh = ra / a
                b.img:SetTexCoord(0, 1, 0.5 - fh / 2, 0.5 + fh / 2)
            end
        end
        -- morceau de raid : nom sur toute la largeur en bas, nombre le plus grand possible en haut à droite
        b.label:SetShown(not raid)
        b.bigName:Show(raid ~= nil)
        b.bigNum:Show(raid ~= nil)
        if raid then
            local bw, bh = w - 2, h - 1
            b.bigName:Set(raid.name, 40)
            local size = math.min(40 * (bw - 24) / math.max(1, b.bigName.main:GetStringWidth()), bh * 0.42)
            b.bigName:Set(raid.name, size)
            b.bigName:Place("BOTTOMLEFT", 12, 6)
            local free = bh - b.bigName.main:GetStringHeight() - 12
            local numSize = math.max(14, free / 0.74)
            b.bigNum:Set(tostring(raid.size), numSize)
            -- ne dépasse pas le milieu horizontal du morceau
            local nw = b.bigNum.main:GetStringWidth()
            if nw > bw / 2 - 12 then b.bigNum:Set(tostring(raid.size), numSize * (bw / 2 - 12) / nw) end
            b.bigNum:Place("TOPRIGHT", -12, -4)
        end
        b:SetScript("OnClick", it.func)
        b:Show()
    end
    for i = #items + 1, #tile.buttons do tile.buttons[i]:Hide() end
end

function ns:RefreshTile()
    local tile, state = self.addTile, self.addState
    tile.plus:SetShown(not state)
    tile.label:SetShown(not state)
    tile.head:SetShown(state and state.raid ~= nil)
    tile.solid:SetShown(state and state.raid ~= nil)
    if not state then
        for _, b in ipairs(tile.buttons) do b:Hide() end
    elseif not state.raid then
        local items = {}
        for _, raid in ipairs(self:GetPhase().raids) do
            items[#items + 1] = { text = raid.name .. " " .. raid.size, raid = raid, func = function()
                ns.addState = { raid = raid.key }
                ns:Refresh()
            end }
        end
        stackButtons(tile, items, 1)
    else
        local raid = self:RaidByKey(state.raid)
        tile.head:SetText(raid.name .. " " .. raid.size .. "  ·  link to an event")
        local items = {}
        for _, ev in ipairs(self:EventsInWeek(self:CurrentWeek())) do
            items[#items + 1] = { text = self:EventLabel(ev), func = function()
                ns.addState = nil
                ns:AddComp(raid.key, ev.id)
                ns:Refresh()
            end }
        end
        items[#items + 1] = { text = "No event", color = C.mute, func = function()
            ns.addState = nil
            ns:AddComp(raid.key, nil)
            ns:Refresh()
        end }
        items[#items + 1] = { text = "Cancel", color = C.mute, func = function() ns.addState = nil ns:Refresh() end }
        stackButtons(tile, items, 34)
    end
end

local function createTile(self, parent)
    local tile = CreateFrame("Frame", nil, parent)
    tile:EnableMouse(true)
    tile.buttons = {}
    ns.Selection(tile, 0)
    ns.Border(tile, TILE_BORDER)
    -- voile au-dessus de l'image de fond floutée (comme les cases du calendrier)
    tile.veil = ns.Tex(tile, C.bg, "BACKGROUND", 0.45)
    tile.veil:SetDrawLayer("BACKGROUND", -7)
    tile.veil:SetAllPoints()
    tile.solid = ns.Tex(tile, C.panel, "BACKGROUND")
    tile.solid:SetAllPoints()
    tile.plus = ns.Text(tile, 30, 400, C.accent)
    tile.plus:SetPoint("CENTER", 0, 12)
    tile.plus:SetText("+")
    tile.label = ns.Text(tile, 12, 600, C.mute)
    tile.label:SetPoint("TOP", tile.plus, "BOTTOM", 0, -2)
    tile.label:SetText(ns.L("New comp"))
    tile.head = ns.Text(tile, 12.5, 700, C.white)
    tile.head:SetPoint("TOPLEFT", 10, -12)
    -- survol : seul le cadre du raid survolé s'éclaire (pas la tuile entière)
    tile:SetScript("OnEnter", function(t)
        if not ns.addState then
            ns.addState = { hover = true }
            ns:RefreshTile()
            -- repli quand la souris quitte la tuile (les boutons enfants déclenchent OnLeave)
            t:SetScript("OnUpdate", function(tt)
                if not tt:IsMouseOver() and ns.addState and ns.addState.hover then
                    ns.addState = nil
                    tt:SetScript("OnUpdate", nil)
                    ns:RefreshTile()
                end
            end)
        end
    end)
    self.addTile = tile
end

---------------------------------------------------------------------------
-- Création et rafraîchissement de la page
---------------------------------------------------------------------------
function ns:CreateComps(page)
    local area = CreateFrame("Frame", nil, page)
    area:SetPoint("TOPLEFT")
    area:SetPoint("BOTTOMRIGHT", -ns.SIDE_W, 0)
    local sf = ns.ScrollArea(area)
    sf:SetPoint("TOPLEFT", 10, -10)
    sf:SetPoint("BOTTOMRIGHT", -3, 10)
    self.compArea = sf
    self.contentW = ns.W - ns.SIDE_W - 2 - 10 - 3 - 9
    self.unitW = (self.contentW - 3 * GAP) / 4
    sf.child:SetWidth(self.contentW)
    self.compWidgets = {}
    createTile(self, sf.child)
    -- clic dans le vide (fond de la zone des compos) : désélectionne
    local function deselect(_, button)
        if button == "LeftButton" and self.db.ui.selected then
            self.db.ui.selected = nil
            self:Invalidate()
            self:Refresh()
        end
    end
    for _, fr in ipairs({ area, sf.child }) do
        fr:EnableMouse(true)
        fr:SetScript("OnMouseDown", deselect)
    end
end

-- Le perso (ou son joueur) est-il inscrit à l'event ? (cache remis à zéro à chaque rafraîchissement)
function ns:SignedFor(eventId, name, tag)
    local s = self.signedCache[eventId]
    if not s then
        s = { names = {}, tags = {} }
        local ev = self:EventById(eventId)
        for _, su in ipairs(ev and ev.signups or {}) do
            if su.st ~= "absence" then
                local t = self:ResolveTag(su)
                local char = self:SignupChar(su, t)
                s.names[char or ("~" .. (su.n or "?") .. "#" .. (su.c or ""))] = true
                if t then s.tags[t] = true end
            end
        end
        self.signedCache[eventId] = s
    end
    return s.names[name] or (tag and s.tags[tag]) or false
end

function ns:RefreshComps()
    LOOK = M()
    self.signedCache = {}
    local week = self:GetWeek()
    self.activeSlots, self.widgetOf = {}, {}
    local function spanW(span) return span * self.unitW + (span - 1) * GAP end
    -- compos cachées (œil barré) : visibles des officiers seulement
    local shown = {}
    for _, comp in ipairs(week.comps) do if comp.valid or self:MayEditComp(comp) then shown[#shown + 1] = comp end end
    -- tuile « + » : largeur d'une compo 10, ou du raid choisi
    local state = self.addState
    local tileSpan = 1
    if state and state.raid then tileSpan = ns.LAYOUT[self:RaidByKey(state.raid).size].span end
    -- 1er passage : rangées de la grille (4 colonnes) ; hauteur d'une rangée = celle de sa compo la plus haute
    -- (les buffs passent à la ligne dans les compos étroites)
    local items, rowH, col, row = {}, {}, 0, 0
    for _, comp in ipairs(shown) do
        local raid = self:RaidByKey(comp.raid) or self:GetPhase().raids[1]
        items[#items + 1] = { comp = comp, raid = raid, span = ns.LAYOUT[raid.size].span }
    end
    items[#items + 1] = { tile = true, span = tileSpan }
    for _, it in ipairs(items) do
        if col + it.span > 4 then col, row = 0, row + 1 end
        it.col, it.row = col, row
        it.rows = it.tile and 1 or buffRows(spanW(it.span), LOOK)
        rowH[row] = math.max(rowH[row] or 0, compHeight(LOOK, it.rows))
        col = col + it.span
    end
    local top, y = {}, 0
    for r = 0, row do top[r] = y y = y + rowH[r] + GAP end
    for i, it in ipairs(items) do
        local frame
        if it.tile then
            frame = self.addTile
            frame:SetSize(spanW(it.span), rowH[it.row])
        else
            frame = self.compWidgets[i] or self:NewCompWidget()
            self.compWidgets[i] = frame
            layoutComp(frame, it.raid, spanW(it.span), rowH[it.row], it.rows)
        end
        frame:ClearAllPoints()
        frame:SetPoint("TOPLEFT", it.col * (self.unitW + GAP), -top[it.row])
        frame.y = top[it.row]
        if not it.tile then
            fillComp(self, frame, it.comp, i)
            self.widgetOf[it.comp] = frame
            frame:Show()
        end
    end
    for i = #shown + 1, #self.compWidgets do self.compWidgets[i]:Hide() end
    self:BlurBehind(self.addTile)
    self:RefreshTile()
    self.compArea.child:SetHeight(math.max(y, 1))
    self.compArea:UpdateThumb()
end
