-- GuildTool : rappel et grouping des raids Main (officiers en ligne)
-- 1 h, puis 30 min, puis 15 min avant un raid Main dont le grouping n'a pas commencé : popup « Raid in X » + bouton
-- « Start Grouping » (plusieurs compos à venir : fenêtre qui les résume, clic sur la compo à grouper).
-- Start Grouping : l'officier devient raid builder, invite une fois les persos prévus en ligne, annonce à la guilde
-- (message « U ») : chacun voit « Guild Raid up - type "inv" in guild » en vert ; les officiers du groupe (chef ou
-- assistant) invitent les persos prévus qui écrivent « inv » en guilde ou qui se connectent. Bouton « Inv Raid »
-- (déplaçable, × pour le fermer, /raidinv pour le rouvrir) : invite les persos prévus en ligne pas encore groupés ;
-- « Sort » place les membres du raid dans les groupes de la compo ; « Stop » arrête le grouping (les rappels
-- « Start Grouping » reprennent pour les officiers).
local _, ns = ...
local C = ns.C
local L = function(...) return ns.L(...) end

local REMIND = { 15, 30, 60 }          -- minutes avant le raid (le plus petit seuil atteint)
local ACTIVE_FOR = 6 * 3600            -- un grouping reste actif 6 h
local reminded = {}                    -- [eventId] = { [seuil] = true } (cette session)

local function first(n) return n and (n:match("^(%S+)") or n) or "" end
local function bare(n) return ((n or ""):gsub("%-.*$", "")) end

-- events Main à venir dans l'heure qui suit (salon Main Raid)
local function mainEventsSoon()
    local out, now, main = {}, time(), ns.db and ns.db.mainChannel
    for _, ev in ipairs((ns.db and ns.db.events) or {}) do
        if ev.start and ev.start > now and ev.start - now <= 3600 and main and ev.chId == main then out[#out + 1] = ev end
    end
    table.sort(out, function(a, b) return a.start < b.start end)
    return out
end
-- compos (non supprimées) d'un event
local function compsOf(evId)
    local out = {}
    for _, w in pairs(ns.db.weeks or {}) do
        for _, comp in ipairs(w.comps or {}) do
            if comp.event == evId and not comp.deleted then out[#out + 1] = comp end
        end
    end
    return out
end
local function compById(id)
    for _, w in pairs(ns.db.weeks or {}) do
        for _, comp in ipairs(w.comps or {}) do if comp.id == id then return comp end end
    end
end
-- grouping en cours (compo), nil sinon
function ns:GroupingComp()
    local g = self.groupingActive
    if not g then
        -- après un /reload : le dernier grouping enregistré (moins de 6 h)
        for _, x in pairs(self.db.grouping or {}) do
            if time() - (x.t or 0) < ACTIVE_FOR and (not g or (x.t or 0) > (g.t or 0)) then g = x end
        end
        if g then self.groupingActive = { comp = g.comp, by = g.by, t = g.t, builder = g.by == self:MyName() } end
    end
    if g and time() - (g.t or 0) < ACTIVE_FOR then return compById(g.comp) end
end
local function started(evId)
    local g = ns.db.grouping and ns.db.grouping[evId]
    return g and time() - (g.t or 0) < ACTIVE_FOR
end
-- persos prévus de la compo
local function planned(comp)
    local out = {}
    for s = 1, 40 do
        local n = comp.c[s]
        if type(n) == "string" and n:sub(1, 1) ~= "~" then out[#out + 1] = n end
    end
    return out
end
local function isPlanned(comp, name)
    name = bare(name)
    for _, n in ipairs(planned(comp)) do
        if n == name or first(n) == first(name) then return n end
    end
end
-- membres de la guilde en ligne
local function onlineSet()
    local out = {}
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() elseif GuildRoster then GuildRoster() end
    for i = 1, (GetNumGuildMembers and GetNumGuildMembers() or 0) do
        local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
        if name and online then out[bare(name)] = true end
    end
    return out
end
local function grouped(name) return UnitInRaid(name) or UnitInParty(name) end
local function invite(name)
    if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(name) elseif InviteUnit then InviteUnit(name) end
end
-- je peux inviter : seul (je deviens chef) ou chef / assistant du groupe
local function canInvite()
    if not IsInGroup() then return true end
    return UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")
end
-- invite les persos prévus en ligne pas encore groupés ; renvoie le nombre d'invitations
function ns:InvitePlanned()
    local comp = self:GroupingComp()
    if not comp then return 0 end
    local on, me, n = onlineSet(), self:MyName(), 0
    for _, name in ipairs(planned(comp)) do
        if name ~= me and first(name) ~= first(me) and not grouped(name) and (on[name] or on[first(name)]) then
            invite(name)
            n = n + 1
        end
    end
    return n
end

-- groupe prévu (1 à 8) de chaque perso de la compo : emplacement s → groupe ceil(s / 5)
local function plannedGroups(comp)
    local out = {}
    for s = 1, 40 do
        local n = comp.c[s]
        if type(n) == "string" and n:sub(1, 1) ~= "~" then
            out[n] = math.floor((s - 1) / 5) + 1
            out[first(n)] = out[first(n)] or out[n]
        end
    end
    return out
end
-- un déplacement à la fois (le raid se met à jour entre deux) : renvoie true s'il en reste à faire
local function sortStep(comp)
    local want, roster, count = plannedGroups(comp), {}, {}
    for i = 1, GetNumGroupMembers() do
        local name, _, sub = GetRaidRosterInfo(i)
        if name then
            local n = bare(name)
            roster[i] = { want = want[n] or want[first(n)], sub = sub }
            count[sub] = (count[sub] or 0) + 1
        end
    end
    for i, r in pairs(roster) do
        if r.want and r.want ~= r.sub then
            -- place libre dans le groupe prévu : déplacé ; sinon échangé avec un membre qui n'y est pas prévu
            if (count[r.want] or 0) < 5 then SetRaidSubgroup(i, r.want) return true end
            for j, o in pairs(roster) do
                if o.sub == r.want and o.want ~= r.want then SwapRaidSubgroup(i, j) return true end
            end
        end
    end
    return false
end
function ns:SortRaidGroups()
    local comp = self:GroupingComp()
    if not comp then UIErrorsFrame:AddMessage(L("No raid grouping in progress."), 1, 0.42, 0.42) return end
    if not IsInRaid() then UIErrorsFrame:AddMessage(L("You must be in a raid."), 1, 0.42, 0.42) return end
    if not (UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")) then
        UIErrorsFrame:AddMessage(L("You must be the raid leader or an assistant to sort the groups."), 1, 0.42, 0.42)
        return
    end
    if self.sortTicker then self.sortTicker:Cancel() end
    local steps = 0
    self.sortTicker = C_Timer.NewTicker(0.35, function(t)
        steps = steps + 1
        if InCombatLockdown() or steps > 80 or not IsInRaid() or not sortStep(comp) then
            t:Cancel()
            ns.sortTicker = nil
            print(("|cff6f7cffGuildTool|r: %s"):format(L("Raid groups sorted as in the comp.")))
        end
    end)
end
-- fin du grouping (ici et, pour un officier, chez toute la guilde) : les rappels « Start Grouping » reprennent
local function stopGrouping(evId)
    for k, x in pairs(ns.db.grouping or {}) do
        if not evId or k == evId then ns.db.grouping[k] = nil reminded[k] = nil end
    end
    ns.groupingActive = nil
    if ns.sortTicker then ns.sortTicker:Cancel() ns.sortTicker = nil end
end
function ns:StopGrouping()
    local comp = self:GroupingComp()
    local evId = comp and comp.event
    stopGrouping(evId)
    if IsInGuild() and evId then C_ChatInfo.SendAddonMessage(ns.COMM_PREFIX, ("V\t%s\t%s"):format(self:MyName(), evId), "GUILD") end
    if self.invBtn then self.invBtn:Hide() end
    print(("|cff6f7cffGuildTool|r: %s"):format(L("Grouping stopped.")))
end
-- reçu d'un officier (vérifié par Comm.lua)
function ns:GroupingStopped(evId)
    stopGrouping(evId ~= "" and evId or nil)
    if self.invBtn then self.invBtn:Hide() end
end

-- message vert façon avertissement de raid
local function raidUp()
    local msg = L("Guild Raid up - type \"inv\" in guild")
    if RaidNotice_AddMessage and RaidWarningFrame then
        RaidNotice_AddMessage(RaidWarningFrame, msg, { r = 0.25, g = 1, b = 0.45 })
    else
        UIErrorsFrame:AddMessage(msg, 0.25, 1, 0.45)
    end
    if PlaySound then PlaySound((SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959) end
    print("|cff40ff73" .. msg .. "|r")
end

---------------------------------------------------------------------------
-- Bouton « Inv Raid » : déplaçable, × pour le fermer, /raidinv pour le rouvrir
---------------------------------------------------------------------------
function ns:ShowInvButton()
    local f = self.invBtn
    if not f then
        f = CreateFrame("Frame", "GuildToolInvRaid", UIParent)
        f:SetSize(250, 40)
        f:SetFrameStrata("MEDIUM")
        f:SetMovable(true)
        f:SetClampedToScreen(true)
        f:EnableMouse(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", function(s) s:StartMoving() end)
        f:SetScript("OnDragStop", function(s)
            s:StopMovingOrSizing()
            local p, _, rp, x, y = s:GetPoint()
            ns.db.ui.invBtnPoint = { p, rp, x, y }
        end)
        ns.Fill(f, C.bg, 0.94)
        ns.Border(f, C.hl)
        f.btn = ns.Button(f, L("Inv Raid"), 96, 26, true)
        f.btn:SetPoint("LEFT", 7, 0)
        f.btn:SetScript("OnClick", function()
            if not ns:GroupingComp() then
                UIErrorsFrame:AddMessage(L("No raid grouping in progress."), 1, 0.42, 0.42)
                return
            end
            if not canInvite() then
                UIErrorsFrame:AddMessage(L("You must be the raid leader or an assistant to invite."), 1, 0.42, 0.42)
                return
            end
            local n = ns:InvitePlanned()
            print(("|cff6f7cffGuildTool|r: %s"):format(L("{0} invitation(s) sent.", n)))
        end)
        f.sort = ns.Button(f, L("Sort"), 60, 26)
        f.sort:SetPoint("LEFT", f.btn, "RIGHT", 4, 0)
        f.sort:SetScript("OnClick", function() ns:SortRaidGroups() end)
        f.stop = ns.Button(f, L("Stop"), 56, 26)
        f.stop:SetPoint("LEFT", f.sort, "RIGHT", 4, 0)
        f.stop:SetScript("OnClick", function() ns:StopGrouping() end)
        f.close = ns.IconButton(f, "×", 18)
        f.close:SetPoint("TOPRIGHT", -2, -2)
        f.close:SetScript("OnClick", function() f:Hide() end)
        local p = ns.db.ui.invBtnPoint
        if p then f:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else f:SetPoint("CENTER", 0, 220) end
        self.invBtn = f
    end
    f:Show()
end
SLASH_GUILDTOOLRAIDINV1 = "/raidinv"
SlashCmdList.GUILDTOOLRAIDINV = function() if ns.db then ns:ShowInvButton() end end

---------------------------------------------------------------------------
-- Start Grouping
---------------------------------------------------------------------------
function ns:StartGrouping(comp)
    if not comp then return end
    local me = self:MyName()
    self.db.grouping = self.db.grouping or {}
    self.db.grouping[comp.event] = { comp = comp.id, by = me, t = time() }
    self.groupingActive = { comp = comp.id, by = me, t = time(), builder = true }
    if self.groupPopup then self.groupPopup:Hide() end
    if self.groupSummary then self.groupSummary:Hide() end
    local n = self:InvitePlanned()
    if IsInGuild() then C_ChatInfo.SendAddonMessage(ns.COMM_PREFIX, ("U\t%s\t%s\t%s"):format(me, comp.event or "", comp.id), "GUILD") end
    raidUp()
    self:ShowInvButton()
    print(("|cff6f7cffGuildTool|r: %s"):format(L("Grouping started: {0} invitation(s) sent.", n)))
end
-- reçu d'un officier (vérifié par Comm.lua) : grouping commencé sur cette compo
function ns:GroupingReceived(name, evId, compId)
    self.db.grouping = self.db.grouping or {}
    self.db.grouping[evId] = { comp = compId, by = name, t = time() }
    self.groupingActive = { comp = compId, by = name, t = time() }
    if self.groupPopup then self.groupPopup:Hide() end
    if self.groupSummary then self.groupSummary:Hide() end
    raidUp()
    if self:IsOfficerOrGM() then self:ShowInvButton() end
end

---------------------------------------------------------------------------
-- Popup « Raid in X » et fenêtre des compos
---------------------------------------------------------------------------
local function popupFrame(w, h)
    local f = CreateFrame("Frame", nil, UIParent)
    f:SetSize(w, h)
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(s) s:StartMoving() end)
    f:SetScript("OnDragStop", function(s) s:StopMovingOrSizing() end)
    ns.Fill(f, C.bg, 0.97)
    ns.Border(f, C.hl)
    f.close = ns.IconButton(f, "×", 20)
    f.close:SetPoint("TOPRIGHT", -4, -4)
    f.close:SetScript("OnClick", function() f:Hide() end)
    return f
end

function ns:ShowGroupPopup(events)
    local p = self.groupPopup
    if not p then
        p = popupFrame(320, 130)
        p:SetPoint("TOP", 0, -140)
        p.title = ns.Text(p, 16, 700, C.white)
        p.title:SetPoint("TOP", 0, -14)
        p.sub = ns.Text(p, 11.5, 600, C.mute)
        p.sub:SetPoint("TOP", p.title, "BOTTOM", 0, -6)
        p.sub:SetWidth(290)
        p.sub:SetJustifyH("CENTER")
        p.start = ns.Button(p, L("Start Grouping"), 180, 30, true)
        p.start:SetPoint("BOTTOM", 0, 16)
        p.start:SetScript("OnClick", function()
            local comps = {}
            for _, ev in ipairs(p.events or {}) do for _, c in ipairs(compsOf(ev.id)) do comps[#comps + 1] = c end end
            if #comps == 1 then ns:StartGrouping(comps[1])
            elseif #comps == 0 then UIErrorsFrame:AddMessage(L("No comp linked to this raid yet."), 1, 0.42, 0.42)
            else ns:ShowGroupSummary(comps) end
        end)
        self.groupPopup = p
    end
    p.events = events
    local left = math.max(1, math.floor((events[1].start - time()) / 60 + 0.5))
    ns.SetFont(p.title, 16, 700)
    p.title:SetText(L("Raid in {0} min", left))
    local names = {}
    for _, ev in ipairs(events) do names[#names + 1] = date("%H:%M", ev.start) .. "  " .. (ev.title or "") end
    ns.SetFont(p.sub, 11.5, 600)
    p.sub:SetText(table.concat(names, "\n"))
    p:SetHeight(110 + 14 * #events)
    ns.SetFont(p.start.label, 12, 700)
    p.start.label:SetText(L("Start Grouping"))
    p:Show()
    if PlaySound then PlaySound((SOUNDKIT and SOUNDKIT.READY_CHECK) or 8960) end
end

-- fenêtre des compos : nom du raid, taille, heure, groupes avec les persos prévus ; clic = grouping de cette compo
-- view : titre de la fenêtre en simple consultation (calendrier : compos d'un event, pas de clic)
local GW, ROW = 118, 15
function ns:ShowGroupSummary(comps, view)
    local s = self.groupSummary
    if not s then
        s = popupFrame(500, 300)
        s:SetPoint("CENTER", 0, 60)
        s.title = ns.Text(s, 14, 700, C.white)
        s.title:SetPoint("TOPLEFT", 12, -10)
        s.blocks = {}
        self.groupSummary = s
    end
    ns.SetFont(s.title, 14, 700)
    s.view = view
    s.title:SetText(view or L("Choose the comp to group"))
    local y, maxW = -36, 300
    for i, comp in ipairs(comps) do
        local b = s.blocks[i]
        if not b then
            b = CreateFrame("Button", nil, s)
            b.bg = ns.Fill(b, C.panel, 0.85)
            ns.Border(b, C.border)
            b.head = ns.Text(b, 12, 700, C.white)
            b.head:SetPoint("TOPLEFT", 8, -6)
            b.cols = {}
            b:SetScript("OnEnter", function(f) if not s.view then ns.SetBorderColor(f, C.hl) end end)
            b:SetScript("OnLeave", function(f) ns.SetBorderColor(f, C.border) end)
            b:SetScript("OnClick", function(f) if not s.view then ns:StartGrouping(f.comp) end end)
            s.blocks[i] = b
        end
        b.comp = comp
        local raid = self:RaidByKey(comp.raid) or {}
        local ev = comp.event and self:EventById(comp.event)
        local size = raid.size or 20
        ns.SetFont(b.head, 12, 700)
        b.head:SetText(("%s (%d)  ·  %s"):format(raid.name or "?", size, ev and ev.start and date("%H:%M", ev.start) or "--:--"))
        local G = size / 5
        for g = 1, G do
            local col = b.cols[g]
            if not col then col = { lines = {} } b.cols[g] = col end
            for k = 1, 6 do
                local fs = col.lines[k] or ns.Text(b, k == 1 and 9.5 or 11, k == 1 and 600 or 700)
                col.lines[k] = fs
                fs:ClearAllPoints()
                fs:SetPoint("TOPLEFT", 8 + ((g - 1) % 4) * GW, -26 - math.floor((g - 1) / 4) * (6 * ROW + 6) - (k - 1) * ROW)
                fs:SetWidth(GW - 6)
                fs:SetJustifyH("LEFT")
                fs:SetWordWrap(false)
                if k == 1 then
                    ns.SetFont(fs, 9.5, 600) fs:SetText(strupper(L("Group")) .. " " .. g) fs:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
                else
                    local n = comp.c[(g - 1) * 5 + k - 1]
                    ns.SetFont(fs, 11, 700)
                    if type(n) == "string" then
                        local u = self:UnitFor(n)
                        local cc = ns.ClassColor(u.class)
                        fs:SetText(u.display) fs:SetTextColor(cc[1], cc[2], cc[3])
                    else
                        fs:SetText(L("Empty")) fs:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
                    end
                end
                fs:Show()
            end
        end
        for g = G + 1, #b.cols do for _, fs in ipairs(b.cols[g].lines) do fs:Hide() end end
        local rows = math.ceil(G / 4)
        local h = 30 + rows * (6 * ROW + 6)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", 10, y)
        b:SetSize(math.min(4, G) * GW + 14, h)
        maxW = math.max(maxW, math.min(4, G) * GW + 34)
        b:Show()
        y = y - h - 8
    end
    for i = #comps + 1, #s.blocks do s.blocks[i]:Hide() end
    s:SetSize(maxW, -y + 6)
    s:Show()
end

-- calendrier : compos visibles (non cachées) d'un event, en simple consultation
function ns:ShowEventComps(ev)
    local comps = {}
    for _, c in ipairs(compsOf(ev.id)) do if c.valid then comps[#comps + 1] = c end end
    if #comps == 0 then
        UIErrorsFrame:AddMessage(L("No visible comp for this event yet."), 1, 0.42, 0.42)
        return
    end
    self:ShowGroupSummary(comps, (ev.title or "?") .. "  ·  " .. date("%d/%m %H:%M", ev.start or 0))
end

---------------------------------------------------------------------------
-- Rappels (toutes les 30 s) et invitations automatiques
---------------------------------------------------------------------------
local function check()
    if not (ns.db and IsInGuild() and ns:IsOfficerOrGM()) then return end
    local due = {}
    for _, ev in ipairs(mainEventsSoon()) do
        if not started(ev.id) then
            local left = (ev.start - time()) / 60
            local th
            for _, t in ipairs(REMIND) do if left <= t then th = t break end end
            reminded[ev.id] = reminded[ev.id] or {}
            if th and not reminded[ev.id][th] then
                -- seuils plus grands déjà passés : comptés comme faits (pas de rappel « 1 h » à 20 min)
                for _, t in ipairs(REMIND) do if t >= th then reminded[ev.id][t] = true end end
                due[#due + 1] = ev
            end
        end
    end
    if #due > 0 then ns:ShowGroupPopup(due) end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_GUILD")
ev:RegisterEvent("CHAT_MSG_SYSTEM")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:SetScript("OnEvent", function(_, event, msg, author)
    if event == "PLAYER_LOGIN" then
        C_Timer.After(20, check)
        C_Timer.NewTicker(30, check)
        return
    end
    if not ns.db then return end
    local comp = ns:GroupingComp()
    if not comp then return end
    if event == "GROUP_ROSTER_UPDATE" then
        -- raid builder : le groupe devient un raid dès qu'il a un 2e membre
        if ns.groupingActive and ns.groupingActive.builder and IsInGroup() and not IsInRaid() and UnitIsGroupLeader("player") and GetNumGroupMembers() > 1 then
            if C_PartyInfo and C_PartyInfo.ConvertToRaid then C_PartyInfo.ConvertToRaid() elseif ConvertToRaid then ConvertToRaid() end
        end
        return
    end
    -- officiers du groupe (chef ou assistant) : invitent les persos prévus qui écrivent « inv » ou qui se connectent
    if not (ns:IsOfficerOrGM() and IsInGroup() and canInvite()) then return end
    if event == "CHAT_MSG_GUILD" then
        if strlower(strtrim(msg or "")) == "inv" then
            local n = isPlanned(comp, author)
            if n and not grouped(n) then invite(n) end
        end
    elseif event == "CHAT_MSG_SYSTEM" then
        -- « X s'est connecté » : fin du texte du jeu (ERR_FRIEND_ONLINE_SS, langue du client) après le lien du perso
        local who = (msg or ""):match("|Hplayer:([^|:]+)")
        local suffix = ERR_FRIEND_ONLINE_SS and ERR_FRIEND_ONLINE_SS:match(".*|h(.+)$")
        if who and suffix and msg:find(suffix, 1, true) then
            local n = isPlanned(comp, who)
            if n and not grouped(n) then C_Timer.After(3, function() if not grouped(n) then invite(n) end end) end
        end
    end
end)
