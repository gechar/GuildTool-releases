-- GuildTool : mini-carte des assigns (« <commande> map ») : fenêtre indépendante, pas fermée par Échap.
-- Barre du haut : compo (date - raid), onglet (boss), phase (chacun ouvre la liste de ses choix au clic),
-- « Push » (officiers : ceux qui ont la carte ouverte passent sur cette vue), « Force » (officiers : la carte s'ouvre
-- chez toute la raid sur cette vue), engrenage (réglages : opacités, échelles), « - » réduit, « x » ferme.
-- Par défaut : la prochaine compo à partir d'aujourd'hui, son 1er onglet, sa 1re phase.
local _, ns = ...
local C = ns.C

local MAP_W, MAP_H = 1000, 625
local BAR_H, WIN_W, PAD = 28, 560, 4

-- réglages de la mini-carte (propres au joueur) : opacités (survol / sans survol / en combat, chacune avec son
-- interrupteur), échelle de la fenêtre, échelle des assigns (icônes, noms, textes ; pas les flèches ni les formes)
local LOOK_DEF = { alphaOn = false, alpha = 1, idleOn = false, idle = 0.5, combatOn = false, combat = 0.3, scale = 1, aScale = 1 }
local function look(self)
    local ui = self.db.ui
    ui.mapLook = ui.mapLook or {}
    for k, v in pairs(LOOK_DEF) do if ui.mapLook[k] == nil then ui.mapLook[k] = v end end
    return ui.mapLook
end

local function mapState(self)
    local ui = self.db.ui
    local list = self:AssignComps()
    local cur
    for _, x in ipairs(list) do if x.comp.id == ui.mComp then cur = x break end end
    if not cur then
        cur = ns.NextAssignComp(list)
        ui.mComp, ui.mTab, ui.mPhase = cur and cur.comp.id, 1, 1
    end
    local tabs = cur and ((self.db.presets[cur.comp.raid] or {}).tabs or {}) or {}
    if (ui.mTab or 1) > #tabs or (ui.mTab or 1) < 1 then ui.mTab = 1 end
    local tab = tabs[ui.mTab]
    local phases = tab and tab.phases or {}
    if (ui.mPhase or 1) > #phases or (ui.mPhase or 1) < 1 then ui.mPhase = 1 end
    return cur, list, tabs, tab, phases
end

-- Bouton de la barre : texte + petit triangle, largeur selon le texte
local function chip(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetHeight(BAR_H - 6)
    b.hl = ns.Fill(b, C.hover)
    b.hl:SetAlpha(0)
    b.label = ns.Text(b, 11.5, 600)
    b.label:SetPoint("LEFT", 7, 0)
    b.tri = ns.Triangle(b, "down", 11)
    b.tri:SetPoint("LEFT", b.label, "RIGHT", 3, 0)
    b:SetScript("OnEnter", function(self) self.hl:SetAlpha(1) end)
    b:SetScript("OnLeave", function(self) self.hl:SetAlpha(0) end)
    function b:SetLabel(text)
        self.label:SetWidth(0)
        self.label:SetText(text)
        if self.label:GetStringWidth() > 190 then self.label:SetWidth(190) end
        self:SetWidth(math.min(190, self.label:GetStringWidth()) + 26)
    end
    return b
end

function ns:CreateMapWindow()
    -- palette, polices et menus partagés : la fenêtre principale doit exister (créée cachée au besoin)
    if not self.frame then
        self:CreateFrame()
        self.frame:Hide()
    end
    local f = CreateFrame("Frame", "GuildToolMapFrame", UIParent)
    f:SetSize(WIN_W, BAR_H + PAD * 2 + WIN_W * MAP_H / MAP_W)
    f:SetFrameStrata("MEDIUM")
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetScale((self.db.ui.scale or 1) * look(self).scale)
    local p = self.db.ui.mapPoint
    if p then f:SetPoint(p[1], UIParent, p[1], p[2], p[3]) else f:SetPoint("CENTER", 0, 120) end
    ns.Fill(f, C.bg, 0.94)
    ns.Border(f, C.border)
    self.mapWin = f

    -- barre : déplacement, choix compo / onglet / phase, boutons
    local bar = CreateFrame("Frame", nil, f)
    bar:SetPoint("TOPLEFT", 1, -1)
    bar:SetPoint("TOPRIGHT", -1, -1)
    bar:SetHeight(BAR_H)
    ns.Fill(bar, C.head, 0.9)
    bar:EnableMouse(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart", function() f:StartMoving() end)
    bar:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        self:PinMapTop()
    end)
    f.bar = bar

    f.compBtn, f.tabBtn, f.phBtn = chip(bar), chip(bar), chip(bar)
    f.compBtn:SetPoint("LEFT", 4, 0)
    f.tabBtn:SetPoint("LEFT", f.compBtn, "RIGHT", 2, 0)
    f.phBtn:SetPoint("LEFT", f.tabBtn, "RIGHT", 2, 0)
    f.compBtn:SetScript("OnClick", function(b) self:MapMenu(b, "comp") end)
    f.tabBtn:SetScript("OnClick", function(b) self:MapMenu(b, "tab") end)
    f.phBtn:SetScript("OnClick", function(b) self:MapMenu(b, "phase") end)

    local close = ns.IconButton(bar, "×", 22)
    close.label:SetFont(ns.FONT[600], 14, "")
    close:SetPoint("RIGHT", -3, 0)
    close:SetScript("OnClick", function() f:Hide() end)
    local mini = ns.IconButton(bar, "-", 22)
    mini:SetPoint("RIGHT", close, "LEFT", -1, 0)
    mini:SetScript("OnClick", function()
        self.db.ui.mapMin = not self.db.ui.mapMin
        self:RefreshMap()
    end)
    local gear = ns.IconBox(bar, "Interface\\AddOns\\GuildTool\\media\\gear", "Map settings", 24, BAR_H - 8)
    gear:SetPoint("RIGHT", mini, "LEFT", -4, 0)
    gear:SetScript("OnClick", function() ns:ToggleMapLook() end)
    -- officiers : 1er clic « Confirm » pendant 2 s ; 2e clic : envoyé à toute la raid
    local function sendButton(label, tip, force)
        local b = ns.Button(bar, ns.L(label), 58, BAR_H - 8, true)
        b:SetScript("OnClick", function(btn)
            if not btn.armed then
                btn.armed = true
                btn.label:SetText(ns.L("Confirm"))
                C_Timer.After(2, function() btn.armed = nil btn.label:SetText(ns.L(label)) end)
                return
            end
            btn.armed = nil
            btn.label:SetText(ns.L(label))
            self:MapPush(force)
        end)
        b:SetScript("OnEnter", function(btn)
            ns.TipOwner(btn)
            GameTooltip:SetText(ns.L(tip), 1, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", GameTooltip_Hide)
        return b
    end
    f.force = sendButton("Force", "Open this map for the whole raid, on this view", true)
    f.force:SetPoint("RIGHT", gear, "LEFT", -6, 0)
    f.push = sendButton("Push", "Switch to this view for the raid members who have the map open", false)
    f.push:SetPoint("RIGHT", f.force, "LEFT", -4, 0)
    -- opacité : survol / sans survol / en combat (vérifiée 10 fois par seconde)
    local acc = 0
    f:SetScript("OnUpdate", function(_, e)
        acc = acc + e
        if acc < 0.1 then return end
        acc = 0
        ns:ApplyMapAlpha()
    end)

    -- carte
    local body = CreateFrame("Frame", nil, f)
    body:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", PAD - 1, -PAD)
    body:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    f.body = body
    f.a = ns.NewMapCanvas(body, {}, function() ns:RefreshMap() end)
    f.empty = ns.Text(body, 12, 400, C.mute)
    f.empty:SetPoint("CENTER")
    f.empty:SetWidth(WIN_W - 40)
    f.empty:SetWordWrap(true)
    f.empty:SetJustifyH("CENTER")
    f:SetScript("OnShow", function() ns:RefreshMap() end)
    -- une fenêtre créée est « visible » : cachée tout de suite, sinon la 1re commande la refermait
    f:Hide()
end

-- Listes des choix (même menu que le reste de l'addon, à la largeur du texte)
function ns:MapMenu(anchor, what)
    local cur, list, tabs, _, phases = mapState(self)
    local ui, items = self.db.ui, {}
    if what == "comp" then
        local idx = 1
        for i, x in ipairs(list) do if x == cur then idx = i end end
        local from = math.max(1, math.min(idx - 10, #list - 21))
        for i = from, math.min(#list, from + 21) do
            local x = list[i]
            items[#items + 1] = {
                text = x.label .. (x.ev and ("  ·  " .. (x.ev.title or "")) or ""), checked = x == cur,
                func = function() ui.mComp, ui.mTab, ui.mPhase = x.comp.id, 1, 1 end,
            }
        end
    elseif what == "tab" then
        for i, t in ipairs(tabs) do
            items[#items + 1] = { text = t.name or ("Tab " .. i), checked = i == ui.mTab, func = function() ui.mTab, ui.mPhase = i, 1 end }
        end
    else
        for i, p in ipairs(phases) do
            items[#items + 1] = { text = p.name or ("P" .. i), checked = i == ui.mPhase, func = function() ui.mPhase = i end }
        end
    end
    if #items == 0 then return end
    -- après un choix, le menu rafraîchit la fenêtre principale ; la mini-carte suit
    for _, it in ipairs(items) do
        local fn = it.func
        it.func = function() fn() ns:RefreshMap() end
    end
    self:OpenMenu(anchor, items, "fit")
    self.menu:SetScale(self.mapWin:GetScale())
end

-- Fenêtre ancrée par son coin haut-gauche (position gardée) : réduite ou agrandie, la barre ne bouge pas
function ns:PinMapTop()
    local f = self.mapWin
    local left, top = f:GetLeft(), f:GetTop()
    if not (left and top) then return end
    local x, y = left, top - UIParent:GetTop() * UIParent:GetEffectiveScale() / f:GetEffectiveScale()
    f:ClearAllPoints()
    f:SetPoint("TOPLEFT", UIParent, "TOPLEFT", x, y)
    self.db.ui.mapPoint = { "TOPLEFT", x, y }
end

function ns:RefreshMap()
    local f = self.mapWin
    if not (f and f:IsShown()) then return end
    local cur, _, tabs, tab = mapState(self)
    local ui = self.db.ui
    local raid = cur and self:RaidByKey(cur.comp.raid)
    f.compBtn:SetLabel(cur and cur.label or ns.L("No comp"))
    f.tabBtn:SetShown(tab ~= nil)
    f.phBtn:SetShown(tab ~= nil and #(tab.phases or {}) > 0)
    if tab then
        f.tabBtn:SetLabel(tab.name or ("Tab " .. ui.mTab))
        local ph = (tab.phases or {})[ui.mPhase]
        f.phBtn:SetLabel(ph and ph.name or ("P" .. ui.mPhase))
    end
    -- officiers : toujours visibles (hors groupe, le clic explique qu'il faut un raid ou un groupe)
    f.push:SetShown(self:MayEdit() and tab ~= nil)
    f.force:SetShown(self:MayEdit() and tab ~= nil)
    f.a.elemScale = look(self).aScale
    -- réduite : la barre seule, au même endroit
    local min = ui.mapMin
    self:PinMapTop()
    f.body:SetShown(not min)
    f:SetHeight(min and BAR_H + 2 or (BAR_H + PAD * 2 + WIN_W * MAP_H / MAP_W))
    if min then return end
    local a = f.a
    if not (cur and tab) then
        a.mapClip:Hide()
        f.empty:SetText(ns.L(cur and (raid and #tabs == 0 and "No assigns tab for this raid yet (created in the exe)." or "No assigns tab.")
            or "No comp yet: create one in Raid Comps."))
        f.empty:Show()
        return
    end
    f.empty:Hide()
    a.mapClip:Show()
    ns.DrawAssignMap(self, a, cur.comp, tab, ui.mPhase, f.body, f.body:GetWidth(), f.body:GetHeight(), 0)
end

function ns:ToggleMap()
    if not self.db then return end
    if not self.mapWin then self:CreateMapWindow() end
    if self.mapWin:IsShown() then self.mapWin:Hide() else self.mapWin:Show() end
end

---------------------------------------------------------------------------
-- Réglages de la mini-carte : petite fenêtre sous l'engrenage (interrupteur + curseur par opacité, échelles)
---------------------------------------------------------------------------
function ns:ApplyMapAlpha()
    local f = self.mapWin
    if not (f and f:IsShown()) then return end
    local lk = look(self)
    local over = f:IsMouseOver() or (self.mapLook and self.mapLook:IsShown() and self.mapLook:IsMouseOver())
        or (self.menu and self.menu:IsShown() and self.menu:IsMouseOver())
    local a = lk.alphaOn and lk.alpha or 1
    if not over then
        if lk.combatOn and (InCombatLockdown() or UnitAffectingCombat("player")) then a = lk.combat
        elseif lk.idleOn then a = lk.idle end
    end
    if math.abs(f:GetAlpha() - a) > 0.001 then f:SetAlpha(a) end
end

-- échelle de la fenêtre : le coin haut-gauche reste en place
function ns:ApplyMapScale()
    local f = self.mapWin
    if not f then return end
    local left, top = f:GetLeft(), f:GetTop()
    local es = f:GetEffectiveScale()
    f:SetScale((self.db.ui.scale or 1) * look(self).scale)
    if left and top then
        local ns2 = f:GetEffectiveScale()
        f:ClearAllPoints()
        f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left * es / ns2, top * es / ns2)
        self:PinMapTop()
    end
end

local function lookSwitch(row, key)
    local sw = CreateFrame("Button", nil, row)
    sw:SetSize(30, 16)
    sw:SetPoint("LEFT", 168, 0)
    sw.track = ns.Tex(sw, C.border, "ARTWORK")
    sw.track:SetAllPoints()
    sw.knob = ns.Tex(sw, C.mute, "OVERLAY")
    sw.knob:SetSize(12, 12)
    function sw:Update()
        local on = look(ns)[key]
        self.knob:ClearAllPoints()
        self.knob:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        local c, k = on and C.accent or C.border, on and C.white or C.mute
        self.track:SetColorTexture(c[1], c[2], c[3])
        self.knob:SetColorTexture(k[1], k[2], k[3])
        if row.slider then row.slider:SetAlpha(on and 1 or 0.4) end
    end
    sw:SetScript("OnClick", function(self)
        local lk = look(ns)
        lk[key] = not lk[key]
        self:Update()
        ns:ApplyMapAlpha()
    end)
    row.switch = sw
end

-- curseur « 60% » : min / max en %, onChange(valeur 0-1+)
local function lookSlider(row, key, lo, hi, onChange)
    local s = CreateFrame("Slider", nil, row)
    s:SetOrientation("HORIZONTAL")
    s:SetSize(110, 14)
    s:SetPoint("RIGHT", -8, 0)
    s:SetMinMaxValues(lo, hi)
    s:SetValueStep(5)
    s:SetObeyStepOnDrag(true)
    local tr = ns.Tex(s, C.input, "BACKGROUND")
    tr:SetPoint("LEFT") tr:SetPoint("RIGHT") tr:SetHeight(4)
    s.fill = ns.Tex(s, C.accent, "ARTWORK")
    s.fill:SetPoint("LEFT") s.fill:SetHeight(4)
    s:SetThumbTexture("Interface\\Buttons\\WHITE8X8")
    s:GetThumbTexture():SetSize(8, 14)
    s.text = ns.Text(row, 11.5, 600)
    s.text:SetPoint("RIGHT", s, "LEFT", -6, 0)
    local function show(v)
        s.text:SetText(math.floor(v + 0.5) .. "%")
        s.fill:SetWidth(math.max(1, 110 * (v - lo) / (hi - lo)))
    end
    s:SetScript("OnValueChanged", function(_, v, user)
        show(v)
        if user then look(ns)[key] = v / 100 onChange() end
    end)
    s:EnableMouseWheel(true)
    s:SetScript("OnMouseWheel", function(self, d)
        self:SetValue(math.max(lo, math.min(hi, self:GetValue() + d * 5)))
        look(ns)[key] = self:GetValue() / 100
        onChange()
    end)
    function s:Update() local v = look(ns)[key] * 100 self:SetValue(v) show(v) end
    row.slider = s
end

function ns:CreateMapLook()
    local w = CreateFrame("Frame", nil, UIParent)
    w:SetFrameStrata("DIALOG")
    w:SetSize(380, 30 + 5 * 28 + 10)
    w:EnableMouse(true)
    w:SetClampedToScreen(true)
    ns.Fill(w, C.bg, 0.97)
    ns.Border(w, C.hl)
    local bar = CreateFrame("Frame", nil, w)
    bar:SetPoint("TOPLEFT", 1, -1) bar:SetPoint("TOPRIGHT", -1, -1)
    bar:SetHeight(26)
    ns.Fill(bar, C.head)
    local title = ns.Text(bar, 12, 700, C.white)
    title:SetPoint("LEFT", 10, 0)
    title:SetText(ns.L("Map settings"))
    local close = ns.IconButton(bar, "×", 22)
    close:SetPoint("RIGHT", -2, 0)
    close:SetScript("OnClick", function() w:Hide() end)
    w.rows = {}
    local function row(i, label, tip)
        local r = CreateFrame("Frame", nil, w)
        r:SetHeight(28)
        r:SetPoint("TOPLEFT", 10, -30 - (i - 1) * 28)
        r:SetPoint("TOPRIGHT", -2, -30 - (i - 1) * 28)
        r:EnableMouse(true)
        r.label = ns.Text(r, 12, 600)
        r.label:SetPoint("LEFT")
        r.label:SetText(ns.L(label))
        r:SetScript("OnEnter", function(self)
            ns.TipOwner(self)
            GameTooltip:SetText(ns.L(tip), 1, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", GameTooltip_Hide)
        w.rows[i] = r
        return r
    end
    local alpha = function() ns:ApplyMapAlpha() end
    local r1 = row(1, "Opacity", "Opacity of the map (mouse over it, or always if the other options are off).")
    lookSlider(r1, "alpha", 10, 100, alpha) lookSwitch(r1, "alphaOn")
    local r2 = row(2, "Opacity no mouseover", "Opacity of the map when the mouse is not over it.")
    lookSlider(r2, "idle", 0, 100, alpha) lookSwitch(r2, "idleOn")
    local r3 = row(3, "Opacity combat", "Opacity of the map in combat when the mouse is not over it (wins over \"no mouseover\").")
    lookSlider(r3, "combat", 0, 100, alpha) lookSwitch(r3, "combatOn")
    lookSlider(row(4, "Scale", "Size of the map window."), "scale", 50, 200, function() ns:ApplyMapScale() end)
    lookSlider(row(5, "Assigns scale", "Size of the icons, names and texts on the map (not the arrows, lines, drawings and shapes)."),
        "aScale", 50, 200, function() ns:RefreshMap() end)
    w:Hide()
    self.mapLook = w
end

function ns:ToggleMapLook()
    if not self.mapLook then self:CreateMapLook() end
    local w = self.mapLook
    if w:IsShown() then w:Hide() return end
    w:SetScale(self.db.ui.scale or 1)
    w:ClearAllPoints()
    w:SetPoint("TOPRIGHT", self.mapWin, "BOTTOMRIGHT", 0, -2)
    for _, r in ipairs(w.rows) do
        if r.slider then r.slider:Update() end
        if r.switch then r.switch:Update() end
    end
    w:Show()
end

---------------------------------------------------------------------------
-- Push / Force (officiers) : la raid passe sur la compo / l'onglet / la phase affichés ; Force ouvre aussi la carte
---------------------------------------------------------------------------
function ns:MapPush(force)
    if not self:CanEdit() then return end
    local cur = mapState(self)
    if not cur then return end
    local channel = IsInRaid() and "RAID" or IsInGroup() and "PARTY" or nil
    if not channel then
        UIErrorsFrame:AddMessage(ns.L("Join a raid or a party to push the map."), 1, 0.42, 0.42)
        return
    end
    local ui = self.db.ui
    C_ChatInfo.SendAddonMessage(ns.COMM_PREFIX, ("%s\t%s\t%s\t%d\t%d"):format(force and "F" or "M", self:MyName() or UnitName("player"), cur.comp.id, ui.mTab or 1, ui.mPhase or 1), channel)
end

-- Reçu d'un officier (vérifié par Comm.lua) : vue envoyée ; Push = seulement si la carte est ouverte (sinon gardée
-- pour sa prochaine ouverture), Force = la carte s'ouvre (et se déplie)
function ns:MapApplyPush(compId, tabIdx, phIdx, force)
    local ui = self.db.ui
    ui.mComp, ui.mTab, ui.mPhase = compId, tonumber(tabIdx) or 1, tonumber(phIdx) or 1
    if not self.mapWin then self:CreateMapWindow() end
    if force then ui.mapMin = false end
    if self.mapWin:IsShown() then self:RefreshMap() elseif force then self.mapWin:Show() end
end
