-- GuildTool : page Calendar (semaines du lundi au dimanche ; teinte et survol par lockout, du mercredi au mardi)
-- + sélecteur de mois (survol du titre de la sous-barre)
local _, ns = ...
local C = ns.C

local HEAD_H, PAD, LINE_H = 24, 10, 17
local RED, GREEN = { 0.85, 0.27, 0.27 }, { 0.25, 0.75, 0.45 }
local ORANGE, YELLOW, BLUE = { 0.886, 0.518, 0.188 }, { 0.878, 0.753, 0.227 }, { 0.361, 0.486, 0.769 }

-- Couleurs d'un event (comme l'appli) : couleur, opacité du fond, opacité de la ligne de gauche.
-- Main : rouge, vert si sa compo est visible ; commu : orangé, jaunâtre si compo visible, fond 20 % moins opaque ;
-- archivés (salon d'archive, ou lockout passé) : Main bleuté discret, commu sans fond (ligne de gauche seule)
function ns:EventColors(ev)
    local db, done = self.db, self:EventDone(ev)
    local commu = ev.commu or (db.commuArchive and db.commuArchive ~= "" and ev.chId == db.commuArchive)
    local archived = (db.mainArchive and db.mainArchive ~= "" and ev.chId == db.mainArchive)
        or (db.commuArchive and db.commuArchive ~= "" and ev.chId == db.commuArchive)
        or (ev.start or 0) < self:WeekStart(time())
    if commu then
        local c = done and YELLOW or ORANGE
        -- archivé : sans fond ; ligne jaune plus terne si sa compo était visible
        return c, archived and 0 or 0.256, (archived and done) and 0.5 or 1
    end
    if archived then return BLUE, 0.14, 0.55 end
    return done and GREEN or RED, 0.32, 1
end
local GOLD = { 1, 0.82, 0.25 }
-- un lockout sur deux assombri, les autres éclaircis (même écart perçu sur fond sombre)
-- couleurs d'alternance des lockouts : réglables dans Settings (opacité 60 %)
local function lockColor(hex) local c = ns.Hex((hex or "#0e0f12"):gsub("#", "")) return c[1], c[2], c[3] end
local MONTHS2_EN = { "Ja", "Fe", "Ma", "Ap", "Ma", "Ju", "Ju", "Au", "Se", "Oc", "No", "De" }
local MONTHS2_FR = { "Ja", "Fé", "Ma", "Av", "Ma", "Jn", "Jl", "Ao", "Se", "Oc", "No", "Dé" }
local MONTHS2 = setmetatable({}, { __index = function(_, i) return (ns.Lang() == "fr" and MONTHS2_FR or MONTHS2_EN)[i] end })

-- Calendrier continu : d'octobre 2026 (pas avant) à 12 mois après le mois actuel ; mois = année * 100 + mois (1-12)
local CAL_MIN = 2026 * 100 + 10
local VISIBLE_ROWS, POOL = 5, 7
local function calMax()
    local t = date("*t")
    local m = t.month + 12
    return (t.year + math.floor((m - 1) / 12)) * 100 + (m - 1) % 12 + 1
end
local function calClamp(v) return math.max(CAL_MIN, math.min(calMax(), v)) end
ns.CalClamp = calClamp

-- mois affiché : celui du haut de la zone visible, sinon le mois actuel
function ns:CalendarMonth()
    local v = self.calVisible or calClamp(tonumber(date("%Y%m")))
    return math.floor(v / 100), v % 100
end

---------------------------------------------------------------------------
-- Cases
---------------------------------------------------------------------------
-- Survol : le jour, et plus légèrement tout son lockout (qui chevauche deux lignes)
local function setHover(cell, on)
    for _, row in ipairs(ns.cal.rows) do
        for _, c in ipairs(row.cells) do
            c.lockHl:SetShown(on and c.lock == cell.lock and c:IsShown())
        end
    end
    cell.hl:SetShown(on)
end

-- Réactions à un event (comme sur Discord) : s'inscrire (classes de l'Event Class), en retard, incertain, absent.
-- Le jeu n'a pas accès à internet : la réaction est mise en file (GuildToolDB.rhQueue) et l'exe l'envoie à
-- Raid-Helper dès que le jeu écrit ses SavedVariables (/reload, déconnexion).
local REACT = {
    { "sign", "Sign up (your classes of the Event Class)", "Interface\\RaidFrame\\ReadyCheck-Ready" },
    { "late", "Late", "Interface\\Icons\\INV_Misc_PocketWatch_01" },
    { "tentative", "Tentative", "Interface\\RaidFrame\\ReadyCheck-Waiting" },
    { "absence", "Absence", "Interface\\RaidFrame\\ReadyCheck-NotReady" },
}
function ns:QueueReaction(ev, kind)
    local q = self.db.rhQueue or {}
    local now = time()
    -- file nettoyée : réactions de plus de 7 jours retirées (l'exe les a déjà traitées)
    local kept = {}
    for _, it in ipairs(q) do if (it.t or 0) > now - 7 * 86400 then kept[#kept + 1] = it end end
    kept[#kept + 1] = { e = ev.id, k = kind, t = now }
    self.db.rhQueue = kept
    self:LogPending(ns.L("Reaction") .. " · " .. (ev.title or "?") .. " · " .. kind)
    print(("|cff6f7cffGuildTool|r: %s · %s — %s"):format(ev.title or "?", ns.L(kind == "sign" and "Sign up" or (kind:sub(1, 1):upper() .. kind:sub(2))),
        ns.L("sent to Raid-Helper by Guild Tool at your next /reload or logout.")))
end

local REACT_FALLBACK = {}
for _, r in ipairs(REACT) do REACT_FALLBACK[r[1]] = r[3] end

-- Mon inscription à un event (compte Discord connecté dans l'exe) : sign / late / tentative / absence, sinon nil
function ns:MyStatus(ev)
    local me = self.db.myDiscord
    if not me then return nil end
    local found, sts = false, {}
    for _, s in ipairs(ev.signups or {}) do
        if s.uid == me then found = true sts[s.st or "primary"] = true end
    end
    if not found then return nil end
    for _, k in ipairs({ "absence", "tentative", "late" }) do if sts[k] then return k end end
    return "sign"
end

local function reactIcon(kind, fallback)
    if ns.db.statusIcons and ns.db.statusIcons[kind] then return ns.MEDIA_PATH .. "status_" .. kind end
    return fallback
end

-- Ma place dans une compo visible de l'event : { u, spec } ; false : inscrit mais pas dans la compo (banc) ;
-- nil : pas de compo visible
local function myCompSpot(ev)
    local db, me = ns.db, ns.db.myDiscord
    if not me or not ev.start then return nil end
    local week = db.weeks[tostring(ns:WeekStart(ev.start))]
    local any = false
    for _, comp in ipairs(week and week.comps or {}) do
        if comp.event == ev.id and comp.valid and not comp.deleted then
            any = true
            for _, name in pairs(comp.c or {}) do
                if type(name) == "string" then
                    local n, c = name:match("^~(.*)#(%u*)$")
                    local su
                    for _, s in ipairs(ev.signups or {}) do
                        if s.uid == me and ((n and s.n == n and (s.c or "") == c) or (not n and s.ch == name)) then su = s break end
                    end
                    if su or (db.myChars or {})[name] then
                        local u = ns:CompUnit(comp, name)
                        return { u = u, spec = u.spec or (su and su.s) }
                    end
                end
            end
        end
    end
    if any then return false end
end

local function eventLine(cell, i)
    local b = cell.lines[i]
    if not b then
        b = CreateFrame("Button", nil, cell)
        b:SetHeight(LINE_H - 2)
        -- (plus d'icônes de réaction au survol : inscriptions faites dans l'appli ou sur Discord)
        b.bg = ns.Tex(b, RED, "BACKGROUND", 0.4)
        b.bg:SetAllPoints()
        b.edge = ns.Tex(b, RED, "ARTWORK")
        b.edge:SetPoint("TOPLEFT") b.edge:SetPoint("BOTTOMLEFT") b.edge:SetWidth(2)
        b.text = ns.Text(b, 11.5, 600)
        b.text:SetPoint("LEFT", 6, 0)
        b.text:SetWordWrap(false)
        -- ma place / mon inscription (spé dans la compo, banc, V, réaction), ancrée à droite, à la hauteur de la ligne
        b.me = b:CreateTexture(nil, "OVERLAY")
        b.me:SetPoint("RIGHT", -2, 0)
        b:SetScript("OnEnter", function(self)
            setHover(cell, true)
            local ev = self.event
            ns.TipOwner(self)
            GameTooltip:SetText(ev.title or "?", 1, 1, 1)
            GameTooltip:AddLine(ns:EventLabel(ev), 0.8, 0.8, 0.8)
            local n = 0
            for _, s in ipairs(ev.signups or {}) do if s.st ~= "absence" then n = n + 1 end end
            GameTooltip:AddLine(n .. " sign-ups", 0.6, 0.6, 0.6)
            if ns:EventDone(ev) then GameTooltip:AddLine("Comp validated", GREEN[1], GREEN[2], GREEN[3])
            else GameTooltip:AddLine("No validated comp yet", RED[1], RED[2], RED[3]) end
            local spot = ns.db.myDiscord and ns:MyStatus(ev) and ns:MyStatus(ev) ~= "absence" and myCompSpot(ev)
            if spot then GameTooltip:AddLine(ns.L("You are in the comp: {0}", ((spot.spec or "") .. " " .. (spot.u.display or "")):gsub("^ ", "")), GREEN[1], GREEN[2], GREEN[3])
            elseif spot == false then GameTooltip:AddLine(ns.L("Not in the comp of this event."), RED[1], RED[2], RED[3]) end
            GameTooltip:AddLine(ns.L("Click to see the comps of this event."), 0.6, 0.6, 0.6)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() setHover(cell, false) GameTooltip:Hide() end)
        b:SetScript("OnClick", function(self)
            if ns.absMode then ns:ToggleAbsenceDay(cell.key) else ns:ShowEventComps(self.event) end
        end)
        cell.lines[i] = b
    end
    return b
end

-- Mode absence : Absence = sélection (les absences actuelles sont présélectionnées), Confirm = enregistrement
-- (pour l'instant les absences ne servent qu'à l'affichage)
function ns:ToggleAbsenceMode()
    if not self.absMode then
        self.absMode, self.absSel = true, CopyTable(self.db.absences)
    else
        self.absMode = false
        self.db.absences = self.absSel
        self.db.absT = time()
    end
    self:Refresh()
end

function ns:ToggleAbsenceDay(key)
    self.absSel[key] = not self.absSel[key] or nil
    self:Refresh()
end

-- Ouvre le lockout dans Raid Comps (et sélectionne la 1re compo de l'event si donné)
function ns:OpenWeek(ts, eventId)
    self:SetWeek(ts)
    if eventId then
        for _, comp in ipairs(self:GetWeek().comps) do
            if comp.event == eventId then self.db.ui.selected = comp.id break end
        end
    end
    self:ShowPage("comps")
end

-- Semaines à la suite (5 visibles), seulement 7 rangées de cases recyclées pendant le défilement.
-- Limite entre deux mois : ligne Highlight au-dessus des 7 premiers jours et à gauche du 1er (escalier),
-- nom du mois au-dessus de son premier jour.
function ns:CreateCalendar(page)
    local cal = { rows = {}, heads = {} }
    self.cal = cal
    for i = 1, 7 do cal.heads[i] = ns.Text(page, 10.5, 700, C.mute) end
    local sf = ns.ScrollArea(page)
    sf:SetPoint("TOPLEFT", PAD, -PAD - HEAD_H)
    sf:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    cal.sf = sf
    -- molette : une semaine par cran
    sf:SetScript("OnMouseWheel", function(f, d) f:ScrollTo(f:GetVerticalScroll() - d * (cal.rh or 100)) end)
    sf:HookScript("OnVerticalScroll", function() ns:FillCalendarRows() end)
    for r = 1, POOL do
        local row = CreateFrame("Frame", nil, sf.child)
        row.cells = {}
        for d = 1, 7 do
            local cell = CreateFrame("Button", nil, row)
            cell.shade = cell:CreateTexture(nil, "BACKGROUND")
            cell.shade:SetAllPoints()
            ns.Border(cell, C.border, 0.6)
            -- absence : teinte rouge (confirmée), plus marquée + contour pendant la sélection
            cell.absent = ns.Tex(cell, { 0.85, 0.27, 0.27 }, "BACKGROUND", 0.16)
            cell.absent:SetDrawLayer("BACKGROUND", 3)
            cell.absent:SetAllPoints()
            cell.lockHl = ns.Tex(cell, C.white, "BACKGROUND", 0.035)
            cell.lockHl:SetDrawLayer("BACKGROUND", 1)
            cell.lockHl:SetAllPoints()
            cell.lockHl:Hide()
            cell.hl = ns.Tex(cell, C.white, "BACKGROUND", 0.06)
            cell.hl:SetDrawLayer("BACKGROUND", 2)
            cell.hl:SetAllPoints()
            cell.hl:Hide()
            -- jour présent : fond bleu (comme la semaine actuelle dans la liste des lockouts)
            cell.todayBg = cell:CreateTexture(nil, "BACKGROUND", nil, 4)
            cell.todayBg:SetAllPoints()
            cell.todayBg:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.28)
            -- limite des mois (couleur Highlight)
            cell.mTop = cell:CreateTexture(nil, "OVERLAY", nil, 7)
            cell.mTop:SetPoint("TOPLEFT", -1, 1)
            cell.mTop:SetPoint("TOPRIGHT", 1, 1)
            cell.mTop:SetHeight(2)
            cell.mLeft = cell:CreateTexture(nil, "OVERLAY", nil, 7)
            cell.mLeft:SetPoint("TOPLEFT", -1, 1)
            cell.mLeft:SetPoint("BOTTOMLEFT", -1, -1)
            cell.mLeft:SetWidth(2)
            cell.day = ns.Text(cell, 12, 700)
            cell.day:SetPoint("TOPLEFT", 6, -5)
            -- note de la guilde : à droite du numéro, sur une ligne (police réduite si trop longue, puis coupée)
            cell.note = ns.Text(cell, 10.5, 500, { 0.91, 0.886, 0.784 })
            cell.note:SetPoint("BOTTOMLEFT", cell.day, "BOTTOMRIGHT", 6, 0)
            cell.note:SetWordWrap(false)
            cell.note:SetJustifyH("LEFT")
            cell.more = ns.Text(cell, 10, 600, C.mute)
            cell.more:SetPoint("BOTTOMRIGHT", -5, 3)
            cell.lines = {}
            cell:SetScript("OnEnter", function(self) setHover(self, true) end)
            cell:SetScript("OnLeave", function(self) setHover(self, false) end)
            cell:SetScript("OnClick", function(self)
                if ns.absMode then ns:ToggleAbsenceDay(self.key) else ns:OpenWeek(self.ts) end
            end)
            row.cells[d] = cell
        end
        cal.rows[r] = row
    end
    -- noms des mois : au-dessus des cases (posés sur la ligne de séparation, sur le jeudi)
    cal.labels = CreateFrame("Frame", nil, sf.child)
    cal.labels:SetAllPoints(sf.child)
    cal.labels:SetFrameLevel(sf.child:GetFrameLevel() + 20)
    cal.mnames = {}
end

-- Fait défiler jusqu'à la semaine qui contient le 1er du mois v (année * 100 + mois)
function ns:CalendarScrollTo(v)
    local cal = self.cal
    if not cal.start then return end
    v = calClamp(v)
    local d1 = time({ year = math.floor(v / 100), month = v % 100, day = 1, hour = 12 })
    local idx = math.max(0, math.floor((d1 - cal.start) / ns.WEEK + 0.01))
    cal.sf:ScrollTo(idx * cal.rh)
    self:FillCalendarRows()
end

function ns:RefreshCalendar()
    local page, cal = self.pages.calendar, self.cal
    local sf = cal.sf
    local W, H = page:GetWidth(), sf:GetHeight()
    local cw = (W - 2 * PAD - 8) / 7       -- place de la barre de défilement à droite
    local rh = math.max(60, H / VISIBLE_ROWS)
    cal.cw, cal.rh = cw, rh
    for d = 1, 7 do
        local h = cal.heads[d]
        h:ClearAllPoints()
        h:SetPoint("BOTTOMLEFT", page, "TOPLEFT", PAD + (d - 1) * cw + 6, -PAD - HEAD_H + 6)
        h:SetText(strupper(ns.DayName(d)))
    end
    -- du lundi de la semaine du 1er octobre 2026 au dernier jour du 12e mois après le mois actuel
    local first = time({ year = math.floor(CAL_MIN / 100), month = CAL_MIN % 100, day = 1, hour = 12 })
    local start = first - ((tonumber(date("%w", first)) + 6) % 7) * ns.DAY
    local mx = calMax()
    local last = time({ year = math.floor(mx / 100), month = mx % 100 + 1, day = 0, hour = 12 })
    cal.start, cal.n = start, math.floor((last - start) / ns.WEEK) + 1
    sf.child:SetSize(cw * 7, cal.n * rh)
    local byDay = {}
    for _, ev in ipairs(self.db.events) do
        if ev.start then
            local k = date("%Y%m%d", ev.start)
            byDay[k] = byDay[k] or {}
            table.insert(byDay[k], ev)
        end
    end
    -- events du salon Main Raid d'abord, puis à l'heure
    -- (salon d'archive des Main Raid compris : events des lockouts passés)
    local main, arch = self.db.mainChannel, self.db.mainArchive
    local function isMain(ev) return (main and ev.chId == main) or (arch and ev.chId == arch) or false end
    for _, list in pairs(byDay) do
        table.sort(list, function(a, b)
            local ma, mb = isMain(a), isMain(b)
            if ma ~= mb then return ma and true or false end
            return a.start < b.start
        end)
    end
    cal.byDay = byDay
    -- saut demandé (< > Today, sélecteur), sinon la position gardée ; 1re ouverture : le mois actuel.
    -- La hauteur défilable n'est connue qu'à l'image suivante : le saut est refait juste après.
    local jump = self.calJump or (not cal.placed and tonumber(date("%Y%m"))) or nil
    self.calJump, cal.placed = nil, true
    if jump then
        self:CalendarScrollTo(jump)
        C_Timer.After(0, function() ns:CalendarScrollTo(jump) end)
    else
        self:FillCalendarRows()
    end
end

function ns:FillCalendarRows()
    local cal = self.cal
    if not (cal and cal.start and cal.rh) then return end
    local rh, cw, sf = cal.rh, cal.cw, cal.sf
    local off = sf:GetVerticalScroll()
    local firstRow = math.floor(off / rh)
    local today, byDay = date("%Y%m%d"), cal.byDay or {}
    local hl = C.accent   -- limite des mois : le bleu du jour présent
    local nl = 0
    for i, row in ipairs(cal.rows) do
        local wi = firstRow + i - 1
        if wi < cal.n then
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", sf.child, "TOPLEFT", 0, -wi * rh)
            row:SetSize(cw * 7, rh)
            for d, cell in ipairs(row.cells) do
                local ts = cal.start + (wi * 7 + (d - 1)) * ns.DAY
                local t = date("*t", ts)
                cell.ts = ts
                -- teinte du lockout (mercredi -> mardi) : sombre / clair en alternance
                cell.lock = self:WeekOf(ts)
                local r, g, b = lockColor(cell.lock % 2 == 1 and self.db.appearance.lockA or self.db.appearance.lockB)
                cell.shade:SetColorTexture(r, g, b, 0.6)
                cell:ClearAllPoints()
                cell:SetPoint("TOPLEFT", (d - 1) * cw, 0)
                cell:SetSize(cw, rh)
                local key = date("%Y%m%d", ts)
                cell.key = key
                local picked = self.absMode and self.absSel[key]
                cell.absent:SetShown(picked or (not self.absMode and self.db.absences[key]) or false)
                cell.absent:SetColorTexture(0.85, 0.27, 0.27, picked and 0.34 or 0.16)
                ns.SetBorderColor(cell, picked and { 1, 0.47, 0.47 } or C.border, picked and 0.9 or 0.6)
                cell.todayBg:SetShown(key == today)
                -- limite des mois : escalier (haut des 7 premiers jours, gauche du 1er) ; nom du mois au-dessus du 1er
                cell.mTop:SetColorTexture(hl[1], hl[2], hl[3], 1)
                cell.mLeft:SetColorTexture(hl[1], hl[2], hl[3], 1)
                cell.mTop:SetShown(t.day <= 7 and wi > 0)
                cell.mLeft:SetShown(t.day == 1 and d > 1)
                -- au jeudi de la ligne : mois précédent au-dessus de la ligne, nouveau mois en dessous
                if d == 4 and t.day <= 7 and wi > 0 then
                    local pm, py = t.month - 1, t.year
                    if pm < 1 then pm, py = 12, py - 1 end
                    for _, lab in ipairs({ { pm, py, "BOTTOM", "TOP", 3 }, { t.month, t.year, "TOP", "TOP", -3 } }) do
                        nl = nl + 1
                        local fs = cal.mnames[nl]
                        if not fs then
                            fs = ns.Text(cal.labels, 10.5, 700)
                            fs:SetShadowOffset(1, -1)
                            fs:SetShadowColor(0, 0, 0, 1)
                            cal.mnames[nl] = fs
                        end
                        fs:ClearAllPoints()
                        fs:SetPoint(lab[3], cell, lab[4], 0, lab[5])
                        fs:SetText(strupper(ns.MonthLong(lab[1])) .. ((lab[1] == 1 or lab[1] == 12) and (" " .. lab[2]) or ""))
                        fs:SetTextColor(hl[1], hl[2], hl[3])
                        fs:Show()
                    end
                end
                cell.day:SetText(t.day)
                cell.day:SetTextColor(C.text[1], C.text[2], C.text[3], 1)
                -- comme l'appli : ligne du numéro puis 4 lignes d'event, chacune 1/5 de la case
                local lh = math.floor(rh / 5) - 1
                local top = lh - 2
                local evs = byDay[key] or {}
                local note = self.db.notes and self.db.notes[tostring(t.year * 10000 + t.month * 100 + t.day)]
                if note and note ~= "" then
                    cell.note:SetWidth(math.max(10, cw - 6 - cell.day:GetStringWidth() - 6 - 5))
                    ns.SetFont(cell.note, 10.5, 500)
                    note = note:gsub("%s+", " ")
                    cell.note:SetText(note)
                    if cell.note:GetUnboundedStringWidth() > cell.note:GetWidth() then ns.SetFont(cell.note, 9.5, 500) cell.note:SetText(note) end
                    cell.note:Show()
                else
                    cell.note:Hide()
                end
                local max = #evs > 4 and 3 or 4
                for k, ev in ipairs(evs) do
                    if k <= max then
                        local bt = eventLine(cell, k)
                        local col, ba, ea = self:EventColors(ev)
                        bt.event = ev
                        -- ma place : spé dans la compo visible, banc (rouge) si je n'y suis pas, sinon V (inscrit) ou réaction
                        local st = ns:MyStatus(ev)
                        local spot = st and st ~= "absence" and myCompSpot(ev)
                        -- compo visible sans moi : ligne moitié moins marquée
                        if spot == false and ns:EventDone(ev) then ba, ea = ba / 2, ea / 2 end
                        bt.bg:SetColorTexture(col[1], col[2], col[3], ba)
                        bt.edge:SetColorTexture(col[1], col[2], col[3], ea)
                        ns.SetFont(bt.text, 11.5, 600)
                        bt.text:SetText(date("%H:%M", ev.start) .. "  " .. (ev.title or "?"))
                        bt:SetHeight(lh - 1)
                        bt.me:SetSize(lh - 5, lh - 5)
                        bt.me:SetVertexColor(1, 1, 1)
                        bt.me:SetShown(st ~= nil)
                        if spot then
                            bt.me:SetTexture(ns:SpecIcon(spot.u, spot.spec) or REACT_FALLBACK.sign)
                        elseif spot == false then
                            bt.me:SetTexture(ns.MEDIA_PATH .. "bench")
                            bt.me:SetVertexColor(RED[1], RED[2], RED[3])
                        elseif st then
                            bt.me:SetTexture(st == "sign" and REACT_FALLBACK.sign or reactIcon(st, REACT_FALLBACK[st]))
                        end
                        bt.text:SetPoint("RIGHT", st and -(lh - 1) or -4, 0)
                        bt:ClearAllPoints()
                        bt:SetPoint("TOPLEFT", 4, -top - (k - 1) * lh)
                        bt:SetPoint("TOPRIGHT", -4, -top - (k - 1) * lh)
                        bt:Show()
                    end
                end
                for k = math.min(#evs, max) + 1, #cell.lines do cell.lines[k]:Hide() end
                cell.more:SetText(#evs > max and ("+" .. (#evs - max) .. " more") or "")
                cell:Show()
                self:BlurBehind(cell) -- image de fond floutée sous la case
            end
            row:Show()
        else
            row:Hide()
        end
    end
    for k = nl + 1, #cal.mnames do cal.mnames[k]:Hide() end
    -- titre : le mois du jeudi de la 2e ligne visible (celui qui occupe le plus la vue)
    local wi = math.min(cal.n - 1, math.floor((off + 4) / rh) + 1)
    local t = date("*t", cal.start + (wi * 7 + 3) * ns.DAY)
    local v = t.year * 100 + t.month
    if v ~= self.calVisible then
        self.calVisible = v
        if self.db.ui.page == "calendar" and self.sub then self.sub.title:SetText(ns.MonthLong(t.month) .. " " .. t.year) end
    end
end

---------------------------------------------------------------------------
-- Sélecteur de mois : années empilées (en-tête + 3 x 4 mois), défilement vertical
---------------------------------------------------------------------------
local YEAR_H, CELL_W, CELL_H, PICK_W = 22 + 4 * 30, 58, 26, 3 * 62 + 14

local function pickerButton(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(CELL_W, CELL_H)
    b.bg = ns.Tex(b, C.input, "BACKGROUND", 0.9)
    b.bg:SetAllPoints()
    b.gold = b:CreateTexture(nil, "BACKGROUND", nil, 1)
    b.gold:SetAllPoints()
    b.gold:SetColorTexture(1, 1, 1, 1)
    b.gold:SetGradient("VERTICAL", CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.45), CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.1))
    b.edges = ns.Border(b, C.border)
    b.label = ns.Text(b, 12, 700)
    b.label:SetPoint("CENTER")
    b:SetScript("OnEnter", function(self) ns.SetBorderColor(self, C.accent) end)
    b:SetScript("OnLeave", function(self) ns.SetBorderColor(self, self.selected and GOLD or C.border) end)
    b:SetScript("OnClick", function(self) ns:PickMonth(self.y, self.m) end)
    return b
end

function ns:PickMonth(y, m)
    if self.db.ui.page == "comps" then
        self:SetWeek(time({ year = y, month = m, day = 1, hour = 12 }))
    else
        self.calJump = calClamp(y * 100 + m)
    end
    self.picker:Hide()
    self:Refresh()
end

function ns:CreateMonthPicker(anchor)
    local p = CreateFrame("Frame", nil, self.frame)
    p:SetFrameStrata("DIALOG")
    p:SetSize(PICK_W, YEAR_H * 2 + 16)
    p:SetPoint("TOP", anchor, "BOTTOM", 0, -4)
    p:EnableMouse(true)
    ns.Fill(p, { 0.09, 0.094, 0.11 }, 0.97)
    ns.Border(p, C.border)
    local sf = ns.ScrollArea(p)
    sf:SetPoint("TOPLEFT", 6, -6)
    sf:SetPoint("BOTTOMRIGHT", -6, 6)
    sf.child:SetWidth(PICK_W - 12)
    p.sf = sf
    p.years, p.buttons = {}, {}
    local y0 = math.floor(CAL_MIN / 100)
    for yi = 0, 9 do
        local year = y0 + yi
        local head = ns.Text(sf.child, 12, 700, C.white)
        head:SetPoint("TOPLEFT", 4, -yi * YEAR_H - 4)
        head:SetText(year)
        p.years[yi + 1] = head
        for mi = 1, 12 do
            local b = pickerButton(sf.child)
            local col, row = (mi - 1) % 3, math.floor((mi - 1) / 3)
            b:SetPoint("TOPLEFT", 2 + col * 62, -yi * YEAR_H - 22 - row * 30)
            b.y, b.m = year, mi
            b.label:SetText(MONTHS2[mi])
            p.buttons[#p.buttons + 1] = b
        end
    end
    sf.child:SetHeight(10 * YEAR_H)
    -- se referme 0,5 s après que la souris a quitté le titre et le cadre (pas de fermeture au passage de l'un à l'autre)
    p:SetScript("OnUpdate", function(self)
        if self:IsMouseOver() or anchor:IsMouseOver() then
            self.outSince = nil
        else
            self.outSince = self.outSince or GetTime()
            if GetTime() - self.outSince > 0.5 then self:Hide() end
        end
    end)
    p:SetScript("OnHide", function(self) self.outSince = nil end)
    p:Hide()
    self.picker = p
end

---------------------------------------------------------------------------
-- Raid Comps : liste verticale des lockouts (même format que le titre)
---------------------------------------------------------------------------
local LOCK_ROW, LIST_W, LIST_H = 28, 230, 320
local LIST_SHIFT = 3 -- décalage du centre des lignes (barre de défilement) pour centrer le tiret sur le cadre

local function autoClose(p, anchor)
    -- se referme 0,5 s après que la souris a quitté le titre et le cadre
    p:SetScript("OnUpdate", function(self)
        if self:IsMouseOver() or anchor:IsMouseOver() then
            self.outSince = nil
        else
            self.outSince = self.outSince or GetTime()
            if GetTime() - self.outSince > 0.5 then self:Hide() end
        end
    end)
    p:SetScript("OnHide", function(self) self.outSince = nil end)
end

function ns:CreateLockoutList(anchor)
    local p = CreateFrame("Frame", nil, self.frame)
    p:SetFrameStrata("DIALOG")
    p:SetSize(LIST_W, LIST_H)
    p:SetPoint("TOP", anchor, "BOTTOM", 0, -4)
    p:EnableMouse(true)
    ns.Fill(p, { 0.09, 0.094, 0.11 }, 0.97)
    ns.Border(p, C.border)
    local sf = ns.ScrollArea(p)
    sf:SetPoint("TOPLEFT", 6, -6)
    sf:SetPoint("BOTTOMRIGHT", -6, 6)
    sf.child:SetWidth(LIST_W - 12)
    p.sf, p.rows = sf, {}
    autoClose(p, anchor)
    p:Hide()
    self.lockList = p
end

function ns:ShowLockoutList()
    local p = self.lockList
    local cur, thisWeek = self:CurrentWeek(), self:WeekStart(time())
    -- de la semaine actuelle au dernier event connu, seulement les lockouts qui ont des events (et celui affiché) ;
    -- le passé (12 lockouts) avec « Show History », en gris
    local from = self.pickHistory and (math.min(thisWeek, cur) - 12 * ns.WEEK) or thisWeek
    local to = math.max(thisWeek, cur)
    for _, ev in ipairs(self.db.events) do
        if ev.start and ev.start > to then to = ev.start end
    end
    to = self:WeekStart(to)
    local counts = {}
    for _, ev in ipairs(self.db.events) do
        if ev.start then
            local k = self:WeekStart(ev.start)
            counts[k] = (counts[k] or 0) + 1
        end
    end
    local top = 0
    if not p.hist then
        local h = CreateFrame("Button", nil, p.sf.child)
        h:SetSize(LIST_W - 22, LOCK_ROW - 2)
        h.icon = h:CreateTexture(nil, "ARTWORK")
        h.icon:SetTexture(ns.HISTORY_ICON)
        h.icon:SetSize(15, 15)
        h.icon:SetPoint("LEFT", 10, 0)
        h.label = ns.Text(h, 12, 500, C.mute)
        h.label:SetPoint("LEFT", h.icon, "RIGHT", 7, 0)
        local function paint(on)
            local c = on and ns.HISTORY_HOVER or C.mute
            ns.SetFont(h.label, 12, on and 700 or 500)
            h.label:SetTextColor(c[1], c[2], c[3])
            h.icon:SetVertexColor(c[1], c[2], c[3])
        end
        h:SetScript("OnEnter", function() paint(true) end)
        h:SetScript("OnLeave", function() paint(false) end)
        h:SetScript("OnClick", function() ns.pickHistory = true ns:ShowLockoutList() end)
        paint(false)
        p.hist = h
    end
    p.hist.label:SetText(ns.L("Show History"))
    p.hist:SetShown(not self.pickHistory)
    if not self.pickHistory then
        p.hist:SetPoint("TOPLEFT", 2, 0)
        top = LOCK_ROW
    end
    local i, selY = 0, 0
    for ws = from, to, ns.WEEK do
      if (counts[ws] or 0) > 0 or ws == cur then
        i = i + 1
        local b = p.rows[i]
        if not b then
            b = CreateFrame("Button", nil, p.sf.child)
            b:SetSize(LIST_W - 22, LOCK_ROW - 2)
            b.bg = ns.Tex(b, C.white, "BACKGROUND", 0)
            b.bg:SetAllPoints()
            b.gold = b:CreateTexture(nil, "BACKGROUND", nil, 1)
            b.gold:SetAllPoints()
            b.gold:SetColorTexture(1, 1, 1, 1)
            b.gold:SetGradient("VERTICAL", CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.45), CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.1))
            ns.Border(b, C.border)
            -- date découpée autour du tiret, tiret au centre de la ligne
            b.dash = ns.Text(b, 12, 700)
            b.dash:SetPoint("CENTER", LIST_SHIFT, 0)
            b.dash:SetText("-")
            b.left = ns.Text(b, 12, 700)
            b.left:SetPoint("RIGHT", b.dash, "LEFT", -6, 0)
            b.right = ns.Text(b, 12, 700)
            b.right:SetPoint("LEFT", b.dash, "RIGHT", 6, 0)
            b.count = ns.Text(b, 10.5, 600, C.mute)
            b.count:SetPoint("RIGHT", -8, 0)
            -- lockout d'une autre année : l'année en petit à gauche
            b.year = ns.Text(b, 9, 600, C.mute)
            b.year:SetPoint("LEFT", 6, 0)
            b:SetScript("OnEnter", function(self) ns.SetBorderColor(self, C.accent) end)
            b:SetScript("OnLeave", function(self) ns.SetBorderColor(self, self.selected and GOLD or C.border, self.selected and 1 or 0) end)
            b:SetScript("OnClick", function(self)
                ns:SetWeek(self.ws)
                p:Hide()
                ns:Refresh()
            end)
            p.rows[i] = b
        end
        b.ws = ws
        b:SetPoint("TOPLEFT", 2, -(i - 1) * LOCK_ROW - top)
        local l, r = self:WeekParts(ws)
        local yr = tonumber(date("%Y", ws))
        ns.SetFont(b.year, 9, 600)
        b.year:SetText(yr ~= tonumber(date("%Y")) and yr or "")
        b.left:SetText(l)
        b.right:SetText(r)
        local n = counts[ws] or 0
        b.count:SetText(n > 0 and (n .. " event" .. (n > 1 and "s" or "")) or "")
        b.selected = ws == cur
        b.gold:SetShown(b.selected)
        local isNow = ws == thisWeek
        b.bg:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], isNow and 0.28 or 0)
        ns.SetBorderColor(b, b.selected and GOLD or C.border, b.selected and 1 or 0)
        local c = b.selected and GOLD or (ws < thisWeek and C.mute) or C.text
        for _, fs in ipairs({ b.left, b.dash, b.right }) do fs:SetTextColor(c[1], c[2], c[3]) end
        b:Show()
        if b.selected then selY = (i - 1) * LOCK_ROW + top end
      end
    end
    for j = i + 1, #p.rows do p.rows[j]:Hide() end
    p.sf.child:SetHeight(i * LOCK_ROW + top)
    -- largeur ajustée aux textes : dates à gauche du tiret (calées à droite), « Show History » commence où commence
    -- la date de la 1re ligne, pas de place perdue à gauche
    local title, m = self.sub.title, self.sub.measure
    local maxL, maxR, firstL, cntW = 0, 0, nil, 0
    for j = 1, i do
        local b = p.rows[j]
        ns.SetFont(m, 12, 700)
        m:SetText(b.left:GetText() or "")
        local lw = m:GetStringWidth()
        maxL, firstL = math.max(maxL, lw), firstL or lw
        m:SetText(b.right:GetText() or "")
        maxR = math.max(maxR, m:GetStringWidth())
        ns.SetFont(m, 10.5, 600)
        m:SetText(b.count:GetText() or "")
        cntW = math.max(cntW, m:GetStringWidth())
    end
    ns.SetFont(m, 12, 700)
    m:SetText("-")
    local dashW = m:GetStringWidth()
    ns.SetFont(m, 12, 500)
    m:SetText(p.hist.label:GetText() or "")
    local histW = m:GetStringWidth() + 22
    local PADL = 10
    -- année à gauche d'une ligne : place réservée devant les dates (les tirets restent alignés)
    for j = 1, i do if (p.rows[j].year:GetText() or "") ~= "" then PADL = 36 break end end
    local dashX = PADL + maxL + 6 + dashW / 2
    local rowW = math.max(dashX + dashW / 2 + 6 + maxR + (cntW > 0 and (14 + cntW) or 0) + 8, PADL + histW + 8)
    for j = 1, i do
        local b = p.rows[j]
        b:SetWidth(rowW)
        b.dash:ClearAllPoints()
        b.dash:SetPoint("CENTER", b, "LEFT", dashX, 0)
    end
    p.hist:SetWidth(rowW)
    p.hist.icon:ClearAllPoints()
    p.hist.icon:SetPoint("LEFT", PADL + maxL - (firstL or maxL), 0)
    p.sf.child:SetWidth(rowW + 4)
    p:SetWidth(rowW + 22)
    p:SetHeight(math.min(LIST_H, i * LOCK_ROW + top + 12))
    -- le tiret des lignes s'aligne sous celui du titre (« 28 Oct - 4 Nov »)
    ns.SetFont(m, 14, 700)
    local l = self:WeekParts(cur)
    m:SetText(l .. " ")
    local x = m:GetStringWidth()
    m:SetText("-")
    x = x + m:GetStringWidth() / 2
    p:ClearAllPoints()
    p:SetPoint("TOPLEFT", title, "BOTTOMLEFT", x - 8 - dashX, -10)
    p:Show()
    p.sf:ScrollTo(selY - 110)
end

function ns:ShowMonthPicker()
    if self.db.ui.page == "comps" then return self:ShowLockoutList() end
    local p = self.picker
    local y, m
    if self.db.ui.page == "comps" then
        local t = date("*t", self:CurrentWeek() + 3 * ns.DAY)
        y, m = t.year, t.month
    else
        y, m = self:CalendarMonth()
    end
    local now = date("*t")
    local y1 = math.floor(calMax() / 100)
    for _, b in ipairs(p.buttons) do
        local v = b.y * 100 + b.m
        -- années au-delà du calendrier : cachées ; mois avant octobre 2026 ou après 12 mois : grisés, inactifs
        b:SetShown(b.y <= y1)
        local off = v < CAL_MIN or v > calMax()
        b:SetEnabled(not off)
        b:SetAlpha(off and 0.35 or 1)
        b.selected = b.y == y and b.m == m
        local isNow = b.y == now.year and b.m == now.month
        b.gold:SetShown(b.selected)
        b.bg:SetColorTexture(isNow and C.accent[1] or C.input[1], isNow and C.accent[2] or C.input[2], isNow and C.accent[3] or C.input[3], isNow and 0.28 or 0.9)
        ns.SetBorderColor(b, b.selected and GOLD or C.border)
        local c = b.selected and GOLD or (off and C.mute) or C.text
        ns.SetFont(b.label, 12, 700)
        b.label:SetText(MONTHS2[b.m])
        b.label:SetTextColor(c[1], c[2], c[3])
    end
    for yi, head in ipairs(p.years) do head:SetShown(math.floor(CAL_MIN / 100) + yi - 1 <= y1) end
    p.sf.child:SetHeight((y1 - math.floor(CAL_MIN / 100) + 1) * YEAR_H)
    p:Show()
    p.sf:ScrollTo((y - math.floor(CAL_MIN / 100)) * YEAR_H)
end
