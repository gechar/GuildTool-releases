-- GuildTool : page Assigns (affichage). Les onglets de boss, cartes, formes, sorts et icônes de boss sont créés dans
-- l'exe (mode Config) et arrivent par Import.lua ; en jeu on choisit la compo, on lit les assigns et on peut
-- remplacer un nom en cliquant dessus. Repère des éléments : carte de 1000 x 625 (ratio 1,6).
local _, ns = ...
local C = ns.C

local MAP_W, MAP_H = 1000, 625
local MEDIA = "Interface\\AddOns\\GuildTool\\media\\"
local TAB_H, PH_H, PAD = 30, 24, 10
local ICON_SIZE = { spell = 36, boss = 70, role = 36, mark = 36 }   -- taille par défaut des icônes
local COLORS = {}

local function rgb(hex)
    if not COLORS[hex] then COLORS[hex] = ns.Hex((hex or "#ffffff"):gsub("#", "")) end
    return COLORS[hex]
end

---------------------------------------------------------------------------
-- Compos de toutes les semaines : « jj/mm - Raid #n » (#n si le même raid apparaît plusieurs fois pour l'event)
---------------------------------------------------------------------------
function ns:AssignComps()
    local out = {}
    local officer = self:MayEdit()
    for key, week in pairs(self.db.weeks) do
        for i, c in ipairs(week.comps or {}) do
            if c.valid or officer or self:MayEditComp(c) then   -- compo cachée : officiers (et créateur de l'event commu)
            local ev = c.event and self:EventById(c.event)
            local ws = tonumber(key) or 0
            out[#out + 1] = { comp = c, ws = ws, ev = ev, ts = ev and ev.start or ws, i = i }
            end
        end
    end
    table.sort(out, function(a, b)
        if a.ts ~= b.ts then return a.ts < b.ts end
        if a.ws ~= b.ws then return a.ws < b.ws end
        return a.i < b.i
    end)
    local groups = {}
    for _, a in ipairs(out) do
        local k = (a.comp.event or ("w" .. a.ws)) .. ":" .. a.comp.raid
        groups[k] = groups[k] or {}
        local g = groups[k]
        g[#g + 1] = a
        a.group, a.n = g, #g
    end
    for _, a in ipairs(out) do
        local raid = self:RaidByKey(a.comp.raid)
        a.label = date("%d/%m", a.ts) .. " - " .. (raid and raid.name or a.comp.raid) .. (#a.group > 1 and (" #" .. a.n) or "")
    end
    return out
end

-- prochaine compo à partir d'aujourd'hui (minuit), sinon la dernière
local function nextComp(list)
    local t = date("*t")
    local today = time({ year = t.year, month = t.month, day = t.day, hour = 0 })
    for _, a in ipairs(list) do if a.ts >= today then return a end end
    return list[#list]
end
ns.NextAssignComp = nextComp

function ns:AssignComp()
    local list = self:AssignComps()
    if #list == 0 then return nil, list end
    for i, a in ipairs(list) do if a.comp.id == self.db.ui.aComp then return a, list, i end end
    local a = nextComp(list)
    self.db.ui.aComp = a.comp.id
    return a, list
end

function ns:OpenAssigns(id)
    self.db.ui.aComp, self.db.ui.aTab, self.db.ui.aPhase = id, 0, 1
    self:ShowPage("assigns")
end

function ns:AssignNav(dir)
    local a, list, i = self:AssignComp()
    if not a then return end
    if dir == 0 then a = nextComp(list)
    else a = list[math.max(1, math.min(#list, (i or 1) + dir))] end
    self.db.ui.aComp, self.db.ui.aTab, self.db.ui.aPhase = a.comp.id, 0, 1
end

-- Survol du titre : liste des compos autour de celle affichée
function ns:ShowAssignCompMenu()
    local cur, all = self:AssignComp()
    if not cur then return end
    -- compos d'avant la semaine actuelle : cachées derrière « Show History », puis en gris
    local thisWeek = self:WeekStart(time())
    local list, hasOld = {}, false
    for _, a in ipairs(all) do
        if a.ws < thisWeek then hasOld = true end
        if self.pickHistory or a.ws >= thisWeek then list[#list + 1] = a end
    end
    -- même liste que l'appli : nom de la compo, titre de l'event à droite, choisie en doré, passées en gris
    -- ordre chronologique des events (liste d'AssignComps)

    local items = {}
    if hasOld and not self.pickHistory then
        items[1] = { hist = true, text = ns.L("Show History"), keep = true, func = function() ns.pickHistory = true ns:ShowAssignCompMenu() end }
    end
    for _, a in ipairs(list) do
        -- « 28/10 - Mount Hyjal #2 » : tirets alignés sur celui du titre
        local l, r = a.label:match("^(.-) %- (.+)$")
        local yr = tonumber(date("%Y", a.ev and a.ev.start or a.ws))
        items[#items + 1] = { left = l, right = r, text = not l and a.label or nil, count = a.ev and a.ev.title or nil,
                              year = yr ~= tonumber(date("%Y")) and yr or nil, sel = a == cur, old = a.ws < thisWeek,
                              func = function() ns.db.ui.aComp, ns.db.ui.aTab, ns.db.ui.aPhase = a.comp.id, 0, 1 end }
    end
    self:TitlePicker(self.sub.titleBtn, items, self.sub.title)
end

-- « Edit Comp » : la compo affichée dans Raid Comps (sa semaine, sélectionnée)
function ns:EditAssignComp()
    local a = self:AssignComp()
    if not a then return end
    self.db.ui.week = a.ws
    self.db.ui.selected = a.comp.id
    self.addState = nil
    self:ShowPage("comps")
end

---------------------------------------------------------------------------
-- Noms : critères automatiques (rôles, classes, spés, index) et changements à la main
---------------------------------------------------------------------------
local function compMembers(comp)
    local raid = ns:RaidByKey(comp.raid)
    local out = {}
    for s = 1, raid and raid.size or 40 do
        if comp.c[s] then out[#out + 1] = ns:CompUnit(comp, comp.c[s]) end
    end
    return out
end

local function has(list, v)
    if type(list) ~= "table" then return false end
    for _, x in ipairs(list) do if x == v then return true end end
    return false
end

local function critMatch(c, u)
    local spec = (u.spec or ""):gsub("%d+$", "")
    return (not c.classes or #c.classes == 0 or has(c.classes, u.class))
        and (not c.roles or #c.roles == 0 or has(c.roles, u.role))
        and (not c.specs or #c.specs == 0 or has(c.specs, (u.class or "") .. ":" .. spec))
end

local function hasCrit(c) return #(c.classes or {}) + #(c.roles or {}) + #(c.specs or {}) > 0 end

local function critLabel(c)
    local parts = {}
    for _, s in ipairs(c.specs or {}) do parts[#parts + 1] = s:match(":(.+)") or s end
    for _, k in ipairs(c.classes or {}) do parts[#parts + 1] = ns.L(ns.CLASS_NAME[k] or k) end
    for _, r in ipairs(c.roles or {}) do parts[#parts + 1] = ns.L(r) end
    return table.concat(parts, "/")
end

-- Blocs de critères essayés dans l'ordre (« else » = secours) : index (un nom) ou nombre (liste) ;
-- les persos retenus par les noms exclus ne sont pas candidats ; un nom changé à la main remplace sa place.
-- Ex. Démoniste/Mage/Prêtre + Distance, index 3 = le 3e distance parmi ces classes (ordre des groupes)
local function resolvePhase(items, members, ovr)
    local res, busy, byId = {}, {}, {}
    for _, it in ipairs(items) do byId[it.id] = it end
    local function get(it)
        if res[it.id] then return res[it.id] end
        if busy[it.id] then return { units = {}, entries = {} } end
        busy[it.id] = true
        local excl = {}
        for _, xid in ipairs(it.exclude or {}) do
            local x = byId[xid]
            if x and x.type == "name" then for _, u in ipairs(get(x).units) do excl[u.name] = true end end
        end
        local crits = it.crits or { it.crit or {} }
        local found, label = {}, nil
        for _, c in ipairs(crits) do
            if hasCrit(c) then
                label = label or critLabel(c)
                local list = {}
                for _, m in ipairs(members) do if not excl[m.name] and critMatch(c, m) then list[#list + 1] = m end end
                if c.multi then
                    for k = 1, math.min(#list, math.max(1, c.amount or 1)) do found[k] = list[k] end
                elseif list[c.idx or 1] then
                    found[1] = list[c.idx or 1]
                end
                if #found > 0 then break end
            end
        end
        local entries, units = {}, {}
        for k = 1, math.max(1, #found) do
            local key = k == 1 and it.id or (it.id .. "#" .. (k - 1))
            local e = { key = key }
            if ovr[key] then e.u, e.manual = ns:UnitFor(ovr[key]), true
            elseif found[k] then e.u = found[k]
            else e.text = label or "?" end
            entries[k] = e
            if e.u then units[#units + 1] = e.u end
        end
        res[it.id] = { entries = entries, units = units }
        return res[it.id]
    end
    for _, it in ipairs(items) do if it.type == "name" then get(it) end end
    return res
end

function ns:SetAssignName(comp, key, name)
    if not self:CanEditComp(comp) then return end   -- officiers, ou créateur de l'event d'une compo communautaire
    local cur = self.db.assigns[comp.id]
    local n = cur and CopyTable(cur.n or {}) or {}
    n[key] = name
    self.db.assigns[comp.id] = { t = time(), n = n }
    if self.QueueShare then self:QueueShare("A", comp.id) end   -- envoyé tout de suite à la guilde
    local ev = comp.event and self:EventById(comp.event)
    self:LogPending(ns.L("Assigns") .. " · " .. (ev and ev.title or comp.raid or "?") .. " · " .. tostring(name or "-"))
    self:Refresh()
    if self.RefreshMap then self:RefreshMap() end
end

---------------------------------------------------------------------------
-- Choix d'un nom : liste de tous les persos filtrée par la frappe
---------------------------------------------------------------------------
local PICK_ROWS = 14
function ns:OpenNamePicker(anchor, comp, itemId)
    local p = self.namePicker
    if not p then
        p = CreateFrame("Frame", nil, UIParent)
        p:SetFrameStrata("FULLSCREEN_DIALOG")
        p:SetSize(200, 26 + PICK_ROWS * 20 + 4)
        p:SetClampedToScreen(true)
        p:EnableMouse(true)
        ns.Fill(p, { 0.09, 0.094, 0.11 })
        ns.Border(p, C.accent)
        local eb = CreateFrame("EditBox", nil, p)
        eb:SetPoint("TOPLEFT", 6, -3)
        eb:SetPoint("TOPRIGHT", -6, -3)
        eb:SetHeight(22)
        eb:SetFont(ns.FONT[400], 12, "")
        eb:SetAutoFocus(false)
        eb.hint = ns.Text(eb, 11, 400, C.mute)
        eb.hint:SetPoint("LEFT", 0, 0)
        eb:SetScript("OnTextChanged", function() p.offset = 0 p:Fill() end)
        eb:SetScript("OnEscapePressed", function() p:Hide() end)
        eb:SetScript("OnEnterPressed", function() if p.buttons[1]:IsShown() then p.buttons[p.list[1] and p.list[1] ~= "" and 1 or 2]:Click() end end)
        p.eb = eb
        local sep = ns.Tex(p, C.border, "ARTWORK")
        sep:SetPoint("TOPLEFT", 1, -26) sep:SetPoint("TOPRIGHT", -1, -26) sep:SetHeight(1)
        p.buttons = {}
        for i = 1, PICK_ROWS do
            local b = CreateFrame("Button", nil, p)
            b:SetHeight(20)
            b:SetPoint("TOPLEFT", 1, -27 - (i - 1) * 20)
            b:SetPoint("TOPRIGHT", -1, -27 - (i - 1) * 20)
            b.hl = ns.Fill(b, C.hover)
            b.hl:Hide()
            b.label = ns.Text(b, 12, 600)
            b.label:SetPoint("LEFT", 9, 0)
            b:SetScript("OnEnter", function(self) self.hl:Show() end)
            b:SetScript("OnLeave", function(self) self.hl:Hide() end)
            b:SetScript("OnClick", function(self) p:Hide() ns:SetAssignName(p.comp, p.itemId, self.name ~= "" and self.name or nil) end)
            p.buttons[i] = b
        end
        p:EnableMouseWheel(true)
        p:SetScript("OnMouseWheel", function(self, d)
            self.offset = math.max(0, math.min(#self.list - PICK_ROWS, self.offset - d * 3))
            self:Fill()
        end)
        -- clic ailleurs = fermeture
        local catcher = CreateFrame("Button", nil, UIParent)
        catcher:SetAllPoints(UIParent)
        catcher:SetFrameStrata("FULLSCREEN")
        catcher:RegisterForClicks("AnyUp")
        catcher:SetScript("OnClick", function() p:Hide() end)
        catcher:Hide()
        p:SetScript("OnHide", function() catcher:Hide() p.eb:ClearFocus() end)
        p.catcher = catcher
        function p:Fill()
            local q = strlower(self.eb:GetText() or "")
            self.eb.hint:SetShown(q == "")
            local list, seen = {}, {}
            if q == "" then list[1] = "" end
            local function add(name)
                if not seen[name] and (q == "" or strlower(name):find(q, 1, true)) then seen[name] = true list[#list + 1] = name end
            end
            for _, u in ipairs(compMembers(self.comp)) do add(u.name) end
            local names = {}
            for name, r in pairs(ns.db.roster) do if r.c then names[#names + 1] = name end end
            table.sort(names)
            for _, name in ipairs(names) do add(name) end
            self.list = list
            for i, b in ipairs(self.buttons) do
                local name = list[i + self.offset]
                if name then
                    b.name = name
                    if name == "" then
                        b.label:SetText(ns.L("Auto (criteria)"))
                        b.label:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
                    else
                        local u = ns:UnitFor(name)
                        local c = ns.ClassColor(u.class)
                        b.label:SetText(u.display)
                        b.label:SetTextColor(c[1], c[2], c[3])
                    end
                    b:Show()
                else
                    b:Hide()
                end
            end
        end
        self.namePicker = p
    end
    p.comp, p.itemId, p.offset = comp, itemId, 0
    p:SetScale(self.frame:GetScale())
    p.eb:SetText("")
    p.eb.hint:SetText(ns.L("Type to filter"))
    p:ClearAllPoints()
    p:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -3)
    p:Fill()
    p.catcher:Show()
    p:Show()
    p.eb:SetFocus()
end

---------------------------------------------------------------------------
-- Page
---------------------------------------------------------------------------
local function tabButton(parent, onClick)
    local b = CreateFrame("Button", nil, parent)
    b:SetHeight(TAB_H - 1)
    ns.Selection(b, nil, C.hl)
    b.label = ns.Text(b, 12, 600)
    b.label:SetPoint("CENTER")
    b:SetScript("OnClick", onClick)
    return b
end

-- Image entière du raid (fond thématique d'Assigns) : cadre découpé (clip) contenant l'image en proportions réelles,
-- placée par rapport à « anchor » (la fenêtre entière) ; masque = zone de fondu choisie dans l'exe (Placement),
-- sinon fondu à droite si l'image ne couvre pas toute la largeur
local function newImage(parent, level, anchor)
    local clip = CreateFrame("Frame", nil, parent)
    clip:SetClipsChildren(true)
    clip:SetFrameLevel(level)
    local holder = CreateFrame("Frame", nil, clip)
    holder:SetPoint("TOPLEFT", anchor or parent, "TOPLEFT")
    local tex = holder:CreateTexture(nil, "BACKGROUND")
    tex:SetAllPoints()
    local mask = holder:CreateMaskTexture()
    mask:SetAllPoints()
    return { clip = clip, holder = holder, tex = tex, mask = mask, page = anchor or parent }
end

-- view = partie de l'image choisie dans l'exe (Placement, cadre bleu) : elle remplit la fenêtre ;
-- sans view, l'image garde la hauteur de la fenêtre, ancrée à gauche
local function placeImage(im, file, W, H, aspect, alpha, fadeFile, view)
    if not file or H <= 0 then im.clip:Hide() return end
    im.clip:Show()
    aspect = aspect or 1.5
    local wf, hf, x, y = H * aspect, H, 0, 0
    if type(view) == "table" and (view.w or 0) > 0 then
        wf = W / view.w
        hf = wf / aspect
        x, y = -(view.x or 0) * wf, (view.y or 0) * hf
    end
    im.holder:ClearAllPoints()
    im.holder:SetPoint("TOPLEFT", im.page, "TOPLEFT", x, y)
    im.holder:SetSize(wf, hf)
    im.tex:SetTexture(file)
    im.tex:SetAlpha(alpha)
    local m = fadeFile or (wf < W - 1 and x == 0 and MEDIA .. "fade_right") or nil
    if m then
        im.mask:SetTexture(m, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        if not im.masked then im.tex:AddMaskTexture(im.mask) im.masked = true end
    elseif im.masked then
        im.tex:RemoveMaskTexture(im.mask)
        im.masked = false
    end
end

-- Fond thématique : même placement que placeImage (view = cadre bleu de l'exe, sinon hauteur de la fenêtre, ancré
-- à gauche) mais sur une texture de la fenêtre : seule la partie visible de l'image est affichée (coordonnées)
local function placeTheme(im, win, file, W, H, aspect, alpha, fadeFile, view)
    local t = im.tex
    if not file or H <= 0 or W <= 0 then t:Hide() return end
    aspect = aspect or 1.5
    local wf, hf, x, y = H * aspect, H, 0, 0
    if type(view) == "table" and (view.w or 0) > 0 then
        wf = W / view.w
        hf = wf / aspect
        x, y = -(view.x or 0) * wf, (view.y or 0) * hf
    end
    -- partie de l'image dans la fenêtre (1 px de bord)
    local l, r = math.max(0, (1 - x) / wf), math.min(1, (W - 1 - x) / wf)
    local top, b = math.max(0, (y + 1) / hf), math.min(1, (H - 1 + y) / hf)
    if r <= l or b <= top then t:Hide() return end
    t:ClearAllPoints()
    t:SetPoint("TOPLEFT", win, "TOPLEFT", x + l * wf, y - top * hf)
    t:SetSize((r - l) * wf, (b - top) * hf)
    t:SetTexture(file)
    t:SetTexCoord(l, r, top, b)
    t:SetAlpha(alpha)
    t:Show()
    local m = fadeFile or (wf < W - 1 and x == 0 and MEDIA .. "fade_right") or nil
    if m then
        im.mask:ClearAllPoints()
        im.mask:SetPoint("TOPLEFT", win, "TOPLEFT", x, y)
        im.mask:SetSize(wf, hf)
        im.mask:SetTexture(m, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        if not im.masked then t:AddMaskTexture(im.mask) im.masked = true end
    elseif im.masked then
        t:RemoveMaskTexture(im.mask)
        im.masked = false
    end
end

-- Cadres d'une carte d'assigns (page Assigns, mini-carte) ajoutés à a : cadre fixe qui découpe (mapClip), carte
-- (map, s'y agrandit avec Ctrl + molette autour du curseur), textes au-dessus (overlay), pools d'éléments
function ns.NewMapCanvas(parent, a, redraw)
    local clip = CreateFrame("Frame", nil, parent)
    clip:SetClipsChildren(true)
    ns.Border(clip, C.border)
    a.mapClip = clip
    local map = CreateFrame("Frame", nil, clip)
    map.bg = ns.Fill(map, { 0, 0, 0 }, 0.45)
    map.img = map:CreateTexture(nil, "BACKGROUND", nil, 1)
    map.img:SetAllPoints()
    a.map = map
    a.zoom = { key = "", z = 1, x = 0, y = 0 }
    clip:EnableMouseWheel(true)
    clip:SetScript("OnMouseWheel", function(self, d)
        if not IsControlKeyDown() then return end
        local zm, w0, h0 = a.zoom, self:GetWidth(), self:GetHeight()
        local sc = self:GetEffectiveScale()
        local cx, cy = GetCursorPosition()
        cx, cy = cx / sc - self:GetLeft(), self:GetTop() - cy / sc
        local lx, ly = (cx - zm.x) / zm.z, (cy - zm.y) / zm.z   -- point visé, en coordonnées de la carte non zoomée
        local nz = math.max(1, math.min(4, zm.z * (d > 0 and 1.15 or 1 / 1.15)))
        local nx = math.min(0, math.max(w0 - nz * w0, cx - nz * lx))
        local ny = math.min(0, math.max(h0 - nz * h0, cy - nz * ly))
        zm.z, zm.x, zm.y = nz, nz > 1 and nx or 0, nz > 1 and ny or 0
        redraw()
    end)
    -- carte zoomée : clic maintenu (gauche ou droit) sur le fond pour la faire glisser
    clip:EnableMouse(true)
    clip:SetScript("OnMouseDown", function(self)
        local zm = a.zoom
        if zm.z <= 1 then return end
        local sc = self:GetEffectiveScale()
        local cx, cy = GetCursorPosition()
        local w0, h0 = self:GetWidth(), self:GetHeight()
        local x0, y0 = zm.x, zm.y
        self:SetScript("OnUpdate", function()
            local mx, my = GetCursorPosition()
            zm.x = math.min(0, math.max(w0 - zm.z * w0, x0 + (mx - cx) / sc))
            zm.y = math.min(0, math.max(h0 - zm.z * h0, y0 - (my - cy) / sc))
            a.map:ClearAllPoints()
            a.map:SetPoint("TOPLEFT", self, "TOPLEFT", zm.x, -zm.y)
        end)
    end)
    clip:SetScript("OnMouseUp", function(self) self:SetScript("OnUpdate", nil) end)
    clip:SetScript("OnHide", function(self) self:SetScript("OnUpdate", nil) end)
    -- textes libres au-dessus des formes
    a.overlay = CreateFrame("Frame", nil, map)
    a.overlay:SetAllPoints()
    a.overlay:SetFrameLevel(map:GetFrameLevel() + 3)
    a.lines, a.fills, a.icons, a.names, a.texts = {}, {}, {}, {}, {}
    return a
end

function ns:CreateAssigns(page)
    local a = {}
    self.asg = a
    a.page = page
    -- fond thématique : image du raid derrière toute la fenêtre (sous la barre du haut, comme le fond général)
    local lvl = page:GetFrameLevel()
    local f = self.frame
    a.win = f
    -- texture de la fenêtre elle-même, juste au-dessus de sa couleur de fond (comme le fond général) : sous les
    -- bandeaux, les pages et leurs cadres ; découpée à la fenêtre par ses coordonnées de texture
    local tex = f:CreateTexture(nil, "BACKGROUND", nil, 2)
    tex:Hide()
    local mask = f:CreateMaskTexture()
    a.img = { tex = tex, mask = mask, clip = tex }
    local bar = CreateFrame("Frame", nil, page)
    bar:SetPoint("TOPLEFT")
    bar:SetPoint("TOPRIGHT")
    bar:SetHeight(TAB_H)
    bar:SetFrameLevel(lvl + 3)
    -- fond de la barre : morceau flouté de l'image du raid (List/Tab Blurred) sous une couleur d'opacité réglable
    bar.glass = newImage(page, lvl + 1, f)
    bar.glass.clip:SetAllPoints(bar)
    bar.bg = ns.Tex(bar, C.head, "BORDER", 0.6)
    bar.bg:SetAllPoints()
    local bl = ns.Tex(bar, C.border, "ARTWORK")
    bl:SetPoint("BOTTOMLEFT") bl:SetPoint("BOTTOMRIGHT") bl:SetHeight(1)
    a.bar, a.tabs = bar, {}
    bar:EnableMouse(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart", function() if ns.assignFull then f:StartMoving() end end)
    bar:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        local point, _, _, x, y = f:GetPoint()
        ns.db.ui.point = { point, x, y }
    end)

    -- récap : un cadre par groupe ; au-dessus, icônes de rôle + nombre
    local recap = CreateFrame("Frame", nil, page)
    recap:SetPoint("TOPLEFT", PAD, -TAB_H - PAD)
    recap:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    a.recap = recap
    recap.roles = {}
    for i, ro in ipairs(ns.ROLE_ORDER) do
        local t = recap:CreateTexture(nil, "ARTWORK")
        t:SetTexture(ns.ROLE_ICON[ro])
        t:SetSize(27, 27)
        t:SetPoint("TOPLEFT", 2 + (i - 1) * 84, 0)
        local n = ns.Text(recap, 19, 700)
        n:SetPoint("LEFT", t, "RIGHT", 6, 0)
        recap.roles[ro] = n
    end
    recap.groups = {}
    for g = 1, 8 do
        local gf = CreateFrame("Frame", nil, recap)
        ns.Fill(gf, C.panel, 0.85)
        gf.title = ns.Text(gf, 9.5, 700, C.mute)
        gf.title:SetPoint("TOPLEFT", 8, -6)
        gf.rows = {}
        for k = 1, 5 do
            local r = CreateFrame("Frame", nil, gf)
            r:SetHeight(24)
            r:SetPoint("TOPLEFT", 6, -20 - (k - 1) * 26)
            r:SetPoint("TOPRIGHT", -6, -20 - (k - 1) * 26)
            r.bg = ns.Fill(r, C.slot)
            r.bar = ns.Tex(r, C.white, "ARTWORK")
            r.bar:SetPoint("TOPLEFT") r.bar:SetPoint("BOTTOMLEFT") r.bar:SetWidth(3)
            -- icône de spé à gauche du nom
            r.spec = r:CreateTexture(nil, "ARTWORK")
            r.spec:SetSize(18, 18)
            r.spec:SetPoint("LEFT", 8, 0)
            r.name = ns.Text(r, 12, 700)
            r.name:SetPoint("LEFT", 9, 0)
            r.cls = ns.Text(r, 11, 400, C.mute)
            r.specName = ns.Text(r, 11, 400, C.mute)
            r.role = r:CreateTexture(nil, "ARTWORK")
            r.role:SetSize(15, 15)
            r.roleName = ns.Text(r, 11, 400, C.mute)
            gf.rows[k] = r
        end
        recap.groups[g] = gf
    end

    -- onglet de boss : sous-onglets de phase + carte
    local boss = CreateFrame("Frame", nil, page)
    boss:SetPoint("TOPLEFT", PAD, -TAB_H - 8)
    boss:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    a.boss = boss
    boss.phases = {}
    ns.NewMapCanvas(boss, a, function() ns:RefreshAssigns() end)
    -- plein écran (en haut à droite de la carte) : seuls restent les onglets de boss, les phases et la carte
    local fb = CreateFrame("Button", nil, boss)
    fb:SetSize(28, 28)
    fb:SetPoint("TOPRIGHT", a.mapClip, "TOPRIGHT", -4, -4)
    fb:SetFrameLevel(a.mapClip:GetFrameLevel() + 20)
    ns.Fill(fb, C.input, 0.85)
    ns.Border(fb, C.border)
    fb.icon = fb:CreateTexture(nil, "OVERLAY")
    fb.icon:SetSize(18, 18)
    fb.icon:SetPoint("CENTER")
    fb.icon:SetVertexColor(0.91, 0.9, 0.88)
    fb:SetScript("OnClick", function() ns:SetAssignFull(not ns.assignFull) end)
    fb:SetScript("OnEnter", function(self)
        ns.SetBorderColor(self, C.hl)
        ns.TipOwner(self)
        GameTooltip:SetText(ns.L(ns.assignFull and "Exit full screen" or "Full screen map"), 1, 1, 1)
        GameTooltip:Show()
    end)
    fb:SetScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) GameTooltip:Hide() end)
    a.fullBtn = fb
    -- texte d'aide au-dessus de l'image du raid
    local ef = CreateFrame("Frame", nil, page)
    ef:SetAllPoints()
    ef:SetFrameLevel(page:GetFrameLevel() + 2)
    a.empty = ns.Text(ef, 12, 400, C.mute)
    a.empty:SetPoint("BOTTOM", 0, 24)
    a.empty:SetWidth(700)
    a.empty:SetWordWrap(true)
    a.empty:SetJustifyH("CENTER")
end

-- Pools d'éléments de la carte (réutilisés à chaque affichage)
local function getLine(a, i)
    local l = a.lines[i]
    if not l then
        l = a.map:CreateLine(nil, "ARTWORK")
        a.lines[i] = l
    end
    l:Show()
    return l
end

local function getFill(a, i)
    local t = a.fills[i]
    if not t then
        t = a.map:CreateTexture(nil, "BORDER")
        a.fills[i] = t
    end
    t:Show()
    return t
end

local function getIcon(a, i)
    local b = a.icons[i]
    if not b then
        b = CreateFrame("Button", nil, a.map)
        b.tex = b:CreateTexture(nil, "ARTWORK")
        b.tex:SetAllPoints()
        b:SetScript("OnEnter", function(self)
            if not self.tip or self.tip == "" then return end
            ns.TipOwner(self)
            GameTooltip:SetText(self.tip, 1, 1, 1)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", GameTooltip_Hide)
        a.icons[i] = b
    end
    b:Show()
    return b
end

-- Cadre d'un nom : une ligne cliquable par perso (liste si « Amount »), puis la note « Action »
local function getName(a, i)
    local b = a.names[i]
    if not b then
        b = CreateFrame("Frame", nil, a.map)
        b:SetFrameLevel(a.map:GetFrameLevel() + 5)
        ns.Fill(b, { 0.04, 0.043, 0.055 }, 0.72)
        ns.Border(b, C.white, 0.12)
        b.action = ns.Text(b, 10, 600, { 0.9, 0.9, 0.9 })
        b.action:SetPoint("BOTTOM", 0, 2)
        b.lines = {}
        a.names[i] = b
    end
    b:Show()
    return b
end

local function nameLine(b, k)
    local l = b.lines[k]
    if not l then
        l = CreateFrame("Button", nil, b)
        l.hl = ns.Fill(l, C.hl, 0.25)
        l.hl:Hide()
        l.label = ns.Text(l, 12, 700)
        l.label:SetPoint("CENTER")
        l.mark = ns.Tex(l, { 1, 0.82, 0.25 }, "ARTWORK", 0.8)
        l.mark:SetPoint("BOTTOMLEFT", l.label, "BOTTOMLEFT", 0, -1)
        l.mark:SetPoint("BOTTOMRIGHT", l.label, "BOTTOMRIGHT", 0, -1)
        l.mark:SetHeight(1)
        l:SetScript("OnClick", function(self) ns:OpenNamePicker(self, self.comp, self.key) end)
        l:SetScript("OnEnter", function(self)
            self.hl:Show()
            ns.TipOwner(self)
            GameTooltip:SetText(ns.L(self.manual and "Changed by hand · click to change" or "Click to change"), 1, 1, 1)
            GameTooltip:Show()
        end)
        l:SetScript("OnLeave", function(self) self.hl:Hide() GameTooltip:Hide() end)
        b.lines[k] = l
    end
    l:Show()
    return l
end

local function getText(a, i)
    local t = a.texts[i]
    if not t then
        t = ns.Text(a.overlay, 12, 700)
        t:SetShadowOffset(1, -1)
        t:SetShadowColor(0, 0, 0, 1)
        t:SetJustifyH("CENTER")
        a.texts[i] = t
    end
    t:Show()
    return t
end

local function drawName(a, b, r, it, s, comp)
    local fs = (it.size or 16) * s
    local lh, w = fs * 1.3, 0
    for k, e in ipairs(r.entries) do
        local l = nameLine(b, k)
        ns.SetFont(l.label, math.max(6, fs), 700)
        l.label:SetText(e.u and e.u.display or e.text)
        local c = e.u and ns.ClassColor(e.u.class) or C.mute
        l.label:SetTextColor(c[1], c[2], c[3])
        l.mark:SetShown(e.manual or false)
        l.comp, l.key, l.manual = comp, e.key, e.manual
        w = math.max(w, l.label:GetStringWidth())
    end
    for k = #r.entries + 1, #b.lines do b.lines[k]:Hide() end
    local ah = 0
    if it.action and it.action ~= "" then
        ns.SetFont(b.action, math.max(6, fs * 0.68), 600)
        b.action:SetText(it.action)
        b.action:Show()
        w = math.max(w, b.action:GetStringWidth())
        ah = fs * 0.68 * 1.4
    else
        b.action:Hide()
    end
    w = w + fs * 0.9
    for k = 1, #r.entries do
        local l = b.lines[k]
        l:SetSize(w - 4, lh)
        l:ClearAllPoints()
        l:SetPoint("TOP", 0, -2 - (k - 1) * lh)
    end
    b:SetSize(w, #r.entries * lh + ah + 4)
end

local function lineTo(a, n, x1, y1, x2, y2, w, col, s)
    n = n + 1
    local l = getLine(a, n)
    l:SetStartPoint("TOPLEFT", a.map, x1 * s, -y1 * s)
    l:SetEndPoint("TOPLEFT", a.map, x2 * s, -y2 * s)
    l:SetThickness(math.max(1, w * s))
    l:SetColorTexture(col[1], col[2], col[3], 1)
    return n
end

-- Formes : lignes, flèches (pointe en deux traits), cercles (polygone de 40 côtés), rectangles
local function drawShape(a, it, s, nl, nf)
    local p1, p2 = it.pts[1], it.pts[2]
    local col, w = rgb(it.color or "#ffffff"), it.w or 4
    if it.type == "draw" then
        -- dessin libre : un trait par segment
        for k = 2, #it.pts do
            local p, q = it.pts[k - 1], it.pts[k]
            nl = lineTo(a, nl, p[1], p[2], q[1], q[2], w, col, s)
        end
        return nl, nf
    end
    local x1, y1, x2, y2 = p1[1], p1[2], p2[1], p2[2]
    if it.type == "line" or it.type == "arrow" then
        nl = lineTo(a, nl, x1, y1, x2, y2, w, col, s)
        if it.type == "arrow" then
            local ang, hl = math.atan2(y2 - y1, x2 - x1), w * 3.2
            for _, d in ipairs({ 2.6, -2.6 }) do
                nl = lineTo(a, nl, x2, y2, x2 + hl * math.cos(ang + d), y2 + hl * math.sin(ang + d), w, col, s)
            end
        end
    elseif it.type == "circle" then
        local r = math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
        local N = 40
        for k = 0, N - 1 do
            local a1, a2 = 2 * math.pi * k / N, 2 * math.pi * (k + 1) / N
            nl = lineTo(a, nl, x1 + r * math.cos(a1), y1 + r * math.sin(a1), x1 + r * math.cos(a2), y1 + r * math.sin(a2), w, col, s)
        end
        nf = nf + 1
        local f = getFill(a, nf)
        f:SetTexture(MEDIA .. "disc")
        f:SetVertexColor(col[1], col[2], col[3], 0.12)
        f:ClearAllPoints()
        f:SetSize(2 * r * s, 2 * r * s)
        f:SetPoint("CENTER", a.map, "TOPLEFT", x1 * s, -y1 * s)
    else
        local l, t, r, b = math.min(x1, x2), math.min(y1, y2), math.max(x1, x2), math.max(y1, y2)
        nl = lineTo(a, nl, l, t, r, t, w, col, s)
        nl = lineTo(a, nl, r, t, r, b, w, col, s)
        nl = lineTo(a, nl, r, b, l, b, w, col, s)
        nl = lineTo(a, nl, l, b, l, t, w, col, s)
        nf = nf + 1
        local f = getFill(a, nf)
        f:SetColorTexture(col[1], col[2], col[3], 0.12)
        f:SetVertexColor(1, 1, 1, 1)
        f:ClearAllPoints()
        f:SetPoint("TOPLEFT", a.map, "TOPLEFT", l * s, -t * s)
        f:SetSize((r - l) * s, (b - t) * s)
    end
    return nl, nf
end

local function refreshRecap(self, a, comp)
    local raid = self:RaidByKey(comp.raid) or { size = 40 }
    local W = a.page:GetWidth() - 2 * PAD
    -- grille « carrée » : même nombre de groupes par ligne (2 pour 10 et 20, 4 pour 40)
    local cols = raid.size >= 40 and 4 or 2
    local gw = math.min(180, (W - (cols - 1) * 8) / cols)
    local roles = { Tank = 0, Healer = 0, Melee = 0, Ranged = 0 }
    for g, gf in ipairs(a.recap.groups) do
        if g <= raid.size / 5 then
            local col, row = (g - 1) % cols, math.floor((g - 1) / cols)
            gf:ClearAllPoints()
            gf:SetSize(gw, 20 + 5 * 26 + 4)
            gf:SetPoint("TOPLEFT", col * (gw + 8), -38 - row * (20 + 5 * 26 + 12))
            gf.title:SetText(strupper(ns.L("Group")) .. " " .. g)
            for k, r in ipairs(gf.rows) do
                local name = comp.c[(g - 1) * 5 + k]
                local show = name ~= nil
                r.cls:Hide() -- la couleur suffit : pas de nom de classe
                r.bar:SetShown(show) r.spec:SetShown(show) r.specName:Hide() r.role:SetShown(show) r.roleName:Hide() -- les icônes suffisent
                if show then
                    local u = self:CompUnit(comp, name)
                    local c = ns.ClassColor(u.class)
                    if roles[u.role or ""] then roles[u.role] = roles[u.role] + 1 end
                    r.bg:SetColorTexture(C.slot[1], C.slot[2], C.slot[3], 1)
                    r.bar:SetColorTexture(c[1], c[2], c[3])
                    -- polices réappliquées : noms et spés visibles dès le premier affichage
                    ns.SetFont(r.name, 12, 700)
                    r.name:SetTextColor(c[1], c[2], c[3])
                    local rw = gw - 12
                    -- spé (icône) | nom | rôle (icône, à droite)
                    r.name:ClearAllPoints()
                    r.name:SetPoint("LEFT", 31, 0)
                    ns.SetName(r.name, u.display, rw - 31 - 24)
                    r.role:ClearAllPoints()
                    r.role:SetPoint("RIGHT", -6, 0)
                    r.role:SetShown(u.role ~= nil)
                    if u.role then r.role:SetTexture(ns.ROLE_ICON[u.role]) end
                    local icon = self:SpecIcon(u)
                    r.spec:SetShown(icon ~= nil)
                    if icon then r.spec:SetTexture(icon) end
                else
                    r.bg:SetColorTexture(0, 0, 0, 0.35)
                    r.name:ClearAllPoints()
                    r.name:SetPoint("LEFT", 9, 0)
                    ns.ClearName(r.name)
                    r.name:SetText(ns.L("Empty"))
                    r.name:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
                end
            end
            gf:Show()
        else
            gf:Hide()
        end
    end
    for ro, n in pairs(a.recap.roles) do n:SetText(roles[ro]) end
end

local function refreshBoss(self, a, comp, tab)
    local phases = tab.phases or {}
    local ui = self.db.ui
    if not phases[ui.aPhase or 1] then ui.aPhase = 1 end
    local ph = phases[ui.aPhase] or { items = {} }
    -- sous-onglets de phase
    local x = 0
    for i, p in ipairs(phases) do
        local b = a.boss.phases[i]
        if not b then
            b = ns.Button(a.boss, "", 40, PH_H - 2)
            b:SetScript("OnClick", function(self) ns.db.ui.aPhase = self.index ns:Refresh() end)
            a.boss.phases[i] = b
        end
        b.index = i
        b.label:SetText(p.name or ("P" .. i))
        b:SetWidth(b.label:GetStringWidth() + 22)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", x, 0)
        ns.SetBorderColor(b, i == ui.aPhase and C.accent or C.border)
        b.label:SetTextColor(i == ui.aPhase and 1 or C.text[1], i == ui.aPhase and 1 or C.text[2], i == ui.aPhase and 1 or C.text[3])
        b:Show()
        x = x + b:GetWidth() + 3
    end
    for i = #phases + 1, #a.boss.phases do a.boss.phases[i]:Hide() end
    -- carte : la plus grande possible au ratio 1,6, sous les sous-onglets
    ns.DrawAssignMap(self, a, comp, tab, ui.aPhase, a.boss, a.boss:GetWidth(), a.boss:GetHeight() - PH_H - 4, -PH_H - 4)
end

-- Carte d'une phase (page Assigns et mini-carte) : a = cadres de la carte (newMapCanvas), dessinée dans
-- holder (W x H, décalée de top), la plus grande possible au ratio 1,6 ; zoom propre à chaque carte
function ns.DrawAssignMap(self, a, comp, tab, phIndex, holder, W, H, top)
    local phases = tab.phases or {}
    local ph = phases[phIndex or 1] or { items = {} }
    local mw = math.max(10, math.min(W, H * MAP_W / MAP_H))
    -- zoom (Ctrl + molette) : remis à 1 en changeant d'onglet ou de phase
    local zm = a.zoom
    local zkey = tostring(tab.id or tab.name) .. ":" .. (phIndex or 1)
    if zm.key ~= zkey then zm.key, zm.z, zm.x, zm.y = zkey, 1, 0, 0 end
    local s = mw * zm.z / MAP_W
    -- es = taille des icônes, noms et textes (« Assigns scale » de la mini-carte) ; positions et formes gardent s
    local es = s * (a.elemScale or 1)
    local clip, map = a.mapClip, a.map
    clip:ClearAllPoints()
    clip:SetSize(mw, mw * MAP_H / MAP_W)
    clip:SetPoint("TOP", holder, "TOP", 0, top or 0)
    map:ClearAllPoints()
    map:SetSize(mw * zm.z, mw * zm.z * MAP_H / MAP_W)
    map:SetPoint("TOPLEFT", clip, "TOPLEFT", zm.x, -zm.y)
    local img = ph.img or tab.img
    map.img:SetShown(img ~= nil)
    if img then map.img:SetTexture(MEDIA .. "assign\\" .. img) end
    -- éléments
    local members = compMembers(comp)
    local ovr = (self.db.assigns[comp.id] or {}).n or {}
    local bosses = {}
    for _, b in ipairs((self.db.presets[comp.raid] or {}).bosses or {}) do bosses[b.id] = b end
    -- noms résolus sur tout l'onglet : un nom peut exclure les résultats d'un nom d'une autre phase
    local all = {}
    for _, p in ipairs(phases) do for _, it in ipairs(p.items or {}) do all[#all + 1] = it end end
    -- sorts : source et cible = noms virtuels « <id>:src » / « <id>:dst » (mêmes critères qu'un nom)
    for i = 1, #all do
        local it = all[i]
        if it.type == "spell" then
            for _, sub in ipairs({ "src", "dst" }) do
                if it[sub] then all[#all + 1] = { id = it.id .. ":" .. sub, type = "name", crits = it[sub].crits, exclude = it[sub].exclude } end
            end
        end
    end
    local res = resolvePhase(all, members, ovr)
    local nl, nf, ni, nn, nt = 0, 0, 0, 0, 0
    for _, it in ipairs(ph.items or {}) do
        if it.pts then
            if #it.pts > 1 then nl, nf = drawShape(a, it, s, nl, nf) end
        elseif ICON_SIZE[it.type] then
            ni = ni + 1
            local b = getIcon(a, ni)
            local size = (it.size or ICON_SIZE[it.type]) * es
            b:SetSize(size, size)
            b:ClearAllPoints()
            b:SetPoint("CENTER", map, "TOPLEFT", it.x * s, -it.y * s)
            b.tex:SetTexCoord(0, 1, 0, 1)
            if it.type == "spell" then
                b.tex:SetTexture("Interface\\Icons\\" .. (it.icon or "inv_misc_questionmark"))
                b.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
                b.tip = it.name
                -- source à gauche de l'icône, cible à droite
                for _, side in ipairs({ { "src", "RIGHT", "LEFT", -4 }, { "dst", "LEFT", "RIGHT", 4 } }) do
                    local r = it[side[1]] and res[it.id .. ":" .. side[1]]
                    if r then
                        nn = nn + 1
                        local nb = getName(a, nn)
                        drawName(a, nb, r, { size = math.max(11, (it.size or ICON_SIZE.spell) * 0.42) }, es, comp)
                        nb:ClearAllPoints()
                        nb:SetPoint(side[2], b, side[3], side[4] * es * 2, 0)
                    end
                end
            elseif it.type == "role" then
                b.tex:SetTexture(ns.ROLE_ICON[it.role or "Tank"])
                b.tip = ns.L(it.role or "")
            elseif it.type == "mark" then
                b.tex:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. (it.mark or 8))
                b.tip = nil
            else
                local bd = bosses[it.boss] or {}
                b.tex:SetTexture(bd.img and (MEDIA .. "assign\\" .. bd.img) or (MEDIA .. "disc"))
                b.tip = bd.name
            end
        elseif it.type == "text" then
            nt = nt + 1
            local t = getText(a, nt)
            ns.SetFont(t, math.max(6, (it.size or 20) * es), 700)
            local c = rgb(it.color or "#ffffff")
            t:SetTextColor(c[1], c[2], c[3])
            t:SetText(it.text or "")
            t:ClearAllPoints()
            t:SetPoint("CENTER", map, "TOPLEFT", it.x * s, -it.y * s)
        elseif it.type == "name" then
            nn = nn + 1
            local b = getName(a, nn)
            drawName(a, b, res[it.id], it, es, comp)
            b:ClearAllPoints()
            b:SetPoint("CENTER", map, "TOPLEFT", it.x * s, -it.y * s)
        end
    end
    for i = nl + 1, #a.lines do a.lines[i]:Hide() end
    for i = nf + 1, #a.fills do a.fills[i]:Hide() end
    for i = ni + 1, #a.icons do a.icons[i]:Hide() end
    for i = nn + 1, #a.names do a.names[i]:Hide() end
    for i = nt + 1, #a.texts do a.texts[i]:Hide() end
end

-- Plein écran de la carte : la page couvre toute la fenêtre, barres du haut cachées
function ns:SetAssignFull(on)
    on = on and true or false
    self.assignFull = on
    local page = self.pages and self.pages.assigns
    if page then
        page:ClearAllPoints()
        page:SetPoint("TOPLEFT", 1, on and -1 or -ns.BODY_TOP)
        page:SetPoint("BOTTOMRIGHT", -1, 1)
    end
    if self.topBar then self.topBar:SetShown(not on) end
    if self.sub then self.sub:SetShown(not on) end
    self:Refresh()
end

function ns:RefreshAssigns()
    local a = self.asg
    if not a then return end
    -- page tout juste ouverte : redessinée une fois de plus (polices pas toujours prêtes : noms, spés vides sinon)
    if not a.page:IsVisible() then a.seen = nil
    elseif not a.seen then a.seen = true C_Timer.After(0.05, function() ns:RefreshAssigns() end) end
    local ui = self.db.ui
    local cur = self:AssignComp()
    local comp = cur and cur.comp
    local preset = comp and self.db.presets[comp.raid] or {}
    local tabs = preset.tabs or {}
    if (ui.aTab or 0) > #tabs then ui.aTab = 0 end
    -- image du raid ; barre des sous-onglets : opacité réglable, image floutée derrière si le verre de la liste est actif
    local raid = comp and self:RaidByKey(comp.raid)
    local full = raid and (raid.full or raid.bg)
    local file = full and (MEDIA .. full)
    local aspect = raid and (raid.fullAspect or raid.aspect)
    local fade = raid and raid.fade and (MEDIA .. raid.fade)
    local ap, W, H = self:Look(), a.win:GetWidth(), a.win:GetHeight()
    local g = ap.listGlass or 0
    local view = raid and raid.view
    -- fond thématique (option « Assign's Thematic Background ») : sinon le fond général reste
    if not ap.assignNoBg then file = nil end
    placeTheme(a.img, a.win, file, W, H, aspect, ap.bgAlpha or 0.6, fade, view)
    -- version floutée sous la barre, mélangée selon le réglage de flou
    placeImage(a.bar.glass, g > 0 and file and (file .. "_blur") or nil, W, H, aspect, (ap.bgAlpha or 0.6) * g, fade, view)
    a.bar.bg:SetColorTexture(C.head[1], C.head[2], C.head[3], ap.tabsAlpha or 1)
    -- onglets : Récap + un par boss
    local x = 6
    for i = 0, comp and #tabs or -1 do
        local b = a.tabs[i + 1]
        if not b then
            b = tabButton(a.bar, function(self) ns.db.ui.aTab, ns.db.ui.aPhase = self.index, 1 ns:Refresh() end)
            a.tabs[i + 1] = b
        end
        b.index = i
        b.label:SetText(i == 0 and ns.L("Recap") or (tabs[i].name or "?"))
        b:SetWidth(b.label:GetStringWidth() + 28)
        b:ClearAllPoints()
        b:SetPoint("BOTTOMLEFT", x, 0)
        local on = i == (ui.aTab or 0)
        ns.ShowSelection(b, on)
        local c = on and C.white or C.mute
        b.label:SetTextColor(c[1], c[2], c[3])
        b:Show()
        x = x + b:GetWidth() + 2
    end
    for i = (comp and #tabs or -1) + 2, #a.tabs do a.tabs[i]:Hide() end
    local tab = comp and (ui.aTab or 0) > 0 and tabs[ui.aTab]
    a.recap:SetShown(comp ~= nil and not tab)
    a.boss:SetShown(tab and true or false)
    a.empty:SetShown(not comp or (not tab and #tabs == 0))
    if not comp then
        a.empty:SetText(ns.L("No comp yet: create one in Raid Comps."))
        return
    end
    -- plein écran : seulement sur un onglet de boss
    if self.assignFull and not tab then self.assignFull = false self:SetAssignFull(false) return end
    a.fullBtn.icon:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. (self.assignFull and "fullscreen_out" or "fullscreen_in"))
    if tab then refreshBoss(self, a, comp, tab) else refreshRecap(self, a, comp) end
    a.empty:SetText(ns.L("No tab yet: create the boss tabs of this raid in Guild Tool (Assigns, Config)."))
end
