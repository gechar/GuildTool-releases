-- GuildTool : fenêtre principale (onglets Calendar / Raid Comps / Members), glisser-déposer,
-- barre de critères de tri animée, fenêtre de copie
local _, ns = ...
local C = ns.C

ns.BODY_TOP = ns.TOP_H + ns.TABS_H + 1

---------------------------------------------------------------------------
-- Glisser-déposer des persos (fantôme qui suit le curseur)
---------------------------------------------------------------------------
local function followCursor(self)
    local x, y = GetCursorPosition()
    local s = self:GetEffectiveScale()
    self:ClearAllPoints()
    self:SetPoint("LEFT", UIParent, "BOTTOMLEFT", x / s + 8, y / s)
end

function ns:BeginDrag(name, fromComp, fromSlot)
    local g = self.ghost
    if not g then
        g = CreateFrame("Frame", nil, UIParent)
        g:SetFrameStrata("TOOLTIP")
        g:SetSize(150, 22)
        ns.Fill(g, C.slot, 0.95)
        ns.Border(g, C.accent)
        g.bar = ns.Tex(g, C.white, "ARTWORK")
        g.bar:SetPoint("TOPLEFT") g.bar:SetPoint("BOTTOMLEFT") g.bar:SetWidth(3)
        g.label = ns.Text(g, 12, 600)
        g.label:SetPoint("LEFT", 9, 0)
        g:SetScript("OnUpdate", followCursor)
        self.ghost = g
    end
    local u = self:UnitFor(name)
    local c = ns.ClassColor(u.class)
    g:SetScale(self.frame:GetScale())
    g.bar:SetColorTexture(c[1], c[2], c[3])
    g.label:SetText(u.display)
    g.label:SetTextColor(c[1], c[2], c[3])
    g:Show()
    self.drag = { name = name, comp = fromComp, slot = fromSlot }
    GameTooltip:Hide()
end

function ns:EndDrag()
    local d = self.drag
    self.drag = nil
    if self.ghost then self.ghost:Hide() end
    if not d then return end
    self.lastDrag = GetTime()
    local target = self:SlotUnderMouse()
    if target then
        self:DropOnSlot(d.name, d.comp, d.slot, target.comp, target.slot)
    elseif d.comp and self.side and self.side:IsMouseOver() then
        self:RemoveAt(d.comp, d.slot)
    end
    self:Refresh()
end

-- Un clic juste après un glisser est ignoré
function ns:JustDragged() return self.lastDrag and GetTime() - self.lastDrag < 0.15 end

---------------------------------------------------------------------------
-- Barre de critères de tri : le critère glissé suit la souris, une ligne lumineuse montre où il ira
---------------------------------------------------------------------------
local SORT_LABEL = { spec = "Spec", class = "Class", player = "Player", alpha = "A-Z", level = "Level", raids = "Raids", loots = "Loots", discord = "Discord", attendance = "Attendance" }

local function chipIndexAt(bar, order, dragKey)
    local x = GetCursorPosition() / bar:GetEffectiveScale()
    local idx, rest = 1, {}
    for _, k in ipairs(order) do if k ~= dragKey then rest[#rest + 1] = k end end
    for i, k in ipairs(rest) do
        local chip = bar.chips[k]
        if x > chip:GetLeft() + chip:GetWidth() / 2 then idx = i + 1 end
    end
    return idx, rest
end

function ns.ChipBar(parent, getOrder, onChange)
    local bar = CreateFrame("Frame", nil, parent)
    bar:SetSize(250, 22)
    bar.chips, bar.seps = {}, {}
    for key, label in pairs(SORT_LABEL) do
        local b = CreateFrame("Button", nil, bar)
        b:SetHeight(22)
        ns.Fill(b, C.input)
        ns.Border(b, C.border)
        local grip = ns.Text(b, 9, 700, C.mute)
        grip:SetPoint("LEFT", 5, 0)
        grip:SetText(":::")
        b.label = ns.Text(b, 11, 500)
        b.label:SetPoint("LEFT", grip, "RIGHT", 3, 0)
        b.label:SetText(ns.L(label))
        b:SetWidth(b.label:GetStringWidth() + 24)
        b.key = key
        b:RegisterForDrag("LeftButton")
        b:SetScript("OnDragStart", function(self) bar:StartDrag(self) end)
        b:SetScript("OnDragStop", function() bar:StopDrag() end)
        b:Hide()
        bar.chips[key] = b
    end
    for i = 1, 6 do
        local s = ns.Text(bar, 10, 600, C.mute)
        s:SetText(">")
        bar.seps[i] = s
    end
    -- ligne d'insertion lumineuse
    local line = bar:CreateTexture(nil, "OVERLAY")
    line:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 1)
    line:SetSize(2, 26)
    local glow = bar:CreateTexture(nil, "OVERLAY")
    glow:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.35)
    glow:SetBlendMode("ADD")
    glow:SetSize(8, 30)
    glow:SetPoint("CENTER", line)
    line:Hide() glow:Hide()
    -- critère « fantôme » qui suit la souris
    local ghost = CreateFrame("Frame", nil, UIParent)
    ghost:SetFrameStrata("TOOLTIP")
    ghost:SetHeight(22)
    ns.Fill(ghost, C.hover, 0.95)
    ns.Border(ghost, C.accent)
    ghost.label = ns.Text(ghost, 11, 600, C.white)
    ghost.label:SetPoint("CENTER")
    ghost:SetScript("OnUpdate", followCursor)
    ghost:Hide()

    -- seuls les critères de cette barre sont affichés (Members a en plus « Level »)
    function bar:Layout()
        local x, order = 0, getOrder()
        for _, chip in pairs(self.chips) do chip:Hide() end
        for i, key in ipairs(order) do
            local chip = self.chips[key]
            chip:ClearAllPoints()
            chip:SetPoint("LEFT", self, "LEFT", x, 0)
            chip:Show()
            x = x + chip:GetWidth()
            if i < #order then
                self.seps[i]:ClearAllPoints()
                self.seps[i]:SetPoint("LEFT", chip, "RIGHT", 3, 0)
                self.seps[i]:Show()
                x = x + 11
            end
        end
        for i = math.max(1, #order), #self.seps do self.seps[i]:Hide() end
    end

    function bar:StartDrag(chip)
        self.dragKey = chip.key
        chip:SetAlpha(0.3)
        ghost:SetScale(self:GetEffectiveScale() / UIParent:GetEffectiveScale())
        ghost.label:SetText(ns.L(SORT_LABEL[chip.key]))
        ghost:SetWidth(chip:GetWidth())
        ghost:Show()
        line:Show() glow:Show()
        self:SetScript("OnUpdate", function()
            local idx, rest = chipIndexAt(self, getOrder(), self.dragKey)
            line:ClearAllPoints()
            if rest[idx] then
                line:SetPoint("RIGHT", self.chips[rest[idx]], "LEFT", -2, 0)
            else
                line:SetPoint("LEFT", self.chips[rest[#rest]], "RIGHT", 2, 0)
            end
        end)
    end

    function bar:StopDrag()
        local key = self.dragKey
        self.dragKey = nil
        self:SetScript("OnUpdate", nil)
        ghost:Hide() line:Hide() glow:Hide()
        self.chips[key]:SetAlpha(1)
        local order = getOrder()
        local idx, rest = chipIndexAt(self, order, key)
        table.insert(rest, idx, key)
        for i, k in ipairs(rest) do order[i] = k end
        self:Layout()
        onChange()
    end

    return bar
end

---------------------------------------------------------------------------
-- Fenêtre de copie (WoW ne peut pas écrire dans le presse-papier)
---------------------------------------------------------------------------
function ns:ShowCopy(title, text)
    local f = self.copyFrame
    if not f then
        f = CreateFrame("Frame", nil, UIParent)
        f:SetSize(460, 170)
        f:SetFrameStrata("DIALOG")
        f:SetPoint("CENTER")
        f:EnableMouse(true)
        ns.Fill(f, C.bg)
        ns.Border(f, C.accent)
        f.title = ns.Text(f, 13, 700, C.white)
        f.title:SetPoint("TOPLEFT", 12, -10)
        local hint = ns.Text(f, 11, 400, C.mute)
        hint:SetPoint("TOPLEFT", f.title, "BOTTOMLEFT", 0, -3)
        hint:SetText(ns.L("Ctrl+C, then paste it in Discord. Esc to close."))
        local close = ns.IconButton(f, "×", 20)
        close:SetPoint("TOPRIGHT", -6, -6)
        close:SetScript("OnClick", function() f:Hide() end)
        local box = CreateFrame("Frame", nil, f)
        box:SetPoint("TOPLEFT", 12, -48)
        box:SetPoint("BOTTOMRIGHT", -12, 12)
        ns.Fill(box, C.input)
        ns.Border(box, C.border)
        local sf = CreateFrame("ScrollFrame", nil, box, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 6, -6)
        sf:SetPoint("BOTTOMRIGHT", -26, 6)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFont(ns.FONT[400], 12, "")
        eb:SetWidth(400)
        eb:SetScript("OnEscapePressed", function() f:Hide() end)
        eb:SetScript("OnTextChanged", function(self, user) if user then self:SetText(f.text) self:HighlightText() end end)
        sf:SetScrollChild(eb)
        f.eb = eb
        self.copyFrame = f
    end
    f:SetScale(self.frame:GetScale())
    f.title:SetText(title)
    f.text = text
    f.eb:SetText(text)
    f:Show()
    f.eb:SetFocus()
    f.eb:HighlightText()
end

---------------------------------------------------------------------------
-- Fenêtre principale
---------------------------------------------------------------------------
local TAB_ICON = "Interface\\AddOns\\GuildTool\\media\\"
local PAGES = { { "calendar", "Calendar", TAB_ICON .. "tab_calendar" }, { "comps", "Compos", TAB_ICON .. "tab_comps" },
                { "assigns", "Assigns", TAB_ICON .. "assign_icon" }, { "members", "Members", TAB_ICON .. "tab_members" },
                { "loots", "Loots", TAB_ICON .. "helmet" } }

-- Sélecteur de phase : jusqu'à 5 numéros, celui du milieu est la phase choisie ;
-- perspective : les voisins rétrécissent et s'estompent ; molette = phase précédente / suivante
local WHEEL = { [0] = { 22, 1 }, [1] = { 15, 0.5 }, [2] = { 11, 0.25 } }
-- get / set : phase lue / choisie (par défaut la phase de la guilde) ; all : « All » après la dernière phase
function ns:CreatePhaseWheel(parent, get, set, all)
    get = get or function() return ns.db.ui.phase end
    set = set or function(p) ns:SetPhase(p) end
    local function count() return #ns.PHASES + (all and 1 or 0) end
    local w = CreateFrame("Button", nil, parent)
    w:SetSize(106, 40)
    w.hl = ns.Fill(w, C.white, 0.05)
    w.hl:Hide()
    -- « PHASE » au-dessus, centré sur le numéro choisi
    local lbl = ns.Text(w, 8.5, 700, C.mute)
    lbl:SetPoint("TOP", 0, -2)
    lbl:SetText(strupper(ns.L("Phase")))
    w.nums = {}
    local xs = { 8, 26, 53, 80, 98 }
    for i = 1, 5 do
        local b = CreateFrame("Button", nil, w)
        b:SetSize(i == 3 and 26 or 18, 26)
        b:SetPoint("CENTER", w, "LEFT", xs[i], -5)
        b.label = ns.Text(b, 12, 700, C.white)
        b.label:SetPoint("CENTER")
        b:SetScript("OnClick", function(self) set(self.phase) end)
        b:SetScript("OnEnter", function(self) w.hl:Show() if self.d > 0 then self.label:SetAlpha(0.8) end end)
        b:SetScript("OnLeave", function(self) w.hl:Hide() self.label:SetAlpha(WHEEL[self.d][2]) end)
        b:EnableMouseWheel(false)
        w.nums[i] = b
    end
    w:SetScript("OnEnter", function(self)
        self.hl:Show()
        ns.TipOwner(self)
        GameTooltip:SetText(ns.L("Phase · scroll or click to change"), 1, 1, 1)
        GameTooltip:Show()
    end)
    w:SetScript("OnLeave", function(self) if not self:IsMouseOver() then self.hl:Hide() end GameTooltip:Hide() end)
    w:EnableMouseWheel(true)
    w:SetScript("OnMouseWheel", function(_, d) set(math.max(1, math.min(count(), get() + (d > 0 and -1 or 1)))) end)
    function w:Update()
        local cur = get()
        for i, b in ipairs(self.nums) do
            local p, d = cur + i - 3, math.abs(i - 3)
            b.phase, b.d = p, d
            if p >= 1 and p <= count() then
                ns.SetFont(b.label, WHEEL[d][1] * (ns.PHASES[p] and 1 or 0.7), 700)
                b.label:SetText(ns.PHASES[p] and p or ns.L("All"))
                b.label:SetAlpha(WHEEL[d][2])
                b:Show()
            else
                b:Hide()
            end
        end
    end
    return w
end

-- Phase de la guilde : admins seulement ; envoyée tout de suite à la guilde, reprise par l'exe (guildPhase / T)
function ns:SetPhase(i, fromGuild)
    i = math.max(1, math.min(#ns.PHASES, i))
    if i == self.db.ui.phase then return end
    if not fromGuild and not self:MayPhase() then
        UIErrorsFrame:AddMessage(ns.L("Only the admins can change the phase of the guild."), 1, 0.42, 0.42)
        return
    end
    self.db.ui.phase, self.db.guildPhase, self.db.guildPhaseT = i, i, time()
    self.addState = nil
    if not fromGuild and IsInGuild() then
        C_ChatInfo.SendAddonMessage(ns.COMM_PREFIX, ("Q\t%s\t%d"):format(self:MyName() or UnitName("player"), i), "GUILD")
    end
    self:Refresh()
end

-- Flèches de navigation : triangles pleins comme dans l'exe (media/tri.tga, pointe en bas, tourné d'un quart de tour)
local function navButton(parent, glyph, onClick)
    local b = ns.IconButton(parent, "", 24)
    local t = ns.Triangle(b, glyph == "<" and "left" or "right", 16)
    t:SetPoint("CENTER")
    t:SetVertexColor(C.mute[1], C.mute[2], C.mute[3])
    b:HookScript("OnEnter", function() t:SetVertexColor(1, 1, 1) end)
    b:HookScript("OnLeave", function() t:SetVertexColor(C.mute[1], C.mute[2], C.mute[3]) end)
    b:SetScript("OnClick", onClick)
    return b
end

function ns:CreateFrame()
    ns.ApplyPalette(self.db.appearance.base)
    ns.ApplyHighlight(self.db.appearance.hl)
    local f = CreateFrame("Frame", "GuildToolFrame", UIParent)
    f:SetSize(ns.W, ns.H)
    f:SetFrameStrata("HIGH")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:SetScale(self.db.ui.scale or 1)
    local p = self.db.ui.point
    if p then f:SetPoint(p[1], UIParent, p[1], p[2], p[3]) else f:SetPoint("CENTER") end
    ns.Fill(f, C.bg)
    ns.Border(f, { 0.204, 0.212, 0.243 })
    tinsert(UISpecialFrames, "GuildToolFrame")
    self.frame = f
    self:CreateWindowBackground(f)

    -- barre du haut (sert aussi de poignée de déplacement)
    local top = CreateFrame("Frame", nil, f)
    top:SetPoint("TOPLEFT", 1, -1)
    top:SetPoint("TOPRIGHT", -1, -1)
    top:SetHeight(ns.TOP_H)
    ns.Fill(top, C.head, 0.7)
    self.topBar = top
    top:EnableMouse(true)
    top:RegisterForDrag("LeftButton")
    top:SetScript("OnDragStart", function() f:StartMoving() end)
    top:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        local point, _, _, x, y = f:GetPoint()
        self.db.ui.point = { point, x, y }
    end)
    local line = ns.Tex(top, C.border, "ARTWORK")
    line:SetPoint("BOTTOMLEFT") line:SetPoint("BOTTOMRIGHT") line:SetHeight(1)

    local title = ns.Text(top, 15, 700, C.white)
    title:SetPoint("LEFT", 14, 0)
    -- nom de la guilde choisie dans l'exe (renommable par un officier)
    title:SetText(self.db.guildTitle or "Guild Tool")
    if title:GetStringWidth() > 180 then title:SetWidth(180) end


    -- onglets de page
    self.pageTabs = {}
    local prev = title
    for i, pg in ipairs(PAGES) do
        local b = CreateFrame("Button", nil, top)
        b:SetHeight(ns.TOP_H - 1)
        ns.Selection(b, nil, C.hl)
        b.label = ns.Text(b, 12.5, 600)
        b.label:SetText(ns.L(pg[2]))
        if pg[3] then
            -- icône devant le nom, de la couleur du texte
            b.icon = b:CreateTexture(nil, "ARTWORK")
            b.icon:SetSize(14, 14)
            b.icon:SetTexture(pg[3])
            b.label:SetPoint("CENTER", 10, 0)
            b.icon:SetPoint("RIGHT", b.label, "LEFT", -6, 0)
            b:SetWidth(b.label:GetStringWidth() + 52)
        else
            b.label:SetPoint("CENTER")
            b:SetWidth(b.label:GetStringWidth() + 32)
        end
        if i == 1 then b:SetPoint("BOTTOM", top, "BOTTOM", 0, 0) b:SetPoint("LEFT", title, "RIGHT", 24, 0) else b:SetPoint("BOTTOMLEFT", prev, "BOTTOMRIGHT", 2, 0) end
        b.key, b.title = pg[1], pg[2]
        b:SetScript("OnClick", function(btn) ns:ShowPage(btn.key) end)
        -- survol : nom et icône en blanc (comme dans l'appli), couleur normale en sortant
        b:SetScript("OnEnter", function(btn)
            btn.label:SetTextColor(1, 1, 1)
            if btn.icon then btn.icon:SetVertexColor(1, 1, 1) end
        end)
        b:SetScript("OnLeave", function(btn)
            local c = btn.key == ns.db.ui.page and C.white or C.mute
            btn.label:SetTextColor(c[1], c[2], c[3])
            if btn.icon then btn.icon:SetVertexColor(c[1], c[2], c[3]) end
        end)
        self.pageTabs[pg[1]] = b
        prev = b
    end

    -- niveau minimum des persos pris en compte (60 en jeu normal, plus bas pendant la bêta)
    self.levelDD = ns.Dropdown(top, ns.L("Min lvl"), 112, function()
        local items = {}
        for _, lvl in ipairs({ 60, 55, 50, 40, 30, 20, 10, 1 }) do
            items[#items + 1] = { text = ns.L("Level {0}+", lvl), checked = lvl == self:MinLevel(), func = function() self.db.ui.minLevel = lvl self:Invalidate() end }
        end
        return items
    end)
    self.levelDD:SetPoint("LEFT", prev, "RIGHT", 14, 0)

    local close = ns.IconButton(top, "×", 24, nil)
    close.label:SetFont(ns.FONT[600], 14, "")
    close:SetPoint("RIGHT", -10, 0)
    close:SetScript("OnClick", function() f:Hide() end)

    -- échelle de la fenêtre : Ctrl + molette sur son fond
    ns.WheelScale(f, function() return self.db.ui.scale or 1 end, function(v, pt)
        self.db.ui.scale = v
        if pt then self.db.ui.point = pt end
    end)
    f.onCap = function() ns:Refresh() end

    self:CreateSettings(f)
    self.settingsBtn:SetPoint("RIGHT", close, "LEFT", -10, 0)
    self.syncText = ns.Text(top, 11, 400, C.mute)
    self.syncText:SetPoint("RIGHT", self.reloadBtn or self.settingsBtn, "LEFT", -10, 0)
    self.syncDot = ns.Tex(top, C.ok, "ARTWORK")
    self.syncDot:SetSize(7, 7)
    self.syncDot:SetPoint("RIGHT", self.syncText, "LEFT", -6, 0)

    -- sous-barre : navigation semaine (Raid Comps) ou mois (Calendar), infos (Members)
    local sub = CreateFrame("Frame", nil, f)
    sub:SetPoint("TOPLEFT", top, "BOTTOMLEFT")
    sub:SetPoint("TOPRIGHT", top, "BOTTOMRIGHT")
    sub:SetHeight(ns.TABS_H)
    ns.Fill(sub, C.head)
    local sl = ns.Tex(sub, C.border, "ARTWORK")
    sl:SetPoint("BOTTOMLEFT") sl:SetPoint("BOTTOMRIGHT") sl:SetHeight(1)
    sub.prev = navButton(sub, "<", function() ns:Navigate(-1) end)
    sub.prev:SetPoint("LEFT", 12, 0)
    sub.title = ns.Text(sub, 14, 700, C.white)
    -- mesure de texte (alignement des tirets de la liste des lockouts)
    sub.measure = ns.Text(sub, 14, 700)
    sub.measure:Hide()
    sub.title:SetPoint("LEFT", sub.prev, "RIGHT", 10, 0)
    sub.next = navButton(sub, ">", function() ns:Navigate(1) end)
    sub.next:SetPoint("LEFT", sub.title, "RIGHT", 10, 0)
    sub.today = ns.Button(sub, ns.L("Today"), 80, 22)
    sub.today:SetPoint("LEFT", sub.next, "RIGHT", 12, 0)
    sub.today:SetScript("OnClick", function() ns:Navigate(0) end)
    -- Absence : passe en sélection de jours ; Confirm enregistre les jours choisis
    sub.absence = ns.Button(sub, ns.L("Absence"), 78, 22)
    sub.absence:SetPoint("LEFT", sub.today, "RIGHT", 8, 0)
    sub.absence:SetScript("OnClick", function() ns:ToggleAbsenceMode() end)
    -- garde sa couleur rouge / verte au survol (le bouton standard repasse au gris)
    sub.absence:SetScript("OnEnter", function(b) ns.SetBorderColor(b, C.white, 0.7) end)
    sub.absence:SetScript("OnLeave", function() ns:RefreshTop() end)
    -- Assigns : « Edit Comp » (onglet Récap) ouvre la compo dans Raid Comps, « Next Raid » = raid suivant
    sub.editComp = ns.Button(sub, ns.L("Edit Comp"), 96, 22)
    sub.editComp:SetPoint("LEFT", sub.today, "RIGHT", 8, 0)
    sub.editComp:SetScript("OnClick", function() ns:EditAssignComp() end)
    sub.info = ns.Text(sub, 11, 400, C.mute)
    sub.info:SetPoint("RIGHT", -14, 0)
    -- clic sur le titre (mois / lockout / compo) : ouvre ou ferme son sélecteur (refermé aussi quand la souris
    -- s'en éloigne) ; molette sur le titre : élément précédent / suivant
    sub.titleBtn = CreateFrame("Button", nil, sub)
    sub.titleBtn:SetPoint("TOPLEFT", sub.title, "TOPLEFT", -6, 6)
    sub.titleBtn:SetPoint("BOTTOMRIGHT", sub.title, "BOTTOMRIGHT", 6, -6)
    local function pickerShown()
        local page = ns.db.ui.page
        if page == "assigns" or page == "loots" then return ns.titlePick and ns.titlePick:IsShown() end
        if page == "comps" then return ns.lockList and ns.lockList:IsShown() end
        return ns.picker and ns.picker:IsShown()
    end
    local function showPicker()
        local page = ns.db.ui.page
        if page == "assigns" then ns:ShowAssignCompMenu()
        elseif page == "loots" then ns:ShowLootWeekMenu()
        elseif page ~= "members" then ns:ShowMonthPicker() end
    end
    sub.titleBtn:SetScript("OnClick", function()
        if pickerShown() then
            if ns.menu then ns.menu:Hide() end
            if ns.lockList then ns.lockList:Hide() end
            if ns.titlePick then ns.titlePick:Hide() end
            if ns.picker then ns.picker:Hide() end
        else
            ns.pickHistory = false   -- le passé de nouveau caché à chaque ouverture
            showPicker()
        end
    end)
    sub.titleBtn:EnableMouseWheel(true)
    sub.titleBtn:SetScript("OnMouseWheel", function(_, d)
        if ns.db.ui.page == "members" then return end
        -- jamais avant la semaine actuelle (lockouts de Raid Comps, compos d'Assigns)
        if d > 0 then
            local thisWeek = ns:WeekStart(time())
            if ns.db.ui.page == "comps" and ns:CurrentWeek() - ns.WEEK < thisWeek then return end
            if ns.db.ui.page == "assigns" then
                local _, list, i = ns:AssignComp()
                if not i or i <= 1 or list[i - 1].ws < thisWeek then return end
            end
        end
        local open = pickerShown()
        -- Compos et Loots : la molette saute les lockouts sans event (sans loot)
        if ns.db.ui.page == "comps" or ns.db.ui.page == "loots" then ns:WheelWeek(d > 0 and -1 or 1)
        else ns:Navigate(d > 0 and -1 or 1) end
        if open then showPicker() end   -- liste ouverte : suit l'élément affiché
    end)
    self.sub = sub
    -- engrenage : apparence de l'onglet affiché
    self:CreateTabLook()
    -- sélecteur de phase : au milieu de la barre de Raid Comps
    self.phaseWheel = self:CreatePhaseWheel(sub)
    self.phaseWheel:SetHeight(ns.TABS_H)
    self.phaseWheel:SetPoint("CENTER", sub, "CENTER", 0, 0)

    -- pages
    self.pages = {}
    for _, pg in ipairs(PAGES) do
        local page = CreateFrame("Frame", nil, f)
        page:SetPoint("TOPLEFT", 1, -ns.BODY_TOP)
        page:SetPoint("BOTTOMRIGHT", -1, 1)
        page:Hide()
        self.pages[pg[1]] = page
    end
    self:CreateCalendar(self.pages.calendar)
    self:CreateComps(self.pages.comps)
    self:CreateSide(self.pages.comps)
    self:CreateMembers(self.pages.members)
    self:CreateAssigns(self.pages.assigns)
    self:CreateLootsPage(self.pages.loots)
    self:CreateMonthPicker(sub.titleBtn)
    self:CreateLockoutList(sub.titleBtn)
end

function ns:ShowPage(key)
    if self.assignFull and key ~= "assigns" then self.assignFull = false self:SetAssignFull(false) end
    self.db.ui.page = key
    self.membersShown = key == "members"
    self:Refresh()
end

-- < / > / Today selon la page
function ns:Navigate(dir)
    local page = self.db.ui.page
    if page == "calendar" then
        -- calendrier continu : défile jusqu'au mois précédent / suivant / actuel (d'octobre 2026 à 12 mois)
        if dir == 0 then self.calJump = tonumber(date("%Y%m"))
        else
            local y, m = self:CalendarMonth()
            m = m + dir
            if m < 1 then y, m = y - 1, 12 elseif m > 12 then y, m = y + 1, 1 end
            self.calJump = ns.CalClamp(y * 100 + m)
        end
    elseif page == "comps" then
        self:SetWeek(dir == 0 and time() or self:CurrentWeek() + dir * ns.WEEK)
    elseif page == "assigns" then
        self:AssignNav(dir)
    elseif page == "loots" then
        -- lockouts du passé jusqu'à l'actuel ; après l'actuel : « All » (pas de filtre)
        local thisWeek, w = self:WeekStart(time()), self.lootWeek
        if dir == 0 then self.lootWeek = thisWeek
        elseif dir < 0 then self.lootWeek = w and w - ns.WEEK or thisWeek
        elseif w then self.lootWeek = w + ns.WEEK <= thisWeek and w + ns.WEEK or nil end
    end
    self:Refresh()
end

-- Molette sur le titre (Compos, Loots) : lockout précédent / suivant qui a des events (des loots) ; Compos : jamais
-- avant l'actuel ni après le dernier event ; Loots : jamais dans le futur, « All » après l'actuel
function ns:WheelWeek(dir)
    local thisWeek, has = self:WeekStart(time()), {}
    if self.db.ui.page == "comps" then
        local last = thisWeek
        for _, ev in ipairs(self.db.events) do
            if ev.start then
                local w = self:WeekStart(ev.start)
                has[w] = true
                if w > last then last = w end
            end
        end
        local ws = self:CurrentWeek() + dir * ns.WEEK
        while ws >= thisWeek and ws <= last and not has[ws] do ws = ws + dir * ns.WEEK end
        if ws < thisWeek or ws > last then return end
        self:SetWeek(ws)
    else
        local oldest = thisWeek
        for _, r in ipairs(self:LootRecords()) do
            local w = self:WeekStart(r.t or 0)
            if w <= thisWeek then has[w] = true if w < oldest then oldest = w end end
        end
        local w = self.lootWeek
        if dir < 0 then
            w = w and w - ns.WEEK or thisWeek
            while w >= oldest and not has[w] do w = w - ns.WEEK end
            if w < oldest then return end
            self.lootWeek = w
        elseif w then
            w = w + ns.WEEK
            while w <= thisWeek and not has[w] do w = w + ns.WEEK end
            self.lootWeek = w <= thisWeek and w or nil
        end
    end
    self:Refresh()
end

function ns:RefreshTop()
    local L = ns.L
    self.phaseWheel:Update()
    self.phaseWheel:SetShown(self.db.ui.page == "comps")
    self.phaseWheel:SetAlpha(self:MayPhase() and 1 or 0.7)
    self.levelDD.value:SetText(self:MinLevel() .. "+")
    for key, b in pairs(self.pageTabs) do
        local on = key == self.db.ui.page
        ns.ShowSelection(b, on)
        local c = on and C.white or C.mute
        -- nom réécrit à chaque fois (police pas toujours prête à l'ouverture : onglet vide sinon)
        ns.SetFont(b.label, 12.5, 600)
        b.label:SetText(ns.L(b.title))
        b.label:SetTextColor(c[1], c[2], c[3])
        if b.icon then b.icon:SetVertexColor(c[1], c[2], c[3]) end
    end
    if self.db.importT then
        self.syncText:SetText(L("Bridge data {0}", date("%d/%m %H:%M", self.db.importT)))
        self.syncDot:SetColorTexture(C.ok[1], C.ok[2], C.ok[3])
    else
        self.syncText:SetText(L("No bridge data yet: run Guild Tool"))
        self.syncDot:SetColorTexture(0.9, 0.7, 0.2)
    end
    local sub, page = self.sub, self.db.ui.page
    local nav = page ~= "members"
    if self.lootsTabs then
        for _, x in ipairs({ self.lootsWheel, self.lootsTabs }) do x:SetShown(page == "loots") end
        self:LootSearchUpdate()
    end
    -- Loots : pas de « Today » (le lockout se choisit par les flèches ou la liste)
    sub.prev:SetShown(nav) sub.next:SetShown(nav) sub.today:SetShown(nav and page ~= "loots")
    sub.absence:SetShown(page == "calendar")
    local editable = page == "assigns" and self:AssignComp() ~= nil
    sub.editComp:SetShown(editable)
    local col = self.absMode and { 0.25, 0.75, 0.45 } or { 0.85, 0.27, 0.27 }
    sub.absence.bg:SetColorTexture(col[1], col[2], col[3], 0.22)
    ns.SetBorderColor(sub.absence, col, 0.6)
    sub.absence.label:SetText(L(self.absMode and "Confirm" or "Absence"))
    sub.absence.label:SetTextColor(col[1] + 0.3, col[2] + 0.3, col[3] + 0.3)
    if page == "comps" then
        local ws = self:CurrentWeek()
        sub.title:SetText(self:WeekLabel(ws))
        local n = #self:EventsInWeek(ws)
        sub.info:SetText(n == 0 and L("No event this lockout week") or L("{0} event(s) this lockout week · click a comp's background to select it", n))
    elseif page == "calendar" then
        local y, m = self:CalendarMonth()
        sub.title:SetText(ns.MonthLong(m) .. " " .. y)
        sub.info:SetText(L("Shading = lockouts (Wednesday to Tuesday) · click the month to jump · click a day to plan its lockout"))
    elseif page == "assigns" then
        local a = self:AssignComp()
        sub.title:SetText(a and a.label or L("No comp"))
        sub.info:SetText(L("Click the title to choose a comp (wheel: next / previous) · click a name to change it"))
    elseif page == "loots" then
        -- lockout des loots (« All » = tous)
        sub.title:SetText(self.lootWeek and self:WeekLabel(self.lootWeek) or L("All lockouts"))
        sub.info:SetText("")
    else
        sub.title:ClearAllPoints()
        sub.title:SetPoint("LEFT", 14, 0)
        sub.title:SetText(L("Guild members"))
        sub.info:SetText(L("Professions and gear come from members who use Guild Tool · loot from RCLootCouncil"))
    end
    if nav then
        sub.title:ClearAllPoints()
        sub.title:SetPoint("LEFT", sub.prev, "RIGHT", 10, 0)
    end
end

function ns:Refresh()
    if not (self.frame and self.frame:IsShown()) then return end
    local page = self.db.ui.page
    for key, frame in pairs(self.pages) do frame:SetShown(key == page) end
    self:ApplyAppearance()
    self:RefreshTop()
    if page == "calendar" then
        self:RefreshCalendar()
    elseif page == "comps" then
        self:RefreshComps()
        self:RefreshList()
    elseif page == "assigns" then
        self:RefreshAssigns()
    elseif page == "loots" then
        self:RefreshLootsPage()
    else
        self:RefreshMembers()
    end
end

function ns:Toggle()
    if not self.db then return end
    -- une fenêtre qui vient d'être créée est « visible » : sans ce test le premier /rp la refermait aussitôt
    local created = not self.frame
    if created then self:CreateFrame() end
    if not created and self.frame:IsShown() then self.frame:Hide() return end
    self:RequestRoster()
    self.membersShown = self.db.ui.page == "members"
    self.frame:Show()
    self:Refresh()
end
