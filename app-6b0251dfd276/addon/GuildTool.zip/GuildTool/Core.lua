-- GuildTool : cœur (SavedVariables, roster de guilde, import du pont, semaines de lockout, compos)
local ADDON, ns = ...

local WEEK, DAY = 7 * 24 * 3600, 24 * 3600
ns.WEEK, ns.DAY = WEEK, DAY

local DEFAULT_UI = {
    phase = #ns.PHASES, page = "comps", tab = "signed", scale = 1,
    order = { "spec", "class", "player", "alpha" },
    membersOrder = { "spec", "discord", "alpha", "level", "attendance" },
    lootOrder = { "raids", "loots", "class", "alpha", "discord" }, lootRole = "Tank",
}

local function lower(s) return s and strlower(s) or nil end
ns.lower = lower

-- Premier « mot » de la note de guilde = tag Discord unique (un @ en tête est ignoré)
-- Un pseudo Discord fait au moins 2 caractères et contient une lettre ("0" ou "-" ne sont pas des tags)
function ns.TagFromNote(note)
    if type(note) ~= "string" then return nil end
    local tag = note:match("^%s*@?(%S+)")
    if not tag or #tag < 2 or not tag:find("%a") then return nil end
    return lower(tag)
end

---------------------------------------------------------------------------
-- SavedVariables
---------------------------------------------------------------------------
function ns:InitDB()
    GuildToolDB = GuildToolDB or {}
    local db = GuildToolDB
    db.v = 2
    db.roster = db.roster or {}
    db.specs = db.specs or {}
    db.events = db.events or {}
    db.weeks = db.weeks or {}
    db.links = db.links or {}
    db.chars = db.chars or {}
    db.items = db.items or {}
    db.absences = db.absences or {} -- jours d'absence { ["AAAAMMJJ"] = true } (pas encore exploités)
    db.absT = db.absT or 0
    -- apparence partagée avec l'exe (la plus récente gagne) ; bg = image de fond de fenêtre fournie par l'exe
    db.appearance = db.appearance or { compAlpha = 0.3, bgAlpha = 0.6, bg = false, t = 0 }
    db.appearance.lockA = db.appearance.lockA or "#0e0f12"
    db.appearance.lockB = db.appearance.lockB or "#34363e"
    db.appearance.base = db.appearance.base or "#1e1f24"
    db.appearance.listGlass = db.appearance.listGlass or 0
    db.appearance.lang = db.appearance.lang or "en"
    db.appearance.assignAlpha = db.appearance.assignAlpha or 0.5
    -- Members : fond des arbres de talents, image de fond des persos
    db.appearance.talentBg = db.appearance.talentBg or 0.35
    db.appearance.charImgA = db.appearance.charImgA or 0.5
    db.appearance.detAlpha = db.appearance.detAlpha or 0.22
    db.appearance.detBlur = db.appearance.detBlur or 0
    db.appearance.membersAlpha = db.appearance.membersAlpha or 0.55
    db.appearance.membersBlur = db.appearance.membersBlur or 0.6
    db.appearance.tabsAlpha = db.appearance.tabsAlpha or 1
    db.appearance.hl = db.appearance.hl or "#6f7cff"
    db.appearance.hl2 = db.appearance.hl2 or "#3fc7eb"
    -- assigns : noms changés à la main par compo { [compId] = { t, n = { [itemId] = perso } } }
    db.assigns = db.assigns or {}
    db.myChars = db.myChars or {}
    db.presets = db.presets or {}
    db.ui = db.ui or {}
    for k, v in pairs(DEFAULT_UI) do
        if db.ui[k] == nil then db.ui[k] = type(v) == "table" and CopyTable(v) or v end
    end
    -- nouveaux critères de tri ajoutés en fin de liste
    if not tContains(db.ui.membersOrder, "level") then tinsert(db.ui.membersOrder, "level") end
    if not tContains(db.ui.lootOrder, "discord") then tinsert(db.ui.lootOrder, "discord") end
    if not tContains(db.ui.membersOrder, "discord") then tinsert(db.ui.membersOrder, "discord") end
    -- Members : « Player » = « Discord », « Class » compris dans « Spec » (classe puis spé) ; « Attendance » ajouté
    for i = #db.ui.membersOrder, 1, -1 do
        local k = db.ui.membersOrder[i]
        if k == "player" or k == "class" then table.remove(db.ui.membersOrder, i) end
    end
    if not tContains(db.ui.membersOrder, "spec") then tinsert(db.ui.membersOrder, 1, "spec") end
    if not tContains(db.ui.membersOrder, "attendance") then tinsert(db.ui.membersOrder, "attendance") end
    self.db = db
    self:MergeImport()
    -- phases éditées dans l'exe (sinon celles de Data.lua)
    if type(db.phases) == "table" and #db.phases > 0 then ns.PHASES = db.phases end
    if db.ui.phase > #ns.PHASES then db.ui.phase = #ns.PHASES end
    self:MigrateComps()
    self:NormalizeWeeks()
    self:DropEmptyComps()
end

-- Import.lua est réécrit par l'exe ; il est relu à chaque /reload
function ns:MergeImport()
    local imp, db = GuildToolImport, self.db
    if type(imp) ~= "table" or not imp.t then return end
    if imp.t > (db.importT or 0) then
        db.importT = imp.t
        db.events = imp.events or {}
        db.importSpecs = imp.specs or {}
        db.charSpecs = imp.charSpecs or {}
        db.specIcons = imp.specIcons or {}
    end
    local a = imp.appearance
    if type(a) == "table" then
        if (a.t or 0) > (db.appearance.t or 0) then
            db.appearance.compAlpha, db.appearance.bgAlpha, db.appearance.t = a.compAlpha, a.bgAlpha, a.t
            db.appearance.lockA, db.appearance.lockB = a.lockA or db.appearance.lockA, a.lockB or db.appearance.lockB
            db.appearance.base = a.base or db.appearance.base
            db.appearance.listGlass = a.listGlass or db.appearance.listGlass
            db.appearance.lang = a.lang or db.appearance.lang
            db.appearance.hlGrad = a.hlGrad and true or false
            for _, k in ipairs({ "assignAlpha", "tabsAlpha", "hl", "hl2", "talentBg", "charImgA", "detAlpha", "detBlur", "membersAlpha", "membersBlur", "charImgOff",
                                 "charImgBlur", "lootAlpha", "lootBlur", "buffBorder", "buffInt", "buffIconInt", "buffSizeR", "buffSizeG" }) do
                if a[k] ~= nil then db.appearance[k] = a[k] end
            end
            -- réglages propres à un onglet (fond, barre d'onglets)
            if type(a.tabs) == "table" then db.appearance.tabs = CopyTable(a.tabs) end
            db.appearance.assignNoBg = a.assignNoBg and true or false
        end
        db.appearance.bg = a.bg and true or false -- l'image n'existe que si l'exe l'a écrite
    end
    if type(imp.absences) == "table" and (imp.absT or 0) > (db.absT or 0) then
        db.absences = {}
        for _, d in ipairs(imp.absences) do db.absences[tostring(d)] = true end
        db.absT = imp.absT
    end
    -- état du compte dans l'exe : nom de la guilde, lecture seule (pas officier), persos cachés
    db.guildTitle = imp.guildTitle
    db.readOnly = imp.readOnly and true or false
    db.hidden = type(imp.hidden) == "table" and imp.hidden or {}
    -- tags Discord trouvés par l'exe (perso partagé par un joueur connecté : prioritaires sur la note de guilde),
    -- persos des officiers (seuls à pouvoir modifier compos et assigns, et dont on accepte les envois en jeu)
    db.charTags = type(imp.charTags) == "table" and imp.charTags or {}
    db.officers = type(imp.officers) == "table" and imp.officers or {}
    db.slash = imp.slash
    -- calendrier : notes de la guilde, salon Main Raid (ses events en premier), icônes des réactions (media de l'exe)
    db.notes = type(imp.notes) == "table" and imp.notes or {}
    db.mainChannel, db.mainArchive, db.commuArchive = imp.mainChannel, imp.mainArchive, imp.commuArchive    db.myDiscord = imp.myDiscord
    -- loot (/tlc) : attributions connues de la guilde par objet (les miennes plus récentes sont ajoutées en jeu)
    db.lootCounts, db.lootT = type(imp.lootCounts) == "table" and imp.lootCounts or {}, imp.lootT or 0
    -- loots vus sur chaque boss, base de la guilde (ceux relevés ici : db.bossLoot, lus par l'exe)
    db.bossLootDB = type(imp.bossLoot) == "table" and imp.bossLoot or {}
    -- modifications à la main des tables de loot (base de la guilde) : les miennes déjà reçues par l'exe sont oubliées
    db.bossLootEd = type(imp.bossLootEd) == "table" and imp.bossLootEd or {}
    for k, e in pairs(db.bossLootEdits or {}) do
        local g = db.bossLootEd[k]
        if g and (g.t or 0) >= (e.t or 0) then db.bossLootEdits[k] = nil end
    end
    -- spé principale de chaque perso (Event Class Raid-Helper, sinon talents) : icône dans les listes de /tlc
    db.mainSpecs = type(imp.mainSpecs) == "table" and imp.mainSpecs or {}
    -- wishlists connues (les miennes + celles partagées par la guilde) et date des miennes côté exe
    db.wishlistsImp = type(imp.wishlists) == "table" and imp.wishlists or {}
    db.wishlistT = type(imp.wishlistT) == "table" and imp.wishlistT or {}
    -- archives de wishlist retirées par un officier ; vues de Loots cachées aux membres (réglages de la guilde)
    db.wishArchHideImp = type(imp.wishArchHide) == "table" and imp.wishArchHide or {}
    db.guildFlags = type(imp.guildFlags) == "table" and imp.guildFlags or {}
    -- Bislist : EP des objets de raid par spé, meilleur set (infobulle, BisTip.lua)
    db.bisTip = type(imp.bisTip) == "table" and imp.bisTip or {}
    db.bisEP = type(imp.bisEP) == "table" and imp.bisEP or {}
    -- images de fond des persos (choisies dans l'appli par leur joueur) : textures media/chars
    db.charImages = type(imp.charImages) == "table" and imp.charImages or {}
    -- réglages par défaut publiés par la guilde : apparence de /two, apparence de /tlc
    db.guildAppearance = type(imp.guildAppearance) == "table" and imp.guildAppearance or nil
    db.guildLootAp = type(imp.guildLootAp) == "table" and imp.guildLootAp or nil
    -- onglet Loots : attributions de la base de la guilde
    db.lootDB = type(imp.lootDB) == "table" and imp.lootDB or {}
    db.statusIcons = type(imp.statusIcons) == "table" and imp.statusIcons or {}
    -- phase de la guilde (choisie par un admin) : imposée, sauf si un admin l'a changée en jeu depuis
    db.admins = type(imp.admins) == "table" and imp.admins or {}
    db.isAdmin = imp.isAdmin and true or false
    -- droits d'officier temporaires : membres de la guilde (officiers seulement) ; demandes faites ici déjà
    -- envoyées par l'exe retirées de la file (les autres restent « en attente »)
    db.guildMembers = type(imp.guildMembers) == "table" and imp.guildMembers or {}
    local gd = type(imp.grantDone) == "table" and imp.grantDone or {}
    local keep = {}
    for _, q in ipairs(db.grantQueue or {}) do
        if type(q) == "table" and not gd[("%s:%d:%d"):format(q.id, q.on and 1 or 0, q.t or 0)] and (q.t or 0) > time() - 30 * 86400 then
            keep[#keep + 1] = q
        end
    end
    db.grantQueue = keep
    if type(imp.phase) == "number" and (imp.phaseT or 0) >= (db.guildPhaseT or 0) then
        db.ui.phase, db.guildPhase, db.guildPhaseT = imp.phase, imp.phase, imp.phaseT or 0
    end
    self:ApplyCharTags()
    -- phases, raids et onglets d'assigns : édités seulement dans l'exe
    if imp.phases ~= nil then db.phases = imp.phases end
    if type(imp.presets) == "table" then db.presets = imp.presets end
    -- noms d'assigns changés à la main : le plus récent gagne, compo par compo
    for id, a in pairs(imp.assigns or {}) do
        local cur = db.assigns[id]
        if type(a) == "table" and (not cur or (a.t or 0) > (cur.t or 0)) then db.assigns[id] = CopyTable(a) end
    end
    -- semaines : la version la plus récente gagne, semaine par semaine
    for key, week in pairs(imp.weeks or {}) do
        local cur = db.weeks[key]
        if type(week) == "table" and (not cur or (week.t or 0) > (cur.t or 0)) then
            db.weeks[key] = CopyTable(week)
        end
    end
end

-- v1 : compos rangées par event puis par raid -> v2 : par semaine de lockout
function ns:MigrateComps()
    local db = self.db
    if not db.comps then return end
    for eventId, raids in pairs(db.comps) do
        local ev = self:EventById(eventId)
        if ev and ev.start and type(raids) == "table" then
            local week = self:GetWeek(self:WeekStart(ev.start), true)
            for raidKey, entry in pairs(raids) do
                for _, slots in ipairs(entry.c or {}) do
                    if next(slots) then
                        week.comps[#week.comps + 1] = { id = self:NewId(), raid = raidKey, event = eventId, c = slots }
                    end
                end
            end
            week.t = math.max(week.t or 0, 1)
        end
    end
    db.comps = nil
end

function ns:NewId()
    self.idCounter = (self.idCounter or 0) + 1
    return ("%x%04x%02x"):format(time(), math.random(0, 0xffff), self.idCounter % 256)
end

---------------------------------------------------------------------------
-- Roster de guilde
---------------------------------------------------------------------------
function ns:RequestRoster()
    if not IsInGuild() then return end
    -- sans « Show offline », le roster Classic ne contient que les membres connectés
    if SetGuildRosterShowOffline and GetGuildRosterShowOffline and not GetGuildRosterShowOffline() then
        SetGuildRosterShowOffline(true)
    end
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() elseif GuildRoster then GuildRoster() end
end

function ns:ScanRoster()
    local n = GetNumGuildMembers()
    if not n or n == 0 then return end
    local roster = {}
    for i = 1, n do
        local name, _, _, level, _, _, note, _, _, _, class = GetGuildRosterInfo(i)
        if name then
            name = name:match("^([^%-]+)") or name
            -- note brute gardée pour le diagnostic (roster) ; tag de l'exe en priorité sur celui de la note
            roster[name] = { c = class, l = level, tag = (self.db.charTags or {})[name] or ns.TagFromNote(note),
                             note = note ~= "" and note or nil }
        end
    end
    self.db.roster = roster
    self.db.guild = GetGuildInfo("player")
    self.db.rosterT = time()
    self:Invalidate()
end

-- Tags Discord de la liaison automatique de l'exe appliqués au roster connu
function ns:ApplyCharTags()
    for name, tag in pairs(self.db.charTags or {}) do
        local r = self.db.roster[name]
        if r and type(tag) == "string" then r.tag = lower(tag) end
    end
    self:Invalidate()
end

-- Officier (ou droits temporaires donnés dans l'exe) : perso de la liste envoyée par l'exe
function ns:IsOfficer(name)
    name = name and (name:match("^([^%-]+)") or name)
    return name ~= nil and self.db.officers ~= nil and self.db.officers[name] == true
end

-- Admin du serveur Discord (liste des persos envoyée par l'exe, ou compte de l'exe) ; sans guilde : tout est local
function ns:IsAdmin(name)
    name = name and (name:match("^([^%-]+)") or name)
    return name ~= nil and self.db.admins ~= nil and self.db.admins[name] == true
end

function ns:MayPhase()
    if self.db.isAdmin then return true end
    if next(self.db.admins or {}) or next(self.db.officers or {}) then return self:IsAdmin(self:MyName()) end
    return not self.db.readOnly
end

-- Commande de l'addon (choisie par un admin dans l'exe), « /gt » par défaut
function ns:Slash()
    local s = self.db and self.db.slash
    if type(s) == "string" and s:match("^/%a%w+$") then return strlower(s) end
    return "/gt"
end

---------------------------------------------------------------------------
-- Semaines de lockout (reset hebdo mercredi 5h)
---------------------------------------------------------------------------
-- Reset hebdo de la guilde : mercredi 5h (heure locale), lockout du mercredi au mardi.
-- (le reset donné par le jeu est un mardi sur ce serveur : on ne l'utilise pas)
function ns:ResetAnchor()
    if not self.anchor then self.anchor = time({ year = 2026, month = 1, day = 7, hour = 5, min = 0, sec = 0 }) end
    return self.anchor
end

function ns:WeekOf(ts) return math.floor((ts - self:ResetAnchor()) / WEEK) end
function ns:WeekStart(ts) return self:ResetAnchor() + self:WeekOf(ts) * WEEK end

-- Semaines créées avec un autre jour de reset : leurs compos rejoignent la semaine de leur event
function ns:NormalizeWeeks()
    local db, bad = self.db, {}
    for key in pairs(db.weeks) do
        local ws = tonumber(key)
        if not ws or self:WeekStart(ws + 1) ~= ws then bad[#bad + 1] = key end
    end
    for _, key in ipairs(bad) do
        local week = db.weeks[key]
        db.weeks[key] = nil
        local ws = tonumber(key) or time()
        for _, comp in ipairs(week.comps or {}) do
            local ev = comp.event and self:EventById(comp.event)
            local target = self:GetWeek(self:WeekStart(ev and ev.start or ws + 3 * DAY), true)
            target.comps[#target.comps + 1] = comp
            target.t = math.max(target.t or 0, week.t or 0, 1)
        end
    end
    if db.ui.week then db.ui.week = self:WeekStart(db.ui.week + 3 * DAY) end
end

-- « 28 Oct - 3 Nov » : du reset à la veille du reset suivant
function ns:WeekParts(ws)
    local function d(t) return tonumber(date("%d", t)) .. " " .. ns.MonthShort(tonumber(date("%m", t))) end
    return d(ws), d(ws + WEEK - DAY)
end

function ns:WeekLabel(ws)
    local a, b = self:WeekParts(ws)
    return a .. " - " .. b
end

function ns:CurrentWeek()
    local ws = self.db.ui.week
    if not ws then ws = self:WeekStart(time()) end
    return ws
end

function ns:SetWeek(ws)
    self.db.ui.week = self:WeekStart(ws + 3600)
    self.db.ui.selected = nil
    self.addState = nil
    self:Invalidate()
end

function ns:EventById(id)
    for _, ev in ipairs(self.db.events) do
        if ev.id == id then return ev end
    end
end

function ns:EventsInWeek(ws)
    local list = {}
    for _, ev in ipairs(self.db.events) do
        if ev.start and ev.start >= ws and ev.start < ws + WEEK then list[#list + 1] = ev end
    end
    table.sort(list, function(a, b) return a.start < b.start end)
    return list
end

function ns:EventLabel(ev)
    if not ev then return ns.L("No event") end
    if not ev.start then return ev.title or "?" end
    return date("%a %d %b %H:%M", ev.start) .. "  ·  " .. (ev.title or "")
end

-- Officiers seulement (admins, rôle officier, droits temporaires donnés dans l'exe) : liste des persos envoyée
-- par l'exe ; sans liste (exe pas connecté à une guilde), l'état du compte dans l'exe décide
function ns:MayEdit()
    if next(self.db.officers or {}) then return self:IsOfficer(self:MyName()) end
    return not self.db.readOnly
end

-- Officier (liste de l'exe, droits temporaires compris) ou GM ; sans liste : rang de guilde 0 ou 1
function ns:IsOfficerOrGM()
    if self:IsOfficer(self:MyName()) or (IsGuildLeader and IsGuildLeader()) then return true end
    if next(self.db.officers or {}) then return false end
    local _, _, rank = GetGuildInfo("player")
    return rank ~= nil and rank <= 1
end

function ns:CanEdit()
    if self:MayEdit() then return true end
    UIErrorsFrame:AddMessage(ns.L("Only the officers can change the comps, assigns and raids of the guild."), 1, 0.42, 0.42)
    return false
end

-- Event communautaire (salon raid-commu) créé par moi (compte Discord connecté dans l'exe)
function ns:IsMyCommuEvent(ev)
    return ev and ev.commu and self.db.myDiscord and ev.lid == self.db.myDiscord and true or false
end
-- Compo communautaire : modifiable par les officiers et par le créateur de son event
function ns:MayEditComp(comp)
    if self:MayEdit() then return true end
    return comp and comp.commu and self.db.myDiscord and comp.owner == self.db.myDiscord and true or false
end
function ns:CanEditComp(comp)
    if self:MayEditComp(comp) then return true end
    return self:CanEdit()
end

-- Persos joués sur ce compte (liste « Mes personnages » de l'exe, pour les cacher ou les partager)
-- Nom du perso tel que le roster de guilde l'écrit : sur Forever, « Sundance Pal » (prénom + nom) alors que
-- UnitName ne rend que « Sundance ». Une fois trouvé, ce qui a été rangé sous le prénom seul y est déplacé.
function ns:MyName()
    local short = UnitName("player")
    if not short or short == UNKNOWNOBJECT then return nil end
    if self.myFull then return self.myFull end
    local _, class = UnitClass("player")
    for i = 1, (IsInGuild() and GetNumGuildMembers() or 0) do
        local name, _, _, _, _, _, _, _, _, _, cls = GetGuildRosterInfo(i)
        name = name and (name:match("^([^%-]+)") or name)
        if name and cls == class and (name == short or name:match("^(%S+)") == short) then
            self.myFull = name
            if name ~= short then
                for _, k in ipairs({ "chars", "myChars", "hidden" }) do
                    local t = self.db[k]
                    if t then
                        if t[short] ~= nil and t[name] == nil then t[name] = t[short] end
                        t[short] = nil
                    end
                end
            end
            return name
        end
    end
    return short
end

function ns:RecordMyChar()
    local name, level = self:MyName(), UnitLevel("player")
    local _, class = UnitClass("player")
    if not name then return end
    self.db.myChars[name] = { c = class, l = level, t = time() }
end

-- Perso caché dans l'exe : ses infos ne sont jamais envoyées à la guilde
function ns:IsHidden(name) return self.db.hidden and self.db.hidden[name] and true or false end

-- réglage propre à un onglet : clé « t.<onglet>.<clé> » (appearance.tabs[onglet][clé]) ; sans valeur propre, le
-- réglage général s'applique
local function tabKey(key)
    local page, k = tostring(key):match("^t%.(%a+)%.(%w+)$")
    return page, k
end
ns.TabKey = tabKey
-- valeur enregistrée telle quelle (nil pour un réglage d'onglet pas encore propre à l'onglet)
function ns:RawAppearance(key)
    local a = self.db.appearance
    local page, k = tabKey(key)
    if page then return type(a.tabs) == "table" and type(a.tabs[page]) == "table" and a.tabs[page][k] or nil end
    return a[key]
end
-- valeur affichée (réglage d'onglet : sinon le réglage général)
function ns:AGet(key, def)
    local v = self:RawAppearance(key)
    if v == nil then
        local _, k = tabKey(key)
        if k then v = self.db.appearance[k] end
    end
    if v == nil then v = def end
    return v
end
-- apparence vue depuis l'onglet affiché : ses réglages propres (fond, barre d'onglets), sinon les généraux
function ns:Look()
    local a = self.db.appearance or {}
    local own = type(a.tabs) == "table" and a.tabs[self.db.ui.page or ""]
    if type(own) ~= "table" or not next(own) then return a end
    return setmetatable({}, { __index = function(_, k) local v = own[k] if v ~= nil then return v end return a[k] end })
end

function ns:SetAppearance(key, value)
    local page, k = tabKey(key)
    if page then
        local a = self.db.appearance
        a.tabs = type(a.tabs) == "table" and a.tabs or {}
        a.tabs[page] = a.tabs[page] or {}
        a.tabs[page][k] = value
        a.t = time()
        self:LogPending(ns.L("Appearance") .. " · " .. tostring(key))
        return
    end
    self.db.appearance[key] = value
    self.db.appearance.t = time()
    self:LogPending(ns.L("Appearance") .. " · " .. tostring(key))
end

function ns:EventTitle(id)
    local ev = id and self:EventById(id)
    return ev and (ev.title or "?") or ns.L("No event")
end

function ns:GetPhase() return ns.PHASES[self.db.ui.phase] or ns.PHASES[#ns.PHASES] end

function ns:RaidByKey(key)
    for _, phase in ipairs(ns.PHASES) do
        for _, raid in ipairs(phase.raids) do
            if raid.key == key then return raid end
        end
    end
end

function ns:NewComp(raidKey, eventId)
    return { id = self:NewId(), raid = raidKey, event = eventId, c = {} }
end

-- Semaine (vide au départ : les compos s'ajoutent avec la tuile « + »)
function ns:GetWeek(ws)
    local key = tostring(ws or self:CurrentWeek())
    local week = self.db.weeks[key]
    if not week then
        week = { t = 0, comps = {} }
        self.db.weeks[key] = week
    end
    return week
end

-- Une fois : supprime les compos sans aucun joueur (avant, chaque semaine en créait 2 par défaut)
function ns:DropEmptyComps()
    if self.db.emptyCompsDropped then return end
    for _, week in pairs(self.db.weeks) do
        local kept = {}
        for _, comp in ipairs(week.comps or {}) do
            if comp.c and next(comp.c) then kept[#kept + 1] = comp end
        end
        if #kept ~= #(week.comps or {}) then
            week.comps = kept
            week.t = time()
        end
    end
    self.db.emptyCompsDropped = true
end

-- Journaux : modifications faites ici depuis la connexion (écrites dans les SavedVariables au /reload ou à la
-- déconnexion : « Pending Updates ») et reçues des autres joueurs par le chat addon (« Addon Updates »)
ns.pendingLog, ns.addonLog = {}, {}
local function logTo(list, text, from)
    local last = list[#list]
    if last and last.text == text and last.from == from then
        last.t, last.n = time(), (last.n or 1) + 1
    else
        list[#list + 1] = { t = time(), text = text, from = from }
    end
    if ns.RefreshLogButtons then ns:RefreshLogButtons() end
end
function ns:LogPending(text) logTo(ns.pendingLog, text) end
function ns:LogReceived(from, text) logTo(ns.addonLog, text, from) end

-- Semaine modifiée : datée (l'exe garde la plus récente) et envoyée tout de suite aux autres joueurs de la guilde
function ns:Touch(week)
    week = week or self:GetWeek()
    week.t = time()
    for key, w in pairs(self.db.weeks) do
        if w == week then
            if self.QueueShare then self:QueueShare("W", key) end
            local ws = tonumber(key)
            self:LogPending(ns.L("Raid comps") .. " · " .. (ws and self.WeekLabel and self:WeekLabel(ws) or key))
            break
        end
    end
end

function ns:CompById(id)
    if not id then return nil end
    for i, comp in ipairs(self:GetWeek().comps) do
        if comp.id == id then return comp, i end
    end
end

function ns:Selected() return self:CompById(self.db.ui.selected) end

function ns:CompLabel(comp, i)
    local raid = self:RaidByKey(comp.raid)
    return (raid and raid.short or comp.raid) .. " #" .. (i or select(2, self:CompById(comp.id)) or "?")
end

-- Un event est « fait » quand au moins une de ses compos est validée (V)
function ns:EventDone(ev)
    if not ev.start then return false end
    local week = self.db.weeks[tostring(self:WeekStart(ev.start))]
    for _, comp in ipairs(week and week.comps or {}) do
        if comp.event == ev.id and comp.valid then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- Liaison inscription -> joueur -> perso
---------------------------------------------------------------------------
-- Forme compacte pour comparer noms et tags : minuscules, sans ponctuation ni espaces ("badboi." == "Badboi")
local function squash(s) return s and (strlower(s):gsub("[%p%s]", "")) or "" end
ns.Squash = squash

function ns:MinLevel() return self.db.ui.minLevel or ns.MAX_LEVEL end

-- Index du roster : tags et persos taggés (nom complet et prénom, les noms Forever ont un nom de famille)
function ns:RosterIndex()
    if self.rindex then return self.rindex end
    local tags, names = {}, {}
    for name, r in pairs(self.db.roster) do
        if r.tag then
            tags[squash(r.tag)] = r.tag
            names[squash(name)] = names[squash(name)] or name
            local first = name:match("^(%S+)")
            if first then names[squash(first)] = names[squash(first)] or name end
        end
    end
    self.rindex = { tags = tags, names = names }
    return self.rindex
end

-- Tag Discord d'une inscription : lien manuel > tag trouvé par l'exe > nom affiché proche d'un tag ou d'un perso
function ns:ResolveTag(s)
    local link = s.uid and self.db.links[s.uid]
    if link then return link end
    if s.tag then return lower(s.tag) end
    local idx, roster = self:RosterIndex(), self.db.roster
    local tokens = { squash(s.n) }
    for t in (s.n or ""):gmatch("[^%p%s]+") do tokens[#tokens + 1] = squash(t) end
    for _, t in ipairs(tokens) do
        if idx.tags[t] then return idx.tags[t] end
    end
    local any
    for _, t in ipairs(tokens) do
        local name = idx.names[t]
        if name then
            if roster[name].c == s.c then return roster[name].tag end
            any = any or roster[name].tag
        end
    end
    return any
end

-- Perso d'un joueur : même tag, même classe, niveau mini, nom proche du nom d'inscription en priorité
function ns:FindChar(tag, class, signupName)
    local best, bestLevel
    local hint = squash(signupName)
    for name, r in pairs(self.db.roster) do
        if r.tag == tag and r.c == class and (r.l or 0) >= self:MinLevel() then
            local first = squash(name:match("^(%S+)") or name)
            if first ~= "" and hint:find(first, 1, true) then return name end
            if not best or (r.l or 0) > bestLevel then best, bestLevel = name, r.l or 0 end
        end
    end
    return best
end

-- Perso d'une inscription (nil si non relié)
function ns:SignupChar(s, tag)
    local roster, char = self.db.roster, s.ch
    if char and not (roster[char] and roster[char].tag == tag and (roster[char].l or 0) >= self:MinLevel()) then char = nil end
    if not char and tag then char = self:FindChar(tag, s.c, s.n) end
    return char
end

function ns:Link(uid, tag)
    self.db.links[uid] = tag and lower(tag) or nil
    self:Invalidate()
end

function ns:Invalidate() self.units = nil self.rindex = nil end

---------------------------------------------------------------------------
-- Unités de la semaine affichée
---------------------------------------------------------------------------
-- Signed : inscrits de l'event de la compo sélectionnée, sinon de tous les events représentés par une compo
function ns:GetUnits()
    local ws, sel = self:CurrentWeek(), self:Selected()
    local key = ws .. ":" .. (sel and sel.id or "") .. ":" .. (sel and sel.event or "")
    if self.units and self.units.key == key then return self.units end
    local db, roster = self.db, self.db.roster
    local events = {}
    if sel then
        if sel.event then events[sel.event] = true end
    else
        for _, comp in ipairs(self:GetWeek().comps) do
            if comp.event then events[comp.event] = true end
        end
    end
    local signed, rest, byName = {}, {}, {}
    for _, ev in ipairs(self:EventsInWeek(ws)) do
        if events[ev.id] then
            for _, s in ipairs(ev.signups or {}) do
                if s.st ~= "absence" then
                    local tag = self:ResolveTag(s)
                    local char = self:SignupChar(s, tag)
                    -- inscription non liée : clé unique par classe (un joueur peut inscrire 2 persos sous le même nom)
                    local name = char or ("~" .. (s.n or "?") .. "#" .. (s.c or ""))
                    local u = byName[name]
                    if not u then
                        u = {
                            name = name, display = char or s.n or "?", class = s.c, spec = s.s, role = s.r,
                            tag = tag or (char and roster[char] and roster[char].tag), uid = s.uid, status = s.st,
                            signed = true, unlinked = not char, rhName = s.n, events = {},
                        }
                        signed[#signed + 1] = u
                        byName[name] = u
                    end
                    u.events[ev.id] = true
                end
            end
        end
    end
    local specs, importSpecs = db.specs, db.importSpecs or {}
    for name, r in pairs(roster) do
        if not byName[name] and (r.l or 0) >= self:MinLevel() and r.c then
            local spec = specs[name] or importSpecs[name]
            local u = { name = name, display = name, class = r.c, spec = spec, role = ns.RoleOf(r.c, spec), tag = r.tag }
            rest[#rest + 1] = u
            byName[name] = u
        end
    end
    self.units = { key = key, signed = signed, rest = rest, byName = byName }
    return self.units
end

-- Unité pour un nom placé dans une compo (même si le perso a quitté la guilde ou n'est pas affiché)
function ns:UnitFor(name)
    local u = self:GetUnits().byName[name]
    if u then return u end
    local r = self.db.roster[name]
    local display = name:gsub("^~", ""):gsub("#.*$", "")
    local spec = self.db.specs[name] or (self.db.importSpecs or {})[name]
    local class = r and r.c or name:match("#(%u+)$")
    local tag = r and r.tag
    -- inscription sans perso lié (« ~nom#CLASSE ») hors de la semaine affichée : spé / tag de son inscription
    if not r and name:sub(1, 1) == "~" then
        local n, c = display, name:match("#(%u*)$") or ""
        for _, ev in ipairs(self.db.events or {}) do
            for _, s in ipairs(ev.signups or {}) do
                if s.n == n and (s.c or "") == c then spec = spec or s.s tag = tag or s.tag end
            end
        end
    end
    return { name = name, display = display, class = class, spec = spec, role = ns.RoleOf(class, spec), tag = tag, missing = not r and not spec }
end

-- Perso dans une compo : avec la spé choisie pour cette compo dans l'exe (comp.sp)
function ns:CompUnit(comp, name)
    local u = self:UnitFor(name)
    local sp = comp and comp.sp and comp.sp[name]
    if not sp then return u end
    local c = {}
    for k, v in pairs(u) do c[k] = v end
    c.spec, c.role = sp, ns.RoleOf(u.class, sp)
    return c
end

-- Icône de spé (emoji Raid-Helper converti en TGA par l'exe), nil si absente
function ns:SpecIcon(u, spec)
    spec = spec or u.spec
    if not (u.class and spec) then return nil end
    local key = u.class .. ":" .. spec
    if self.db.specIcons and self.db.specIcons[key] then
        return "Interface\\AddOns\\GuildTool\\media\\specs\\" .. u.class .. "_" .. spec
    end
end

function ns:SetSpec(name, spec)
    self.db.specs[name] = spec
    self:Invalidate()
end

---------------------------------------------------------------------------
-- Placements dans la semaine
---------------------------------------------------------------------------
function ns:FindInComp(comp, name)
    for slot, n in pairs(comp.c) do
        if n == name then return slot end
    end
end

-- Autre perso du même joueur dans une compo
function ns:RerollIn(comp, tag, except)
    if not tag then return nil end
    for slot, n in pairs(comp.c) do
        if n ~= except and self:UnitFor(n).tag == tag then return n, slot end
    end
end

-- Le perso est-il placé quelque part dans la semaine ?
function ns:IsPlaced(name)
    for _, comp in ipairs(self:GetWeek().comps) do
        if self:FindInComp(comp, name) then return true end
    end
end

-- Lockout : le perso fait déjà ce raid dans une autre compo de la semaine -> { comp, index, slot }
function ns:LockoutOf(name, raidKey, exceptComp)
    if not name or name:sub(1, 1) == "~" then return nil end
    for i, comp in ipairs(self:GetWeek().comps) do
        if comp ~= exceptComp and comp.raid == raidKey then
            local slot = self:FindInComp(comp, name)
            if slot then return { comp = comp, index = i, slot = slot } end
        end
    end
end

-- « already in » : un autre perso du joueur est déjà dans une compo du même raid et du même event
-- (compo sélectionnée : son raid et son event ; sinon : n'importe quel event où le joueur est inscrit)
function ns:AlreadyIn(u)
    if not u.tag then return nil end
    local sel = self:Selected()
    for i, comp in ipairs(self:GetWeek().comps) do
        local match
        if sel then match = comp.raid == sel.raid and comp.event == sel.event
        else match = u.events and comp.event and u.events[comp.event] end
        if match then
            local n = self:RerollIn(comp, u.tag, u.name)
            if n then return { comp = comp, index = i, name = n } end
        end
    end
end

-- Clic : compo sélectionnée, sinon première compo d'un event où le joueur est inscrit
-- (jamais dans une compo où le joueur a déjà un perso ; sans sélection, jamais dans un raid déjà fait cette semaine)
function ns:AutoPlace(u)
    local sel, week = self:Selected(), self:GetWeek()
    local list = sel and { sel } or week.comps
    -- membre : seulement ses compos d'events communautaires
    local any = false
    for _, comp in ipairs(list) do if self:MayEditComp(comp) then any = true break end end
    if not any then self:CanEdit() return true end
    for _, comp in ipairs(list) do
        local ok = self:MayEditComp(comp) and not self:FindInComp(comp, u.name) and not self:RerollIn(comp, u.tag, u.name)
        if ok and not sel then
            if u.signed then ok = comp.event and u.events[comp.event] end
            ok = ok and not self:LockoutOf(u.name, comp.raid, comp)
        end
        if ok then
            local raid = self:RaidByKey(comp.raid)
            for slot = 1, raid and raid.size or 40 do
                if not comp.c[slot] then
                    comp.c[slot] = u.name
                    self:Touch(week)
                    return comp, slot
                end
            end
        end
    end
end

function ns:RemoveAt(comp, slot)
    if not self:CanEditComp(comp) then return end   -- membre sans droits d'officier
    if comp and comp.c[slot] then comp.c[slot] = nil self:Touch() end
end

-- Glisser-déposer sur un slot (même compo ou autre) : échange si le perso venait d'un slot
function ns:DropOnSlot(name, fromComp, fromSlot, comp, slot)
    if not self:CanEditComp(comp) or (fromComp and not self:CanEditComp(fromComp)) then return end
    local displaced = comp.c[slot]
    if fromComp then fromComp.c[fromSlot] = nil end
    comp.c[slot] = name
    if displaced and displaced ~= name and fromComp then fromComp.c[fromSlot] = displaced
    elseif displaced and displaced ~= name then
        -- venu de la liste : l'occupant n'est pas écrasé, il passe dans la 1re case libre de la compo (sinon il en sort)
        local raid = self:RaidByKey(comp.raid)
        for k = 1, (raid and raid.size) or 40 do
            if not comp.c[k] and not (comp.ph or {})[k] then comp.c[k] = displaced break end
        end
    end
    self:Touch()
end

function ns:AddComp(raidKey, eventId)
    -- membre : compo d'un de ses events communautaires seulement
    local ev = eventId and self:EventById(eventId)
    if not self:MayEdit() and not self:IsMyCommuEvent(ev) then self:CanEdit() return end
    local week = self:GetWeek()
    local comp = self:NewComp(raidKey, eventId)
    -- event du salon raid-commu : compo communautaire (rangée à part par l'exe), à son créateur
    if ev and ev.commu then comp.commu, comp.owner = true, ev.lid end
    week.comps[#week.comps + 1] = comp
    self:Touch(week)
    self:Invalidate()
    return comp
end

function ns:DeleteComp(comp)
    if not self:CanEditComp(comp) then return end   -- membre sans droits d'officier
    local week = self:GetWeek()
    for i, c in ipairs(week.comps) do
        if c == comp then table.remove(week.comps, i) break end
    end
    -- compo communautaire : l'exe la supprime aussi sur le serveur
    if comp.commu and comp.id then
        self.db.deletedCommu = self.db.deletedCommu or {}
        self.db.deletedCommu[comp.id] = time()
    end
    if self.db.ui.selected == comp.id then self.db.ui.selected = nil end
    self:Touch(week)
    self:Invalidate()
end

function ns:SetCompEvent(comp, eventId)
    if not self:CanEditComp(comp) then return end   -- membre sans droits d'officier
    local ev = eventId and self:EventById(eventId)
    if not self:MayEdit() and not self:IsMyCommuEvent(ev) then self:CanEdit() return end
    comp.event = eventId
    if ev and ev.commu then comp.commu, comp.owner = true, ev.lid else comp.commu, comp.owner = nil, nil end
    self:Touch()
    self:Invalidate()
end

function ns:ToggleValid(comp)
    if not self:CanEditComp(comp) then return end   -- membre sans droits d'officier
    comp.valid = not comp.valid or nil
    self:Touch()
end

function ns:Select(comp)
    self.db.ui.selected = (comp and self.db.ui.selected ~= comp.id) and comp.id or nil
    self:Invalidate()
end

-- Vide la compo sélectionnée, sinon toutes les compos de la semaine
function ns:ClearComps()
    local sel = self:Selected()
    for _, comp in ipairs(sel and { sel } or self:GetWeek().comps) do
        if self:MayEditComp(comp) then wipe(comp.c) end
    end
    self:Touch()
end

-- Texte de mentions Discord d'une compo : <@id> notifie vraiment, sinon @tag
function ns:Mentions(comp)
    local out, seen, uidByTag = {}, {}, {}
    for _, ev in ipairs(self.db.events) do
        for _, s in ipairs(ev.signups or {}) do
            if s.tag and s.uid then uidByTag[lower(s.tag)] = s.uid end
        end
    end
    for uid, tag in pairs(self.db.links) do uidByTag[tag] = uidByTag[tag] or uid end
    for slot = 1, 40 do
        local name = comp.c[slot]
        if name then
            local u = self:UnitFor(name)
            local uid = u.uid or (u.tag and uidByTag[u.tag])
            local m = uid and ("<@" .. uid .. ">") or (u.tag and ("@" .. u.tag))
            if m and not seen[m] then seen[m] = true out[#out + 1] = m end
        end
    end
    return table.concat(out, " ")
end

---------------------------------------------------------------------------
-- Démarrage
---------------------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("GUILD_ROSTER_UPDATE")
local scanPending
f:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        ns:InitDB()
    elseif event == "PLAYER_LOGIN" then
        ns:RequestRoster()
        if ns.CreateMinimapButton then ns:CreateMinimapButton() end
    elseif event == "GUILD_ROSTER_UPDATE" and ns.db and not scanPending then
        -- GUILD_ROSTER_UPDATE arrive en rafale : on regroupe
        scanPending = true
        C_Timer.After(1, function()
            scanPending = false
            ns:ScanRoster()
            if ns.Refresh then ns:Refresh() end
        end)
    end
end)

-- Commande choisie par un admin dans l'exe (Import.lua est chargé avant ce fichier), « /gt » par défaut ;
-- « /guildtool » marche toujours
do
    local custom = type(GuildToolImport) == "table" and GuildToolImport.slash
    SLASH_GUILDTOOL1 = (type(custom) == "string" and custom:match("^/%a%w+$")) and strlower(custom) or "/gt"
    SLASH_GUILDTOOL2 = "/guildtool"
end
SlashCmdList.GUILDTOOL = function(msg)
    msg = strtrim(msg or "")
    local scale = tonumber(msg:match("^scale%s+([%d%.]+)"))
    if scale then
        ns.db.ui.scale = math.max(0.5, math.min(1.5, scale))
        if ns.frame then ns.frame:SetScale(ns.db.ui.scale) end
        if ns.scaleBox then ns.scaleBox.value:SetText(math.floor(ns.db.ui.scale * 100 + 0.5) .. "%") end
        return
    end
    if msg == "map" then ns:ToggleMap() return end
    if msg == "scan" then ns:RequestRoster() print("|cff6f7cffGuildTool|r: guild roster refreshed.") return end
    if msg == "me" then
        -- relit tout de suite métiers, équipement, sets et talents du perso, les envoie à la guilde, et dit ce qui a été trouvé
        ns.commErrors = nil
        ns:SendMyInfo(true)
        local c = ns.db.chars[ns:MyName() or ""] or {}
        local n = function(t) local k = 0 for _ in pairs(t or {}) do k = k + 1 end return k end
        local recipes = 0
        for _, list in pairs(c.recipes or {}) do recipes = recipes + #list end
        print(("|cff6f7cffGuildTool|r: %d professions, %d items worn, %d equipment sets, %d talent specs, %d recipes."):format(
            n(c.profs), n(c.gear), n(c.sets), n(c.talents), recipes))
        for what, err in pairs(ns.commErrors or {}) do print("|cffff6b6bGuildTool|r " .. what .. ": " .. tostring(err)) end
        print("|cff6f7cffGuildTool|r: open each profession window once to read its recipes; /reload to hand everything to the exe.")
        return
    end
    if msg == "debug" then
        -- rapport complet (fonctions du jeu présentes, réponses brutes, erreurs) gardé dans les SavedVariables
        local log = ns:DebugDump()
        for _, line in ipairs(log) do
            if line:find("^ERROR") or line:find("^stored") or line:find("^MyName") or line:find("^API missing") then
                print("|cff6f7cffRP|r " .. line)
            end
        end
        print("|cff6f7cffGuildTool|r: full report saved (" .. #log .. " lines). Type /reload so it is written to the SavedVariables file.")
        return
    end
    if msg == "roster" then
        -- diagnostic : ce que l'addon a lu dans les notes de guilde
        local n = 0
        for name, r in pairs(ns.db.roster) do
            n = n + 1
            print(("|cff6f7cffRP|r %s  lvl %d  %s  note: \"%s\"  tag: %s"):format(name, r.l or 0, r.c or "?", r.note or "", r.tag or "|cffff6b6bnone|r"))
        end
        print(("|cff6f7cffGuildTool|r: %d characters, Min lvl %d."):format(n, ns:MinLevel()))
        return
    end
    ns:Toggle()
end
