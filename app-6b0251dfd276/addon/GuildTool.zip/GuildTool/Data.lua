-- GuildTool : données statiques (phases, raids, spés, buffs)
-- Les mêmes tables existent côté exe dans Bridge/web/data.js : garder les deux synchronisées.
local _, ns = ...

ns.MAX_LEVEL = 60

-- Phases et raids, par taille croissante. bg = image de fond des compos (media/bg_*.tga, aspect = largeur/hauteur d'origine)
ns.PHASES = {
    { name = "Phase 1", raids = {
        { key = "barrow", name = "Barrow Deeps",  short = "Barrow", size = 10, bg = "bg_barrow", aspect = 0.5 },
        { key = "hyjal",  name = "Mount Hyjal",   short = "Hyjal",  size = 20, bg = "bg_hyjal",  aspect = 1.5 },
        { key = "ony",    name = "Onyxia's Lair", short = "Ony",    size = 40, bg = "bg_ony",    aspect = 2.5 },
    } },
}

-- Disposition selon la taille : largeur en colonnes (grille de 4), colonnes de groupes par compo
ns.LAYOUT = {
    [10] = { span = 1, gcols = 1 },
    [20] = { span = 2, gcols = 2 },
    [40] = { span = 4, gcols = 4 },
}

ns.CLASS_ORDER = { "WARRIOR", "PALADIN", "DRUID", "PRIEST", "SHAMAN", "ROGUE", "HUNTER", "MAGE", "WARLOCK" }
ns.CLASS_NAME = {
    WARRIOR = "Warrior", PALADIN = "Paladin", DRUID = "Druid", PRIEST = "Priest", SHAMAN = "Shaman",
    ROGUE = "Rogue", HUNTER = "Hunter", MAGE = "Mage", WARLOCK = "Warlock",
}
ns.CLASS_COLOR = {
    WARRIOR = "C69B6D", PALADIN = "F48CBA", HUNTER = "AAD372", ROGUE = "FFF468", PRIEST = "F0F0F0",
    SHAMAN = "0070DD", MAGE = "3FC7EB", WARLOCK = "8788EE", DRUID = "FF7C0A",
}
ns.ROLE_ORDER = { "Tank", "Healer", "Melee", "Ranged" }
ns.ROLE_ICON = {
    Tank   = "Interface\\AddOns\\GuildTool\\media\\role_tank",
    Healer = "Interface\\AddOns\\GuildTool\\media\\role_healer",
    Melee  = "Interface\\AddOns\\GuildTool\\media\\role_melee",
    Ranged = "Interface\\AddOns\\GuildTool\\media\\role_ranged",
}

-- Spés jouables par classe (pour choisir la spé d'un perso non inscrit)
ns.SPECS = {
    WARRIOR = { { "Protection", "Tank" }, { "Arms", "Melee" }, { "Fury", "Melee" } },
    PALADIN = { { "Holy", "Healer" }, { "Protection", "Tank" }, { "Retribution", "Melee" } },
    DRUID   = { { "Restoration", "Healer" }, { "Guardian", "Tank" }, { "Feral", "Melee" }, { "Balance", "Ranged" } },
    PRIEST  = { { "Holy", "Healer" }, { "Discipline", "Healer" }, { "Shadow", "Ranged" } },
    SHAMAN  = { { "Restoration", "Healer" }, { "Enhancement", "Melee" }, { "Elemental", "Ranged" } },
    ROGUE   = { { "Combat", "Melee" }, { "Assassination", "Melee" }, { "Subtlety", "Melee" } },
    HUNTER  = { { "Marksmanship", "Ranged" }, { "Survival", "Ranged" }, { "Beastmastery", "Ranged" } },
    MAGE    = { { "Frost", "Ranged" }, { "Fire", "Ranged" }, { "Arcane", "Ranged" } },
    WARLOCK = { { "Affliction", "Ranged" }, { "Destruction", "Ranged" }, { "Demonology", "Ranged" } },
}

-- arbres de talents dans l'ordre du jeu -> spé (= TALENT_SPECS d'app.py et de web/data.js)
ns.TALENT_SPECS = {
    WARRIOR = { "Arms", "Fury", "Protection" }, PALADIN = { "Holy", "Protection", "Retribution" },
    DRUID = { "Balance", "Feral", "Restoration" }, PRIEST = { "Discipline", "Holy", "Shadow" },
    SHAMAN = { "Elemental", "Enhancement", "Restoration" }, ROGUE = { "Assassination", "Combat", "Subtlety" },
    HUNTER = { "Beastmastery", "Marksmanship", "Survival" }, MAGE = { "Arcane", "Fire", "Frost" },
    WARLOCK = { "Affliction", "Demonology", "Destruction" },
}

function ns.RoleOf(class, spec)
    local list = ns.SPECS[class]
    if not (list and spec) then return nil end
    for _, s in ipairs(list) do
        if s[1] == spec then return s[2] end
    end
end

-- Buffs. test(m) reçoit un membre { class, spec, role }. (= web/data.js, GARDER SYNCHRONISÉS)
local function isClass(c) return function(m) return m.class == c end end
local function isSpec(c, ...)
    local specs = { ... }
    return function(m)
        if m.class ~= c then return false end
        for _, s in ipairs(specs) do if m.spec == s then return true end end
        return false
    end
end

-- buffs de groupe (par groupe de 5)
ns.GROUP_BUFFS = {
    { key = "TA",  spell = 25908, icon = "spell_nature_brilliance",          name = "Tranquil Air Totem", effect = "-20% threat",                        provider = "Shaman",             test = isClass("SHAMAN") },
    { key = "MS",  spell = 10497, icon = "spell_nature_manaregentotem",      name = "Mana Spring Totem",  effect = "Restores mana every 2 sec",          provider = "Shaman",             test = isClass("SHAMAN") },
    { key = "MTT", spell = 17359, icon = "spell_frost_summonwaterelemental", name = "Mana Tide Totem",    effect = "Restores mana to the party",         provider = "Restoration Shaman", test = isSpec("SHAMAN", "Restoration") },
    { key = "VE",  spell = 15286, icon = "spell_shadow_unsummonbuilding",    name = "Vampiric Embrace",   effect = "Heals the party from Shadow damage", provider = "Shadow Priest",      test = isSpec("PRIEST", "Shadow") },
    { key = "DI",  spell = 1326159, icon = "spell_warlock_demonsoul",        name = "Dark Inspiration",   effect = "+15% Spirit for the party (Mind Blast, Mind Flay)", provider = "Shadow Priest (talent)",      test = isSpec("PRIEST", "Shadow") },
}

-- buffs de raid (toute la compo). paladins = nombre de paladins requis : Salvation dès un paladin, puis une
-- Greater Blessing par paladin dans cet ordre. hideOff = caché (pas grisé) quand absent.
ns.RAID_BUFFS = {
    { key = "AB",   spell = 23028, icon = "spell_holy_magicalsentry",              name = "Arcane Brilliance",           effect = "+Intellect",                  provider = "Mage",                    test = isClass("MAGE") },
    { key = "GOTW", spell = 21850, icon = "spell_nature_giftofthewild",            name = "Gift of the Wild",            effect = "+All stats and resistances",  provider = "Druid",                   test = isClass("DRUID") },
    { key = "POF",  spell = 21564, icon = "spell_holy_prayeroffortitude",          name = "Prayer of Fortitude",         effect = "+Stamina",                    provider = "Priest",                  test = isClass("PRIEST") },
    { key = "POS",  spell = 27681, icon = "spell_holy_prayerofspirit",             name = "Prayer of Spirit",            effect = "+Spirit",                     provider = "Priest",                  test = isClass("PRIEST") },
    { key = "BS",   spell = 25289, icon = "ability_warrior_battleshout",           name = "Battle Shout",                effect = "+Attack power",               provider = "Warrior",                 test = isClass("WARRIOR") },
    { key = "TSA",  spell = 20906, icon = "ability_trueshot",                      name = "Trueshot Aura",               effect = "+Attack power",               provider = "Beastmastery or Survival Hunter", test = isSpec("HUNTER", "Beastmastery", "Survival"), hideOff = true },
    { key = "LOTP", spell = 17007, icon = "spell_nature_unyeildingstamina",        name = "Leader of the Pack",          effect = "+3% melee and ranged crit",   provider = "Feral or Guardian Druid", test = isSpec("DRUID", "Feral", "Guardian") },
    { key = "MK",   spell = 24907, icon = "spell_nature_moonglow",                 name = "Moonkin Aura",                effect = "+3% spell crit",              provider = "Balance Druid",           test = isSpec("DRUID", "Balance") },
    { key = "WF",   spell = 10614, icon = "spell_nature_windfury",                 name = "Windfury Totem",              effect = "Chance of an extra melee attack", provider = "Shaman",              test = isClass("SHAMAN") },
    { key = "GOA",  spell = 25359, icon = "spell_nature_invisibilitytotem",        name = "Grace of Air Totem",          effect = "+Agility",                    provider = "Shaman",                  test = isClass("SHAMAN") },
    { key = "SOE",  spell = 25361, icon = "spell_nature_earthbindtotem",           name = "Strength of Earth Totem",     effect = "+Strength",                   provider = "Shaman",                  test = isClass("SHAMAN") },
    { key = "FT",   spell = 16387, icon = "spell_nature_guardianward",             name = "Flametongue Totem",           effect = "Fire damage on weapon hits",  provider = "Shaman",                  test = isClass("SHAMAN") },
    { key = "SAL",  spell = 25895, icon = "spell_holy_greaterblessingofsalvation", name = "Salvation",                   effect = "-30% threat",                 provider = "Any Paladin",             paladins = 1 },
    { key = "GBK",  spell = 25898, icon = "spell_magic_greaterblessingofkings",    name = "Greater Blessing of Kings",   effect = "+10% all stats",              provider = "1st Paladin (talent)",    paladins = 1 },
    { key = "GBM",  spell = 25916, icon = "spell_holy_greaterblessingofkings",     name = "Greater Blessing of Might",   effect = "+Attack power",               provider = "2nd Paladin",             paladins = 2 },
    { key = "GBW",  spell = 25918, icon = "spell_holy_greaterblessingofwisdom",    name = "Greater Blessing of Wisdom",  effect = "+Mana every 5 sec",           provider = "3rd Paladin",             paladins = 3 },
    { key = "GBL",  spell = 25890, icon = "spell_holy_greaterblessingoflight",     name = "Greater Blessing of Light",   effect = "+Healing received",           provider = "4th Paladin",             paladins = 4 },
}

-- debuffs sur les boss ; vars = variantes selon la classe qui l'apporte (icône / nom / sort remplacés)
ns.RAID_DEBUFFS = {
    { key = "COE",   spell = 11722, icon = "spell_shadow_chilltouch", name = "Curse of the Elements", effect = "+10% mage damage",   provider = "Warlock" },
    { key = "SUN",   spell = 11597, icon = "ability_warrior_sunder",  name = "Sunder Armor",          effect = "Reduces armor",      provider = "Warrior, or Rogue (Expose Armor)",
      vars = { expose = { spell = 11198, icon = "ability_warrior_riposte", name = "Expose Armor" } } },
    { key = "FF",    spell = 9907,  icon = "spell_nature_faeriefire", name = "Faerie Fire",           effect = "Reduces armor (minor)", provider = "Druid, or a 2nd Warlock (Curse of Recklessness)",
      vars = { cor = { spell = 11717, icon = "spell_shadow_unholystrength", name = "Curse of Recklessness" } } },
    { key = "PURGE", spell = 8012,  icon = "spell_nature_purge",      name = "Purge",                 effect = "Removes 2 buffs",    provider = "Shaman (Purge), Priest (Dispel Magic), or Warlock pet (Devour Magic, 1 buff)",
      vars = { priest = { spell = 988, icon = "spell_holy_dispelmagic", name = "Dispel Magic" }, lock = { spell = 19736, icon = "spell_nature_purge", name = "Devour Magic" } } },
    { key = "TRQ",   spell = 19801, icon = "spell_nature_drowsy",     name = "Tranquilizing Shot",    effect = "Removes 1 frenzy effect", provider = "Hunter" },
}

-- Mêlées (Autofill)
function ns.IsMelee(m)
    return (m.role == "Melee" or m.role == "Tank") and m.class ~= "SHAMAN" and m.class ~= "HUNTER"
end

local function countClasses(members)
    local n = {}
    for _, m in ipairs(members) do if m.class then n[m.class] = (n[m.class] or 0) + 1 end end
    return n
end

-- members = liste de { class, spec, role } ; retourne set clé -> true
function ns.GroupBuffs(members)
    local on = {}
    for _, b in ipairs(ns.GROUP_BUFFS) do
        for _, m in ipairs(members) do
            if b.test(m) then on[b.key] = true break end
        end
    end
    return on
end

function ns.RaidBuffs(members)
    local on, paladins = {}, countClasses(members).PALADIN or 0
    for _, b in ipairs(ns.RAID_BUFFS) do
        if b.paladins then
            on[b.key] = paladins >= b.paladins
        else
            for _, m in ipairs(members) do
                if b.test(m) then on[b.key] = true break end
            end
        end
    end
    return on
end

-- -> clé -> { on, v (variante : clé de vars), effect (texte remplacé) } ; Purge : chaman > prêtre > familier du démoniste
function ns.RaidDebuffs(members)
    local n = countClasses(members)
    local wl, war, rog, dru, pri, sha, hun = n.WARLOCK or 0, n.WARRIOR or 0, n.ROGUE or 0, n.DRUID or 0, n.PRIEST or 0, n.SHAMAN or 0, n.HUNTER or 0
    return {
        COE = { on = wl > 0 },
        SUN = { on = war + rog > 0, v = war == 0 and rog > 0 and "expose" or nil },
        FF = { on = dru > 0 or wl >= 2, v = dru == 0 and wl >= 2 and "cor" or nil },
        PURGE = { on = pri + sha + wl > 0, v = sha == 0 and (pri > 0 and "priest" or wl > 0 and "lock") or nil,
                  effect = pri + sha == 0 and wl > 0 and "Removes 1 buff" or nil },
        TRQ = { on = hun > 0 },
    }
end
