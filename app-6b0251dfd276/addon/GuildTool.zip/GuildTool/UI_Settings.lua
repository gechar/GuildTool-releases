-- GuildTool : fenêtre Settings flottante (Undo, curseurs compacts, infobulles), apparence, image de fond
-- L'image de fond est choisie et recadrée dans l'exe, qui écrit media/bg_window.tga (nette) et bg_window_blur.tga (floutée).
-- WoW ne sait pas flouter en direct : sous les zones « interactives » (cases du calendrier, liste Members) on affiche
-- le morceau correspondant de la version floutée.
local _, ns = ...
local C = ns.C

local BG = "Interface\\AddOns\\GuildTool\\media\\bg_window"
local BG_BLUR = "Interface\\AddOns\\GuildTool\\media\\bg_window_blur"

---------------------------------------------------------------------------
-- Image de fond
---------------------------------------------------------------------------
function ns:CreateWindowBackground(f)
    local t = f:CreateTexture(nil, "BACKGROUND", nil, 1)
    t:SetPoint("TOPLEFT", 1, -1)
    t:SetPoint("BOTTOMRIGHT", -1, 1)
    t:Hide()
    self.winBg = t
    self.blurTextures = {}
end

-- Morceau flouté de l'image de fond sous une zone (texture créée au besoin sur la zone)
function ns:BlurBehind(region, sublevel)
    local t = region.blurTex
    if not t then
        t = region:CreateTexture(nil, "BACKGROUND", nil, sublevel or -8)
        t:SetAllPoints()
        region.blurTex = t
        self.blurTextures[#self.blurTextures + 1] = t
    end
    local a, f = self:Look(), self.frame
    -- fond thématique d'Assigns : l'image du raid passe sous les bandeaux, pas le fond général flouté
    if not a.bg or not region:GetLeft() or (a.assignNoBg and self.db.ui.page == "assigns") then t:Hide() return end
    local fl, ft, fw, fh = f:GetLeft() + 1, f:GetTop() - 1, f:GetWidth() - 2, f:GetHeight() - 2
    local l = (region:GetLeft() - fl) / fw
    local r = (region:GetRight() - fl) / fw
    local top = (ft - region:GetTop()) / fh
    local bottom = (ft - region:GetBottom()) / fh
    t:SetTexture(BG_BLUR)
    t:SetTexCoord(math.max(0, l), math.min(1, r), math.max(0, top), math.min(1, bottom))
    t:SetAlpha(a.bgAlpha or 0.6)
    t:Show()
end

function ns:ApplyAppearance()
    local a = self:Look()
    -- Assigns : fond thématique (image du raid sur toute la fenêtre) à la place de l'image de fond générale
    if self.asg and (self.db.ui.page ~= "assigns" or not a.assignNoBg) then self.asg.img.clip:Hide() self.asg.bar.glass.clip:Hide() end
    if a.bg and not (a.assignNoBg and self.db.ui.page == "assigns") then
        self.winBg:SetTexture(BG)
        self.winBg:SetAlpha(a.bgAlpha or 0.6)
        self.winBg:Show()
    else
        self.winBg:Hide()
    end
    local thematic = a.assignNoBg and self.db.ui.page == "assigns"
    for _, t in ipairs(self.blurTextures) do
        if not a.bg or thematic then t:Hide() else t:SetAlpha(a.bgAlpha or 0.6) t:Show() end
    end
    for _, w in ipairs(self.compWidgets or {}) do w.img:SetAlpha(a.compAlpha or 0.3) end
    -- barre du haut (onglets de page) : même réglages que la liste et la barre d'onglets
    if self.topBar and self.topBar.bg then
        local g = a.listGlass or 0
        self.topBar.bg:SetColorTexture(C.head[1], C.head[2], C.head[3], a.tabsAlpha or 1)
        if g > 0 then
            self:BlurBehind(self.topBar)
            if self.topBar.blurTex:IsShown() then self.topBar.blurTex:SetAlpha((a.bgAlpha or 0.6) * g) end
        elseif self.topBar.blurTex then self.topBar.blurTex:Hide() end
    end
    if self.side then
        -- List/Tab opacity = fond ; List/Tab Blurred = part de l'image de fond floutée derrière la liste
        local g = a.listGlass or 0
        self.side.bg:SetColorTexture(C.side[1], C.side[2], C.side[3], a.tabsAlpha or 1)
        if g > 0 then
            self:BlurBehind(self.side)
            if self.side.blurTex:IsShown() then self.side.blurTex:SetAlpha((a.bgAlpha or 0.6) * g) end
        elseif self.side.blurTex then self.side.blurTex:Hide() end
    end
    -- fenêtre d'apparence de l'onglet ouverte et onglet changé : ses réglages à lui
    if self.tabLook and self.tabLook:IsShown() and self.tabLook.page ~= self.db.ui.page then self:FillTabLook() end
end

-- Après un curseur d'apparence : fond, images ; la page Assigns (image du raid, barre d'onglets) est redessinée
function ns:AppearanceChanged()
    self:ApplyAppearance()
    if self.db.ui.page == "loots" and self.LootListLook then self:LootListLook() end
    if self.db.ui.page == "assigns" and self.RefreshAssigns then self:RefreshAssigns() end
    -- Members : fond de la liste, détail (talents, cadres, image du joueur)
    if self.db.ui.page == "members" and self.RefreshMembers then self:RefreshMembers() end
    -- Raid Comps : taille / cadre / intensité des icônes de buffs
    if self.db.ui.page == "comps" and self.RefreshComps then self:RefreshComps() end
end

---------------------------------------------------------------------------
-- Annulation (Undo) : chaque réglage empile sa valeur précédente ; les changements rapprochés
-- d'un même réglage (glissement d'un curseur) ne comptent qu'une fois
---------------------------------------------------------------------------
local UNDO = {}

function ns:SetAppearanceUndo(key, value, label)
    local prev = self:RawAppearance(key)
    if prev == value then return end
    local last = UNDO[#UNDO]
    if not (last and last.key == key and GetTime() - last.t < 1.5) then
        UNDO[#UNDO + 1] = { key = key, prev = prev, label = label }
        last = UNDO[#UNDO]
    end
    last.t = GetTime()
    self:SetAppearance(key, value)
    self:UpdateSettings()
end

-- Réglages par défaut : apparence publiée par la guilde (exe), sinon celle d'origine ; annulable (Undo)
local APP_DEF = { buffBorder = 1, buffInt = 1, buffIconInt = 1, buffSizeR = 16, buffSizeG = 13, membersAlpha = 0.55, membersBlur = 0.6, charImgOff = false, compAlpha = 0.3, bgAlpha = 0.6, listGlass = 0, tabsAlpha = 1, assignAlpha = 0.5, assignNoBg = false, talentBg = 0.35, charImgA = 0.5, detAlpha = 0.22, detBlur = 0,
                  hl = "#6f7cff", hl2 = "#3fc7eb", hlGrad = false, base = "#1e1f24", lockA = "#0e0f12", lockB = "#34363e" }
function ns:DefaultAppearance()
    local g = type(self.db.guildAppearance) == "table" and self.db.guildAppearance or {}
    local multi = {}
    for k, v in pairs(APP_DEF) do
        local nv = g[k]
        if nv == nil then nv = v end
        multi[k] = self.db.appearance[k]
        self:SetAppearance(k, nv)
    end
    UNDO[#UNDO + 1] = { multi = multi, label = "Default settings", t = 0 }
    ns.ApplyHighlight(self.db.appearance.hl) ns.RepaintHighlight()
    self:UpdateSettings()
    self:Refresh()
end

function ns:UndoSetting()
    local u = table.remove(UNDO)
    if not u then return end
    -- (réglage d'onglet sans valeur propre avant : prev = nil, remis à nil -> le réglage général reprend)
    if u.multi then for k, v in pairs(u.multi) do self:SetAppearance(k, v) end
    else self:SetAppearance(u.key, u.prev) end
    self:UpdateSettings()
    self:Refresh()
end

---------------------------------------------------------------------------
-- Infobulle d'aide au survol (remplace les commentaires sous les titres)
---------------------------------------------------------------------------
local function help(frame, text)
    frame:HookScript("OnEnter", function(self)
        ns.TipOwner(self)
        GameTooltip:SetText(ns.L(text), 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    frame:HookScript("OnLeave", GameTooltip_Hide)
end

---------------------------------------------------------------------------
-- Curseur compact : « 30% » devant un petit curseur ; clic sur le nombre = saisie (Entrée valide, Échap annule)
---------------------------------------------------------------------------
local function miniSlider(row, key, def, label, x, w)
    w = w or 80
    local s = CreateFrame("Slider", nil, row)
    s:SetOrientation("HORIZONTAL")
    s:SetSize(w, 14)
    s:SetPoint("RIGHT", x or -4, 0)
    s:SetMinMaxValues(0, 100)
    s:SetValueStep(1)
    s:SetObeyStepOnDrag(true)
    local track = ns.Tex(s, C.input, "BACKGROUND")
    track:SetPoint("LEFT") track:SetPoint("RIGHT") track:SetHeight(4)
    s.fill = ns.Tex(s, C.accent, "ARTWORK")
    s.fill:SetPoint("LEFT") s.fill:SetHeight(4)
    s:SetThumbTexture("Interface\\Buttons\\WHITE8X8")
    s:GetThumbTexture():SetSize(8, 14)
    local pct = CreateFrame("Button", nil, row)
    pct:SetSize(42, 20)
    pct:SetPoint("RIGHT", s, "LEFT", -6, 0)
    pct.hl = ns.Fill(pct, C.input)
    pct.hl:Hide()
    pct.text = ns.Text(pct, 12, 600)
    pct.text:SetPoint("RIGHT", -3, 0)
    pct:SetScript("OnEnter", function(self) self.hl:Show() end)
    pct:SetScript("OnLeave", function(self) self.hl:Hide() end)
    local eb = CreateFrame("EditBox", nil, row)
    eb:SetSize(38, 20)
    eb:SetPoint("RIGHT", s, "LEFT", -8, 0)
    eb:SetFont(ns.FONT[600], 12, "")
    eb:SetJustifyH("RIGHT")
    eb:SetAutoFocus(false)
    eb:SetNumeric(true)
    eb:SetMaxLetters(3)
    ns.Fill(eb, C.input)
    ns.Border(eb, C.accent)
    eb:Hide()
    local function show(v)
        pct.text:SetText(math.floor(v + 0.5) .. "%")
        s.fill:SetWidth(math.max(1, w * v / 100))
    end
    s:SetScript("OnValueChanged", function(_, v, user)
        show(v)
        if user then ns:SetAppearanceUndo(key, v / 100, label) ns:AppearanceChanged() end
    end)
    s:EnableMouseWheel(true)
    s:SetScript("OnMouseWheel", function(self, d)
        self:SetValue(self:GetValue() + d * 5)
        ns:SetAppearanceUndo(key, self:GetValue() / 100, label)
        ns:AppearanceChanged()
    end)
    pct:SetScript("OnClick", function()
        pct:Hide()
        eb:SetText(math.floor(s:GetValue() + 0.5))
        eb:Show()
        eb:SetFocus()
        eb:HighlightText()
    end)
    local function close() eb:ClearFocus() eb:Hide() pct:Show() end
    eb:SetScript("OnEnterPressed", function(self)
        local v = tonumber(self:GetText())
        close()
        if v then
            v = math.max(0, math.min(100, v))
            s:SetValue(v)
            ns:SetAppearanceUndo(key, v / 100, label)
            ns:AppearanceChanged()
        end
    end)
    eb:SetScript("OnEscapePressed", close)
    eb:SetScript("OnEditFocusLost", close)
    -- plusieurs curseurs sur une ligne : chacun se met à jour
    local prev = row.Update
    function row:Update() if prev then prev(self) end local v = ns:AGet(key, def) * 100 s:SetValue(v) show(v) end
    help(s, row.helpText)
    help(pct, row.helpText)
    return s
end

---------------------------------------------------------------------------
-- Fenêtre Settings flottante : barre du haut pour la déplacer (dans la fenêtre), coin pour la redimensionner,
-- croix et Échap pour la fermer, Undo à la place de Save
---------------------------------------------------------------------------
local ROW_H = 28
-- deux curseurs sur une ligne (opac/blur) : plus étroits, le nom du réglage a plus de place
local TWO_W, TWO_X = 50, -110

local function swatch(parent, key)
    local sw = CreateFrame("Button", nil, parent)
    sw:SetSize(32, 20)
    sw.tex = ns.Tex(sw, C.white, "ARTWORK")
    sw.tex:SetPoint("TOPLEFT", 2, -2) sw.tex:SetPoint("BOTTOMRIGHT", -2, 2)
    ns.Border(sw, C.border)
    sw:SetScript("OnEnter", function(self) ns.SetBorderColor(self, C.accent) end)
    sw:SetScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) end)
    sw:SetScript("OnClick", function() ns:PickColor(key) end)
    sw.key = key
    return sw
end

-- Suit la souris (déplacement ou taille) tant que le bouton est enfoncé
local function track(frame, onMove)
    local x0, y0 = GetCursorPosition()
    local s = frame:GetEffectiveScale()
    frame:SetScript("OnUpdate", function(self)
        if not IsMouseButtonDown("LeftButton") then self:SetScript("OnUpdate", nil) ns:SaveSettingsRect() return end
        local x, y = GetCursorPosition()
        onMove((x - x0) / s, (y0 - y) / s)
    end)
end

-- Nombre de modifications des deux boutons du haut des Settings (textes réécrits : polices pas toujours prêtes)
function ns:RefreshLogButtons()
    local w = self.settingsPage
    if not (w and w.logButtons) then return end
    for _, b in ipairs(w.logButtons) do
        ns.SetFont(b.num, 24, 700)
        b.num:SetText(#b.list)
        ns.SetFont(b.l1, 10.5, 600) b.l1:SetText(b.texts[1])
        ns.SetFont(b.l2, 10.5, 600) b.l2:SetText(b.texts[2])
    end
    if self.logWin and self.logWin:IsShown() then self:FillLogWindow() end
end

-- Fenêtre (comme les Settings) : liste des modifications, la plus récente en haut
function ns:ShowLogWindow(titleText, list)
    local w = self.logWin
    if not w then
        w = CreateFrame("Frame", nil, self.frame)
        w:SetFrameLevel(self.frame:GetFrameLevel() + 90)
        w:SetSize(460, 380)
        w:SetPoint("CENTER")
        w:EnableMouse(true)
        ns.Fill(w, C.bg, 0.97)
        ns.Border(w, C.hl)
        local bar = CreateFrame("Frame", nil, w)
        bar:SetPoint("TOPLEFT", 1, -1)
        bar:SetPoint("TOPRIGHT", -1, -1)
        bar:SetHeight(28)
        ns.Fill(bar, C.head)
        w.title = ns.Text(bar, 12.5, 700, C.white)
        w.title:SetPoint("LEFT", 10, 0)
        local close = ns.IconButton(bar, "×", 22, ns.L("Close (Esc)"))
        close:SetPoint("RIGHT", -3, 0)
        close:SetScript("OnClick", function() w:Hide() end)
        local sf = ns.ScrollArea(w)
        sf:SetPoint("TOPLEFT", 1, -30)
        sf:SetPoint("BOTTOMRIGHT", -1, 1)
        w.scroll = sf
        sf.child:SetWidth(440)
        w.text = ns.Text(sf.child, 11.5, 500)
        w.text:SetPoint("TOPLEFT", 10, -8)
        w.text:SetWidth(420)
        w.text:SetWordWrap(true)
        w.text:SetJustifyV("TOP")
        self.logWin = w
    end
    w.list, w.titleText = list, titleText
    w:Show()
    self:FillLogWindow()
end
function ns:FillLogWindow()
    local w = self.logWin
    ns.SetFont(w.title, 12.5, 700)
    w.title:SetText(w.titleText .. "  ·  " .. #w.list)
    local lines = {}
    for i = #w.list, 1, -1 do
        local e = w.list[i]
        lines[#lines + 1] = ("|cff9a9ea9%s|r  %s%s%s"):format(date("%H:%M:%S", e.t), e.text,
            e.from and ("  |cff9a9ea9(" .. e.from .. ")|r") or "", (e.n or 1) > 1 and ("  |cff6f7cff×" .. e.n .. "|r") or "")
    end
    ns.SetFont(w.text, 11.5, 500)
    w.text:SetText(#lines > 0 and table.concat(lines, "\n") or ("|cff9a9ea9" .. ns.L("Nothing yet.") .. "|r"))
    w.scroll.child:SetHeight(w.text:GetStringHeight() + 16)
end

function ns:CreateSettings(f)
    local L = ns.L
    local w = CreateFrame("Frame", nil, f)
    w:SetFrameLevel(f:GetFrameLevel() + 80)
    w:EnableMouse(true)
    ns.Fill(w, C.bg, 0.97)
    ns.Border(w, C.hl)
    ns.HighlightBorder(w)   -- suit la couleur Highlight (et son dégradé)
    w:Hide()
    self.settingsPage = w

    -- barre du haut : titre, croix ; glisser = déplacer
    local bar = CreateFrame("Frame", nil, w)
    bar:SetPoint("TOPLEFT", 1, -1)
    bar:SetPoint("TOPRIGHT", -1, -1)
    bar:SetHeight(28)
    ns.Fill(bar, C.head)
    bar:EnableMouse(true)
    local title = ns.Text(bar, 12.5, 700, C.white)
    title:SetPoint("LEFT", 10, 0)
    title:SetText(L("Settings"))
    local close = ns.IconButton(bar, "×", 22, L("Close (Esc)"))
    close.label:SetFont(ns.FONT[600], 15, "")
    close:SetPoint("RIGHT", -3, 0)
    close:SetScript("OnClick", function() w:Hide() end)
    bar:SetScript("OnMouseDown", function()
        local r = ns.db.ui.setWin
        local x1, y1 = r.x, r.y
        track(w, function(dx, dy) r.x, r.y = x1 + dx, y1 + dy ns:PlaceSettings() end)
    end)

    -- pied : Undo
    local undo = ns.Button(w, L("Undo"), 70, 22)
    undo:SetPoint("BOTTOMLEFT", 8, 7)
    undo:SetScript("OnClick", function() ns:UndoSetting() end)
    w.undo = undo
    w.undoInfo = ns.Text(w, 10.5, 400, C.mute)
    w.undoInfo:SetPoint("LEFT", undo, "RIGHT", 8, 0)
    w.undoInfo:SetPoint("RIGHT", -18, 0)
    local fl = ns.Tex(w, C.border, "ARTWORK")
    fl:SetPoint("BOTTOMLEFT", 1, 36) fl:SetPoint("BOTTOMRIGHT", -1, 36) fl:SetHeight(1)

    -- coin de redimensionnement
    local grip = CreateFrame("Button", nil, w)
    grip:SetSize(14, 14)
    grip:SetPoint("BOTTOMRIGHT", -1, 1)
    for i = 0, 1 do
        local l = grip:CreateLine(nil, "OVERLAY")
        l:SetColorTexture(0.35, 0.37, 0.41, 1)
        l:SetThickness(1.2)
        l:SetStartPoint("BOTTOMRIGHT", grip, -3 - i * 4, 2)
        l:SetEndPoint("BOTTOMRIGHT", grip, -2, 3 + i * 4)
    end
    grip:SetScript("OnMouseDown", function()
        local r = ns.db.ui.setWin
        local w1, h1 = r.w, r.h
        track(w, function(dx, dy) r.w, r.h = w1 + dx, h1 + dy ns:PlaceSettings() end)
    end)

    -- contenu (défile si la fenêtre est petite)
    local sf = ns.ScrollArea(w)
    sf:SetPoint("TOPLEFT", 1, -30)
    sf:SetPoint("BOTTOMRIGHT", -1, 38)
    w.scroll = sf
    local child = sf.child
    local y = 0
    -- en haut à gauche : modifications en attente d'écriture dans les SavedVariables (/reload, déconnexion)
    -- et modifications reçues des autres joueurs par le chat addon ; clic = liste
    local function logButton(x, l1, l2, list, titleText)
        local b = CreateFrame("Button", nil, child)
        b:SetSize(150, 42)
        b:SetPoint("TOPLEFT", x, -8)
        ns.Fill(b, C.input)
        ns.Border(b, C.border)
        b.num = ns.Text(b, 24, 700, C.white)
        b.num:SetPoint("LEFT", 10, 0)
        b.l1 = ns.Text(b, 10.5, 600, C.mute)
        b.l1:SetPoint("BOTTOMLEFT", b.num, "RIGHT", 8, 1)
        b.l2 = ns.Text(b, 10.5, 600, C.mute)
        b.l2:SetPoint("TOPLEFT", b.num, "RIGHT", 8, -1)
        b.texts = { l1, l2 }
        b.list = list
        b:SetScript("OnEnter", function(self) ns.SetBorderColor(self, C.hl) end)
        b:SetScript("OnLeave", function(self) ns.SetBorderColor(self, C.border) end)
        b:SetScript("OnClick", function() ns:ShowLogWindow(titleText, list) end)
        return b
    end
    w.logButtons = {
        logButton(10, L("Pending"), L("Updates"), ns.pendingLog, L("Pending Updates")),
        logButton(168, L("Addon"), L("Updates"), ns.addonLog, L("Addon Updates")),
    }
    w:HookScript("OnShow", function() ns:RefreshLogButtons() end)
    y = 58
    local function row(label, helpText)
        local r = CreateFrame("Frame", nil, child)
        r:SetPoint("TOPLEFT", 10, -y)
        r:SetPoint("TOPRIGHT", -10, -y)
        r:SetHeight(ROW_H)
        r:EnableMouse(true)
        r.helpText = helpText
        r.label = ns.Text(r, 12, 600)
        r.label:SetPoint("LEFT", 0, 0)
        r.label:SetText(L(label))
        help(r, helpText)
        y = y + ROW_H
        return r
    end
    local function section(text)
        y = y + 8
        local t = ns.Text(child, 9.5, 700, C.mute)
        t:SetPoint("TOPLEFT", 10, -y)
        t:SetText(strupper(L(text)))
        local l = ns.Tex(child, C.border, "ARTWORK")
        l:SetPoint("TOPLEFT", 10, -y - 14) l:SetPoint("TOPRIGHT", -10, -y - 14) l:SetHeight(1)
        y = y + 20
    end
    w.rows, w.swatches = {}, {}

    section("Appearance")
    -- Français : interrupteur on/off (l'interface se recharge pour changer de langue)
    local lr = row("Français", "Translate the interface (exe and addon) into French.")
    local sw = CreateFrame("Button", nil, lr)
    sw:SetSize(30, 16)
    sw:SetPoint("RIGHT", -4, 0)
    sw.track = ns.Tex(sw, C.border, "ARTWORK")
    sw.track:SetAllPoints()
    sw.knob = ns.Tex(sw, C.mute, "OVERLAY")
    sw.knob:SetSize(12, 12)
    help(sw, "The interface reloads to change the language.")
    sw:SetScript("OnClick", function()
        ns:SetAppearanceUndo("lang", ns.Lang() == "fr" and "en" or "fr", "Language")
        ReloadUI()
    end)
    function lr:Update()
        local on = ns.Lang() == "fr"
        sw.knob:ClearAllPoints()
        sw.knob:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        local c = on and C.accent or C.border
        sw.track:SetColorTexture(c[1], c[2], c[3])
        local k = on and C.white or C.mute
        sw.knob:SetColorTexture(k[1], k[2], k[3])
    end
    w.rows[#w.rows + 1] = lr

    local cr = row("Comp images", "Opacity of the raid image behind each comp.")
    miniSlider(cr, "compAlpha", 0.3, "Comp images")
    w.rows[#w.rows + 1] = cr
    -- liste des persos (Compos) et barre des onglets d'Assigns : opacité / flou sur une ligne
    local gr = row("List/Tab opac/blur", "Opacity and blur of the character list (Raid Comps) and of the Assigns tabs bar. Lower the opacity with some blur for a glass look.")
    miniSlider(gr, "listGlass", 0, "List/Tab opac/blur", nil, TWO_W)
    miniSlider(gr, "tabsAlpha", 1, "List/Tab opac/blur", TWO_X, TWO_W)
    w.rows[#w.rows + 1] = gr
    -- opacité du fond général, et de l'image du raid quand le fond thématique d'Assigns la remplace
    local bgr = row("Background opacity", "Opacity of the window background image (and of the raid image when the Assigns thematic background is on). The images are chosen in Guild Tool (Settings).")
    miniSlider(bgr, "bgAlpha", 0.6, "Background opacity")
    w.rows[#w.rows + 1] = bgr
    -- Members : fond des arbres de talents (images de la fenêtre de talents), image de fond des persos
    local tbr = row("Talent background", "Opacity of the talent tree backgrounds (Members, character details).")
    miniSlider(tbr, "talentBg", 0.35, "Talent background")
    w.rows[#w.rows + 1] = tbr
    -- Members : fond de la liste (opacité / flou), images de fond choisies par les joueurs (interrupteur)
    local mbr = row("Members Background opac/blur", "Members: opacity and blur of the background of the character list.")
    miniSlider(mbr, "membersBlur", 0.6, "Members Background opac/blur", nil, TWO_W)
    miniSlider(mbr, "membersAlpha", 0.55, "Members Background opac/blur", TWO_X, TWO_W)
    w.rows[#w.rows + 1] = mbr
    local cir = row("Members custom background", "Show the background pictures chosen by the players for their characters (Members, character details).")
    local csw = CreateFrame("Button", nil, cir)
    csw:SetSize(30, 16)
    csw:SetPoint("RIGHT", -4, 0)
    csw.track = ns.Tex(csw, C.border, "ARTWORK")
    csw.track:SetAllPoints()
    csw.knob = ns.Tex(csw, C.mute, "OVERLAY")
    csw.knob:SetSize(12, 12)
    csw:SetScript("OnClick", function()
        ns:SetAppearanceUndo("charImgOff", not ns.db.appearance.charImgOff, "Members custom background")
        ns:AppearanceChanged()
    end)
    function cir:Update()
        local on = not ns.db.appearance.charImgOff
        csw.knob:ClearAllPoints()
        csw.knob:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        local c = on and C.accent or C.border
        csw.track:SetColorTexture(c[1], c[2], c[3])
        local k = on and C.white or C.mute
        csw.knob:SetColorTexture(k[1], k[2], k[3])
    end
    w.rows[#w.rows + 1] = cir
    -- détail des persos : opacité et flou des cadres des talents et de la présence (deux curseurs côte à côte)
    local dr = row("Char details opac/blur", "Members, character details: opacity and blur of the frames of the talents and of the attendance.")
    miniSlider(dr, "detBlur", 0, "Char details opac/blur", nil, TWO_W)
    miniSlider(dr, "detAlpha", 0.22, "Char details opac/blur", TWO_X, TWO_W)
    w.rows[#w.rows + 1] = dr
    -- fond thématique d'Assigns : interrupteur on/off (fond général ↔ image du raid)
    local nr = row("Assign's Thematic Background", "In the Assigns tab, the window background becomes the image of the raid instead of the general background.")
    local ns2 = CreateFrame("Button", nil, nr)
    ns2:SetSize(30, 16)
    ns2:SetPoint("RIGHT", -4, 0)
    ns2.track = ns.Tex(ns2, C.border, "ARTWORK")
    ns2.track:SetAllPoints()
    ns2.knob = ns.Tex(ns2, C.mute, "OVERLAY")
    ns2.knob:SetSize(12, 12)
    ns2:SetScript("OnClick", function()
        ns:SetAppearanceUndo("assignNoBg", not ns.db.appearance.assignNoBg, "Assign's Thematic Background")
        ns:AppearanceChanged()
    end)
    function nr:Update()
        local on = ns.db.appearance.assignNoBg and true or false
        ns2.knob:ClearAllPoints()
        ns2.knob:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        local c = on and C.accent or C.border
        ns2.track:SetColorTexture(c[1], c[2], c[3])
        local k = on and C.white or C.mute
        ns2.knob:SetColorTexture(k[1], k[2], k[3])
    end
    w.rows[#w.rows + 1] = nr
    -- surbrillance (sélections, survols, onglets) ; dégradé = alterne doucement entre deux couleurs
    local hr = row("Highlight", "Color of the selections, hovers and selected tabs.")
    local hreset = ns.IconButton(hr, "R", 20, L("Default color"))
    hreset:SetPoint("RIGHT", -4, 0)
    hreset:SetScript("OnClick", function()
        ns:SetAppearanceUndo("hl", "#6f7cff", "Highlight")
        ns:SetAppearanceUndo("hl2", "#3fc7eb", "Highlight")
        ns.ApplyHighlight(ns.db.appearance.hl) ns.RepaintHighlight() ns:Refresh()
    end)
    local hsw2 = swatch(hr, "hl2")
    hsw2:SetPoint("RIGHT", hreset, "LEFT", -6, 0)
    local hsw = swatch(hr, "hl")
    hsw:SetPoint("RIGHT", hsw2, "LEFT", -4, 0)
    w.swatches[#w.swatches + 1] = hsw
    w.swatches[#w.swatches + 1] = hsw2
    local gr2 = row("Gradient", "Alternate progressively between two highlight colors.")
    local gsw = CreateFrame("Button", nil, gr2)
    gsw:SetSize(30, 16)
    gsw:SetPoint("RIGHT", -4, 0)
    gsw.track = ns.Tex(gsw, C.border, "ARTWORK")
    gsw.track:SetAllPoints()
    gsw.knob = ns.Tex(gsw, C.mute, "OVERLAY")
    gsw.knob:SetSize(12, 12)
    gsw:SetScript("OnClick", function()
        ns:SetAppearanceUndo("hlGrad", not ns.db.appearance.hlGrad, "Gradient")
        ns.ApplyHighlight(ns.db.appearance.hl) ns.RepaintHighlight()
    end)
    function gr2:Update()
        local on = ns.db.appearance.hlGrad and true or false
        hsw2:SetShown(on)
        gsw.knob:ClearAllPoints()
        gsw.knob:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        local c = on and C.accent or C.border
        gsw.track:SetColorTexture(c[1], c[2], c[3])
        local k = on and C.white or C.mute
        gsw.knob:SetColorTexture(k[1], k[2], k[3])
    end
    w.rows[#w.rows + 1] = gr2

    local br = row("Base color", "Color of the bars (tab bar, indicator bar of each tab) and of the buttons. The window background keeps its color. Applies after /reload.")
    local breset = ns.IconButton(br, "R", 20, L("Default color"))
    breset:SetPoint("RIGHT", -4, 0)
    breset:SetScript("OnClick", function() ns:SetAppearanceUndo("base", "#1e1f24", "Base color") end)
    local bsw = swatch(br, "base")
    bsw:SetPoint("RIGHT", breset, "LEFT", -6, 0)
    w.swatches[#w.swatches + 1] = bsw

    local kr = row("Lockouts", "Alternate lockout weeks in the calendar (Wednesday to Tuesday).")
    local kreset = ns.IconButton(kr, "R", 20, L("Default colors"))
    kreset:SetPoint("RIGHT", -4, 0)
    kreset:SetScript("OnClick", function()
        local a = ns.db.appearance
        UNDO[#UNDO + 1] = { multi = { lockA = a.lockA, lockB = a.lockB }, label = "Lockout colors", t = 0 }
        ns:SetAppearance("lockA", "#0e0f12")
        ns:SetAppearance("lockB", "#34363e")
        ns:UpdateSettings()
        ns:Refresh()
    end)
    local kb = swatch(kr, "lockB")
    kb:SetPoint("RIGHT", kreset, "LEFT", -6, 0)
    local ka = swatch(kr, "lockA")
    ka:SetPoint("RIGHT", kb, "LEFT", -4, 0)
    w.swatches[#w.swatches + 1] = ka
    w.swatches[#w.swatches + 1] = kb


    y = y + 10
    local note = ns.Text(child, 10.5, 400, C.mute)
    note:SetPoint("TOPLEFT", 10, -y)
    note:SetPoint("TOPRIGHT", -10, -y)
    note:SetWordWrap(true)
    note:SetText(L("Phases, raids, assign tabs and the background image are edited in Guild Tool."))
    -- réglages par défaut (ceux publiés par la guilde, sinon ceux d'origine) ; publication (officiers) : écrite au
    -- /reload, l'exe l'envoie à la guilde à sa synchro et elle devient l'apparence par défaut de tous
    y = y + 36
    local def = ns.Button(child, L("Default settings"), 150, 24)
    def:SetPoint("TOPLEFT", 10, -y)
    def:SetScript("OnClick", function() ns:DefaultAppearance() end)
    local pub = ns.Button(child, L("Publish guild settings"), 180, 24)
    pub:SetPoint("TOPRIGHT", -10, -y)
    pub:SetScript("OnClick", function(b)
        if not b.armed then
            b.armed = true
            b.label:SetText(L("Confirm"))
            C_Timer.After(2, function() b.armed = nil b.label:SetText(L("Publish guild settings")) end)
            return
        end
        if not ns:IsOfficerOrGM() then return end
        GuildToolDB.publishReq = GuildToolDB.publishReq or {}
        GuildToolDB.publishReq.two = time()
        ReloadUI()
    end)
    -- officiers / GM seulement (visible et cliquable)
    w:HookScript("OnShow", function() pub:SetShown(ns:IsOfficerOrGM()) end)
    y = y + 30
    child:SetHeight(y + 40)
    -- droits d'officier temporaires (officiers) : sous les boutons, hauteur variable
    w.grantY = y
    self:CreateGrants(w, child)
    w:HookScript("OnShow", function() ns:RefreshGrants() end)

    -- Échap ferme la fenêtre (et seulement elle)
    w:EnableKeyboard(true)
    w:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then return end
        if key == "ESCAPE" then
            self:SetPropagateKeyboardInput(false)
            self:Hide()
        else
            self:SetPropagateKeyboardInput(true)
        end
    end)

    -- boutons de la barre du haut, comme Sync / Settings de l'appli : /reload (à gauche) et Settings (engrenage)
    local b = ns.IconBox(self.topBar, "Interface\\AddOns\\GuildTool\\media\\gear", "Settings")
    b:SetScript("OnClick", function() ns:ShowSettings() end)
    self.settingsBtn = b
    local rl = ns.IconBox(self.topBar, "Interface\\AddOns\\GuildTool\\media\\sync", "Reload the interface (/reload)")
    rl:SetPoint("RIGHT", b, "LEFT", -6, 0)
    rl:SetScript("OnClick", function() ReloadUI() end)
    self.reloadBtn = rl
end

-- Position et taille (dans la fenêtre principale) : 1/4 de la largeur, 1/2 de la hauteur par défaut
function ns:PlaceSettings()
    local w, f = self.settingsPage, self.frame
    local r = self.db.ui.setWin
    if not r then
        r = { w = ns.W / 4, h = ns.H / 2, x = ns.W * 0.73, y = 50 }
        self.db.ui.setWin = r
    end
    local W, H = f:GetWidth(), f:GetHeight()
    r.w = math.max(280, math.min(r.w, W - 4))
    r.h = math.max(240, math.min(r.h, H - 4))
    r.x = math.max(2, math.min(r.x, W - r.w - 2))
    r.y = math.max(2, math.min(r.y, H - r.h - 2))
    w:ClearAllPoints()
    w:SetPoint("TOPLEFT", f, "TOPLEFT", r.x, -r.y)
    w:SetSize(r.w, r.h)
    w.scroll.child:SetWidth(r.w - 8)
    w.scroll:UpdateThumb()
end

function ns:SaveSettingsRect() end -- la position est déjà dans db.ui.setWin

function ns:UpdateSwatches(win)
    for _, sw in ipairs((win or self.settingsPage).swatches) do
        local c = ns.Hex((self.db.appearance[sw.key] or "#000000"):gsub("#", ""))
        sw.tex:SetColorTexture(c[1], c[2], c[3])
    end
end

-- Apparence d'un onglet : engrenage à droite de la barre indicateur -> fenêtre des réglages qui touchent cet onglet ;
-- ceux qui touchent tous les onglets (fond, barre d'onglets) y sont propres à l'onglet (appearance.tabs)
local TL_NAME = { calendar = "Calendar", comps = "Raid Comps", assigns = "Assigns", members = "Members", loots = "Loots" }
-- Champ numérique (px) à droite de la ligne : Entrée valide (borné lo..hi), Échap annule
local function numBox(row, key, def, lo, hi, label)
    local eb = CreateFrame("EditBox", nil, row)
    eb:SetSize(42, 20)
    eb:SetPoint("RIGHT", -4, 0)
    eb:SetFont(ns.FONT[600], 12, "")
    eb:SetJustifyH("CENTER")
    eb:SetAutoFocus(false)
    eb:SetNumeric(true)
    eb:SetMaxLetters(2)
    ns.Fill(eb, C.input)
    ns.Border(eb, C.border)
    local px = ns.Text(row, 11, 600, C.mute)
    px:SetPoint("RIGHT", eb, "LEFT", -4, 0)
    px:SetText("px")
    local function show() eb:SetText(tostring(math.floor(ns:AGet(key, def) + 0.5))) end
    eb:SetScript("OnEnterPressed", function(self)
        local v = tonumber(self:GetText())
        self:ClearFocus()
        if v then
            v = math.max(lo, math.min(hi, math.floor(v)))
            ns:SetAppearanceUndo(key, v, label)
            ns:AppearanceChanged()
        end
        show()
    end)
    eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() show() end)
    eb:SetScript("OnEditFocusGained", function(self) ns.SetBorderColor(self, C.accent) self:HighlightText() end)
    eb:SetScript("OnEditFocusLost", function(self) ns.SetBorderColor(self, C.border) show() end)
    local prev = row.Update
    function row:Update() if prev then prev(self) end show() end
    help(eb, row.helpText)
    return eb
end
local function tlSwitch(row, isOn, onClick)
    local sw = CreateFrame("Button", nil, row)
    sw:SetSize(30, 16)
    sw:SetPoint("RIGHT", -4, 0)
    sw.track = ns.Tex(sw, C.border, "ARTWORK")
    sw.track:SetAllPoints()
    sw.knob = ns.Tex(sw, C.mute, "OVERLAY")
    sw.knob:SetSize(12, 12)
    sw:SetScript("OnClick", onClick)
    local prev = row.Update
    function row:Update()
        if prev then prev(self) end
        local on = isOn()
        sw.knob:ClearAllPoints()
        sw.knob:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        local c, k = on and C.accent or C.border, on and C.white or C.mute
        sw.track:SetColorTexture(c[1], c[2], c[3])
        sw.knob:SetColorTexture(k[1], k[2], k[3])
    end
end
local function tlBuild(w, page)
    local box = CreateFrame("Frame", nil, w)
    box:SetPoint("TOPLEFT", 1, -30)
    box:SetPoint("TOPRIGHT", -1, -30)
    box.rows = {}
    local y = 6
    local function row(label, helpText, cond)
        local r = CreateFrame("Frame", nil, box)
        r:SetHeight(ROW_H)
        r:EnableMouse(true)
        r.helpText = helpText
        r.cond = cond
        r.label = ns.Text(r, 12, 600)
        r.label:SetPoint("LEFT", 0, 0)
        r.label:SetText(ns.L(label))
        help(r, helpText)
        box.rows[#box.rows + 1] = r
        return r
    end
    local own = function(k) return "t." .. page .. "." .. k end
    miniSlider(row("Background opacity", "Opacity of the window background image in this tab only."), own("bgAlpha"), 0.6, "Background opacity")
    local lt = row("List/Tab opac/blur", "Opacity and blur of the tab bar (and of the list of this tab) in this tab only.")
    miniSlider(lt, own("listGlass"), 0, "List/Tab opac/blur", nil, TWO_W)
    miniSlider(lt, own("tabsAlpha"), 1, "List/Tab opac/blur", TWO_X, TWO_W)
    if page == "calendar" then
        local kr = row("Lockouts", "Alternate lockout weeks in the calendar (Wednesday to Tuesday).")
        local kb = swatch(kr, "lockB") kb:SetPoint("RIGHT", -4, 0)
        local ka = swatch(kr, "lockA") ka:SetPoint("RIGHT", kb, "LEFT", -4, 0)
        w.swatches[#w.swatches + 1] = ka
        w.swatches[#w.swatches + 1] = kb
    elseif page == "comps" then
        miniSlider(row("Comp images", "Opacity of the raid image behind each comp."), "compAlpha", 0.3, "Comp images")
        numBox(row("Raid buff icons size", "Size of the raid buff and debuff icons (pixels)."), "buffSizeR", 16, 10, 32, "Raid buff icons size")
        numBox(row("Group buff icons size", "Size of the buff icons of each group (pixels)."), "buffSizeG", 13, 8, 28, "Group buff icons size")
        numBox(row("Buff frame thickness", "Thickness of the green / red frame around the buff icons (pixels)."), "buffBorder", 1, 1, 4, "Buff frame thickness")
        miniSlider(row("Buff frame color", "Intensity of the green / red frame color: 100% = normal, 0% = black."), "buffInt", 1, "Buff frame color")
        miniSlider(row("Buff icons color", "Intensity of the buff icon colors: 100% = normal, 0% = black."), "buffIconInt", 1, "Buff icons color")
    elseif page == "assigns" then
        tlSwitch(row("Assign's Thematic Background", "In the Assigns tab, the window background becomes the image of the raid instead of the general background. The placement of the image is edited in Guild Tool."),
            function() return ns.db.appearance.assignNoBg and true or false end,
            function() ns:SetAppearanceUndo("assignNoBg", not ns.db.appearance.assignNoBg, "Assign's Thematic Background") ns:AppearanceChanged() end)
    elseif page == "members" then
        local mb = row("Members Background opac/blur", "Members: opacity and blur of the background of the character list.")
        miniSlider(mb, "membersBlur", 0.6, "Members Background opac/blur", nil, TWO_W)
        miniSlider(mb, "membersAlpha", 0.55, "Members Background opac/blur", TWO_X, TWO_W)
        local dr = row("Char details opac/blur", "Members, character details: opacity and blur of the frames of the talents and of the attendance.")
        miniSlider(dr, "detBlur", 0, "Char details opac/blur", nil, TWO_W)
        miniSlider(dr, "detAlpha", 0.22, "Char details opac/blur", TWO_X, TWO_W)
        miniSlider(row("Talent background", "Opacity of the talent tree backgrounds (Members, character details)."), "talentBg", 0.35, "Talent background")
        tlSwitch(row("Members custom background", "Show the background pictures chosen by the players for their characters (Members, character details)."),
            function() return not ns.db.appearance.charImgOff end,
            function() ns:SetAppearanceUndo("charImgOff", not ns.db.appearance.charImgOff, "Members custom background") ns:AppearanceChanged() end)
        -- seulement si l'interrupteur est actif
        local cb = row("Custom Background opac/blur", "Opacity and blur of the background picture of a character (Members, character details).",
            function() return not ns.db.appearance.charImgOff end)
        miniSlider(cb, "charImgBlur", 0, "Custom Background opac/blur", nil, TWO_W)
        miniSlider(cb, "charImgA", 0.5, "Custom Background opac/blur", TWO_X, TWO_W)
    elseif page == "loots" then
        local lr = row("List opac/blur", "Opacity and blur of the item lines (History), of the raid and boss bars (Boss) and of the player frames (Player).")
        miniSlider(lr, "lootBlur", 0, "List opac/blur", nil, TWO_W)
        miniSlider(lr, "lootAlpha", 0.85, "List opac/blur", TWO_X, TWO_W)
    end
    function box:Layout()
        local yy = 6
        for _, r in ipairs(self.rows) do
            local show = not r.cond or r.cond()
            r:SetShown(show)
            if show then
                r:ClearAllPoints()
                r:SetPoint("TOPLEFT", 10, -yy) r:SetPoint("TOPRIGHT", -10, -yy)
                yy = yy + ROW_H
            end
        end
        self:SetHeight(yy + 6)
        return yy + 6
    end
    return box
end
function ns:CreateTabLook()
    local w = CreateFrame("Frame", nil, self.frame)
    w:SetFrameLevel(self.frame:GetFrameLevel() + 80)
    w:SetSize(380, 200)
    w:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -10, -ns.BODY_TOP - 6)
    w:EnableMouse(true)
    ns.Fill(w, C.bg, 0.97)
    ns.Border(w, C.hl)
    ns.HighlightBorder(w)
    w:Hide()
    local bar = CreateFrame("Frame", nil, w)
    bar:SetPoint("TOPLEFT", 1, -1) bar:SetPoint("TOPRIGHT", -1, -1)
    bar:SetHeight(28)
    ns.Fill(bar, C.head)
    w.title = ns.Text(bar, 12.5, 700, C.white)
    w.title:SetPoint("LEFT", 10, 0)
    local close = ns.IconButton(bar, "×", 22, ns.L("Close (Esc)"))
    close:SetPoint("RIGHT", -3, 0)
    close:SetScript("OnClick", function() w:Hide() end)
    w.note = ns.Text(w, 10, 400, C.mute)
    w.note:SetPoint("BOTTOMLEFT", 10, 8)
    w.swatches, w.boxes = {}, {}
    w:EnableKeyboard(true)
    w:SetScript("OnKeyDown", function(f, key)
        if InCombatLockdown() then return end
        if key == "ESCAPE" then f:SetPropagateKeyboardInput(false) f:Hide() else f:SetPropagateKeyboardInput(true) end
    end)
    self.tabLook = w
    -- engrenage à droite de la barre indicateur ; le texte d'info de la barre passe à sa gauche
    local b = ns.IconBox(self.sub, "Interface\\AddOns\\GuildTool\\media\\gear", "Appearance of this tab", 28, 24)
    b:SetPoint("RIGHT", -6, 0)
    b:SetScript("OnClick", function() if w:IsShown() and w.page == ns.db.ui.page then w:Hide() else ns:FillTabLook() end end)
    self.sub.info:ClearAllPoints()
    self.sub.info:SetPoint("RIGHT", b, "LEFT", -10, 0)
    self.tabLookBtn = b
end
-- contenu de la fenêtre pour l'onglet affiché (construit une fois par onglet)
function ns:FillTabLook()
    local w = self.tabLook
    if not w then return end
    local page = self.db.ui.page
    w.page = page
    for p, box in pairs(w.boxes) do box:SetShown(p == page) end
    w.boxes[page] = w.boxes[page] or tlBuild(w, page)
    local box = w.boxes[page]
    box:Show()
    ns.SetFont(w.title, 12.5, 700)
    w.title:SetText(ns.L("Appearance") .. "  ·  " .. ns.L(TL_NAME[page] or page))
    ns.SetFont(w.note, 10, 400)
    w.note:SetText(ns.L("Only this tab · general settings: Settings"))
    local h = box:Layout()
    w:SetHeight(30 + h + 26)
    w:Show()
    self:UpdateSwatches(w)
    for _, r in ipairs(box.rows) do if r.Update then r:Update() end end
end

function ns:UpdateSettings()
    -- fenêtre d'apparence de l'onglet ouverte : ses curseurs suivent (Undo, changements)
    local tl = self.tabLook
    if tl and tl:IsShown() then
        if tl.page ~= self.db.ui.page then tl:Hide() else self:FillTabLook() end
    end
    local w = self.settingsPage
    if not (w and w:IsShown()) then return end
    self:UpdateSwatches()
    for _, r in ipairs(w.rows) do r:Update() end
    local last = UNDO[#UNDO]
    w.undo:SetAlpha(last and 1 or 0.4)
    w.undo:SetEnabled(last and true or false)
    w.undoInfo:SetText(last and ns.L("Undo: {0}", ns.L(last.label)) or "")
end

-- Sélecteur de couleur du jeu (API moderne SetupColorPickerAndShow, sinon l'ancienne)
function ns:PickColor(key)
    local c = ns.Hex((self.db.appearance[key] or "#000000"):gsub("#", ""))
    local label = key == "base" and "Base color" or (key == "hl" or key == "hl2") and "Highlight" or "Lockout colors"
    local function apply(r, g, b)
        self:SetAppearanceUndo(key, ("#%02x%02x%02x"):format(math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5), math.floor(b * 255 + 0.5)), label)
        -- surbrillance : appliquée tout de suite
        if key == "hl" then ns.ApplyHighlight(self.db.appearance.hl) ns.RepaintHighlight() end
        self:Refresh()
    end
    local info = {
        r = c[1], g = c[2], b = c[3], hasOpacity = false,
        swatchFunc = function() apply(ColorPickerFrame:GetColorRGB()) end,
        cancelFunc = function() apply(c[1], c[2], c[3]) end,
    }
    if ColorPickerFrame.SetupColorPickerAndShow then
        ColorPickerFrame:SetupColorPickerAndShow(info)
    else
        ColorPickerFrame.func, ColorPickerFrame.cancelFunc, ColorPickerFrame.hasOpacity = info.swatchFunc, info.cancelFunc, false
        ColorPickerFrame:SetColorRGB(c[1], c[2], c[3])
        ColorPickerFrame:Show()
    end
end

---------------------------------------------------------------------------
-- Droits d'officier temporaires (officiers) : donnés / retirés ici, écrits dans GuildToolDB.grantQueue au /reload,
-- envoyés une seule fois par l'exe avec leur date ; le serveur garde le changement le plus récent (une demande plus
-- ancienne arrivée en retard est ignorée). Rien ne passe par le chat addon : pas d'écho entre joueurs.
---------------------------------------------------------------------------
-- État voulu d'un membre : dernière demande en attente ici, sinon liste de l'exe ; pending = pas encore envoyée
function ns:GrantState(id)
    local on, pending
    for _, q in ipairs(self.db.grantQueue or {}) do
        if q.id == id then on, pending = q.on and true or false, true end
    end
    if pending then return on, true end
    for _, m in ipairs(self.db.guildMembers or {}) do
        if m.id == id then return m.g and true or false, false end
    end
    return false, false
end

-- Une seule demande par membre dans la file (la nouvelle remplace la précédente non envoyée) ; toujours ajoutée,
-- même si elle revient à l'état connu : celui-ci peut dater d'avant une demande déjà envoyée par l'exe
function ns:QueueGrant(id, on)
    if not self:MayEdit() then return end
    local q = self.db.grantQueue or {}
    self.db.grantQueue = q
    for i = #q, 1, -1 do if q[i].id == id then table.remove(q, i) end end
    q[#q + 1] = { id = id, on = on and true or false, t = time() }
    self:RefreshGrants()
end

local GRANT_ROW = 24
function ns:CreateGrants(w, child)
    local L = ns.L
    local g = CreateFrame("Frame", nil, child)
    g:SetPoint("TOPLEFT", 0, -w.grantY)
    g:SetPoint("TOPRIGHT", 0, -w.grantY)
    g:SetHeight(1)
    w.grants = g
    g.title = ns.Text(g, 9.5, 700, C.mute)
    g.title:SetPoint("TOPLEFT", 10, -8)
    g.title:SetText(strupper(L("Temporary officers")))
    local l = ns.Tex(g, C.border, "ARTWORK")
    l:SetPoint("TOPLEFT", 10, -22) l:SetPoint("TOPRIGHT", -10, -22) l:SetHeight(1)
    g:EnableMouse(true)
    help(g, "Officer rights given by an officer (on top of the Discord officer role). Sent by Guild Tool after /reload; the most recent change wins.")
    -- recherche d'un membre à promouvoir (nom Discord ou perso)
    local eb = CreateFrame("EditBox", nil, g)
    eb:SetHeight(22)
    eb:SetFont(ns.FONT[500], 11.5, "")
    eb:SetTextInsets(6, 6, 0, 0)
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(30)
    ns.Fill(eb, C.input)
    ns.Border(eb, C.border)
    eb.ph = ns.Text(eb, 11.5, 400, C.mute)
    eb.ph:SetPoint("LEFT", 6, 0)
    eb.ph:SetText(L("Add a member..."))
    eb:SetScript("OnTextChanged", function(self) self.ph:SetShown(self:GetText() == "") ns:RefreshGrants() end)
    eb:SetScript("OnEscapePressed", function(self) self:SetText("") self:ClearFocus() end)
    eb:SetScript("OnEnterPressed", function(self)
        local c = g.cands and g.cands[1]
        if c then ns:QueueGrant(c.id, true) self:SetText("") end
        self:ClearFocus()
    end)
    g.search = eb
    g.note = ns.Text(g, 10.5, 400, C.mute)
    g.note:SetWordWrap(true)
    g.note:SetJustifyH("LEFT")
    g.reload = ns.Button(g, L("Reload to send"), 130, 22)
    g.reload:SetScript("OnClick", function() ReloadUI() end)
    g.rows = {}
end

local function grantRow(g, i)
    local r = g.rows[i]
    if r then return r end
    r = CreateFrame("Frame", nil, g)
    r:SetHeight(GRANT_ROW)
    r.name = ns.Text(r, 12, 600)
    r.name:SetPoint("LEFT", 10, 0)
    r.chars = ns.Text(r, 10.5, 400, C.mute)
    r.chars:SetPoint("LEFT", r.name, "RIGHT", 8, 0)
    r.chars:SetWordWrap(false)
    r.btn = ns.IconButton(r, "×", 20)
    r.btn:SetPoint("RIGHT", -8, 0)
    r.state = ns.Text(r, 10.5, 600, C.mute)
    r.state:SetPoint("RIGHT", r.btn, "LEFT", -6, 0)
    r.chars:SetPoint("RIGHT", r.state, "LEFT", -8, 0)
    r.btn:SetScript("OnClick", function(self) ns:QueueGrant(r.id, r.add) end)
    r.btn:HookScript("OnEnter", function(self)
        ns.TipOwner(self)
        GameTooltip:SetText(ns.L(r.add and "Give the officer rights" or "Remove the officer rights"), 1, 1, 1)
        GameTooltip:Show()
    end)
    g.rows[i] = r
    return r
end

function ns:RefreshGrants()
    local w = self.settingsPage
    local g = w and w.grants
    if not g then return end
    local L = ns.L
    local members = self.db.guildMembers or {}
    -- officiers seulement (l'exe n'envoie la liste qu'à un compte officier)
    if not (self:MayEdit() and #members > 0) then
        g:Hide()
        w.scroll.child:SetHeight(w.grantY + 40)
        return
    end
    g:Show()
    local y, n = 28, 0
    local function place(m, add, stateText)
        n = n + 1
        local r = grantRow(g, n)
        r.id, r.add = m.id, add
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, -y) r:SetPoint("TOPRIGHT", 0, -y)
        ns.SetFont(r.name, 12, 600)
        r.name:SetText(m.n or "?")
        ns.SetFont(r.chars, 10.5, 400)
        r.chars:SetText(table.concat(m.chars or {}, ", "))
        ns.SetFont(r.state, 10.5, 600)
        r.state:SetText(stateText or "")
        r.btn.label:SetText(add and "+" or "×")
        local c = add and C.mute or C.text
        r.name:SetTextColor(c[1], c[2], c[3])
        r:Show()
        y = y + GRANT_ROW
    end
    -- droits donnés (ou demandés ici) ; retrait en attente : grisé, « + » pour revenir dessus
    local pendingAny = false
    for _, m in ipairs(members) do
        local on, pending = self:GrantState(m.id)
        if pending then pendingAny = true end
        if on or (pending and m.g) then
            place(m, not on, pending and L(on and "Pending" or "Removal pending") or nil)
        end
    end
    -- recherche : membres sans droits d'officier (ni admin, ni rôle officier), 6 au plus
    y = y + 6
    g.search:ClearAllPoints()
    g.search:SetPoint("TOPLEFT", 10, -y) g.search:SetPoint("TOPRIGHT", -10, -y)
    y = y + 28
    local q = strlower(g.search:GetText() or "")
    g.cands = {}
    if q ~= "" then
        for _, m in ipairs(members) do
            local hit = strlower(m.n or ""):find(q, 1, true)
            for _, c in ipairs(m.chars or {}) do hit = hit or strlower(c):find(q, 1, true) end
            if hit and not (m.a or m.o) and not self:GrantState(m.id) and #g.cands < 6 then g.cands[#g.cands + 1] = m end
        end
    end
    for _, m in ipairs(g.cands) do place(m, true) end
    for i = n + 1, #g.rows do g.rows[i]:Hide() end
    -- envoi : au /reload (SavedVariables), par l'exe
    y = y + 4
    g.note:ClearAllPoints()
    g.note:SetPoint("TOPLEFT", 10, -y) g.note:SetPoint("TOPRIGHT", -10, -y)
    ns.SetFont(g.note, 10.5, 400)
    g.note:SetText(L(pendingAny and "Pending changes are sent by Guild Tool after /reload." or "Changes are sent by Guild Tool after /reload; the most recent change wins."))
    y = y + g.note:GetStringHeight() + 6
    g.reload:SetShown(pendingAny)
    g.reload:ClearAllPoints()
    g.reload:SetPoint("TOPLEFT", 10, -y)
    if pendingAny then y = y + 28 end
    g:SetHeight(y)
    w.scroll.child:SetHeight(w.grantY + y + 20)
    if w.scroll.UpdateThumb then w.scroll:UpdateThumb() end
end

function ns:ShowSettings()
    local w = self.settingsPage
    if w:IsShown() then w:Hide() return end
    w:Show()
    self:PlaceSettings()
    self:UpdateSettings()
end
