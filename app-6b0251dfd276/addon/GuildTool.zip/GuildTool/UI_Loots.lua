-- GuildTool : onglet Loots — attributions de la base de la guilde (exe) et les miennes plus récentes (/tlc) :
-- icône, objet (infobulle), joueur, réaction, dés (mêmes intentions), date ; barre : lockout, vues History / Player / Items,
-- phase, recherche (UI_LootsTools.lua) ; officiers : « + » ajoute une attribution, double-clic sur le joueur ou la
-- réaction = changer, croix = supprimer (lus par l'exe : GuildToolDB.lootEdits, lootHistory).
local _, ns = ...
local C = ns.C
local GetItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
local GetItemIcon = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
local ROW_H, PAD = 34, 10
local TAB_LABEL = { all = "History", role = "Compare", boss = "Tables", wish = "Wishlist" }
local TAB_ORDER = { "role", "boss", "all", "wish" }
-- réglage de la guilde (officiers, exe) : vue cachée aux membres
local TAB_FLAG = { role = "lootHideCompare", all = "lootHideHistory" }
function ns:LootFlag(k)
    return not self:MayEdit() and (self.db.guildFlags or {})[k] and true or false
end
local KIND = { bis = "Bis", upp = "Up+", up = "Up", os = "Off Spec", pvp = "PvP", mog = "Mog", de = "Disenchant", vendor = "Vendor" }

local function first(n) return n and (n:match("^(%S+)") or n) or "" end
local function ymd(t) return tonumber(date("%Y%m%d", t or 0)) end

-- attributions affichées : base de la guilde + mes attributions arrivées depuis, modifications faites ici
function ns:LootRecords()
    local out, seen, edits = {}, {}, self.db.lootEdits or {}
    local function add(r)
        if not r.k or seen[r.k] then return end
        seen[r.k] = true
        local e = edits[r.k]
        if e and e.deleted then return end
        local c = {}
        for k, v in pairs(r) do c[k] = v end
        if e and e.to then c.to = e.to end
        if e and e.kind then c.kind = e.kind end
        out[#out + 1] = c
    end
    for _, r in ipairs(self.db.lootDB or {}) do add(r) end
    for _, r in ipairs(self.db.lootHistory or {}) do
        -- attributions plus récentes que l'import de l'exe, et celles ajoutées à la main (date libre)
        if ((r.t or 0) > (self.db.lootT or 0) or r.manual) and r.key then
            add({ k = "g:" .. tostring(r.key), id = r.id, name = r.name, link = r.link, t = r.t, to = r.to, kind = r.kind, same = r.same, zone = r.zone, boss = r.boss, raid = r.raid, spec = r.spec })
        end
    end
    table.sort(out, function(a, b) return (a.t or 0) > (b.t or 0) end)
    return out
end

local function classOf(name)
    local r = ns.db.roster and ns.db.roster[name]
    if r and r.c then return r.c end
    local f = first(name)
    for n, x in pairs(ns.db.roster or {}) do if first(n) == f and x.c then return x.c end end
    local c = ns.db.chars and ns.db.chars[name]
    return c and c.c
end

local function setEdit(k, field, value)
    ns.db.lootEdits = ns.db.lootEdits or {}
    local e = ns.db.lootEdits[k] or {}
    e[field], e.t = value, time()
    ns.db.lootEdits[k] = e
    if ns.LogPending then ns:LogPending(ns.L("Loots") .. " · " .. (field == "deleted" and ns.L("Remove") or tostring(value))) end
    ns:RefreshLootsPage()
end
ns.LootSetEdit = setEdit

-- changement du joueur : champ de saisie posé sur le nom, liste filtrée au fil de la frappe
local function openPicker(cell, k)
    local p = ns.lootPick
    if not p then
        p = CreateFrame("EditBox", nil, ns.frame)
        p:SetSize(180, 22)
        p:SetAutoFocus(false)
        p:SetFontObject(ChatFontNormal)
        p:SetTextInsets(6, 6, 0, 0)
        p:SetFrameLevel(ns.frame:GetFrameLevel() + 60)
        ns.Fill(p, C.input)
        ns.Border(p, C.hl)
        local function list()
            local q = strlower(p:GetText() or "")
            local names = {}
            for n, r in pairs(ns.db.roster or {}) do
                if r and r.c and (q == "" or strlower(n):find(q, 1, true)) then names[#names + 1] = n end
            end
            table.sort(names)
            local items = {}
            for i = 1, math.min(25, #names) do
                local n = names[i]
                local cc = ns.ClassColor(ns.db.roster[n].c)
                items[#items + 1] = { text = n, color = cc, func = function() p:Hide() setEdit(p.k, "to", n) end }
            end
            if #items == 0 then items[1] = { text = ns.L("No character found."), func = function() end } end
            ns:OpenMenu(p, items, 200)
        end
        p:SetScript("OnTextChanged", function(self, user) if user then list() end end)
        p:SetScript("OnEscapePressed", function(self) self:Hide() if ns.menu then ns.menu:Hide() end end)
        p:SetScript("OnEnterPressed", function(self)
            local m = ns.menu
            local b = m and m:IsShown() and m.buttons[1]
            if b and b:IsShown() then b:Click() end
        end)
        p:SetScript("OnHide", function(self) self:ClearFocus() end)
        ns.lootPick = p
        p.list = list
    end
    p.k = k
    p:ClearAllPoints()
    p:SetPoint("LEFT", cell, "LEFT", -4, 0)
    p:SetText("")
    p:Show()
    p:SetFocus()
    p.list()
end

-- lignes (History), cadres de joueurs et de réactions (Player), barres de raid / boss (Items) : opacité de leur
-- fond réglable (apparence de l'onglet Loots : « List opac/blur ») ; flou : fond flouté derrière la liste
local LOOK = {}
local function lookFill(f)
    ns.Fill(f, C.panel, (ns.db.appearance or {}).lootAlpha or 0.85)
    LOOK[#LOOK + 1] = f
    return f.bg
end
function ns:LootListLook()
    local ap = self:Look()
    for _, f in ipairs(LOOK) do f.bg:SetColorTexture(C.panel[1], C.panel[2], C.panel[3], ap.lootAlpha or 0.85) end
    for _, area in ipairs({ self.lootsArea, self.lootsRoleArea }) do
        if area then
            if (ap.lootBlur or 0) > 0 then
                self:BlurBehind(area, -6)
                if area.blurTex and area.blurTex:IsShown() then area.blurTex:SetAlpha((ap.bgAlpha or 0.6) * ap.lootBlur) end
            elseif area.blurTex then area.blurTex:Hide() end
        end
    end
end

local function newRow(parent)
    local r = CreateFrame("Frame", nil, parent)
    r:SetHeight(ROW_H)
    lookFill(r)
    ns.Border(r, C.border)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(26, 26)
    r.icon:SetPoint("LEFT", 6, 0)
    -- objet : infobulle au survol
    r.item = CreateFrame("Frame", nil, r)
    r.item:SetPoint("LEFT", 4, 0)
    r.item:SetSize(360, ROW_H - 4)
    r.item:EnableMouse(true)
    r.item:SetScript("OnEnter", function(self)
        ns.TipOwner(self)
        GameTooltip:SetHyperlink(r.rec.link or ("item:" .. (r.rec.id or 0)))
        GameTooltip:Show()
    end)
    r.item:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r.name = ns.Text(r, 12.5, 700)
    r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
    r.name:SetWidth(320)
    -- joueur : double-clic = changer (officiers)
    r.to = CreateFrame("Button", nil, r)
    r.to:SetSize(230, ROW_H - 4)
    r.to:SetPoint("LEFT", 400, 0)
    r.to.text = ns.Text(r.to, 12, 700)
    r.to.text:SetPoint("LEFT", 0, 0)
    r.to.kind = ns.Text(r.to, 10.5, 500, C.mute)
    r.to:SetScript("OnDoubleClick", function(self) if ns:MayEdit() then openPicker(self, r.rec.k) end end)
    r.to:SetScript("OnEnter", function(self)
        if ns:MayEdit() then ns.TipOwner(self) GameTooltip:SetText(ns.L("Double-click to give it to another character"), 1, 1, 1, 1, true) GameTooltip:Show() end
    end)
    r.to:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- réaction : colonne alignée, double-clic = changer (officiers) ; Off Spec : icône de la spé choisie
    r.kind = CreateFrame("Button", nil, r)
    r.kind:SetSize(110, ROW_H - 4)
    r.kind.icon = r.kind:CreateTexture(nil, "ARTWORK")
    r.kind.icon:SetSize(16, 16)
    r.kind.icon:SetPoint("LEFT", 0, 0)
    r.kind.text = ns.Text(r.kind, 11.5, 700)
    r.kind:SetScript("OnDoubleClick", function(self) if ns:MayEdit() then ns:LootKindMenu(self, r.rec.k) end end)
    r.kind:SetScript("OnEnter", function(self)
        if ns:MayEdit() then ns.TipOwner(self) GameTooltip:SetText(ns.L("Double-click to change the roll"), 1, 1, 1, 1, true) GameTooltip:Show() end
    end)
    r.kind:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- dés : joueurs qui avaient la même intention
    r.dice = CreateFrame("Frame", nil, r)
    r.dice:SetSize(20, 20)
    r.dice:SetPoint("LEFT", 650, 0)
    r.dice.t = r.dice:CreateTexture(nil, "ARTWORK")
    r.dice.t:SetAllPoints()
    r.dice.t:SetTexture("Interface\\Buttons\\UI-GroupLoot-Dice-Up")
    r.dice:EnableMouse(true)
    r.dice:SetScript("OnEnter", function(self)
        local same = r.rec.same or {}
        ns.TipOwner(self)
        GameTooltip:SetText(ns.L("Same roll: {0}", #same > 0 and table.concat(same, ", ") or ns.L("Nobody else")), 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    r.dice:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r.date = ns.Text(r, 11, 500, C.mute)
    r.date:SetPoint("LEFT", 700, 0)
    -- croix (officiers) : 1er clic « Confirm », 2e clic supprimé
    r.del = ns.Button(r, "×", 64, 22)
    r.del:SetPoint("RIGHT", -6, 0)
    r.del:SetScript("OnClick", function(self)
        if self.armed then self.armed = nil setEdit(r.rec.k, "deleted", true) return end
        self.armed = true
        self.label:SetText(ns.L("Confirm"))
        C_Timer.After(4, function() self.armed = nil self.label:SetText("×") end)
    end)
    return r
end

-- loots gardés par les filtres de l'onglet (outils de consultation, propres à la session) : phase (« All » par
-- défaut ; zone du loot = un de ses raids, zone inconnue : gardé), lockout (« All » par défaut)
local function phaseRaids()
    local ph = ns.lootPhase and ns.PHASES[ns.lootPhase]
    return ph and ph.raids
end
local function inPhase(r, raids)
    if not raids or not r.zone then return true end
    local z = strlower(r.zone)
    for _, x in ipairs(raids) do
        for _, n in ipairs({ x.name or "", x.short or "" }) do
            n = strlower(n)
            if n ~= "" and (z:find(n, 1, true) or n:find(z, 1, true)) then return true end
        end
    end
    return false
end
function ns:LootFiltered()
    local out, raids = {}, phaseRaids()
    for _, r in ipairs(self:LootRecords()) do
        if (not self.lootWeek or self:WeekStart(r.t or 0) == self.lootWeek) and inPhase(r, raids) then out[#out + 1] = r end
    end
    return out
end

-- lockouts (clic sur le titre) : « All lockouts » en tête (le plus récent), puis de l'actuel vers le passé, liste
-- qui défile (6 mois au moins, jusqu'au plus ancien loot) ; refermée quand la souris s'en éloigne
function ns:ShowLootWeekMenu()
    local thisWeek, counts = self:WeekStart(time()), {}
    local oldest = thisWeek - 26 * ns.WEEK
    for _, r in ipairs(self:LootRecords()) do
        local w = self:WeekStart(r.t or 0)
        counts[w] = (counts[w] or 0) + 1
        if w < oldest then oldest = w end
    end
    local items = { { text = ns.L("All lockouts"), sel = not self.lootWeek, func = function() ns.lootWeek = nil end } }
    for w = thisWeek, oldest, -ns.WEEK do
        local l, r = self:WeekParts(w)
        items[#items + 1] = { left = l, right = r, count = counts[w] and tostring(counts[w]) or nil, sel = self.lootWeek == w,
                              now = w == thisWeek, func = function() ns.lootWeek = w end }
    end
    self:TitlePicker(self.sub.titleBtn, items, self.sub.title)
end

-- raids faits par perso : compos visibles (validées) où il est placé ; phase choisie : seulement ses raids
local function raidCounts()
    local raids, keys, n = phaseRaids(), nil, {}
    if raids then keys = {} for _, x in ipairs(raids) do keys[x.key] = true end end
    for _, w in pairs(ns.db.weeks) do
        for _, c in ipairs(w.comps or {}) do
            if c.valid and not c.deleted and (not keys or keys[c.raid]) then
                local seen = {}
                for _, name in pairs(c.c or {}) do
                    if type(name) == "string" and not seen[name] then seen[name] = true n[name] = (n[name] or 0) + 1 end
                end
            end
        end
    end
    return n
end

-- bouton sélectionné : bordure Highlight, texte blanc
local function setTab(b, on)
    -- onglet de vue (surbrillance des onglets de page) ou bouton à bordure
    if b.sel then ns.ShowSelection(b, on) else ns.SetBorderColor(b, on and C.hl or C.border) end
    local c = on and C.white or C.mute
    if b.label then b.label:SetTextColor(c[1], c[2], c[3]) end
end
-- bouton carré « check all » (couleur du texte des boutons non choisis, Highlight quand tout est choisi)
local function checkAll(parent, tip, onClick)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(24, 24)
    ns.Fill(b, C.input)
    ns.Border(b, C.border)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(18, 18)
    b.icon:SetPoint("CENTER")
    b.icon:SetTexture("Interface\\AddOns\\GuildTool\\media\\checkall")
    b:SetScript("OnClick", onClick)
    b:SetScript("OnEnter", function(f)
        ns.SetBorderColor(f, C.hl)
        ns.TipOwner(f) GameTooltip:SetText(ns.L(tip), 1, 1, 1) GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function(f) ns.SetBorderColor(f, f.on and C.hl or C.border) GameTooltip:Hide() end)
    function b:Paint(on)
        self.on = on
        local c = on and C.hl or C.mute
        self.icon:SetVertexColor(c[1], c[2], c[3])
        ns.SetBorderColor(self, on and C.hl or C.border)
    end
    return b
end

-- défilement vertical (molette) et horizontal (Maj + molette) ; Ctrl + molette : échelle de la fenêtre
local function scroll2D(parent)
    local s = CreateFrame("ScrollFrame", nil, parent)
    local child = CreateFrame("Frame", nil, s)
    child:SetSize(1, 1)
    s:SetScrollChild(child)
    s.child = child
    s.hthumb = ns.Tex(s, { 0.29, 0.30, 0.345 }, "OVERLAY")
    s.hthumb:SetHeight(4)
    function s:Thumb()
        local range, w = self:GetHorizontalScrollRange(), self:GetWidth()
        self.hthumb:SetShown(range > 0)
        if range <= 0 then return end
        local tw = math.max(30, w * w / (w + range))
        self.hthumb:SetWidth(tw)
        self.hthumb:ClearAllPoints()
        self.hthumb:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", (w - tw) * self:GetHorizontalScroll() / range, 0)
    end
    s:EnableMouseWheel(true)
    s:SetScript("OnMouseWheel", function(self, d)
        if IsControlKeyDown() and ns.WheelScaleFrom(self, d) then return end
        if IsShiftKeyDown() then
            self:SetHorizontalScroll(math.max(0, math.min(self:GetHorizontalScrollRange(), self:GetHorizontalScroll() - d * 90)))
        else
            self:SetVerticalScroll(math.max(0, math.min(self:GetVerticalScrollRange(), self:GetVerticalScroll() - d * 60)))
        end
        self:Thumb()
    end)
    return s
end

function ns:CreateLootsPage(page)
    local sf = ns.ScrollArea(page)
    sf:SetPoint("TOPLEFT", PAD, -PAD)
    sf:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    self.lootsArea, self.lootsRows, self.lootsCols = sf, {}, {}
    self.lootsBars, self.lootsItems = {}, {}
    self.lootsEmpty = ns.Text(page, 12, 500, C.mute)
    self.lootsEmpty:SetPoint("TOPLEFT", PAD + 6, -PAD - 8)
    -- barre : lockout (titre, flèches), sous-onglets, phase (comme Compos, « All » après la dernière : toutes)
    -- phase (comme l'appli) : « PHASE » + 5 boutons autour de la phase choisie, « All » après la dernière (toutes),
    -- molette = phase suivante / précédente ; juste à droite du lockout
    local function allIdx() return #ns.PHASES + 1 end
    local w = CreateFrame("Frame", nil, self.sub)
    w:SetSize(200, ns.TABS_H)
    w:SetPoint("LEFT", self.sub.next, "RIGHT", 14, 0)
    w:EnableMouseWheel(true)
    w.label = ns.Text(w, 9.5, 700, C.mute)
    w.label:SetPoint("LEFT", 0, 0)
    w.btns = {}
    local function setPhase(p)
        p = math.max(1, math.min(allIdx(), p))
        ns.lootPhase = p < allIdx() and p or nil
        ns:Refresh()
    end
    for j = 1, 5 do
        local b = CreateFrame("Button", nil, w)
        b:SetSize(24, 20)
        b.bg = ns.Fill(b, C.input, 0.8)
        ns.Border(b, C.border)
        b.label = ns.Text(b, 10, 700, C.mute)
        b.label:SetPoint("CENTER")
        b:SetScript("OnClick", function(s) if s.p then setPhase(s.p) end end)
        b:SetScript("OnEnter", function(s) if not s.on then ns.SetBorderColor(s, C.hl) end end)
        b:SetScript("OnLeave", function(s) if not s.on then ns.SetBorderColor(s, C.border) end end)
        b:EnableMouseWheel(false)
        w.btns[j] = b
    end
    w:SetScript("OnMouseWheel", function(_, d) setPhase((ns.lootPhase or allIdx()) - d) end)
    function w:Update()
        local cur = ns.lootPhase or allIdx()
        ns.SetFont(self.label, 9.5, 700)
        self.label:SetText(strupper(ns.L("Phase")))
        local x = self.label:GetStringWidth() + 10
        for j, b in ipairs(self.btns) do
            local i = cur + j - 3
            b:ClearAllPoints()
            b:SetPoint("LEFT", x, 0)
            x = x + 27
            -- hors des phases : case vide (les autres gardent leur place)
            if i < 1 or i > allIdx() then b.p = nil b:Hide()
            else
                b.p, b.on = i, i == cur
                ns.SetFont(b.label, 10, 700)
                b.label:SetText(i == allIdx() and ns.L("All") or tostring(i))
                -- choisie : fond blanc, texte sombre (comme le détail des persos de Members)
                if b.on then
                    b.bg:SetColorTexture(1, 1, 1, 1)
                    b.label:SetTextColor(0.09, 0.09, 0.11)
                    ns.SetBorderColor(b, C.white)
                else
                    b.bg:SetColorTexture(C.input[1], C.input[2], C.input[3], 0.8)
                    b.label:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
                    ns.SetBorderColor(b, C.border)
                end
                b:Show()
            end
        end
        self:SetWidth(x)
    end
    w:Hide()
    self.lootsWheel = w
    -- vues affichées comme des onglets (même surbrillance que les onglets de page), entre le lockout et la phase
    local tabs = CreateFrame("Frame", nil, self.sub)
    tabs:SetSize(4 * 80, ns.TABS_H)
    tabs:SetPoint("LEFT", self.sub, "CENTER", -290 - 94, 0)
    -- Compare, Tables, History, Wishlist
    local prev
    for _, key in ipairs(TAB_ORDER) do
        local b = CreateFrame("Button", nil, tabs)
        b:SetHeight(ns.TABS_H)
        ns.Selection(b, nil, C.hl)
        b.label = ns.Text(b, 12.5, 600)
        b.label:SetPoint("CENTER")
        b.label:SetText(ns.L(TAB_LABEL[key]))
        b:SetWidth(b.label:GetStringWidth() + 32)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 2, 0) else b:SetPoint("LEFT", 0, 0) end
        b:SetScript("OnClick", function() ns.lootTab = key ns:Refresh() end)
        b:SetScript("OnEnter", function() b.label:SetTextColor(1, 1, 1) end)
        b:SetScript("OnLeave", function() setTab(b, (ns.lootTab or "all") == key) end)
        tabs[key], prev = b, b
    end
    tabs:Hide()
    self.lootsTabs = tabs
    -- vue Role : check all + rôles, écart, check all + classes (aucune = toutes), priorité de tri des persos
    local rb = CreateFrame("Frame", nil, page)
    rb:SetPoint("TOPLEFT", PAD, -PAD)
    rb:SetPoint("TOPRIGHT", -PAD, -PAD)
    rb:SetHeight(26)
    rb.allRoles = checkAll(rb, "All roles", function()
        local all = true
        for _, ro in ipairs(ns.ROLE_ORDER) do if not ns.db.ui.lootRoles[ro] then all = false end end
        for _, ro in ipairs(ns.ROLE_ORDER) do ns.db.ui.lootRoles[ro] = not all or nil end
        ns:RefreshLootsPage()
    end)
    rb.allRoles:SetPoint("LEFT", 0, 0)
    rb.roles = {}
    for i, ro in ipairs(ns.ROLE_ORDER) do
        local b = ns.Button(rb, ns.L(ro), 88, 24)
        b:SetPoint("LEFT", 28 + (i - 1) * 92, 0)
        b.label:ClearAllPoints()
        b.label:SetPoint("LEFT", 26, 0)
        local t = b:CreateTexture(nil, "OVERLAY")
        t:SetSize(16, 16)
        t:SetPoint("LEFT", 6, 0)
        t:SetTexture(ns.ROLE_ICON[ro])
        b:SetScript("OnClick", function() ns.db.ui.lootRoles[ro] = not ns.db.ui.lootRoles[ro] or nil ns:RefreshLootsPage() end)
        b:HookScript("OnLeave", function() setTab(b, ns.db.ui.lootRoles[ro]) end)
        rb.roles[ro] = b
    end
    -- écart de deux boutons « check all » entre le dernier rôle et le 2e check all
    local cx = 28 + 4 * 92 - 4 + 48
    rb.allClasses = checkAll(rb, "All classes", function()
        local all = true
        for _, c in ipairs(ns.CLASS_ORDER) do if not ns.db.ui.lootClasses[c] then all = false end end
        for _, c in ipairs(ns.CLASS_ORDER) do ns.db.ui.lootClasses[c] = not all or nil end
        ns:RefreshLootsPage()
    end)
    rb.allClasses:SetPoint("LEFT", cx, 0)
    rb.classes = {}
    for i, cl in ipairs(ns.CLASS_ORDER) do
        local b = CreateFrame("Button", nil, rb)
        b:SetSize(24, 24)
        b:SetPoint("LEFT", cx + 28 + (i - 1) * 28, 0)
        ns.Fill(b, C.input)
        ns.Border(b, C.border)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetSize(18, 18)
        b.icon:SetPoint("CENTER")
        b.icon:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
        local tc = CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[cl]
        if tc then b.icon:SetTexCoord(tc[1], tc[2], tc[3], tc[4]) end
        b:SetScript("OnClick", function() ns.db.ui.lootClasses[cl] = not ns.db.ui.lootClasses[cl] or nil ns:RefreshLootsPage() end)
        b:SetScript("OnEnter", function(f)
            ns.SetBorderColor(f, C.hl)
            ns.TipOwner(f) GameTooltip:SetText(ns.L(ns.CLASS_NAME[cl] or cl), 1, 1, 1) GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function(f) setTab(f, ns.db.ui.lootClasses[cl]) GameTooltip:Hide() end)
        rb.classes[cl] = b
    end
    rb.sortLabel = ns.Text(rb, 10, 600, C.mute)
    rb.sortLabel:SetPoint("LEFT", cx + 28 + #ns.CLASS_ORDER * 28 + 20, 0)
    rb.chips = ns.ChipBar(rb, function() return ns.db.ui.lootOrder end, function() ns:RefreshLootsPage() end)
    rb.chips:SetPoint("LEFT", rb.sortLabel, "RIGHT", 10, 0)
    rb:Hide()
    self.lootsRoleBar = rb
    -- colonnes des persos : défilement vertical et horizontal (Maj + molette)
    local rs = scroll2D(page)
    rs:SetPoint("TOPLEFT", PAD, -PAD - 36)
    rs:SetPoint("BOTTOMRIGHT", -PAD, PAD)
    rs:Hide()
    self.lootsRoleArea = rs
    -- mesure des noms d'objets (largeur de la colonne)
    self.lootsMeasure = ns.Text(page, 12.5, 700)
    self.lootsMeasure:Hide()
    -- recherche à droite de la phase (vues Player et Items)
    self:CreateLootSearch()
end

-- colonne d'un perso (vue Role) : nom Discord, icône de spé + nom, compteurs, puis ses loots (plus récent en haut)
local COL_W, LINE_H = 210, 19
local function itemEnter(self)
    ns.TipOwner(self)
    GameTooltip:SetHyperlink(self.link or ("item:" .. (self.id or 0)))
    GameTooltip:Show()
end
local function newCol(parent)
    local c = CreateFrame("Frame", nil, parent)
    c:SetWidth(COL_W)
    lookFill(c)
    ns.Border(c, C.border)
    c.discord = ns.Text(c, 9.5, 600, C.mute)
    c.discord:SetPoint("TOPLEFT", 8, -6)
    c.discord:SetWidth(COL_W - 16)
    c.discord:SetJustifyH("LEFT")
    c.spec = c:CreateTexture(nil, "ARTWORK")
    c.spec:SetSize(16, 16)
    c.spec:SetPoint("TOPLEFT", 8, -20)
    c.name = ns.Text(c, 12, 700)
    c.name:SetPoint("LEFT", c.spec, "RIGHT", 5, 0)
    c.stats = ns.Text(c, 9.5, 500, C.mute)
    c.stats:SetPoint("TOPLEFT", 8, -40)
    -- réaction des loots de ce cadre (Bis), calée à droite de la ligne des compteurs
    c.kind = ns.Text(c, 10.5, 700)
    c.kind:SetPoint("TOPRIGHT", -8, -39)
    c.sep = ns.Tex(c, C.border, "ARTWORK")
    c.sep:SetPoint("TOPLEFT", 6, -54) c.sep:SetPoint("TOPRIGHT", -6, -54) c.sep:SetHeight(1)
    c.empty = ns.Text(c, 11, 500, C.mute)
    c.empty:SetPoint("TOP", 0, -60)
    c.empty:SetText("-")
    c.lines = {}
    return c
end
local function colLine(c, i)
    local l = c.lines[i]
    if l then return l end
    l = CreateFrame("Frame", nil, c)
    l:SetSize(COL_W - 12, LINE_H)
    l:SetPoint("TOPLEFT", 6, -(c.y0 or 58) - (i - 1) * LINE_H)
    l:EnableMouse(true)
    l:SetScript("OnEnter", itemEnter)
    l:SetScript("OnLeave", function() GameTooltip:Hide() end)
    l.date = ns.Text(l, 9.5, 500, { 0.55, 0.55, 0.55 })
    l.date:SetPoint("LEFT", 2, 0)
    l.icon = l:CreateTexture(nil, "ARTWORK")
    l.icon:SetSize(16, 16)
    l.icon:SetPoint("LEFT", 34, 0)
    l.name = ns.Text(l, 11, 600)
    l.name:SetPoint("LEFT", l.icon, "RIGHT", 5, 0)
    l.name:SetWidth(COL_W - 12 - 58)
    l.name:SetJustifyH("LEFT")
    l.name:SetWordWrap(false)
    c.lines[i] = l
    return l
end
-- cadre d'une autre réaction sous la colonne du perso : même présentation, label de la réaction à droite
local function newSub(parent)
    local c = CreateFrame("Frame", nil, parent)
    c:SetWidth(COL_W)
    lookFill(c)
    ns.Border(c, C.border)
    c.kind = ns.Text(c, 10.5, 700)
    c.kind:SetPoint("TOPRIGHT", -8, -6)
    c.sep = ns.Tex(c, C.border, "ARTWORK")
    c.sep:SetPoint("TOPLEFT", 6, -22) c.sep:SetPoint("TOPRIGHT", -6, -22) c.sep:SetHeight(1)
    c.y0, c.lines = 26, {}
    return c
end
-- réactions des attributions, dans l'ordre (Bis dans le cadre du perso, les autres en dessous) ; le reste : Other
local KIND_ORDER = { "bis", "upp", "up", "os", "pvp", "mog", "other" }
local KIND_NAME = { bis = "Bis", upp = "Up+", up = "Up", os = "Off Spec", pvp = "PvP", mog = "Mog", other = "Other" }
local KIND_COL = { bis = { 1, 0.62, 0.2 }, upp = { 0.3, 0.85, 0.45 }, up = { 0.35, 0.65, 1 }, os = { 0.72, 0.5, 1 },
                   pvp = { 1, 0.38, 0.38 }, mog = { 1, 0.5, 0.8 }, other = { 0.6, 0.62, 0.68 } }
local function itemLook(rec)
    local name, _, q, _, _, _, _, _, _, ic = GetItemInfo(rec.link or rec.id or 0)
    local qc = ITEM_QUALITY_COLORS and q and ITEM_QUALITY_COLORS[q] or { r = 1, g = 1, b = 1 }
    return name or rec.name or "?", ic or (rec.id and GetItemIcon and GetItemIcon(rec.id)) or 134400, qc
end

function ns:RefreshLootsRoles(list)
    local rs, rb, ui = self.lootsRoleArea, self.lootsRoleBar, self.db.ui
    local allR, allC, anyC = true, true, false
    for ro, b in pairs(rb.roles) do
        ns.SetFont(b.label, 11.5, 600) b.label:SetText(ns.L(ro)) setTab(b, ui.lootRoles[ro])
        if not ui.lootRoles[ro] then allR = false end
    end
    for cl, b in pairs(rb.classes) do
        setTab(b, ui.lootClasses[cl])
        if ui.lootClasses[cl] then anyC = true else allC = false end
    end
    -- classes : aucune choisie = toutes (icônes pleines), sinon les autres pâlies
    for cl, b in pairs(rb.classes) do b.icon:SetAlpha((not anyC or ui.lootClasses[cl]) and 1 or 0.35) end
    rb.allRoles:Paint(allR)
    rb.allClasses:Paint(allC)
    ns.SetFont(rb.sortLabel, 10, 600)
    rb.sortLabel:SetText(strupper(ns.L("Sort priority · drag to reorder")))
    rb.chips:Layout()
    local byChar, raids, units = {}, raidCounts(), {}
    for _, r in ipairs(list) do
        if r.to then byChar[r.to] = byChar[r.to] or {} table.insert(byChar[r.to], r) end
    end
    local tokens = ns.LootPlayerTokens()
    local allNone = true
    for _, ro in ipairs(ns.ROLE_ORDER) do if ui.lootRoles[ro] then allNone = false end end
    rb:SetAlpha(1)
    for _, b in pairs(rb.roles) do b:SetAlpha(tokens and 0.35 or 1) end
    for _, b in pairs(rb.classes) do b:SetAlpha(tokens and 0.35 or 1) end
    rb.allRoles:SetAlpha(tokens and 0.35 or 1) rb.allClasses:SetAlpha(tokens and 0.35 or 1)
    local function wanted(u)
        if tokens then
            local n = strlower(u.display or u.name or "")
            for _, t in ipairs(tokens) do if n:find(t, 1, true) then return true end end
            return false
        end
        -- filtre de rôle de cette vue seulement : les chasseurs comptent comme Melee
        local role = u.class == "HUNTER" and "Melee" or u.role or ""
        return (allNone or ui.lootRoles[role]) and (not anyC or ui.lootClasses[u.class or ""])
    end
    for _, u in ipairs(self:MembersUnits()) do
        if wanted(u) then
            u.loots, u.raids = #(byChar[u.name] or {}), raids[u.name] or 0
            units[#units + 1] = u
        end
    end
    ns.SortUnits(units, ui.lootOrder)
    local maxH = 0
    for i, u in ipairs(units) do
        local c = self.lootsCols[i] or newCol(rs.child)
        self.lootsCols[i] = c
        local items = byChar[u.name] or {}
        local cc = ns.ClassColor(u.class)
        ns.SetFont(c.discord, 9.5, 600) c.discord:SetText(u.discord or "")
        c.spec:SetTexture(self:SpecIcon(u) or ns.ROLE_ICON[u.role or "Tank"])
        ns.SetFont(c.name, 12, 700) ns.SetName(c.name, u.display, COL_W - 40)
        c.name:SetTextColor(cc[1], cc[2], cc[3])
        ns.SetFont(c.stats, 9.5, 500) c.stats:SetText(ns.L("{0} raids · {1} loots", u.raids, u.loots))
        -- loots par réaction : Bis dans ce cadre, les autres dans des cadres en dessous
        local byKind = {}
        for _, rec in ipairs(items) do
            local k = KIND_NAME[rec.kind or ""] and rec.kind or "other"
            byKind[k] = byKind[k] or {}
            table.insert(byKind[k], rec)
        end
        local function fill(f, recs)
            for j, rec in ipairs(recs) do
                local l = colLine(f, j)
                l.link, l.id = rec.link, rec.id
                local name, icon, qc = itemLook(rec)
                ns.SetFont(l.date, 9.5, 500) l.date:SetText(date("%d/%m", rec.t or 0))
                l.icon:SetTexture(icon)
                ns.SetFont(l.name, 11, 600) l.name:SetText(name)
                l.name:SetTextColor(qc.r, qc.g, qc.b)
                l:Show()
            end
            for j = #recs + 1, #f.lines do f.lines[j]:Hide() end
        end
        local bis = byKind.bis or {}
        ns.SetFont(c.kind, 10.5, 700) c.kind:SetText(ns.L("Bis"))
        c.kind:SetTextColor(KIND_COL.bis[1], KIND_COL.bis[2], KIND_COL.bis[3])
        ns.SetFont(c.empty, 11, 500) c.empty:SetShown(#bis == 0)
        fill(c, bis)
        local h = 58 + math.max(1, #bis) * LINE_H + 8
        c:SetHeight(h)
        c:ClearAllPoints()
        c:SetPoint("TOPLEFT", (i - 1) * (COL_W + 6), 0)
        c:Show()
        c.subs = c.subs or {}
        local prev, n = c, 0
        for _, k in ipairs(KIND_ORDER) do
            local recs = byKind[k]
            if k ~= "bis" and recs then
                n = n + 1
                local s = c.subs[n] or newSub(rs.child)
                c.subs[n] = s
                ns.SetFont(s.kind, 10.5, 700) s.kind:SetText(ns.L(KIND_NAME[k]))
                s.kind:SetTextColor(KIND_COL[k][1], KIND_COL[k][2], KIND_COL[k][3])
                fill(s, recs)
                local sh = 26 + #recs * LINE_H + 6
                s:SetHeight(sh)
                s:ClearAllPoints()
                s:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -4)
                s:Show()
                h, prev = h + 4 + sh, s
            end
        end
        for j = n + 1, #c.subs do c.subs[j]:Hide() end
        maxH = math.max(maxH, h)
    end
    for i = #units + 1, #self.lootsCols do
        local c = self.lootsCols[i]
        c:Hide()
        for _, s in ipairs(c.subs or {}) do s:Hide() end
    end
    ns.SetFont(self.lootsEmpty, 12, 500)
    self.lootsEmpty:SetText(#units == 0 and ns.L(tokens and "No character found." or "No character with this role.") or "")
    rs.child:SetSize(math.max(1, #units * (COL_W + 6)), maxH + 12)
    rs:UpdateScrollChildRect()
    rs:SetHorizontalScroll(math.min(rs:GetHorizontalScroll(), rs:GetHorizontalScrollRange()))
    rs:SetVerticalScroll(math.min(rs:GetVerticalScroll(), rs:GetVerticalScrollRange()))
    rs:Thumb()
end

-- Vue Boss : une barre par raid (40 > 20 > 10), dépliée : ses boss (et « Trash »), dépliés : les objets vus sur
-- ce boss (icône, nom tronqué à 25 caractères), à droite les persos qui l'ont reçu (du plus ancien au plus récent)
local BAR_H, ITEM_H, CELL_W, NAME_W = 30, 34, 120, 200
-- Tables : bouton d'un boss (190 x 44 fermé, comme l'appli) dans la marge ; lignes d'objets après (étoile comprise)
local BOSS_W, BOSS_H, BOSS_X = 127, 29, 22
-- boss replié : bouton 50 % plus large (format du recadrage de la bannière, comme l'appli)
local BOSS_W_SHUT = 190
-- barre d'un raid : dépliée / repliée (4 fois plus haute) ; animation de l'une à l'autre (0,28 s)
local RAID_OPEN_H, RAID_SHUT_H, ANIM_T = BAR_H + 4, (BAR_H + 4) * 4, 0.28
local ROWS_X = BOSS_X + BOSS_W + 30
local function trunc(s, n)
    s = s or ""
    local len = strlenutf8 and strlenutf8(s) or #s
    if len <= n then return s end
    -- coupe sur un caractère entier (UTF-8)
    local out, count = "", 0
    for ch in s:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
        if count >= n - 1 then break end
        out, count = out .. ch, count + 1
    end
    return out .. "…"
end
local function newBar(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetHeight(BAR_H)
    b.fill = lookFill(b)
    ns.Border(b, C.border)
    b.tri = ns.Triangle(b, "down", 11)
    b.tri:SetPoint("LEFT", 10, 0)
    b.img = b:CreateTexture(nil, "ARTWORK")
    b.img:SetSize(22, 22)
    b.img:SetPoint("LEFT", 26, 0)
    b.label = ns.Text(b, 13, 700)
    b.count = ns.Text(b, 10.5, 600, C.mute)
    b.count:SetPoint("RIGHT", -12, 0)
    -- Tables : image du raid recadrée en fond de sa barre, assombrie aux bords (texte lisible)
    b.bgTex = b:CreateTexture(nil, "BACKGROUND", nil, 2)
    b.bgTex:SetPoint("TOPLEFT", 1, -1)
    b.bgTex:SetPoint("BOTTOMRIGHT", -1, 1)
    b.bgTex:Hide()
    b.bgBlur = b:CreateTexture(nil, "BACKGROUND", nil, 2)
    b.bgBlur:SetAllPoints(b.bgTex)
    b.bgBlur:Hide()
    -- taille du raid (10, 20, 40) à droite du nom, même style
    b.num = ns.Text(b, 13, 700)
    b.num:SetPoint("LEFT", b.label, "RIGHT", 8, 0)
    b.num:Hide()
    b.shade = b:CreateTexture(nil, "BACKGROUND", nil, 3)
    b.shade:SetAllPoints(b.bgTex)
    b.shade:SetColorTexture(1, 1, 1, 1)
    b.shade:SetGradient("HORIZONTAL", CreateColor(0, 0, 0, 0.7), CreateColor(0, 0, 0, 0.25))
    b.shade:Hide()
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    -- Tables (officiers) : « + » = ajouter des objets à la table de ce boss
    b.plus = ns.IconButton(b, "+", 22, ns.L("Add items to this boss"))
    b.plus:SetPoint("RIGHT", -6, 0)
    b.plus:SetScript("OnClick", function(f) ns:BossAddOpen(f:GetParent().bossKey) end)
    b.plus:Hide()
    b:SetScript("OnClick", function(f, btn)
        -- clic droit sur un raid (Tables) : tous ses boss dépliés / repliés
        if btn == "RightButton" then if f.raidKey then ns:LootRaidToggleAll(f.raidKey) end return end
        -- transfert en cours : la barre du boss cliquée reçoit l'objet
        if ns.bossMove and f.bossKey then ns:BossLootMoveTo(f.bossKey) return end
        if f.wishKey then
            ns.wishOpen = ns.wishOpen or {}
            ns.wishOpen[f.wishKey] = not ns.wishOpen[f.wishKey] or nil
            ns:RefreshLootsPage()
            return
        end
        local set = ns.LootSearching() and "lootSClosed" or "lootOpen"
        ns[set] = ns[set] or {}
        ns[set][f.okey] = not ns[set][f.okey] or nil
        if f.raidKey then
            local nowOpen = (set == "lootSClosed") == not ns[set][f.okey]
            ns:LootAnimStart(f.raidKey, f:GetHeight(), nowOpen and RAID_OPEN_H or RAID_SHUT_H)
        end
        ns:RefreshLootsPage()
    end)
    b:SetScript("OnEnter", function(f) ns.SetBorderColor(f, C.hl) end)
    b:SetScript("OnLeave", function(f) ns.SetBorderColor(f, C.border) end)
    return b
end
-- animation d'une barre de raid : hauteur (et taille du texte) de « from » à « to », la page redessinée à chaque image
-- to = nil : arrivée calculée au rendu (boss : hauteur de sa liste) ; w0 : largeur de départ (bouton d'un boss)
function ns:LootAnimStart(key, from, to, w0)
    if not from or (to and math.abs(from - to) < 1) then return end
    self.lootAnims = self.lootAnims or {}
    self.lootAnims[key] = { from = from, to = to, w0 = w0, t0 = GetTime() }
    self.lootAnimF = self.lootAnimF or CreateFrame("Frame")
    self.lootAnimF:SetScript("OnUpdate", function(f)
        local any = false
        for k, a in pairs(ns.lootAnims) do
            if GetTime() - a.t0 >= ANIM_T then ns.lootAnims[k] = nil else any = true end
        end
        if not any then f:SetScript("OnUpdate", nil) end
        ns:RefreshLootsPage()
    end)
end
-- avancée (0 … 1, ralentie à la fin) d'une animation en cours, nil sinon
function ns:LootAnimP(key)
    local a = self.lootAnims and self.lootAnims[key]
    if not a then return nil end
    local p = math.min(1, (GetTime() - a.t0) / ANIM_T)
    return 1 - (1 - p) * (1 - p), a
end
-- hauteur d'une barre de raid (animée ou non) et avancée vers « repliée » (0 dépliée … 1 repliée : taille du texte)
function ns:LootRaidBarH(rk, target)
    local h = target
    local p, a = self:LootAnimP(rk)
    if p then h = a.from + ((a.to or target) - a.from) * p end
    return h, (h - RAID_OPEN_H) / (RAID_SHUT_H - RAID_OPEN_H)
end
-- texcoords d'une image (ar = largeur / hauteur) dans un cadre bw x bh, d'après son cadrage (fractions, au format du
-- cadre fermé) : même calcul que placeCrop de l'appli (largeur et centre gardés ; cadre plus haut = plus d'image en haut
-- et en bas ; image pas assez haute = largeur resserrée ; cadre plus large que l'image = bande centrée)
function ns.CropCoords(crop, ar, bw, bh)
    local x, y, w, h = 0, 0.4, 1, 0.2
    if type(crop) == "table" and (crop.w or 0) > 0 then x, y, w, h = crop.x or 0, crop.y or 0, crop.w, crop.h or 0.2 end
    local iw = 1000
    local ih = iw / ((ar and ar > 0) and ar or 1.5)
    local cx, cy = (x + w / 2) * iw, (y + h / 2) * ih
    local sw = w * iw
    local sh, sx = sw * bh / bw, x * iw
    if sh > ih then sh, sw = ih, ih * bw / bh sx = cx - sw / 2 end
    if sw > iw then sw, sh, sx = iw, iw * bh / bw, 0 end
    sx = math.min(math.max(0, sx), iw - sw)
    local sy = math.min(math.max(0, cy - sh / 2), ih - sh)
    return sx / iw, (sx + sw) / iw, sy / ih, (sy + sh) / ih
end
-- bouton d'un boss (Tables) : bannière recadrée qui suit la hauteur de sa liste ; nom et nombre en haut ; « + »
local GOLDL = { 1, 0.82, 0.48 }
local function newBossBtn(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetWidth(BOSS_W)
    b.fill = ns.Fill(b, C.input, 0.6)
    b.ban = b:CreateTexture(nil, "BACKGROUND", nil, 2)
    b.ban:SetPoint("TOPLEFT", 1, -1)
    b.ban:SetPoint("BOTTOMRIGHT", -1, 1)
    b.banBlur = b:CreateTexture(nil, "BACKGROUND", nil, 2)
    b.banBlur:SetAllPoints(b.ban)
    b.banBlur:Hide()
    b.shade = b:CreateTexture(nil, "BACKGROUND", nil, 3)
    b.shade:SetPoint("TOPLEFT", 1, -1)
    b.shade:SetPoint("TOPRIGHT", -1, -1)
    b.shade:SetHeight(28)
    b.shade:SetColorTexture(1, 1, 1, 1)
    b.shade:SetGradient("VERTICAL", CreateColor(0, 0, 0, 0), CreateColor(0, 0, 0, 0.6))
    ns.Border(b, { 0.5, 0.42, 0.26 })
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(16, 16)
    b.icon:SetPoint("TOPLEFT", 5, -6)
    b.label = ns.Text(b, 11.5, 700, GOLDL)
    b.label:SetJustifyH("LEFT")
    b.label:SetWordWrap(false)
    b.count = ns.Text(b, 10.5, 600, { 0.84, 0.85, 0.87 })
    b.count:SetPoint("TOPRIGHT", -6, -8)
    b.plus = ns.IconButton(b, "+", 16, ns.L("Add items to this boss"))
    b.plus:SetPoint("TOPRIGHT", -20, -6)
    b.plus:SetScript("OnClick", function(f) ns:BossAddOpen(f:GetParent().bossKey) end)
    b:SetScript("OnClick", function(f)
        if ns.bossMove and f.bossKey then ns:BossLootMoveTo(f.bossKey) return end
        local set = ns.LootSearching() and "lootSClosed" or "lootOpen"
        ns[set] = ns[set] or {}
        ns[set][f.okey] = not ns[set][f.okey] or nil
        ns:LootAnimStart(f.okey, f:GetHeight(), nil, f:GetWidth())
        ns:RefreshLootsPage()
    end)
    b:SetScript("OnEnter", function(f) ns.SetBorderColor(f, C.hl) end)
    b:SetScript("OnLeave", function(f) ns.SetBorderColor(f, (ns.bossMove and C.hl) or f.edge) end)
    return b
end
local function newItemLine(parent)
    local l = CreateFrame("Frame", nil, parent)
    l:SetHeight(ITEM_H)
    l.icon = l:CreateTexture(nil, "ARTWORK")
    l.icon:SetSize(20, 20)
    l.icon:SetPoint("LEFT", 0, 0)
    l.hit = CreateFrame("Frame", nil, l)
    l.hit:SetPoint("LEFT", 0, 0)
    l.hit:SetSize(NAME_W + 24, ITEM_H)
    l.hit:EnableMouse(true)
    l.hit:SetScript("OnEnter", function(f) ns.TipOwner(f) GameTooltip:SetHyperlink("item:" .. (l.id or 0)) GameTooltip:Show() end)
    l.hit:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- étoile (wishlist) à gauche de l'icône : vide, pleine si l'objet est dans la wishlist d'un de mes persos
    l.star = CreateFrame("Button", nil, l)
    l.star:SetSize(18, 18)
    l.star:SetPoint("RIGHT", l.icon, "LEFT", -4, 0)
    l.star.tex = l.star:CreateTexture(nil, "ARTWORK")
    l.star.tex:SetAllPoints()
    l.star:SetScript("OnClick", function(b) ns:WishPopup(l.id, b) end)
    l.star:SetScript("OnEnter", function(b) ns.TipOwner(b) GameTooltip:SetText(ns.L("Wishlist"), 1, 1, 1) GameTooltip:Show() end)
    l.star:SetScript("OnLeave", function() GameTooltip:Hide() end)
    l.name = ns.Text(l, 11.5, 600)
    l.name:SetPoint("LEFT", l.icon, "RIGHT", 6, 0)
    l.name:SetWidth(NAME_W)
    l.name:SetJustifyH("LEFT")
    l.name:SetWordWrap(false)
    l.cells = {}
    -- (officiers) tout à droite : × = supprimer (« Confirm », cliquable après 1,5 s) ; à sa gauche : transférer
    l.hl = l:CreateTexture(nil, "BACKGROUND")
    l.hl:SetAllPoints()
    l.hl:SetColorTexture(C.hl[1], C.hl[2], C.hl[3], 0.18)
    l.hl:Hide()
    l.del = ns.IconButton(l, "×", 22, ns.L("Remove this item from the table"))
    l.del:SetPoint("RIGHT", -4, 0)
    l.del:SetScript("OnClick", function() ns:BossLootArm(l) end)
    l.confirm = ns.Button(l, ns.L("Confirm"), 70, 22)
    l.confirm:SetPoint("RIGHT", -4, 0)
    l.confirm:SetScript("OnClick", function(b)
        if not b.ready then return end
        ns:BossLootEdit(l.raid, l.boss, l.id, "del")
        ns:RefreshLootsPage()
    end)
    l.confirm:Hide()
    l.move = CreateFrame("Button", nil, l)
    l.move:SetSize(20, 20)
    ns.BossMovePlace(l, false)
    l.move.tex = l.move:CreateTexture(nil, "ARTWORK")
    l.move.tex:SetAllPoints()
    l.move.tex:SetTexture("Interface\\AddOns\\GuildTool\\media\\transfer")
    l.move.tex:SetVertexColor(0.92, 0.9, 0.86)
    l.move:SetScript("OnEnter", function(b)
        b.tex:SetVertexColor(1, 1, 1)
        ns.TipOwner(b)
        GameTooltip:SetText(ns.L("Move to another boss"), 1, 1, 1)
        GameTooltip:AddLine(ns.L("Then click the line of the boss that gets it (click here again: cancel)."), 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    l.move:SetScript("OnLeave", function(b) b.tex:SetVertexColor(0.92, 0.9, 0.86) GameTooltip:Hide() end)
    l.move:SetScript("OnClick", function()
        local m = ns.bossMove
        if m and m.raid == l.raid and m.boss == l.boss and m.id == l.id then ns.bossMove = nil
        else ns.bossMove = { raid = l.raid, boss = l.boss, id = l.id } end
        ns:RefreshLootsPage()
    end)
    return l
end
local function itemCell(l, i)
    local c = l.cells[i]
    if c then return c end
    c = CreateFrame("Frame", nil, l)
    c:SetSize(CELL_W, ITEM_H)
    c:SetPoint("LEFT", 26 + NAME_W + 10 + (i - 1) * CELL_W, 0)
    -- fine ligne grise entre les colonnes de noms
    c.line = ns.Tex(c, { 0.35, 0.36, 0.40 }, "ARTWORK")
    c.line:SetPoint("TOPLEFT", 0, -4) c.line:SetPoint("BOTTOMLEFT", 0, 4) c.line:SetWidth(1)
    c.top = ns.Text(c, 9, 500, { 0.55, 0.55, 0.55 })
    c.top:SetPoint("TOPLEFT", 6, -4)
    c.top:SetWidth(CELL_W - 10)
    c.top:SetJustifyH("LEFT")
    c.top:SetWordWrap(false)
    c.name = ns.Text(c, 11.5, 700)
    c.name:SetPoint("BOTTOMLEFT", 6, 4)
    -- « N x » : survol = dates des attributions (une par ligne, nombre si plusieurs le même jour)
    c:EnableMouse(true)
    c:SetScript("OnEnter", function(f)
        if not f.run then return end
        ns.TipOwner(f)
        GameTooltip:SetText(f.run[1].to or "?", 1, 1, 1)
        local days, order = {}, {}
        for _, r in ipairs(f.run) do
            local d = date("%d/%m/%Y", r.t or 0)
            if not days[d] then order[#order + 1] = d end
            days[d] = (days[d] or 0) + 1
        end
        for _, d in ipairs(order) do GameTooltip:AddLine(d .. (days[d] > 1 and ("  ×" .. days[d]) or ""), 0.85, 0.85, 0.85) end
        GameTooltip:Show()
    end)
    c:SetScript("OnLeave", function() GameTooltip:Hide() end)
    l.cells[i] = c
    return c
end

-- loots vus sur chaque boss : base de la guilde + relevés ici + attributions qui ont un boss
local function bossData(list)
    local out = {}
    local function add(raid, boss, id)
        if not (raid and boss and id) then return end
        out[raid] = out[raid] or {}
        out[raid][boss] = out[raid][boss] or {}
        out[raid][boss][tonumber(id) or id] = true
    end
    for _, src in ipairs({ ns.db.bossLootDB or {}, ns.db.bossLoot or {} }) do
        for raid, bosses in pairs(src) do
            for boss, items in pairs(bosses) do for id in pairs(items) do add(raid, boss, id) end end
        end
    end
    for _, r in ipairs(list) do
        local raid = r.raid or (r.zone and ns.LootZoneRaid and (ns.LootZoneRaid(r.zone) or {}).key)
        if r.boss and r.id then add(raid, r.boss, r.id) end
    end
    -- modifications à la main (officiers) : base de la guilde puis les miennes, la plus récente par objet
    for key, e in pairs(ns:BossLootEdits()) do
        local raid, boss, id = key:match("^(.-)|(.-)|(%d+)$")
        if raid then
            if e.op == "del" then
                if out[raid] and out[raid][boss] then out[raid][boss][tonumber(id)] = nil end
            else add(raid, boss, id) end
        end
    end
    return out
end
-- double flèche à gauche du × (ou du bouton « Confirm », plus large, pendant la confirmation)
function ns.BossMovePlace(l, armed)
    l.move:ClearAllPoints()
    l.move:SetPoint("RIGHT", armed and l.confirm or l.del, "LEFT", -4, 0)
end
-- modifications des tables de loot : celles de la guilde (exe) et les miennes pas encore envoyées, la plus récente gagne
function ns:BossLootEdits()
    local out = {}
    for _, src in ipairs({ self.db.bossLootEd or {}, self.db.bossLootEdits or {} }) do
        for k, e in pairs(src) do
            if type(e) == "table" and (not out[k] or (e.t or 0) >= (out[k].t or 0)) then out[k] = e end
        end
    end
    return out
end
-- (officiers) ajout / suppression d'un objet dans la table d'un boss (transfert = les deux), lu par l'exe à la synchro
function ns:BossLootEdit(raid, boss, id, op)
    id = tonumber(id)
    if not (raid and boss and id and self:MayEdit()) then return end
    self.db.bossLootEdits = self.db.bossLootEdits or {}
    self.db.bossLootEdits[raid .. "|" .. boss .. "|" .. id] = { op = op, t = time() }
    -- suppression : retirée aussi de mes relevés (sinon l'exe les relit)
    local obs = self.db.bossLoot and self.db.bossLoot[raid] and self.db.bossLoot[raid][boss]
    if op == "del" and obs then obs[tostring(id)] = nil end
    if self.LogPending then self:LogPending(ns.L("Tables") .. " · " .. boss) end
end
-- transfert : objet choisi (flèches) envoyé au boss dont la barre est cliquée
function ns:BossLootMoveTo(bk)
    local m = self.bossMove
    self.bossMove = nil
    if m and bk and not (bk[1] == m.raid and bk[2] == m.boss) then
        self:BossLootEdit(m.raid, m.boss, m.id, "del")
        self:BossLootEdit(bk[1], bk[2], m.id, "add")
    end
    self:RefreshLootsPage()
end
-- × : devient « Confirm », cliquable après 1,5 s ; redevient × au bout de 6 s ; la double flèche recule à côté
function ns:BossLootArm(l)
    local token = GetTime()
    l.armT = token
    l.del:Hide()
    l.confirm.ready = false
    l.confirm:SetAlpha(0.45)
    l.confirm:Show()
    ns.BossMovePlace(l, true)
    C_Timer.After(1.5, function() if l.armT == token then l.confirm.ready = true l.confirm:SetAlpha(1) end end)
    C_Timer.After(6, function() if l.armT == token then l.armT = nil l.confirm:Hide() l.del:Show() ns.BossMovePlace(l, false) end end)
end
-- « + » sur un boss : case d'ajout en haut de sa liste (Maj + clic sur un objet, son ID + Entrée, ou « Bags »)
function ns:BossAddOpen(bk)
    if not bk then return end
    local key = bk[1] .. "|" .. bk[2]
    self.bossAdd = self.bossAdd ~= key and key or nil
    self.lootOpen = self.lootOpen or {}
    self.lootOpen[bk[1]], self.lootOpen[key] = true, true
    if self.lootSClosed then self.lootSClosed[bk[1]], self.lootSClosed[key] = nil, nil end
    self:RefreshLootsPage()
    if self.bossAdd and self.bossAddRowF then self.bossAddRowF.edit:SetFocus() end
end
function ns:BossAddItem(id)
    local raid, boss = (self.bossAdd or ""):match("^(.-)|(.+)$")
    if not (raid and tonumber(id)) then return end
    self:BossLootEdit(raid, boss, id, "add")
    self:RefreshLootsPage()
end
-- objets de mes sacs (vert et mieux), triés par nom : menu « Bags »
function ns:BossBagItems()
    local seen, list = {}, {}
    local C_C = C_Container
    for bag = 0, NUM_BAG_SLOTS or 4 do
        for slot = 1, (C_C and C_C.GetContainerNumSlots or GetContainerNumSlots)(bag) or 0 do
            local info = C_C and C_C.GetContainerItemInfo and C_C.GetContainerItemInfo(bag, slot)
            local link = info and info.hyperlink or (not C_C and GetContainerItemLink(bag, slot))
            local id = link and tonumber(link:match("item:(%d+)"))
            local name, _, q, _, _, _, _, _, _, icon = GetItemInfo(link or "")
            if id and not seen[id] and (q or 0) >= 2 then
                seen[id] = true
                local qc = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q] or { r = 1, g = 1, b = 1 }
                list[#list + 1] = { text = name or ("item " .. id), icon = icon, iconSize = 18, noTint = true, color = { qc.r, qc.g, qc.b },
                                    func = function() ns:BossAddItem(id) end }
            end
        end
    end
    table.sort(list, function(a, b) return a.text < b.text end)
    if #list == 0 then list[1] = { text = ns.L("No item in your bags."), color = C.mute } end
    return list
end
function ns:BossAddRow()
    local r = self.bossAddRowF
    if r then return r end
    r = CreateFrame("Frame", nil, self.lootsArea.child)
    r:SetHeight(26)
    local e = CreateFrame("EditBox", nil, r)
    e:SetSize(300, 22)
    e:SetPoint("LEFT", 0, 0)
    e:SetAutoFocus(false)
    e:SetFontObject(ChatFontNormal)
    e:SetTextInsets(6, 6, 0, 0)
    ns.Fill(e, C.input)
    ns.Border(e, C.hl)
    e.ph = ns.Text(e, 11, 400, C.mute)
    e.ph:SetPoint("LEFT", 7, 0)
    e:SetScript("OnTextChanged", function(s) s.ph:SetShown(s:GetText() == "") end)
    e:SetScript("OnEnterPressed", function(s)
        local t = s:GetText()
        local id = tonumber(t:match("item:(%d+)") or t:match("^%s*(%d+)%s*$"))
        s:SetText("")
        if id then ns:BossAddItem(id) end
    end)
    e:SetScript("OnEscapePressed", function(s) s:SetText("") s:ClearFocus() ns.bossAdd = nil ns:RefreshLootsPage() end)
    r.edit = e
    r.bags = ns.Button(r, ns.L("Bags"), 70, 22)
    r.bags:SetPoint("LEFT", e, "RIGHT", 6, 0)
    r.bags:SetScript("OnClick", function(b) ns:OpenMenu(b, ns:BossBagItems(), 280) end)
    r.close = ns.IconButton(r, "×", 22, ns.L("Close"))
    r.close:SetPoint("LEFT", r.bags, "RIGHT", 6, 0)
    r.close:SetScript("OnClick", function() ns.bossAdd = nil ns:RefreshLootsPage() end)
    self.bossAddRowF = r
    return r
end
-- Maj + clic sur un objet pendant que la case d'ajout d'une table de loot est active
if ChatEdit_InsertLink then
    hooksecurefunc("ChatEdit_InsertLink", function(link)
        local r = ns.bossAddRowF
        if r and r:IsVisible() and r.edit:HasFocus() and type(link) == "string" then
            local id = tonumber(link:match("item:(%d+)"))
            if id then ns:BossAddItem(id) end
        end
    end)
end

-- noms des boss d'un raid : ceux des Settings dans leur ordre, puis ceux vus seulement dans les données, « Trash »
local function bossNames(raid, bosses)
    local names, seen, extra = {}, {}, {}
    for _, b in ipairs(raid.bosses or {}) do
        if b.name and not seen[b.name] then
            seen[b.name] = true
            names[#names + 1] = { name = b.name, img = b.img, banner = b.banner, bAspect = b.bAspect, bcrop = b.bcrop }
        end
    end
    for bn in pairs(bosses) do if not seen[bn] and bn ~= "Trash" then extra[#extra + 1] = bn end end
    table.sort(extra)
    for _, bn in ipairs(extra) do names[#names + 1] = { name = bn } end
    names[#names + 1] = { name = "Trash" }
    return names
end

function ns:RefreshLootsBoss(list)
    local sf = self.lootsArea
    local data, receivers = bossData(list), {}
    for _, r in ipairs(list) do
        if r.id then receivers[r.id] = receivers[r.id] or {} table.insert(receivers[r.id], r) end
    end
    for _, rs in pairs(receivers) do table.sort(rs, function(a, b) return (a.t or 0) < (b.t or 0) end) end
    -- raids de la phase choisie (toutes : « All »), du plus grand au plus petit
    local raids = {}
    for i, ph in ipairs(ns.PHASES) do
        if not ns.lootPhase or ns.lootPhase == i then for _, r in ipairs(ph.raids or {}) do raids[#raids + 1] = r end end
    end
    table.sort(raids, function(a, b) if (a.size or 0) ~= (b.size or 0) then return (a.size or 0) > (b.size or 0) end return a.name < b.name end)
    local searching, st = ns.LootSearching(), { y = 0, nb = 0, ni = 0, w = sf:GetWidth() - 12 }
    local officer = self:MayEdit()
    local open = setmetatable({}, { __index = function(_, k)
        if searching then return not (ns.lootSClosed or {})[k] end
        return (ns.lootOpen or {})[k]
    end })
    -- objets d'un boss gardés par la recherche (nom, types)
    local function keep(ids)
        if not searching then return ids end
        local out = {}
        for _, id in ipairs(ids) do if ns.LootItemMatch(id, (itemLook({ id = id }))) then out[#out + 1] = id end end
        return out
    end
    local function bar(x, okey, label, count, img, size)
        st.nb = st.nb + 1
        local b = self.lootsBars[st.nb] or newBar(sf.child)
        self.lootsBars[st.nb] = b
        b.okey, b.wishKey = okey, nil
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", x, -st.y)
        b:SetWidth(st.w - x)
        b:SetHeight(size)
        b.tri:SetRotation(open[okey] and 0 or math.pi / 2)
        b.img:SetShown(img ~= nil)
        if img then b.img:SetTexture(img) end
        b.label:ClearAllPoints()
        b.label:SetPoint("LEFT", img and 54 or 26, 0)
        ns.SetFont(b.label, size >= BAR_H and 13 or 12, 700)
        b.label:SetText(label)
        -- barres réutilisées par les autres vues (couleur de classe) : couleur du texte remise
        b.label:SetTextColor(C.text[1], C.text[2], C.text[3])
        ns.SetFont(b.count, 10.5, 600)
        b.count:SetText(count)
        b:Show()
        st.y = st.y + size + 3
    end
    -- style de l'appli (Craft) : barre du raid avec son image recadrée (4 fois plus haute repliée), boss = bouton dans la
    -- marge aussi haut que sa liste, avec sa bannière ; replié : une ligne « N items »
    local shownRaids, nbb, nsh, nsep = 0, 0, 0, 0
    self.lootsSeps = self.lootsSeps or {}
    self.lootsBossBtns, self.lootsShuts, self.lootRaidBosses = self.lootsBossBtns or {}, self.lootsShuts or {}, {}
    for _, raid in ipairs(raids) do
        local bosses = data[raid.key] or {}
        local list2, total = {}, 0
        for _, bo in ipairs(bossNames(raid, bosses)) do
            local ids = {}
            for id in pairs(bosses[bo.name] or {}) do ids[#ids + 1] = id end
            ids = keep(ids)
            if not searching or #ids > 0 then list2[#list2 + 1] = { bo = bo, ids = ids } total = total + #ids end
        end
        if not searching or #list2 > 0 then
            shownRaids = shownRaids + 1
            local keys = {}
            for i, x in ipairs(list2) do keys[i] = raid.key .. "|" .. x.bo.name end
            self.lootRaidBosses[raid.key] = keys
            local ro = open[raid.key]
            local rh, shut = self:LootRaidBarH(raid.key, ro and RAID_OPEN_H or RAID_SHUT_H)
            bar(0, raid.key, raid.name, ns.L("{0} items", total), nil, rh)
            local rb = self.lootsBars[st.nb]
            rb.raidKey = raid.key
            -- nom et taille en grandes lettres claires translucides (lettres « verre » de l'appli) ; repliée : deux fois plus
            -- lettres « verre » de l'appli (le jeu ne remplit pas un texte d'image) : claires et très translucides (l'image
            -- du raid se voit à travers), ombre fine ; triangle pareil ; texte accroché au triangle (écart qui grandit avec lui)
            local k = 1 + math.max(0, math.min(1, shut))
            rb.tri:SetSize(12 * k, 12 * k)
            rb.tri:SetVertexColor(1, 1, 1, 0.42)
            ns.SetFont(rb.label, 26 * k, 700)
            rb.label:SetText(raid.name)
            rb.label:ClearAllPoints()
            rb.label:SetPoint("LEFT", rb.tri, "RIGHT", 7 * k, 0)
            ns.SetFont(rb.num, 26 * k, 700)   -- même taille que le nom
            rb.num:SetText(raid.size or "")
            rb.num:Show()
            for _, fs in ipairs({ rb.label, rb.num }) do
                fs:SetTextColor(1, 1, 1, 0.42)
                fs:SetShadowColor(0, 0, 0, 0.55)
                fs:SetShadowOffset(1, -1)
            end
            if raid.bg then
                local cr = type(raid.bar) == "table" and raid.bar or {}
                local al, bl = cr.a or 1, cr.b or 0
                local l, r, t, bt = ns.CropCoords(raid.bar, raid.bgAspect, st.w, rh)
                rb.bgTex:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. raid.bg)
                rb.bgTex:SetTexCoord(l, r, t, bt)
                rb.bgTex:SetAlpha(al * (1 - bl))
                rb.bgTex:Show() rb.shade:Show()
                -- « Blurred » : la version floutée de l'image par-dessus, dosée
                rb.bgBlur:SetShown(bl > 0)
                if bl > 0 then
                    rb.bgBlur:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. raid.bg .. "_blur")
                    rb.bgBlur:SetTexCoord(l, r, t, bt)
                    rb.bgBlur:SetAlpha(al * bl)
                end
                rb.count:SetTextColor(0.84, 0.85, 0.87)
            end
            if ro then
                for bi, x in ipairs(list2) do
                    local bo, okey = x.bo, raid.key .. "|" .. x.bo.name
                    -- entre deux boss : écart et fine ligne qui s'efface sur les bords (deux dégradés)
                    if bi > 1 then
                        nsep = nsep + 1
                        local sp = self.lootsSeps[nsep]
                        if not sp then
                            sp = CreateFrame("Frame", nil, sf.child)
                            sp:SetHeight(1)
                            sp.l, sp.r = sp:CreateTexture(nil, "ARTWORK"), sp:CreateTexture(nil, "ARTWORK")
                            sp.l:SetPoint("TOPLEFT") sp.l:SetPoint("BOTTOMRIGHT", sp, "BOTTOM")
                            sp.r:SetPoint("TOPRIGHT") sp.r:SetPoint("BOTTOMLEFT", sp, "BOTTOM")
                            for _, t in ipairs({ sp.l, sp.r }) do t:SetColorTexture(1, 1, 1, 1) end
                            sp.l:SetGradient("HORIZONTAL", CreateColor(1, 1, 1, 0), CreateColor(1, 1, 1, 0.16))
                            sp.r:SetGradient("HORIZONTAL", CreateColor(1, 1, 1, 0.16), CreateColor(1, 1, 1, 0))
                            self.lootsSeps[nsep] = sp
                        end
                        sp:ClearAllPoints()
                        sp:SetPoint("TOPLEFT", 0, -(st.y + 2))
                        sp:SetWidth(st.w)
                        sp:Show()
                        st.y = st.y + 6
                    end
                    local top, bopen = st.y, open[okey]
                    local ni0 = st.ni
                    local p, an = self:LootAnimP(okey)
                    local wNat = bopen and BOSS_W or BOSS_W_SHUT
                    local bw = p and an.w0 and (an.w0 + (wNat - an.w0) * p) or wNat
                    if bopen then self:LootBossItems(x.ids, receivers, st, raid.key, bo.name, ROWS_X)
                    else
                        nsh = nsh + 1
                        local t = self.lootsShuts[nsh] or ns.Text(sf.child, 11, 500, C.mute)
                        self.lootsShuts[nsh] = t
                        ns.SetFont(t, 11, 500)
                        t:SetText(ns.L("{0} items", #x.ids))
                        t:ClearAllPoints()
                        t:SetPoint("LEFT", sf.child, "TOPLEFT", BOSS_X + bw + 10, -(top + BOSS_H / 2))
                        t:Show()
                    end
                    local h = math.max(BOSS_H, st.y - top)
                    -- animation : hauteur de l'ancienne à la nouvelle ; lignes au-delà cachées le temps qu'elle finisse
                    if p then
                        h = math.max(BOSS_H, an.from + (h - an.from) * p)
                        for li = ni0 + 1, st.ni do
                            local l = self.lootsItems[li]
                            if l.ty and l.ty + ITEM_H > top + h then l:Hide() end
                        end
                        if self.bossAddRowF and self.bossAdd == okey and h < st.y - top then self.bossAddRowF:Hide() end
                    end
                    nbb = nbb + 1
                    local b = self.lootsBossBtns[nbb] or newBossBtn(sf.child)
                    self.lootsBossBtns[nbb] = b
                    b.okey, b.bossKey = okey, { raid.key, bo.name }
                    b:ClearAllPoints()
                    b:SetPoint("TOPLEFT", BOSS_X, -top)
                    b:SetHeight(h)
                    b:SetWidth(bw)
                    local ban = bo.banner and bo.bAspect
                    b.ban:SetShown(ban ~= nil)
                    b.shade:SetShown(ban ~= nil)
                    b.banBlur:Hide()
                    if ban then
                        local cr = type(bo.bcrop) == "table" and bo.bcrop or {}
                        local al, bl, v = cr.a or 1, cr.b or 0, bopen and 1 or 0.75
                        local l, r, t, bt = ns.CropCoords(bo.bcrop, bo.bAspect, bw, h)
                        b.ban:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. bo.banner)
                        b.ban:SetTexCoord(l, r, t, bt)
                        b.ban:SetVertexColor(v, v, v)
                        b.ban:SetAlpha(al * (1 - bl))
                        if bl > 0 then
                            b.banBlur:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. bo.banner .. "_blur")
                            b.banBlur:SetTexCoord(l, r, t, bt)
                            b.banBlur:SetVertexColor(v, v, v)
                            b.banBlur:SetAlpha(al * bl)
                            b.banBlur:Show()
                        end
                    end
                    b.icon:SetShown(not ban and bo.img ~= nil)
                    if not ban and bo.img then b.icon:SetTexture("Interface\\AddOns\\GuildTool\\media\\" .. bo.img) end
                    b.label:ClearAllPoints()
                    b.label:SetPoint("TOPLEFT", (not ban and bo.img) and 25 or 6, -8)
                    b.label:SetWidth(bw - ((not ban and bo.img) and 25 or 6) - (officer and 40 or 24))
                    ns.SetFont(b.label, 11.5, 700)
                    b.label:SetText(ns.L(bo.name))
                    local lc = (bopen or ban) and GOLDL or C.mute
                    if ban and not bopen then lc = { 1, 1, 1 } end
                    b.label:SetTextColor(lc[1], lc[2], lc[3])
                    ns.SetFont(b.count, 10.5, 600)
                    b.count:SetText(#x.ids)
                    b.plus:SetShown(officer)
                    -- transfert en cours : les boss sont des cibles (cadre Highlight)
                    b.edge = bopen and { 0.62, 0.52, 0.3 } or C.border
                    ns.SetBorderColor(b, (self.bossMove or b:IsMouseOver()) and C.hl or b.edge)
                    b:Show()
                    st.y = top + h + 5
                end
            end
            st.y = st.y + 2
        end
    end
    for i = nbb + 1, #self.lootsBossBtns do self.lootsBossBtns[i]:Hide() end
    for i = nsep + 1, #self.lootsSeps do self.lootsSeps[i]:Hide() end
    for i = nsh + 1, #self.lootsShuts do self.lootsShuts[i]:Hide() end
    for i = st.nb + 1, #self.lootsBars do self.lootsBars[i]:Hide() end
    for i = st.ni + 1, #self.lootsItems do self.lootsItems[i]:Hide() end
    ns.SetFont(self.lootsEmpty, 12, 500)
    self.lootsEmpty:SetText(shownRaids == 0 and ns.L(searching and "No item found." or "No raid in this phase.") or "")
    sf.child:SetHeight(st.y + 10)
end
-- objets d'un boss : les plus reçus d'abord, puis par nom ; à droite les receveurs (Discord + date au-dessus)
function ns:LootBossItems(ids, receivers, st, raidKey, bossName, x0)
    local sf, items = self.lootsArea, {}
    x0 = x0 or 46
    local officer = self:MayEdit()
    -- case d'ajout (« + » du boss) en haut de sa liste
    if officer and raidKey and self.bossAdd == raidKey .. "|" .. bossName then
        local r = self:BossAddRow()
        ns.SetFont(r.edit.ph, 11, 400)
        r.edit.ph:SetText(ns.L("Shift + click an item (or its ID + Enter)"))
        r.edit.ph:SetShown(r.edit:GetText() == "")
        ns.SetFont(r.bags.label, 11, 600)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", x0 - 22, -st.y - 2)
        r:SetPoint("RIGHT", sf.child, "RIGHT", -10, 0)
        r:Show()
        st.y = st.y + 30
    end
    for _, id in ipairs(ids) do
        local name, icon, qc = itemLook({ id = id })
        items[#items + 1] = { id = id, name = name, icon = icon, qc = qc, rs = receivers[id] or {} }
    end
    table.sort(items, function(a, b) if #a.rs ~= #b.rs then return #a.rs > #b.rs end return a.name < b.name end)
    for _, it in ipairs(items) do
        st.ni = st.ni + 1
        local l = self.lootsItems[st.ni] or newItemLine(sf.child)
        self.lootsItems[st.ni] = l
        if l.id ~= it.id or l.boss ~= bossName then l.armT = nil end
        l.id, l.raid, l.boss = it.id, raidKey, bossName
        -- (officiers) transférer / supprimer ; ligne en surbrillance pendant son transfert
        local mv = self.bossMove
        l.move:SetShown(officer and raidKey ~= nil)
        if not l.armT then l.del:SetShown(officer and raidKey ~= nil) l.confirm:Hide() ns.BossMovePlace(l, false) end
        l.hl:SetShown(mv ~= nil and mv.raid == raidKey and mv.boss == bossName and mv.id == it.id)
        local on = self:WishHasMine(it.id)
        l.star.tex:SetTexture("Interface\\Common\\ReputationStar")
        l.star.tex:SetTexCoord(on and 0 or 0.5, on and 0.5 or 1, on and 0 or 0, on and 0.5 or 0.5)
        l.star:Show()
        l:ClearAllPoints()
        l:SetPoint("TOPLEFT", x0, -st.y)
        l:SetWidth(st.w - x0)
        l.ty = st.y
        l.icon:SetTexture(it.icon)
        ns.SetFont(l.name, 11.5, 600)
        l.name:SetText(trunc(it.name, 25))
        l.name:SetTextColor(it.qc.r, it.qc.g, it.qc.b)
        local runs = {}
        -- ordre de loot (persos qui l'ont reçu) caché aux membres si un officier l'a choisi
        for _, rec in ipairs(self:LootFlag("lootHideOrder") and {} or it.rs) do
            local last = runs[#runs]
            if last and last.to == rec.to then table.insert(last.list, rec) else runs[#runs + 1] = { to = rec.to, list = { rec } } end
        end
        for j, run in ipairs(runs) do
            local c = itemCell(l, j)
            local rec, n = run.list[#run.list], #run.list
            local u = rec.to and self:UnitFor(rec.to)
            st.dn = st.dn or (ns.DiscordNames and ns.DiscordNames()) or {}
            local disc = u and u.tag and st.dn[u.tag]
            ns.SetFont(c.top, 9, 500)
            c.top:SetText((disc and (disc .. " · ") or "") .. date("%d/%m", rec.t or 0))
            local cc = ns.ClassColor(classOf(rec.to))
            ns.SetFont(c.name, 11.5, 700)
            ns.SetName(c.name, rec.to or "?", CELL_W - 10 - (n > 1 and 26 or 0))
            if n > 1 then c.name:SetText("|cffffd140" .. n .. " x|r " .. (c.name:GetText() or "")) end
            c.name:SetTextColor(cc[1], cc[2], cc[3])
            c.run = n > 1 and run.list or nil
            c:Show()
        end
        for j = #runs + 1, #l.cells do l.cells[j]:Hide() end
        l:Show()
        st.y = st.y + ITEM_H
    end
    if #items == 0 then st.y = st.y + 4 end
end
-- clic droit sur la barre d'un raid : tous ses boss dépliés (s'il en reste un replié), sinon tous repliés
function ns:LootRaidToggleAll(rk)
    local searching = ns.LootSearching()
    local function isOpen(k) if searching then return not (ns.lootSClosed or {})[k] end return (ns.lootOpen or {})[k] end
    local function set(k, on)
        if searching then ns.lootSClosed = ns.lootSClosed or {} ns.lootSClosed[k] = not on or nil
        else ns.lootOpen = ns.lootOpen or {} ns.lootOpen[k] = on or nil end
    end
    local keys = (self.lootRaidBosses or {})[rk] or {}
    local openAll = not isOpen(rk)
    for _, k in ipairs(keys) do if not isOpen(k) then openAll = true end end
    if openAll and not isOpen(rk) then
        for _, b in ipairs(self.lootsBars or {}) do if b.raidKey == rk then self:LootAnimStart(rk, b:GetHeight(), RAID_OPEN_H) end end
    end
    if openAll then set(rk, true) end
    for _, k in ipairs(keys) do set(k, openAll) end
    self:RefreshLootsPage()
end

function ns:RefreshLootsPage()
    local sf = self.lootsArea
    self:LootListLook()
    if not sf then return end
    local ui = self.db.ui
    ui.lootClasses = ui.lootClasses or {}
    if not ui.lootRoles then ui.lootRoles = {} for _, ro in ipairs(ns.ROLE_ORDER) do ui.lootRoles[ro] = true end end
    -- vue cachée aux membres : Tables à la place
    if TAB_FLAG[self.lootTab or "all"] and self:LootFlag(TAB_FLAG[self.lootTab or "all"]) then self.lootTab = "boss" end
    local officer, tab = self:MayEdit(), self.lootTab or "all"
    -- phase choisie (« Phase 1 », « All Raids ») en grand en bas à droite de la fenêtre : posée sur la page Loots
    -- (cachée avec elle), au-dessus du fond de la fenêtre, sous le reste
    local pg = self.pages and self.pages.loots
    if pg then
        if not self.lootPhaseMark then
            self.lootPhaseMark = ns.Text(pg, 40, 700, nil, "BACKGROUND")
            self.lootPhaseMark:SetPoint("BOTTOMRIGHT", self.frame, "BOTTOMRIGHT", -22, 14)
            self.lootPhaseMark:SetShadowColor(0, 0, 0, 0.9)
            self.lootPhaseMark:SetShadowOffset(1, -1)
        end
        local ph = ns.lootPhase and ns.PHASES[ns.lootPhase]
        ns.SetFont(self.lootPhaseMark, 40, 700)
        self.lootPhaseMark:SetText(ph and (ph.name or ("Phase " .. ns.lootPhase)) or ns.L("All Raids"))
        self.lootPhaseMark:SetTextColor(1, 1, 1, 0.3)
    end
    -- barres réutilisées par les vues (Tables) : « + », clé de boss et cadre remis à zéro
    for _, b in ipairs(self.lootsBars) do
        b.plus:Hide() b.bossKey = nil b.count:SetPoint("RIGHT", -12, 0)
        -- souris encore dessus (raid déplié / replié au clic) : encadré du survol gardé
        ns.SetBorderColor(b, b:IsShown() and b:IsMouseOver() and C.hl or C.border)
        b.raidKey = nil b.bgTex:Hide() b.shade:Hide() b.bgBlur:Hide() b.num:Hide() b.count:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
        b.tri:SetSize(11, 11) b.tri:SetVertexColor(0.85, 0.86, 0.9, 1)
        b.label:SetShadowOffset(0, 0)
    end
    for _, b in ipairs(self.lootsBossBtns or {}) do b:Hide() end
    for _, t in ipairs(self.lootsShuts or {}) do t:Hide() end
    for _, t in ipairs(self.lootsSeps or {}) do t:Hide() end
    if self.bossAddRowF then self.bossAddRowF:Hide() end
    local list = self:LootFiltered()
    self.lootsWheel:Update()
    self:LootSearchUpdate()
    local prev
    for _, key in ipairs(TAB_ORDER) do
        local b = self.lootsTabs[key]
        local shown = not (TAB_FLAG[key] and self:LootFlag(TAB_FLAG[key]))
        b:SetShown(shown)
        if shown then
            b:ClearAllPoints()
            if prev then b:SetPoint("LEFT", prev, "RIGHT", 2, 0) else b:SetPoint("LEFT", 0, 0) end
            prev = b
        end
        -- nom réécrit (police pas toujours prête à l'ouverture), largeur ajustée au nom
        ns.SetFont(b.label, 12.5, 600) b.label:SetText(ns.L(TAB_LABEL[key]))
        b:SetWidth(b.label:GetStringWidth() + 32)
        setTab(b, tab == key)
    end
    self.lootsRoleBar:SetShown(tab == "role")
    self.lootsRoleArea:SetShown(tab == "role")
    sf:SetShown(tab ~= "role")
    sf.child:SetWidth(sf:GetWidth())
    if tab ~= "all" then
        for _, r in ipairs(self.lootsRows) do r:Hide() end
        self:LootAddRow(sf.child, false)
    end
    if tab ~= "boss" and tab ~= "wish" then
        for _, b in ipairs(self.lootsBars) do b:Hide() end
        for _, l in ipairs(self.lootsItems) do l:Hide() end
    end
    if tab ~= "wish" then
        for _, l in ipairs(self.wishLines or {}) do l:Hide() end
        if self.wishAddBtn then self.wishAddBtn:Hide() end
        if self.wishNewRow then self.wishNewRow:Hide() end
        if self.wishHead then self.wishHead:Hide() end
        if self.wishArchTitle then self.wishArchTitle:Hide() end
    end
    self.lootsEmpty:ClearAllPoints()
    self.lootsEmpty:SetPoint("TOPLEFT", PAD + 6, -PAD - 8)
    if tab == "role" then return self:RefreshLootsRoles(list) end
    if tab == "boss" then return self:RefreshLootsBoss(list) end
    if tab == "wish" then
        for _, l in ipairs(self.lootsItems) do l:Hide() end
        return self:RefreshLootsWish()
    end
    -- History : recherche par joueur et par type d'objet
    local dn, kept = ns.DiscordNames and ns.DiscordNames() or {}, {}
    for _, rec in ipairs(list) do
        local u = rec.to and self:UnitFor(rec.to)
        if ns.LootHistoryMatch(rec, u and u.tag and dn[u.tag]) then kept[#kept + 1] = rec end
    end
    list = kept
    -- colonne des objets : largeur du plus long nom ; colonnes suivantes à la suite
    local m, nameW = self.lootsMeasure, 140
    ns.SetFont(m, 12.5, 700)
    for _, rec in ipairs(list) do
        m:SetText((itemLook(rec)))
        nameW = math.max(nameW, m:GetStringWidth())
    end
    nameW = math.min(nameW, 420)
    local toX = 6 + 26 + 8 + nameW + 24
    local kindX = toX + 200
    local diceX = kindX + 120
    local dateX = diceX + 40
    local y0 = self:LootAddRow(sf.child, officer, { nameW = nameW, toX = toX, kindX = kindX, dateX = dateX })
    self.lootsEmpty:ClearAllPoints()
    self.lootsEmpty:SetPoint("TOPLEFT", PAD + 6, -PAD - 8 - y0)
    for i, rec in ipairs(list) do
        local r = self.lootsRows[i] or newRow(sf.child)
        self.lootsRows[i] = r
        r.rec = rec
        r.item:SetWidth(nameW + 40)
        r.name:SetWidth(nameW + 4)
        r.to:ClearAllPoints() r.to:SetPoint("LEFT", toX, 0)
        r.kind:ClearAllPoints() r.kind:SetPoint("LEFT", kindX, 0)
        r.dice:ClearAllPoints() r.dice:SetPoint("LEFT", diceX, 0)
        r.date:ClearAllPoints() r.date:SetPoint("LEFT", dateX, 0)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, -y0 - (i - 1) * (ROW_H + 3))
        r:SetPoint("RIGHT", sf.child, "RIGHT", -8, 0)
        local name, icon, qc = itemLook(rec)
        r.icon:SetTexture(icon)
        ns.SetFont(r.name, 12.5, 700)
        r.name:SetText(name)
        r.name:SetTextColor(qc.r, qc.g, qc.b)
        local cc = ns.ClassColor(classOf(rec.to))
        ns.SetFont(r.to.text, 12, 700)
        ns.SetName(r.to.text, rec.to or "?", 160)
        r.to.text:SetTextColor(cc[1], cc[2], cc[3])
        r.to.kind:SetText("")
        -- zone cliquable = le nom seul (ne déborde plus sur la colonne de la réaction)
        r.to:SetWidth(math.min(kindX - toX - 8, math.max(30, r.to.text:GetStringWidth() + 8)))
        -- réaction (colonne) : couleur, icône de la spé Off Spec
        local kc = ns.LOOT_KIND_COL[rec.kind or ""] or C.mute
        local sicon = rec.kind == "os" and rec.spec and ns:SpecIcon({ class = classOf(rec.to) }, rec.spec)
        r.kind.icon:SetShown(sicon ~= nil and sicon ~= false)
        if sicon then r.kind.icon:SetTexture(sicon) end
        ns.SetFont(r.kind.text, 11.5, 700)
        r.kind.text:ClearAllPoints()
        r.kind.text:SetPoint("LEFT", sicon and 20 or 0, 0)
        r.kind.text:SetText(rec.kind and ns.L(KIND[rec.kind] or rec.kind) or "-")
        r.kind.text:SetTextColor(kc[1], kc[2], kc[3])
        ns.SetFont(r.date, 11, 500)
        r.date:SetText(date("%d/%m/%Y %H:%M", rec.t or 0))
        r.del:SetShown(officer)
        if not r.del.armed then ns.SetFont(r.del.label, 11.5, 600) r.del.label:SetText("×") end
        r:Show()
    end
    for i = #list + 1, #self.lootsRows do self.lootsRows[i]:Hide() end
    ns.SetFont(self.lootsEmpty, 12, 500)
    self.lootsEmpty:SetText(#list == 0 and ns.L("No loot attributed yet: use /tlc in game during the raid.") or "")
    sf.child:SetHeight(y0 + #list * (ROW_H + 3) + 10)
end


---------------------------------------------------------------------------
-- Vue Wishlist (= appli) : une barre par perso (mes persos, ou ceux du joueur cherché par un officier : nom Discord
-- dans la recherche), ses objets (obtenu = fond doré, en bas) ; objets d'une phase passée sous « Phase X » en bas
---------------------------------------------------------------------------
local function newWishLine(parent)
    local l = CreateFrame("Frame", nil, parent)
    l:SetHeight(ITEM_H)
    l.gold = ns.Tex(l, { 1, 0.77, 0.24 }, "BACKGROUND", 0.2)
    l.gold:SetAllPoints()
    l.goldBar = ns.Tex(l, { 1, 0.82, 0.48 }, "ARTWORK")
    l.goldBar:SetPoint("TOPLEFT") l.goldBar:SetPoint("BOTTOMLEFT") l.goldBar:SetWidth(3)
    l.icon = l:CreateTexture(nil, "ARTWORK")
    l.icon:SetSize(20, 20)
    l.icon:SetPoint("LEFT", 8, 0)
    l.hit = CreateFrame("Frame", nil, l)
    l.hit:SetPoint("LEFT", 8, 0)
    l.hit:SetSize(NAME_W + 24, ITEM_H)
    l.hit:EnableMouse(true)
    l.hit:SetScript("OnEnter", function(f) ns.TipOwner(f) GameTooltip:SetHyperlink("item:" .. (l.id or 0)) GameTooltip:Show() end)
    l.hit:SetScript("OnLeave", function() GameTooltip:Hide() end)
    l.name = ns.Text(l, 11.5, 600)
    l.name:SetPoint("LEFT", l.icon, "RIGHT", 6, 0)
    l.name:SetWidth(NAME_W)
    l.name:SetJustifyH("LEFT")
    l.name:SetWordWrap(false)
    -- roll : bouton (mes persos : clic = changer), texte sinon
    l.kind = ns.Button(l, "", 100, 22)
    l.kind:SetPoint("LEFT", 8 + 26 + NAME_W + 10, 0)
    l.kind:SetScript("OnClick", function(b)
        if not l.own or l.frozen then return end
        local items = {}
        for _, k in ipairs(ns.WISH_KINDS) do
            items[#items + 1] = { text = ns.L(KIND[k]), color = ns.LOOT_KIND_COL[k], func = function()
                local out = {}
                for _, x in ipairs(ns:WishOf(l.char)) do
                    out[#out + 1] = tonumber(x.id) == tonumber(l.id) and { id = x.id, k = k, t = x.t } or x
                end
                ns:WishSet(l.char, out)
            end }
        end
        ns:OpenMenu(b, items, 140)
    end)
    l.date = ns.Text(l, 11, 500, C.mute)
    l.date:SetPoint("LEFT", l.kind, "RIGHT", 12, 0)
    l.del = ns.IconButton(l, "×", 22)
    l.del:SetPoint("RIGHT", -8, 0)
    l.del:SetScript("OnClick", function() if l.arch then ns:WishArchHide(l.char, l.id) else ns:WishRemove(l.char, l.id) end end)
    return l
end

function ns:RefreshLootsWish()
    local sf = self.lootsArea
    self.wishLines = self.wishLines or {}
    local st = { y = 0, nb = 0, nl = 0, w = sf:GetWidth() - 12 }
    -- archivé : objet qui ne vient pas d'un raid de la phase la plus récente
    local latest = #ns.PHASES
    -- persos montrés : les miens, ou (officier) ceux du joueur cherché (nom Discord)
    local q, own, who, chars = strlower(ns.LootQ("wish")), true, nil, nil
    if q ~= "" and self:MayEdit() then
        own, chars = false, {}
        local dn = ns.DiscordNames and ns.DiscordNames() or {}
        local tag
        for t, n in pairs(dn) do if strlower(n) == q then tag, who = t, n end end
        if not tag then for t, n in pairs(dn) do if strlower(n):find(q, 1, true) then tag, who = t, n break end end end
        for n, r in pairs(self.db.roster) do if tag and r.tag == tag then chars[#chars + 1] = { name = n, class = r.c } end end
        table.sort(chars, function(a, b) return a.name < b.name end)
    else
        chars = self:WishMine()
    end
    local function bar(x, key, label, count, color, defaultOpen, size)
        st.nb = st.nb + 1
        local b = self.lootsBars[st.nb] or newBar(sf.child)
        self.lootsBars[st.nb] = b
        b.okey, b.wishKey = nil, key
        local open = defaultOpen and not (ns.wishOpen or {})[key] or (not defaultOpen and (ns.wishOpen or {})[key])
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", x, -st.y)
        b:SetWidth(st.w - x)
        b:SetHeight(size)
        b.tri:SetRotation(open and 0 or math.pi / 2)
        b.img:Hide()
        b.label:ClearAllPoints()
        b.label:SetPoint("LEFT", 26, 0)
        ns.SetFont(b.label, 13, 700)
        b.label:SetText(label)
        local c = color or C.text
        b.label:SetTextColor(c[1], c[2], c[3])
        ns.SetFont(b.count, 10.5, 600)
        b.count:SetText(count)
        b:Show()
        st.y = st.y + size + 3
        return open
    end
    local function line(char, x, isOwn, indent, arch)
        st.nl = st.nl + 1
        local l = self.wishLines[st.nl] or newWishLine(sf.child)
        self.wishLines[st.nl] = l
        l.char, l.id, l.own, l.arch = char, x.id, isOwn, arch
        local name, icon, qc = itemLook({ id = x.id })
        local got = self:WishGot(char, x.id)
        -- obtenu ou archivé : roll figé
        l.frozen = got or arch
        l:ClearAllPoints()
        l:SetPoint("TOPLEFT", indent, -st.y)
        l:SetWidth(st.w - indent)
        l.gold:SetShown(got) l.goldBar:SetShown(got)
        l.icon:SetTexture(icon)
        ns.SetFont(l.name, 11.5, 600)
        l.name:SetText(trunc(name, 30))
        l.name:SetTextColor(qc.r, qc.g, qc.b)
        local kc = ns.LOOT_KIND_COL[x.k] or C.mute
        ns.SetFont(l.kind.label, 11, 700)
        l.kind.label:SetText(ns.L(KIND[x.k] or x.k or "?"))
        l.kind.label:SetTextColor(kc[1], kc[2], kc[3])
        ns.SetFont(l.date, 11, 600)
        l.date:SetText(got and ("|cffffd27a" .. ns.L("Obtained") .. "|r") or (x.t and x.t > 0 and date("%d/%m/%Y", x.t) or ""))
        -- archive : seul un officier peut la retirer (pour tout le monde)
        if arch then l.del:SetShown(self:MayEdit()) else l.del:SetShown(isOwn) end
        l:Show()
        st.y = st.y + ITEM_H
    end
    -- en-tête : wishlist d'un autre joueur, ou ligne d'ajout / « + » (mes persos)
    if not self.wishHead then self.wishHead = ns.Text(sf.child, 12, 700, C.mute) end
    self.wishHead:SetShown(not own)
    if not own then
        ns.SetFont(self.wishHead, 12, 700)
        self.wishHead:ClearAllPoints()
        self.wishHead:SetPoint("TOPLEFT", 4, -4)
        self.wishHead:SetText(who and ns.L("Wishlist of {0}", who) or ns.L("No player found with this Discord name."))
        st.y = 24
    end
    if not self.wishAddBtn then
        local b = CreateFrame("Button", nil, sf.child)
        b:SetHeight(26)
        ns.Fill(b, C.panel, 0.6)
        ns.Border(b, C.border)
        b.label = ns.Text(b, 16, 700, C.mute)
        b.label:SetPoint("CENTER")
        b:SetScript("OnEnter", function(s) ns.SetBorderColor(s, C.hl) s.label:SetTextColor(1, 1, 1)
            ns.TipOwner(s) GameTooltip:SetText(ns.L("Add an item to the wishlist of one of your characters"), 1, 1, 1) GameTooltip:Show() end)
        b:SetScript("OnLeave", function(s) ns.SetBorderColor(s, C.border) s.label:SetTextColor(C.mute[1], C.mute[2], C.mute[3]) GameTooltip:Hide() end)
        b:SetScript("OnClick", function()
            local m = ns:WishMine()
            ns.wishNew = { char = m[1] and m[1].name, k = "bis" }
            local r = ns:WishAddRow(sf.child)
            r.item:SetText("") r.icon:SetTexture(134400) r.item:SetTextColor(1, 1, 1)
            ns:RefreshLootsPage()
            r.item:SetFocus()
        end)
        self.wishAddBtn = b
    end
    local addB = self.wishAddBtn
    local row = self.wishNew and self:WishAddRow(sf.child) or self.wishNewRow
    addB:SetShown(own and not self.wishNew and #chars > 0)
    if row then row:SetShown(own and self.wishNew ~= nil) end
    if own and self.wishNew and row then
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 0, -st.y)
        row:SetPoint("RIGHT", sf.child, "RIGHT", -8, 0)
        self:WishAddRowFill()
        st.y = st.y + 30 + 6
    elseif own and #chars > 0 then
        addB:ClearAllPoints()
        addB:SetPoint("TOPLEFT", 0, -st.y)
        addB:SetPoint("RIGHT", sf.child, "RIGHT", -8, 0)
        ns.SetFont(addB.label, 16, 700)
        addB.label:SetText("+")
        st.y = st.y + 26 + 6
    end
    -- persos, puis phases passées
    local archived, phaseList = {}, {}
    for _, c in ipairs(chars) do
        local act = {}
        for _, x in ipairs(self:WishOf(c.name)) do
            local ph = self:WishItemPhase(x.id)
            -- seuls les objets obtenus sont archivés (non obtenus : restent dans la liste du perso)
            if ph and ph < latest and self:WishGot(c.name, x.id) then
                -- archive retirée par un officier : ne s'affiche plus nulle part
                if not self:WishArchHidden(c.name, x.id) then
                    if not archived[ph] then archived[ph] = {} phaseList[#phaseList + 1] = ph end
                    archived[ph][c.name] = archived[ph][c.name] or { class = c.class, items = {} }
                    table.insert(archived[ph][c.name].items, x)
                end
            else
                act[#act + 1] = { x = x, got = self:WishGot(c.name, x.id) }
            end
        end
        -- obtenus en bas
        table.sort(act, function(a, b)
            if a.got ~= b.got then return not a.got end
            return (a.x.t or 0) < (b.x.t or 0)
        end)
        local cc = ns.ClassColor(c.class)
        if bar(0, "c:" .. c.name, c.name, ns.L("{0} items", #act), cc, true, BAR_H) then
            for _, a in ipairs(act) do line(c.name, a.x, own, 22) end
            if #act == 0 then st.y = st.y + 4 end
        end
    end
    table.sort(phaseList, function(a, b) return a > b end)
    -- Archives : grand titre, puis les phases (de la précédente à la première), les persos décalés, leurs objets
    if not self.wishArchTitle then self.wishArchTitle = ns.Text(sf.child, 16, 800, C.white) end
    self.wishArchTitle:SetShown(#phaseList > 0)
    if #phaseList > 0 then
        st.y = st.y + 12
        ns.SetFont(self.wishArchTitle, 16, 800)
        self.wishArchTitle:ClearAllPoints()
        self.wishArchTitle:SetPoint("TOPLEFT", 4, -st.y)
        self.wishArchTitle:SetText(ns.L("Archives"))
        st.y = st.y + 24
    end
    for _, ph in ipairs(phaseList) do
        local n = 0
        for _, v in pairs(archived[ph]) do n = n + #v.items end
        if bar(0, "p:" .. ph, ns.L("Phase {0}", ph), ns.L("{0} items", n), nil, false, BAR_H) then
            local names = {}
            for name in pairs(archived[ph]) do names[#names + 1] = name end
            table.sort(names)
            for _, name in ipairs(names) do
                local v = archived[ph][name]
                if bar(22, "p:" .. ph .. ":" .. name, name, ns.L("{0} items", #v.items), ns.ClassColor(v.class), false, BAR_H - 4) then
                    for _, x in ipairs(v.items) do line(name, x, own, 44, true) end
                end
            end
        end
    end
    for i = st.nb + 1, #self.lootsBars do self.lootsBars[i]:Hide() end
    for i = st.nl + 1, #self.wishLines do self.wishLines[i]:Hide() end
    ns.SetFont(self.lootsEmpty, 12, 500)
    self.lootsEmpty:SetText(own and #chars == 0 and ns.L("No character of yours is known yet: log in with Discord and play them once with Guild Tool.") or "")
    sf.child:SetHeight(st.y + 10)
end
