-- GuildTool : bouton de la mini-carte (media/minimap = icône de l'exe, Bridge/icon.ico)
-- Clic : fenêtre principale ; Maj + clic : /tlc ; Alt + clic : /tlc trade ; glisser : déplacer autour de la mini-carte
local _, ns = ...

local ICON = "Interface\\AddOns\\GuildTool\\media\\minimap"

local function place(b)
    local a = math.rad(ns.db.ui.mmAngle or 200)
    local r = (Minimap:GetWidth() / 2) + 5
    b:ClearAllPoints()
    b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

function ns:CreateMinimapButton()
    if self.mmButton or not Minimap then return end
    local b = CreateFrame("Button", "GuildToolMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    -- fond rond sombre (l'icône, celle de l'exe, a un fond transparent)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(22, 22)
    bg:SetPoint("CENTER", 0, 1)
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(22, 22)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture(ICON)
    b.icon = icon
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetScript("OnClick", function()
        if IsAltKeyDown() then ns:LootTradeWindow()
        elseif IsShiftKeyDown() then ns:ToggleLoot()
        else ns:Toggle() end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Guild Tool", 1, 1, 1)
        GameTooltip:AddLine(ns.L("Click: open ({0})", ns:Slash()), 0.8, 0.8, 0.8)
        GameTooltip:AddLine(ns.L("Shift + click: loot council (/tlc)"), 0.8, 0.8, 0.8)
        GameTooltip:AddLine(ns.L("Alt + click: tradeable loots (/tlc trade)"), 0.8, 0.8, 0.8)
        GameTooltip:AddLine(ns.L("Drag: move"), 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    -- glisser : angle autour de la mini-carte (gardé dans les SavedVariables)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local x, y = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            ns.db.ui.mmAngle = math.deg(math.atan2(y / s - my, x / s - mx))
            place(self)
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    place(b)
    self.mmButton = b
end
