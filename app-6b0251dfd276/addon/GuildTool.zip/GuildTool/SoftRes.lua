-- GuildTool : réservations softres.it (colonne SR de /tlc)
-- Source : CSV d'export softres.it collé dans /tlc (GuildToolDB.softres.csv, réservations gardées sans le texte).
-- Chaque réservation est rattachée au perso du groupe : nom du raider s'il est là, sinon un perso du même compte
-- Discord (tag du roster, inscription à un event).
local _, ns = ...

local function first(n) return n and (n:match("^([^%-%s]+)") or n) or "" end

-- champs d'une ligne CSV (guillemets : virgules et "" à l'intérieur)
local function csvFields(line)
    local out, i, n = {}, 1, #line
    while i <= n + 1 do
        if line:sub(i, i) == '"' then
            local buf, j = {}, i + 1
            while j <= n do
                local c = line:sub(j, j)
                if c == '"' and line:sub(j + 1, j + 1) == '"' then buf[#buf + 1] = '"' j = j + 2
                elseif c == '"' then j = j + 1 break
                else buf[#buf + 1] = c j = j + 1 end
            end
            out[#out + 1] = table.concat(buf)
            local comma = line:find(",", j, true)
            i = comma and comma + 1 or n + 2
        else
            local comma = line:find(",", i, true)
            out[#out + 1] = strtrim(line:sub(i, (comma or n + 1) - 1))
            i = comma and comma + 1 or n + 2
        end
    end
    return out
end

-- CSV softres.it -> { list = {{n, d, dn, i}}, date = "AAAA-MM-JJ HH:MM:SS" (export le plus récent) } ou nil
function ns:SRParseCSV(text)
    local head, list, latest = nil, {}, nil
    for line in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        if strtrim(line) ~= "" then
            local f = csvFields(line)
            if not head then
                head = {}
                for i, h in ipairs(f) do head[strlower(strtrim(h))] = i end
                if not head["item id"] then return nil end
            else
                local id = tonumber(f[head["item id"]] or "")
                local name = head["raider name"] and f[head["raider name"]]
                if id and name and name ~= "" then
                    list[#list + 1] = { n = name, i = id, d = head["discord id"] and f[head["discord id"]] or nil,
                                        dn = head["discord name"] and f[head["discord name"]] or nil }
                end
                local dt = head["date"] and f[head["date"]]
                if dt and dt ~= "" and (not latest or dt > latest) then latest = dt end
            end
        end
    end
    if not head then return nil end
    return { list = list, date = latest }
end

-- texte collé : réservations gardées (pas le texte), interrupteur allumé
function ns:SRSetCSV(text)
    local r = self:SRParseCSV(text)
    if not r then return false end
    local s = self:SRState()
    s.csv = { list = r.list, date = r.date, t = time() }
    s.on = true
    self.srCache = nil
    return true
end

function ns:SRState()
    self.db.softres = type(self.db.softres) == "table" and self.db.softres or {}
    return self.db.softres
end
function ns:SROn() return self:SRState().on and true or false end
function ns:SRToggle() local s = self:SRState() s.on = not s.on self.srCache = nil end

-- persos du groupe (prénoms) et taille du groupe
local function groupSet()
    local set, n = {}, 0
    local count = GetNumGroupMembers() or 0
    if count == 0 then set[first(UnitName("player"))] = true return set, 1 end
    for i = 1, count do
        local unit = IsInRaid() and ("raid" .. i) or (i == 1 and "player" or "party" .. (i - 1))
        local name = UnitName(unit)
        if name then set[first(name)] = true n = n + 1 end
    end
    return set, n
end

-- source utilisée : { list, label (heure d'export du CSV), t }
function ns:SRSource()
    local csv = self:SRState().csv
    if not csv then return nil end
    local d = csv.date and csv.date:match("^%d+%-(%d+%-%d+ %d+:%d+)")
    local label = d and (d:sub(4, 5) .. "/" .. d:sub(1, 2) .. d:sub(6)) or date("%d/%m %H:%M", csv.t or 0)
    return { list = csv.list or {}, label = "CSV " .. label, t = csv.t }
end

-- perso du groupe d'une réservation : nom du raider s'il est là, sinon un perso du même compte Discord
local function resolve(r, inGroup)
    local n = first(r.n)
    if inGroup[n] then return n end
    local dn = r.dn and strlower(r.dn)
    if dn and dn ~= "" then
        for name, ro in pairs(ns.db.roster or {}) do
            if ro.tag and strlower(ro.tag) == dn and inGroup[name] then return name end
        end
    end
    if r.d and r.d ~= "" then
        for _, ev in ipairs(ns.db.events or {}) do
            for _, s in ipairs(ev.signups or {}) do
                if s.uid == r.d and s.ch and inGroup[first(s.ch)] then return first(s.ch) end
            end
        end
    end
    return n
end

-- réservations d'un objet : liste de noms (un nom par réservation, triés) et nombre par nom
function ns:SRItem(itemId)
    if not (itemId and self:SROn()) then return {}, {} end
    local src = self:SRSource()
    if not src then return {}, {} end
    local now = time()
    local sk = "csv:" .. tostring(src.t)   -- CSV collé et sa date
    if not (self.srCache and self.srCache.src == sk and now - self.srCache.at < 5) then
        local inGroup = groupSet()
        local by = {}
        for _, r in ipairs(src.list) do
            local name = resolve(r, inGroup)
            by[r.i] = by[r.i] or {}
            by[r.i][name] = (by[r.i][name] or 0) + 1
        end
        self.srCache = { src = sk, at = now, by = by }
    end
    local counts = self.srCache.by[tonumber(itemId)] or {}
    local names = {}
    for n in pairs(counts) do names[#names + 1] = n end
    table.sort(names)
    local list = {}
    for _, n in ipairs(names) do for _ = 1, counts[n] do list[#list + 1] = n end end
    return list, counts
end

-- nombre de réservations d'un joueur sur un objet (jets permis), 1 au moins
function ns:SRCount(itemId, player)
    local _, counts = self:SRItem(itemId)
    return math.max(1, counts[first(player)] or 0)
end
