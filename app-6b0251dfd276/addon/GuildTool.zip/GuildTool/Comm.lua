-- GuildTool : communication entre addons (métiers, équipement) et historique de loot RCLootCouncil
-- Chaque joueur qui a l'addon envoie à la guilde les infos de son perso connecté :
--   "P\t<nom>\t<métier>:<rang>:<max>\t<métier>:<rang>:<max>"   métiers principaux
--   "G\t<nom>\t<slot>:<itemID>,<slot>:<itemID>,..."              équipement porté
--   "R"                                                          demande : « envoyez-moi vos infos »
--   "X\t<nom>\t<clé>\t<n°>/<total>\t<morceau>"                    données longues découpées (messages limités à 255 octets) :
--       clé "S"  = sets du gestionnaire d'équipement : <nom>|<icône>|<slot>:<itemID>,... (sets séparés par "\a")
--       clé "T1" / "T2" = talents de la spé 1 / 2 : <actif 0/1>\b<onglet>~<icône>~<points>~<rang.max.ligne.col.icône.nom>;...\b...
local _, ns = ...

local PREFIX = "GuildTool"
ns.COMM_PREFIX = PREFIX
local SLOTS = { 1, 2, 3, 15, 5, 4, 19, 9, 10, 6, 7, 8, 11, 12, 13, 14, 16, 17, 18 }
ns.GEAR_SLOTS = SLOTS
-- disposition de la fenêtre de personnage : colonne gauche, colonne droite, armes
-- Icônes des métiers par nom (anglais / français), pour les persos dont l'icône n'a pas été relevée
ns.PROF_ICON = {
    Alchemy = "trade_alchemy", Blacksmithing = "trade_blacksmithing", Enchanting = "trade_engraving",
    Engineering = "trade_engineering", Herbalism = "trade_herbalism", Leatherworking = "trade_leatherworking",
    Mining = "trade_mining", Skinning = "inv_misc_pelt_wolf_01", Tailoring = "trade_tailoring",
    Cooking = "inv_misc_food_15", ["First Aid"] = "spell_holy_sealofsacrifice", Fishing = "trade_fishing",
    Alchimie = "trade_alchemy", Forge = "trade_blacksmithing", Enchantement = "trade_engraving",
    ["Ingénierie"] = "trade_engineering", Herboristerie = "trade_herbalism", ["Travail du cuir"] = "trade_leatherworking",
    Minage = "trade_mining", ["Dépeçage"] = "inv_misc_pelt_wolf_01", Couture = "trade_tailoring",
    Cuisine = "inv_misc_food_15", Secourisme = "spell_holy_sealofsacrifice", ["Pêche"] = "trade_fishing",
}
ns.GEAR_LEFT, ns.GEAR_RIGHT, ns.GEAR_BOTTOM = { 1, 2, 3, 15, 5, 4, 19, 9 }, { 10, 6, 7, 8, 11, 12, 13, 14 }, { 16, 17, 18 }

-- Moteur récent : les fonctions d'objets globales ont migré dans C_Item
local GetItemInfo = _G.GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetItemIcon = _G.GetItemIcon or (C_Item and C_Item.GetItemIconByID)

-- Nom complet du perso tel que le roster de guilde le connaît (« Sundance Pal » : prénom + nom sur Forever)
local function playerName() return ns:MyName() end

-- Métiers principaux du perso connecté : { { n = nom, r = rang, m = max } }
local function myProfessions()
    local out = {}
    if GetProfessions and GetProfessionInfo then
        local p1, p2 = GetProfessions()
        for _, idx in ipairs({ p1, p2 }) do
            if idx then
                local name, icon, rank, max, _, _, line = GetProfessionInfo(idx)
                if name then out[#out + 1] = { n = name, r = rank, m = max, i = icon, id = line } end
            end
        end
    end
    if #out == 0 and GetNumSkillLines then
        -- Classic : les métiers principaux sont les compétences « abandonnables »
        for i = 1, GetNumSkillLines() do
            local name, isHeader, _, rank, _, _, max, abandonable = GetSkillLineInfo(i)
            if not isHeader and abandonable and #out < 2 then out[#out + 1] = { n = name, r = rank, m = max } end
        end
    end
    return out
end

local function myGear()
    local gear = {}
    for _, slot in ipairs(SLOTS) do
        local id = GetInventoryItemID("player", slot)
        if id then gear[slot] = id end
    end
    return gear
end

-- Infobulle réelle de chaque objet porté (suffixe aléatoire « of the Bear », stats exactes, enchantements) :
-- { [slot] = { { l = texte gauche, c = couleur, r = texte droite, rc = couleur }, ... } } pour l'exe
local function hex(r, g, b)
    local function c(v) return math.floor(math.max(0, math.min(1, v or 1)) * 255 + 0.5) end
    return ("%02x%02x%02x"):format(c(r), c(g), c(b))
end
local function plain(s)
    if type(s) ~= "string" then return nil end
    s = s:gsub("|T.-|t", ""):gsub("|A.-|a", ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|n", " ")
    return s ~= "" and s or nil
end

local scanTip
local function tipLines(slot)
    local out = {}
    local TI = C_TooltipInfo
    if TI and TI.GetInventoryItem then
        local data = TI.GetInventoryItem("player", slot)
        for _, line in ipairs(data and data.lines or {}) do
            local l, r = plain(line.leftText), plain(line.rightText)
            if l or r then
                local lc, rc = line.leftColor, line.rightColor
                out[#out + 1] = { l = l, c = lc and hex(lc.r, lc.g, lc.b), r = r, rc = rc and hex(rc.r, rc.g, rc.b) }
            end
        end
        return out
    end
    -- sinon : infobulle cachée lue ligne par ligne
    if not scanTip then
        scanTip = CreateFrame("GameTooltip", "GuildToolScanTip", nil, "GameTooltipTemplate")
        scanTip:SetOwner(UIParent, "ANCHOR_NONE")
    end
    scanTip:ClearLines()
    scanTip:SetInventoryItem("player", slot)
    for i = 1, scanTip:NumLines() do
        local L, R = _G["GuildToolScanTipTextLeft" .. i], _G["GuildToolScanTipTextRight" .. i]
        local l, r = plain(L and L:GetText()), plain(R and R:IsShown() and R:GetText())
        if l or r then
            out[#out + 1] = { l = l, c = L and hex(L:GetTextColor()), r = r, rc = r and hex(R:GetTextColor()) }
        end
    end
    return out
end

local function myGearTips()
    local out = {}
    for _, slot in ipairs(SLOTS) do
        if GetInventoryItemID("player", slot) then
            local lines = tipLines(slot)
            if #lines > 0 then out[slot] = lines end
        end
    end
    return out
end

-- Sets du gestionnaire d'équipement Blizzard : { { n = nom, i = icône, g = { [slot] = itemID } } }
local function mySets()
    local out = {}
    local api = C_EquipmentSet
    if not (api and api.GetEquipmentSetIDs) then return out end
    for _, id in ipairs(api.GetEquipmentSetIDs() or {}) do
        local name, icon = api.GetEquipmentSetInfo(id)
        local items, gear = api.GetItemIDs(id) or {}, {}
        for slot, item in pairs(items) do
            if type(item) == "number" and item > 0 then gear[slot] = item end
        end
        if name then out[#out + 1] = { n = name, i = icon, g = gear } end
    end
    return out
end

-- Infos d'un onglet de talents : le format de GetTalentTabInfo change selon la version du jeu
local function tabInfo(tab, group)
    local v = { GetTalentTabInfo(tab, false, false, group) }
    if type(v[1]) == "number" and type(v[2]) == "string" then return v[2], v[4], v[5] end -- id, nom, description, icône, points
    return v[1], v[2], v[3]                                                                -- nom, icône, points
end

-- Ordre des arbres classiques (de gauche à droite dans l'arbre de traits de Forever)
local TREE_NAMES = {
    WARRIOR = { "Arms", "Fury", "Protection" },        PALADIN = { "Holy", "Protection", "Retribution" },
    HUNTER  = { "Beast Mastery", "Marksmanship", "Survival" }, ROGUE = { "Assassination", "Combat", "Subtlety" },
    PRIEST  = { "Discipline", "Holy", "Shadow" },      SHAMAN  = { "Elemental", "Enhancement", "Restoration" },
    MAGE    = { "Arcane", "Fire", "Frost" },           WARLOCK = { "Affliction", "Demonology", "Destruction" },
    DRUID   = { "Balance", "Feral", "Restoration" },
}

-- Spé active (double spé) : 1 ou 2
local function activeGroup()
    local S = C_SpecializationInfo
    if S and S.GetActiveSpecGroup then local ok, g = pcall(S.GetActiveSpecGroup) if ok and g then return g end end
    if GetActiveSpecGroup then return GetActiveSpecGroup() or 1 end
    if GetActiveTalentGroup then return GetActiveTalentGroup() or 1 end
    return 1
end

local function spellNameIcon(spellID)
    if C_Spell and C_Spell.GetSpellInfo then
        local info = C_Spell.GetSpellInfo(spellID)
        if info then return info.name, info.iconID end
    end
    if GetSpellInfo then local n, _, ic = GetSpellInfo(spellID) return n, ic end
end

-- Forever : les 3 arbres classiques sont côte à côte dans UN arbre de traits ; colonnes à ~600 d'écart,
-- arbres à plus de 2200 : un écart > 1200 commence un nouvel arbre (méthode de GuildOS). Les 3 plus gros
-- groupes sont les arbres, un nœud isolé rejoint le plus proche. Rang / colonne = position / pas de la grille.
local function traitTabs()
    local CT, T = C_ClassTalents, C_Traits
    if not (CT and CT.GetActiveConfigID and T and T.GetConfigInfo and T.GetTreeNodes and T.GetNodeInfo) then return nil end
    local configID = CT.GetActiveConfigID()
    local config = configID and T.GetConfigInfo(configID)
    local treeID = config and config.treeIDs and config.treeIDs[1]
    if not treeID then return nil end
    local nodes = {}
    for _, nodeID in ipairs(T.GetTreeNodes(treeID) or {}) do
        local info = T.GetNodeInfo(configID, nodeID)
        if info and info.posX and (info.maxRanks or 0) > 0 then
            local entryID = (info.activeEntry and info.activeEntry.entryID) or (info.entryIDs and info.entryIDs[1])
            local entry = entryID and T.GetEntryInfo and T.GetEntryInfo(configID, entryID)
            local def = entry and entry.definitionID and T.GetDefinitionInfo and T.GetDefinitionInfo(entry.definitionID)
            local spellID = def and (def.spellID or def.overriddenSpellID)
            local name, icon
            if spellID then name, icon = spellNameIcon(spellID) end
            nodes[#nodes + 1] = { x = info.posX, y = info.posY or 0, r = tonumber(info.ranksPurchased or info.currentRank) or 0,
                                  m = info.maxRanks, s = spellID, n = name or ("Talent " .. nodeID), i = icon }
        end
    end
    if #nodes == 0 then return nil end
    -- nœuds fantômes (anciens talents remplacés, cachés hors de la grille par le jeu : « Holy Specialization » en
    -- double du prêtre, « Improved Serpent Sting » du chasseur) : très loin sous / au-dessus du bloc des autres.
    -- Hauteurs distinctes triées : un écart de plus de 4 fois l'écart habituel coupe un groupe ; seul le plus
    -- gros groupe est gardé (sinon ils décalaient les rangées et les colonnes de l'arbre qu'ils rejoignaient)
    do
        local ys, seen = {}, {}
        for _, n in ipairs(nodes) do if not seen[n.y] then seen[n.y] = true ys[#ys + 1] = n.y end end
        table.sort(ys)
        if #ys >= 3 then
            local gaps = {}
            for k = 2, #ys do gaps[#gaps + 1] = ys[k] - ys[k - 1] end
            local sorted = {}
            for k, g in ipairs(gaps) do sorted[k] = g end
            table.sort(sorted)
            local med = math.max(100, sorted[math.ceil(#sorted / 2)])
            local cluster, clusters = { lo = ys[1], hi = ys[1] }, {}
            for k = 2, #ys do
                if gaps[k - 1] > 4 * med then clusters[#clusters + 1] = cluster cluster = { lo = ys[k], hi = ys[k] }
                else cluster.hi = ys[k] end
            end
            clusters[#clusters + 1] = cluster
            if #clusters > 1 then
                local best, bestN
                for _, c in ipairs(clusters) do
                    local cnt = 0
                    for _, n in ipairs(nodes) do if n.y >= c.lo and n.y <= c.hi then cnt = cnt + 1 end end
                    if not bestN or cnt > bestN then best, bestN = c, cnt end
                end
                local kept = {}
                for _, n in ipairs(nodes) do if n.y >= best.lo and n.y <= best.hi then kept[#kept + 1] = n end end
                nodes = kept
            end
        end
    end
    table.sort(nodes, function(a, b) return a.x < b.x end)
    local groups = {}
    for _, n in ipairs(nodes) do
        local g = groups[#groups]
        if not g or n.x - g.hi > 1200 then g = { lo = n.x, hi = n.x, list = {} } groups[#groups + 1] = g end
        g.hi = n.x
        g.list[#g.list + 1] = n
    end
    local bySize = {}
    for i, g in ipairs(groups) do bySize[i] = g end
    table.sort(bySize, function(a, b) return #a.list > #b.list end)
    for i = 1, math.min(3, #bySize) do bySize[i].tree = true end
    local trees = {}
    for _, g in ipairs(groups) do if g.tree then trees[#trees + 1] = g end end
    for _, g in ipairs(groups) do
        if not g.tree then
            local nearest, best
            for _, t in ipairs(trees) do
                local d = math.max(t.lo - g.hi, g.lo - t.hi)
                if not best or d < best then nearest, best = t, d end
            end
            for _, n in ipairs(g.list) do nearest.list[#nearest.list + 1] = n end
        end
    end
    -- pas de la grille : plus petit écart entre deux positions distinctes (au moins 100)
    local function step(list, key)
        local vals, s = {}, nil
        for _, n in ipairs(list) do vals[#vals + 1] = n[key] end
        table.sort(vals)
        for k = 2, #vals do
            local d = vals[k] - vals[k - 1]
            if d >= 100 and (not s or d < s) then s = d end
        end
        return s or 600, vals[1] or 0
    end
    local _, class = UnitClass("player")
    local names = TREE_NAMES[class] or {}
    local tabs = {}
    for k, g in ipairs(trees) do
        local sx, x0 = step(g.list, "x")
        local sy, y0 = step(g.list, "y")
        local tt = { n = names[k] or ("Tree " .. k), p = 0, t = {} }
        for _, n in ipairs(g.list) do
            tt.t[#tt.t + 1] = { n = n.n, i = n.i, s = n.s, r = n.r, m = n.m,
                                row = math.floor((n.y - y0) / sy + 0.5) + 1, col = math.min(4, math.floor((n.x - x0) / sx + 0.5) + 1) }
            tt.p = tt.p + n.r
        end
        tabs[k] = tt
    end
    return tabs
end

-- Talents de chaque spé (double spé) : { [groupe] = { active = bool, tabs = { { n, i, p, t = { { n, i, s, r, m, row, col } } } } } }
-- Forever : seule la spé active se lit ; l'autre est gardée telle qu'elle était à sa dernière activation.
local function myTalents()
    local out = {}
    if not (GetNumTalentTabs and GetTalentInfo) then
        local tabs = traitTabs()
        if not tabs then return nil end -- talents pas encore chargés : on garde l'ancien relevé
        local me = playerName()
        local old = me and ns.db.chars[me] and ns.db.chars[me].talents or {}
        local g = activeGroup()
        for k, spec in pairs(old) do if type(spec) == "table" then out[k] = spec spec.active = false end end
        out[g] = { active = true, tabs = tabs }
        return out
    end
    local groups = GetNumTalentGroups and GetNumTalentGroups() or 1
    local active = GetActiveTalentGroup and GetActiveTalentGroup() or 1
    for g = 1, math.max(1, groups or 1) do
        local spec = { active = g == active, tabs = {} }
        for tab = 1, GetNumTalentTabs() do
            local tname, ticon, points = tabInfo(tab, g)
            local tt = { n = tname or ("Tree " .. tab), i = ticon, p = 0, t = {} }
            for i = 1, GetNumTalents(tab) do
                local name, icon, row, col, rank, max = GetTalentInfo(tab, i, false, false, g)
                if name then
                    tt.t[#tt.t + 1] = { n = name, i = icon, r = rank or 0, m = max or 0, row = row, col = col }
                    tt.p = tt.p + (rank or 0)
                end
            end
            spec.tabs[tab] = tt
        end
        out[g] = spec
    end
    return out
end

-- Texte compact (pas de séparateurs dans les noms)
local function clean(s) return (tostring(s or ""):gsub("[\t|~;\a\b,:]", " ")) end

local function encodeSets(sets)
    local parts = {}
    for _, s in ipairs(sets) do
        local items = {}
        for slot, id in pairs(s.g) do items[#items + 1] = slot .. ":" .. id end
        parts[#parts + 1] = clean(s.n) .. "|" .. tostring(s.i or "") .. "|" .. table.concat(items, ",")
    end
    return table.concat(parts, "\a")
end

local function decodeSets(text)
    local out = {}
    for part in (text .. "\a"):gmatch("([^\a]*)\a") do
        local n, i, items = part:match("^(.-)|(.-)|(.*)$")
        if n then
            local g = {}
            for slot, id in items:gmatch("(%d+):(%d+)") do g[tonumber(slot)] = tonumber(id) end
            out[#out + 1] = { n = n, i = tonumber(i) or i, g = g }
        end
    end
    return out
end

local function encodeSpec(spec)
    local tabs = {}
    for _, tt in ipairs(spec.tabs) do
        local list = {}
        for _, t in ipairs(tt.t) do
            -- champ icône = « <icône>_<sort> » (le sort sert à l'exe pour l'infobulle Wowhead)
            list[#list + 1] = ("%d.%d.%d.%d.%s_%s.%s"):format(t.r, t.m, t.row or 0, t.col or 0, tostring(t.i or ""), tostring(t.s or ""), clean(t.n))
        end
        tabs[#tabs + 1] = clean(tt.n) .. "~" .. tostring(tt.i or "") .. "~" .. tt.p .. "~" .. table.concat(list, ";")
    end
    return (spec.active and "1" or "0") .. "\b" .. table.concat(tabs, "\b")
end

local function decodeSpec(text)
    local parts = {}
    for p in (text .. "\b"):gmatch("([^\b]*)\b") do parts[#parts + 1] = p end
    local spec = { active = parts[1] == "1", tabs = {} }
    for k = 2, #parts do
        local n, i, p, list = parts[k]:match("^(.-)~(.-)~(%d+)~(.*)$")
        if n then
            local tt = { n = n, i = tonumber(i) or i, p = tonumber(p), t = {} }
            for r, m, row, col, icon, name in list:gmatch("(%d+)%.(%d+)%.(%d+)%.(%d+)%.([^%.]*)%.([^;]*)") do
                local ic, sp = icon:match("^(.-)_(.*)$")
                ic = ic or icon
                tt.t[#tt.t + 1] = { n = name, i = tonumber(ic) or (ic ~= "" and ic or nil), s = tonumber(sp), r = tonumber(r), m = tonumber(m), row = tonumber(row), col = tonumber(col) }
            end
            spec.tabs[#spec.tabs + 1] = tt
        end
    end
    return spec
end

-- Envoi découpé : morceaux de 200 caractères espacés (limite de débit des messages d'addon)
local function sendLong(me, key, text)
    local total = math.max(1, math.ceil(#text / 200))
    for n = 1, total do
        C_Timer.After(0.4 * n, function()
            C_ChatInfo.SendAddonMessage(PREFIX, ("X\t%s\t%s\t%d/%d\t%s"):format(me, key, n, total, text:sub((n - 1) * 200 + 1, n * 200)), "GUILD")
        end)
    end
end

-- Nom, qualité, icône d'un objet ; mémorisé pour l'exe (GuildToolDB.items)
function ns:ItemInfo(id)
    local name, _, quality, ilvl, _, _, _, _, _, icon
    local info = (C_Item and C_Item.GetItemInfo) or GetItemInfo   -- ce client : C_Item seulement
    if info then name, _, quality, ilvl, _, _, _, _, _, icon = info(id) end
    if name then
        self.db.items[id] = { n = name, q = quality, l = ilvl }
        return name, quality, icon
    end
    local cached = self.db.items[id]
    if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
    local icon = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
    return cached and cached.n, cached and cached.q, icon and icon(id)
end

local function store(name, key, value)
    local c = ns.db.chars[name] or {}
    c[key] = value
    c[key .. "T"] = time()
    ns.db.chars[name] = c
end

---------------------------------------------------------------------------
-- Envoi / réception
---------------------------------------------------------------------------
-- Infos du perso connecté : toujours enregistrées pour soi (l'exe les lit), même hors guilde ;
-- chaque partie est protégée : une API absente sur ce client n'empêche pas les autres
-- erreurs gardées aussi dans GuildToolDB.debugErrors (lisibles après /reload)
local function collect(label, fn)
    local ok, res = xpcall(fn, function(e) return tostring(e) .. " | " .. (debugstack and debugstack(2, 3, 0) or ""):gsub("\n", " ") end)
    if not ok then
        ns.commErrors = ns.commErrors or {}
        ns.commErrors[label] = res
        ns.db.debugErrors = ns.db.debugErrors or {}
        ns.db.debugErrors[label] = date("%d/%m %H:%M:%S") .. " " .. res
        return nil
    end
    return res
end

local function gearWithInfo()
    local gear = myGear()
    for _, id in pairs(gear) do ns:ItemInfo(id) end
    return gear
end

local function setsWithInfo()
    local sets = mySets()
    for _, s in ipairs(sets) do for _, id in pairs(s.g) do ns:ItemInfo(id) end end
    return sets
end

function ns:UpdateMyInfo()
    local me = playerName()
    if not me then return end
    ns:RecordMyChar()
    local info = {}
    info.profs = collect("professions", myProfessions) or {}
    store(me, "profs", info.profs)
    info.gear = collect("gear", gearWithInfo) or {}
    store(me, "gear", info.gear)
    -- texte des infobulles : seulement pour soi (trop long pour les messages de guilde, partagé par le serveur de l'exe)
    local tips = collect("gear tooltips", myGearTips)
    if tips then store(me, "gearTip", tips) end
    info.sets = collect("sets", setsWithInfo) or {}
    store(me, "sets", info.sets)
    info.talents = collect("talents", myTalents)
    if info.talents then store(me, "talents", info.talents) else info.talents = {} end
    if ns.membersShown and ns.RefreshMembers then ns:RefreshMembers() end
    return me, info
end

local lastSend = 0
function ns:SendMyInfo(force)
    if not force and GetTime() - lastSend < 30 then return end
    lastSend = GetTime()
    local me, info = ns:UpdateMyInfo()
    -- envoi à la guilde (les autres joueurs avec l'addon) ; perso caché dans l'exe : rien n'est envoyé
    if not me or not IsInGuild() or ns:IsHidden(me) then return end
    local parts = { "P", me }
    for _, p in ipairs(info.profs) do parts[#parts + 1] = ("%s:%d:%d"):format(p.n, p.r or 0, p.m or 0) end
    C_ChatInfo.SendAddonMessage(PREFIX, table.concat(parts, "\t"), "GUILD")
    local items = {}
    for slot, id in pairs(info.gear) do items[#items + 1] = slot .. ":" .. id end
    C_ChatInfo.SendAddonMessage(PREFIX, "G\t" .. me .. "\t" .. table.concat(items, ","), "GUILD")
    sendLong(me, "S", encodeSets(info.sets))
    for g, spec in pairs(info.talents) do sendLong(me, "T" .. g, encodeSpec(spec)) end
end

---------------------------------------------------------------------------
-- Recettes : lues à l'ouverture de la fenêtre du métier (artisanat classique et Enchantement)
---------------------------------------------------------------------------
local function scanRecipes()
    local me = playerName()
    local prof, list = nil, {}
    if GetTradeSkillLine and GetNumTradeSkills and (GetNumTradeSkills() or 0) > 0 then
        prof = GetTradeSkillLine()
        for i = 1, GetNumTradeSkills() do
            local name, kind = GetTradeSkillInfo(i)
            if name and kind ~= "header" and kind ~= "subheader" then
                local link = GetTradeSkillItemLink and GetTradeSkillItemLink(i)
                list[#list + 1] = { n = name, id = link and tonumber(link:match("item:(%d+)")) }
            end
        end
    end
    return prof, list
end

-- Forever (moteur récent) : C_TradeSkillUI, seulement pour son propre métier, une fois les données prêtes
-- (méthode de ProfDB) : { n = nom, id = objet créé, s = recette }
-- dernier essai noté dans GuildToolDB.debugRecipes (diagnostic)
local function recipeNote(why) ns.db.debugRecipes = date("%d/%m %H:%M:%S") .. " " .. why end

local function scanMainline()
    local T = C_TradeSkillUI
    if not (T and T.GetAllRecipeIDs and T.GetRecipeInfo) then recipeNote("no C_TradeSkillUI") return nil, {} end
    if T.IsTradeSkillReady and not T.IsTradeSkillReady() then recipeNote("not ready") return nil, {} end
    if (T.IsTradeSkillGuild and T.IsTradeSkillGuild()) or (T.IsNPCCrafting and T.IsNPCCrafting()) then recipeNote("guild / npc view") return nil, {} end
    if T.IsTradeSkillLinked and T.IsTradeSkillLinked() then recipeNote("linked view (another player)") return nil, {} end
    local base = T.GetBaseProfessionInfo and T.GetBaseProfessionInfo()
    local prof = base and base.professionName
    if (not prof or prof == "") and T.GetTradeSkillLine then
        local a, b = T.GetTradeSkillLine()
        prof = type(b) == "string" and b ~= "" and b or (type(a) == "string" and a or nil)
    end
    if (not prof or prof == "") and T.GetChildProfessionInfo then
        local ci = T.GetChildProfessionInfo()
        prof = ci and ci.parentProfessionName or (ci and ci.professionName)
    end
    if not prof or prof == "" then recipeNote("no profession name") return nil, {} end
    local list = {}
    for _, rid in ipairs(T.GetAllRecipeIDs() or {}) do
        local ri = T.GetRecipeInfo(rid)
        if ri and ri.learned then
            local item
            if T.GetRecipeSchematic then
                local ok, s = pcall(T.GetRecipeSchematic, rid, false)
                item = ok and s and s.outputItemID or nil
            end
            list[#list + 1] = { n = ri.name, id = item, s = rid }
        end
    end
    recipeNote(("%s: %d recipes learned of %d"):format(prof, #list, #(T.GetAllRecipeIDs() or {})))
    return prof, list
end

local function scanCraft()
    local prof, list = nil, {}
    if GetCraftDisplaySkillLine and GetNumCrafts and (GetNumCrafts() or 0) > 0 then
        prof = GetCraftDisplaySkillLine()
        for i = 1, GetNumCrafts() do
            local name, _, kind = GetCraftInfo(i)
            if name and kind ~= "header" then list[#list + 1] = { n = name } end
        end
    end
    return prof, list
end

function ns:StoreRecipes(prof, list)
    if not prof or #list == 0 then return end
    local me = playerName()
    local c = ns.db.chars[me] or {}
    c.recipes = c.recipes or {}
    c.recipes[prof] = list
    c.recipesT = time()
    ns.db.chars[me] = c
end

---------------------------------------------------------------------------
-- Modifications faites en jeu par un officier, envoyées tout de suite à la guilde (sans attendre l'exe) :
--   clé "W:<semaine>" = semaine de compos, "A:<compo>" = noms d'assigns changés à la main
-- Données mises en texte par un format simple (lu sans exécuter de code) : n<nombre>; s<long>:<texte> t f {…}
---------------------------------------------------------------------------
local function ser(v, out)
    local tv = type(v)
    if tv == "number" then out[#out + 1] = "n" .. v .. ";"
    elseif tv == "string" then out[#out + 1] = "s" .. #v .. ":" .. v
    elseif tv == "boolean" then out[#out + 1] = v and "t" or "f"
    elseif tv == "table" then
        out[#out + 1] = "{"
        for k, x in pairs(v) do
            local tk, tx = type(k), type(x)
            if (tk == "string" or tk == "number") and (tx ~= "function" and tx ~= "userdata") then
                ser(k, out)
                ser(x, out)
            end
        end
        out[#out + 1] = "}"
    end
    return out
end
local function serialize(v) return table.concat(ser(v, {})) end

-- Lecture : nil si le texte est invalide (profondeur limitée)
local function deserialize(text)
    local pos = 1
    local function read(depth)
        if depth > 20 then error("too deep") end
        local c = text:sub(pos, pos)
        if c == "n" then
            local num, e = text:match("^([^;]*);()", pos + 1)
            pos = e
            return tonumber(num) or error("bad number")
        elseif c == "s" then
            local len, e = text:match("^(%d+):()", pos + 1)
            len = tonumber(len) or error("bad string")
            local s = text:sub(e, e + len - 1)
            pos = e + len
            return s
        elseif c == "t" then pos = pos + 1 return true
        elseif c == "f" then pos = pos + 1 return false
        elseif c == "{" then
            pos = pos + 1
            local t = {}
            while text:sub(pos, pos) ~= "}" do
                if pos > #text then error("unterminated") end
                local k = read(depth + 1)
                t[k] = read(depth + 1)
            end
            pos = pos + 1
            return t
        end
        error("bad token")
    end
    local ok, v = pcall(read, 0)
    return ok and v or nil
end
ns.Serialize, ns.Deserialize = serialize, deserialize

-- Envois regroupés (une seconde après la dernière modification), seulement par un officier en guilde
local shareQueue, shareTimer = {}, nil
function ns:QueueShare(kind, key)
    if not (IsInGuild() and self:MayEdit()) then return end
    shareQueue[kind .. ":" .. key] = true
    if shareTimer then shareTimer:Cancel() end
    shareTimer = C_Timer.NewTimer(1, function()
        shareTimer = nil
        local me = playerName()
        for k in pairs(shareQueue) do
            local kind2, key2 = k:match("^(%a):(.+)$")
            local data = kind2 == "W" and ns.db.weeks[key2] or kind2 == "A" and ns.db.assigns[key2] or nil
            if data and me then sendLong(me, k, serialize(data)) end
        end
        wipe(shareQueue)
    end)
end

-- Expéditeur réel = officier annoncé ? (nom du message comparé à l'expéditeur donné par le jeu)
local function fromOfficer(name, sender)
    if not ns:IsOfficer(name) then return false end
    local s = (sender or ""):gsub("%-", " ")
    return s:match("^(%S+)") == name:match("^(%S+)")
end

local function applyShare(key, text, name, sender)
    if not fromOfficer(name, sender) or name == playerName() then return end
    local kind, id = key:match("^(%a):(.+)$")
    local data = deserialize(text)
    if type(data) ~= "table" or type(data.t) ~= "number" then return end
    local target = kind == "W" and ns.db.weeks or kind == "A" and ns.db.assigns or nil
    if not target then return end
    local cur = target[id]
    if cur and (cur.t or 0) >= data.t then return end
    target[id] = data
    if kind == "W" then
        local ws = tonumber(id)
        ns:LogReceived(name, ns.L("Raid comps") .. " · " .. (ws and ns:WeekLabel(ws) or id))
    else
        local ev
        for _, w in pairs(ns.db.weeks) do for _, c in ipairs(w.comps or {}) do if c.id == id then ev = c.event and ns:EventById(c.event) end end end
        ns:LogReceived(name, ns.L("Assigns") .. " · " .. (ev and ev.title or id))
    end
    ns:Invalidate()
    if ns.Refresh and ns.frame and ns.frame:IsShown() then ns:Refresh() end
    if ns.RefreshMap then ns:RefreshMap() end
end

-- Réception des envois découpés : morceaux rassemblés par expéditeur et clé
local pending = {}
local function onChunk(name, rest, sender)
    local key, n, total, chunk = rest:match("^([^\t]+)\t(%d+)/(%d+)\t(.*)$")
    if not key then return end
    n, total = tonumber(n), tonumber(total)
    local id = name .. ":" .. key
    local p = pending[id]
    if not p or p.total ~= total or n == 1 then p = { total = total, parts = {} } pending[id] = p end
    p.parts[n] = chunk
    for k = 1, total do if not p.parts[k] then return end end
    pending[id] = nil
    local text = table.concat(p.parts)
    if key:match("^[WA]:") then
        applyShare(key, text, name, sender)
    elseif key == "S" then
        local sets = decodeSets(text)
        for _, s in ipairs(sets) do for _, id2 in pairs(s.g) do ns:ItemInfo(id2) end end
        store(name, "sets", sets)
    elseif key:match("^T%d$") then
        local talents = ns.db.chars[name] and ns.db.chars[name].talents or {}
        talents[tonumber(key:sub(2))] = decodeSpec(text)
        store(name, "talents", talents)
    end
end

local function onMessage(msg, sender)
    local kind, name, rest = msg:match("^(%a)\t([^\t]+)\t?(.*)$")
    if msg == "R" then
        if (sender or ""):match("^([^%-]+)") ~= UnitName("player") then ns:SendMyInfo(true) end
        return
    end
    if not kind then return end
    if kind == "Q" then
        -- phase de la guilde changée en jeu par un admin
        local ph = tonumber(rest)
        local nm = (sender or ""):gsub("%-", " ")
        if ph and ns:IsAdmin(name) and nm:match("^(%S+)") == name:match("^(%S+)") and name ~= playerName() then
            ns:SetPhase(ph, true)
            ns:LogReceived(name, ns.L("Phase") .. " " .. ph)
        end
        return
    end
    if kind == "U" then
        -- grouping d'un raid Main commencé par un officier : « event \t compo »
        local evId, compId = rest:match("^([^\t]*)\t([^\t]+)$")
        if compId and fromOfficer(name, sender) and name ~= playerName() and ns.GroupingReceived then ns:GroupingReceived(name, evId, compId) end
        return
    end
    if kind == "V" then
        -- grouping arrêté par un officier : « event »
        local evId = rest:match("^([^\t]*)$")
        if evId and fromOfficer(name, sender) and name ~= playerName() and ns.GroupingStopped then ns:GroupingStopped(evId) end
        return
    end
    if kind == "M" or kind == "F" then
        -- mini-carte poussée par un officier (raid / groupe) : compo, onglet, phase ; F (Force) = l'ouvre chez tous
        local cid, tabIdx, phIdx = rest:match("^([^\t]+)\t(%d+)\t(%d+)$")
        if cid and fromOfficer(name, sender) and ns.MapApplyPush then
            ns:MapApplyPush(cid, tabIdx, phIdx, kind == "F")
            ns:LogReceived(name, ns.L("Minimap"))
        end
        return
    end
    if kind == "P" then
        local profs = {}
        for part in rest:gmatch("[^\t]+") do
            local n, r, m = part:match("^(.-):(%d+):(%d+)$")
            if n then profs[#profs + 1] = { n = n, r = tonumber(r), m = tonumber(m) } end
        end
        store(name, "profs", profs)
    elseif kind == "G" then
        local gear = {}
        for slot, id in rest:gmatch("(%d+):(%d+)") do
            gear[tonumber(slot)] = tonumber(id)
            ns:ItemInfo(tonumber(id))
        end
        store(name, "gear", gear)
    elseif kind == "X" then
        onChunk(name, rest, sender)
    end
    if ns.membersShown and ns.RefreshMembers then ns:RefreshMembers() end
end

---------------------------------------------------------------------------
-- RCLootCouncil : RCLootCouncilLootDB.factionrealm[<faction - royaume>][<Nom-Royaume>] = { entrées }
---------------------------------------------------------------------------
-- Entrées triées du plus récent au plus ancien : { t, date, item, itemID, response, boss, instance }
function ns:LootHistory(name)
    local db = _G.RCLootCouncilLootDB
    local out = {}
    if type(db) ~= "table" or type(db.factionrealm) ~= "table" then return out, false end
    for _, players in pairs(db.factionrealm) do
        for key, entries in pairs(players) do
            if type(entries) == "table" and (key == name or key:match("^([^%-]+)") == name) then
                for _, e in ipairs(entries) do
                    local link = e.lootWon
                    local id = link and tonumber(link:match("item:(%d+)"))
                    out[#out + 1] = {
                        t = tonumber(tostring(e.id or ""):match("^(%d+)")) or 0, date = e.date, item = link, itemID = id,
                        response = e.response, boss = e.boss, instance = e.instance,
                    }
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.t > b.t end)
    return out, true
end

---------------------------------------------------------------------------
-- Diagnostic (/rp debug) : tout ce que le jeu répond, gardé dans GuildToolDB.debugLog (lisible après /reload)
---------------------------------------------------------------------------
local function vals(...)
    local t = {}
    for i = 1, select("#", ...) do t[i] = tostring((select(i, ...))) end
    return table.concat(t, ", ")
end

local function try(fn, ...)
    if type(fn) ~= "function" then return "MISSING" end
    local r = { pcall(fn, ...) }
    if not r[1] then return "ERROR " .. tostring(r[2]) end
    return vals(unpack(r, 2))
end

function ns:DebugDump()
    local log = {}
    local function add(...) log[#log + 1] = vals(...) end
    add("date", date("%d/%m/%Y %H:%M:%S"), "build", try(GetBuildInfo))
    add("UnitName", try(UnitName, "player"), "GetUnitName", try(GetUnitName, "player", true), "UnitFullName", try(UnitFullName, "player"))
    add("MyName", ns:MyName(), "IsInGuild", IsInGuild(), "guild members", try(GetNumGuildMembers), "class", try(UnitClass, "player"), "level", UnitLevel("player"))
    -- fonctions présentes sur ce client
    local apis = { "GetProfessions", "GetProfessionInfo", "GetNumSkillLines", "GetSkillLineInfo", "GetInventoryItemID", "GetItemInfo",
                   "GetNumTalentTabs", "GetTalentTabInfo", "GetNumTalents", "GetTalentInfo", "GetNumTalentGroups", "GetActiveTalentGroup",
                   "GetTradeSkillLine", "GetNumTradeSkills", "GetTradeSkillInfo", "GetCraftDisplaySkillLine", "GetNumCrafts", "GetCraftInfo" }
    local miss, have = {}, {}
    for _, k in ipairs(apis) do if type(_G[k]) == "function" then have[#have + 1] = k else miss[#miss + 1] = k end end
    add("API present", table.concat(have, " "))
    add("API missing", table.concat(miss, " "))
    local tables = {}
    for _, k in ipairs({ "C_Item", "C_EquipmentSet", "C_TradeSkillUI", "C_ClassTalents", "C_Traits", "C_SpecializationInfo", "C_SkillLine" }) do
        tables[#tables + 1] = k .. "=" .. type(_G[k])
    end
    add("tables", table.concat(tables, " "))
    -- métiers
    add("GetProfessions", try(GetProfessions))
    if GetNumSkillLines then
        local n = GetNumSkillLines()
        add("skill lines", n)
        for i = 1, math.min(n or 0, 40) do add("  skill " .. i, try(GetSkillLineInfo, i)) end
    end
    -- équipement
    for _, slot in ipairs(SLOTS) do
        local id = GetInventoryItemID and GetInventoryItemID("player", slot)
        if id then add("  slot " .. slot, id, "info", try(GetItemInfo, id)) end
    end
    -- sets
    local api = C_EquipmentSet
    if api and api.GetEquipmentSetIDs then
        local ids = api.GetEquipmentSetIDs() or {}
        add("equipment sets", #ids)
        for _, id in ipairs(ids) do add("  set " .. id, try(api.GetEquipmentSetInfo, id)) end
    else
        add("equipment sets", "C_EquipmentSet missing", "GetNumEquipmentSets", try(GetNumEquipmentSets))
    end
    -- talents
    add("talent groups", try(GetNumTalentGroups), "active", try(GetActiveTalentGroup), "tabs", try(GetNumTalentTabs))
    local S = C_SpecializationInfo or {}
    add("spec group", try(activeGroup), "num spec groups", try(S.GetNumSpecGroups), try(GetNumSpecGroups), "active config", try(C_ClassTalents and C_ClassTalents.GetActiveConfigID))
    local okT, tabs = pcall(traitTabs)
    if not okT then add("traits ERROR", tabs)
    elseif not tabs then add("traits", "none (talents not loaded yet?)")
    else for k, t in ipairs(tabs) do add("  trait tree " .. k, t.n, "talents", #t.t, "points", t.p) end end
    if GetNumTalentTabs then
        for tab = 1, GetNumTalentTabs() or 0 do
            add("  tab " .. tab, try(GetTalentTabInfo, tab), "talents", try(GetNumTalents, tab), "first", try(GetTalentInfo, tab, 1))
        end
    end
    -- recettes : dernier relevé à l'ouverture d'un métier
    add("recipes last scan", ns.db.debugRecipes or "never (no profession window event received)", "error", ns.db.debugErrors and ns.db.debugErrors.recipes)
    -- relevé normal, ses erreurs et ce qui a été stocké
    ns.commErrors = nil
    ns:UpdateMyInfo()
    for what, err in pairs(ns.commErrors or {}) do add("ERROR " .. what, err) end
    local c = ns.db.chars[ns:MyName()] or {}
    local function n(t) local k = 0 for _ in pairs(t or {}) do k = k + 1 end return k end
    add("stored under", ns:MyName(), "profs", n(c.profs), "gear", n(c.gear), "sets", n(c.sets), "talents", n(c.talents), "recipes", n(c.recipes))
    ns.db.debugLog = log
    return log
end

---------------------------------------------------------------------------
-- Événements
---------------------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("CHAT_MSG_ADDON")
f:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
f:RegisterEvent("SKILL_LINES_CHANGED")
for _, ev in ipairs({ "EQUIPMENT_SETS_CHANGED", "CHARACTER_POINTS_CHANGED", "ACTIVE_TALENT_GROUP_CHANGED", "PLAYER_TALENT_UPDATE",
                     "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "CRAFT_SHOW", "CRAFT_UPDATE", "PLAYER_LEVEL_UP",
                     "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED", "TRAIT_CONFIG_UPDATED",
                     "ACTIVE_PLAYER_SPECIALIZATION_CHANGED", "PLAYER_SPECIALIZATION_CHANGED", "ACTIVE_TALENT_GROUP_CHANGED" }) do
    pcall(f.RegisterEvent, f, ev) -- certains événements n'existent pas sur toutes les versions du jeu
end
f:SetScript("OnEvent", function(_, event, prefix, msg, _, sender)
    if event == "PLAYER_LOGIN" then
        C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
        -- infos du perso dès que le jeu les a chargées, puis envoi à la guilde
        C_Timer.After(5, function() if ns.db then ns:UpdateMyInfo() end end)
        C_Timer.After(15, function()
            if not ns.db then return end
            ns:SendMyInfo(true)
            if IsInGuild() then C_ChatInfo.SendAddonMessage(PREFIX, "R", "GUILD") end
        end)
    elseif event == "CHAT_MSG_ADDON" then
        if prefix == PREFIX and ns.db then onMessage(msg, sender) end
    elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" or event == "TRADE_SKILL_LIST_UPDATE"
        or event == "TRADE_SKILL_DATA_SOURCE_CHANGED" then
        if not ns.db then return end
        if C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs then
            -- les données arrivent par vagues : un relevé 0,5 s après le premier événement (sans repousser :
            -- des événements continus empêcheraient sinon tout relevé), puis un autre à la vague suivante
            if ns.recipePending then return end
            ns.recipePending = true
            C_Timer.After(0.5, function()
                ns.recipePending = nil
                local ok, prof, list = pcall(scanMainline)
                if ok then ns:StoreRecipes(prof, list) else ns.db.debugErrors = ns.db.debugErrors or {} ns.db.debugErrors.recipes = tostring(prof) end
            end)
        else
            ns:StoreRecipes(scanRecipes())
        end
    elseif event == "CRAFT_SHOW" or event == "CRAFT_UPDATE" then
        if ns.db then ns:StoreRecipes(scanCraft()) end
    elseif ns.db then
        -- équipement ou métiers modifiés : renvoi groupé (au plus toutes les 30 s)
        C_Timer.After(5, function() ns:SendMyInfo() end)
    end
end)
