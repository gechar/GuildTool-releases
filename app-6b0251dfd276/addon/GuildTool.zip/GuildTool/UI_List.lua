-- GuildTool : panneau de droite de Raid Comps (Signed / Rest, tri glissable, liste des persos)
local _, ns = ...
local C = ns.C

local ROW_H, HEAD_H = 22, 24
local STATUS = {
    tentative = { "Tentative", { 0.91, 0.76, 0.38 } },
    late = { "Late", { 0.58, 0.72, 1 } },
    bench = { "Bench", { 0.72, 0.72, 0.72 } },
}

---------------------------------------------------------------------------
-- Tri (partagé avec Members)
---------------------------------------------------------------------------
local function indexOf(t, v)
    for i, x in ipairs(t) do if x == v then return i end end
    return 99
end

local CMP = {
    spec = function(a, b) return indexOf(ns.ROLE_ORDER, a.role), indexOf(ns.ROLE_ORDER, b.role) end,
    class = function(a, b) return indexOf(ns.CLASS_ORDER, a.class), indexOf(ns.CLASS_ORDER, b.class) end,
    player = function(a, b) return a.tag or "~", b.tag or "~" end,
    alpha = function(a, b) return strlower(a.display), strlower(b.display) end,
    -- niveau : du plus haut au plus bas
    level = function(a, b) return -(a.level or 0), -(b.level or 0) end,
    -- Loots (vue Role) : raids faits, loots reçus, du plus au moins
    raids = function(a, b) return -(a.raids or 0), -(b.raids or 0) end,
    loots = function(a, b) return -(a.loots or 0), -(b.loots or 0) end,
    -- nom Discord (A-Z), sans nom à la fin
    discord = function(a, b) return a.discord and strlower(a.discord) or "~~", b.discord and strlower(b.discord) or "~~" end,
}

ns.SORT_HEAD = {
    spec = function(u) return ns.L(u.role or "Unknown spec") end,
    class = function(u) return ns.L(ns.CLASS_NAME[u.class or ""] or "Unknown") end,
    player = function(u) return u.tag and ("@" .. u.tag) or ns.L("No Discord tag") end,
    alpha = function(u) return strupper(u.display:sub(1, 1)) end,
    level = function(u) return ns.L("Level") .. " " .. (u.level or "?") end,
    discord = function(u) return u.discord or ns.L("No Discord name") end,
}

-- over : comparateurs propres à une liste (Members : Spec = classe puis spé, Attendance)
function ns.SortUnits(list, order, over)
    table.sort(list, function(a, b)
        for _, k in ipairs(order) do
            local cmp = (over and over[k]) or CMP[k]
            if cmp then
                local x, y = cmp(a, b)
                if x ~= y then return x < y end
            end
        end
        return a.name < b.name
    end)
end

---------------------------------------------------------------------------
-- Menus clic droit
---------------------------------------------------------------------------
-- Inscrit : lier l'inscription Raid-Helper au tag Discord d'un perso de la guilde
function ns:LinkMenu(anchor, u)
    if not u.uid then return end
    local list = {}
    for name, r in pairs(self.db.roster) do
        if r.tag then list[#list + 1] = { name = name, r = r, same = r.c == u.class } end
    end
    table.sort(list, function(a, b)
        if a.same ~= b.same then return a.same end
        return a.name < b.name
    end)
    local items = {}
    for i = 1, math.min(#list, 20) do
        local e = list[i]
        items[#items + 1] = {
            text = ("%s  @%s  (%d)"):format(e.name, e.r.tag, e.r.l or 0), color = ns.ClassColor(e.r.c), checked = u.tag == e.r.tag,
            func = function() ns:Link(u.uid, e.r.tag) end,
        }
    end
    if #items == 0 then
        UIErrorsFrame:AddMessage("Nobody in the guild has a Discord tag in their guild note yet.", 1, 0.42, 0.42)
        return
    end
    items[#items + 1] = { text = "Remove manual link", color = C.mute, func = function() ns:Link(u.uid, nil) end }
    self:OpenMenu(anchor, items, 240)
end

-- Clic droit : lien pour un inscrit, spé pour un perso non inscrit
function ns:SpecMenu(anchor, u)
    if u.signed then return self:LinkMenu(anchor, u) end
    if not ns.SPECS[u.class or ""] then return end
    local items = {}
    for _, s in ipairs(ns.SPECS[u.class]) do
        items[#items + 1] = { text = s[1] .. "  (" .. s[2] .. ")", checked = u.spec == s[1], func = function() ns:SetSpec(u.name, s[1]) end }
    end
    items[#items + 1] = { text = "Clear spec", color = C.mute, func = function() ns:SetSpec(u.name, nil) end }
    self:OpenMenu(anchor, items, 170)
end

---------------------------------------------------------------------------
-- Lignes et en-têtes
---------------------------------------------------------------------------
local function rowClick(self, button)
    if ns:JustDragged() then return end
    local u = self.unit
    if button == "RightButton" then ns:SpecMenu(self, u) return end
    -- clic sur « locked » : aller à la compo où ce perso fait déjà ce raid
    if u.lock and self.right:IsMouseOver() then ns:GoToLock(u.lock) return end
    if not ns:AutoPlace(u) then
        local sel = ns:Selected()
        local msg = sel and "This comp is full or already has one of this player's characters."
            or (u.signed and "No comp with a free slot for an event this player signed up for." or "No free slot: add a comp with +.")
        UIErrorsFrame:AddMessage(msg, 1, 0.42, 0.42)
        return
    end
    ns:Refresh()
end

local function newRow(parent)
    local r = CreateFrame("Button", nil, parent)
    r:SetHeight(ROW_H)
    ns.Selection(r, 0)
    r.ci = ns.Tex(r, C.white, "ARTWORK")
    r.ci:SetSize(9, 9)
    r.ci:SetPoint("LEFT", 9, 0)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(15, 15)
    r.icon:SetPoint("LEFT", 6, 0)
    r.name = ns.Text(r, 12, 600)
    r.name:SetPoint("LEFT", 27, 0)
    r.right = ns.Text(r, 10, 600)
    r.right:SetPoint("RIGHT", -6, 0)
    r.right:SetJustifyH("RIGHT")
    r.tag = ns.Text(r, 10.5, 400, C.mute)
    r.tag:SetPoint("LEFT", r.name, "RIGHT", 6, 0)
    r.tag:SetPoint("RIGHT", r.right, "LEFT", -6, 0)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r:RegisterForDrag("LeftButton")
    r:SetScript("OnClick", rowClick)
    r:SetScript("OnEnter", function(self)
        ns.ShowSelection(self, true)
        if self.unit.lock and self.right:IsMouseOver() then ns:LockTooltip(self, self.unit.lock) else ns:UnitTooltip(self, self.unit) end
    end)
    r:SetScript("OnLeave", function(self) ns.ShowSelection(self, false) GameTooltip:Hide() end)
    r:SetScript("OnDragStart", function(self) ns:BeginDrag(self.unit.name) end)
    r:SetScript("OnDragStop", function() ns:EndDrag() end)
    return r
end

local function newHeader(parent)
    local h = CreateFrame("Frame", nil, parent)
    h:SetHeight(HEAD_H)
    h.icon = h:CreateTexture(nil, "ARTWORK")
    h.icon:SetSize(18, 18)
    h.icon:SetPoint("BOTTOMLEFT", 4, 2)
    h.text = ns.Text(h, 10, 700, C.mute)
    h.count = ns.Text(h, 10, 400, C.mute)
    h.count:SetPoint("BOTTOMRIGHT", -6, 5)
    return h
end
ns.NewListHeader = newHeader

local function fillRow(r, u)
    r.unit = u
    local c = ns.ClassColor(u.class)
    r.ci:SetColorTexture(c[1], c[2], c[3])
    local icon = ns:SpecIcon(u)
    r.icon:SetShown(icon ~= nil)
    r.ci:SetShown(icon == nil)
    if icon then r.icon:SetTexture(icon) end
    r.name:SetTextColor(c[1], c[2], c[3])
    -- le tag Discord suit le nom de famille s'il est affiché
    local last = ns.SetName(r.name, u.display, 150, true)
    r.tag:ClearAllPoints()
    r.tag:SetPoint("LEFT", last, "RIGHT", 6, 0)
    r.tag:SetPoint("RIGHT", r.right, "LEFT", -6, 0)
    r.tag:SetText(u.tag and ("@" .. u.tag) or "")
    if u.lock then
        r.right:SetText(ns.L("locked"))
        r.right:SetTextColor(C.red[1], C.red[2], C.red[3])
    elseif u.already then
        r.right:SetText(u.alreadyShort)
        r.right:SetTextColor(C.red[1], C.red[2], C.red[3])
    elseif u.unlinked then
        r.right:SetText(ns.L("Unlinked"))
        r.right:SetTextColor(1, 0.6, 0.3)
    elseif STATUS[u.status or ""] then
        local s = STATUS[u.status]
        r.right:SetText(ns.L(s[1]))
        r.right:SetTextColor(s[2][1], s[2][2], s[2][3])
    elseif not u.signed and not u.spec then
        r.right:SetText(ns.L("no spec"))
        r.right:SetTextColor(C.mute[1], C.mute[2], C.mute[3])
    else
        r.right:SetText("")
    end
    u.hint = u.signed and "Click: place in the selected comp, or the first comp of an event this player signed up for. Drag: place manually. Right-click: link to a guild member."
        or "Click: place in the selected comp, or the first comp with room. Drag: place manually. Right-click: set spec."
end

---------------------------------------------------------------------------
-- Panneau
---------------------------------------------------------------------------
function ns:CreateSide(page)
    local side = CreateFrame("Frame", nil, page)
    side:SetPoint("TOPRIGHT")
    side:SetPoint("BOTTOMRIGHT")
    side:SetWidth(ns.SIDE_W)
    ns.Fill(side, C.side)
    local l = ns.Tex(side, C.border, "ARTWORK")
    l:SetPoint("TOPLEFT") l:SetPoint("BOTTOMLEFT") l:SetWidth(1)
    self.side = side

    -- onglets Signed / Rest
    self.sideTabs = {}
    for i, key in ipairs({ "signed", "rest" }) do
        local b = CreateFrame("Button", nil, side)
        b:SetSize(ns.SIDE_W / 2, 34)
        b:SetPoint("TOPLEFT", (i - 1) * ns.SIDE_W / 2, 0)
        ns.Selection(b, nil, ns.C.hl)
        b.label = ns.Text(b, 12.5, 600)
        b.label:SetPoint("CENTER", -8, 0)
        b.label:SetText(ns.L(i == 1 and "Signed" or "Rest"))
        b.count = ns.Text(b, 11, 400, C.mute)
        b.count:SetPoint("LEFT", b.label, "RIGHT", 5, 0)
        b:SetScript("OnClick", function() ns.db.ui.tab = key ns:Refresh() ns.listArea:ScrollTo(0) end)
        self.sideTabs[key] = b
    end
    local tl = ns.Tex(side, C.border, "ARTWORK")
    tl:SetPoint("TOPLEFT", 1, -34) tl:SetPoint("TOPRIGHT", 0, -34) tl:SetHeight(1)

    -- sélection en cours
    self.selText = ns.Text(side, 10.5, 600, C.accent)
    self.selText:SetPoint("TOPLEFT", 11, -40)
    self.selText:SetPoint("TOPRIGHT", -10, -40)

    -- priorité de tri (critères glissables)
    local sl = ns.Text(side, 9.5, 600, C.mute)
    sl:SetPoint("TOPLEFT", 11, -58)
    sl:SetText(strupper(ns.L("Sort priority · drag to reorder")))
    self.chipBar = ns.ChipBar(side, function() return ns.db.ui.order end, function() ns:Refresh() end)
    self.chipBar:SetPoint("TOPLEFT", 10, -72)
    local sb = ns.Tex(side, C.border, "ARTWORK")
    sb:SetPoint("TOPLEFT", 1, -102) sb:SetPoint("TOPRIGHT", 0, -102) sb:SetHeight(1)

    -- pied : Autofill Buffs / Autofill / Scan / Clear (balai), largeurs proportionnelles à leur texte
    local L = ns.L
    local GAP_B, W_ALL = 6, ns.SIDE_W - 20
    local weights = { 13, 8, 10, 4 }
    local wsum = 0
    for _, v in ipairs(weights) do wsum = wsum + v end
    local function bw(i) return math.floor((W_ALL - 3 * GAP_B) * weights[i] / wsum) end
    local function tip(b, title, text)
        b:SetScript("OnEnter", function(self)
            ns.TipOwner(self)
            GameTooltip:SetText(title, 1, 1, 1)
            if text then GameTooltip:AddLine(text, 0.8, 0.8, 0.8, true) end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", GameTooltip_Hide)
    end
    local buffs = ns.Button(side, L("Autofill Buffs"), bw(1), 26)
    buffs:SetPoint("BOTTOMLEFT", 10, 9)
    tip(buffs, L("Autofill Buffs"), L("Add only the sign-ups that bring missing raid buffs / debuffs to each comp that can be filled at 80% (players already placed stay)"))
    buffs:SetScript("OnClick", function() ns:Autofill(true) ns:Refresh() end)
    local fill = ns.Button(side, L("Autofill"), bw(2), 26, true)
    fill:SetPoint("LEFT", buffs, "RIGHT", GAP_B, 0)
    -- complète les compos (ne remplace plus) : pas de confirmation ; Clear pour repartir de zéro
    tip(fill, L("Autofill"), L("Complete the selected comp (or every comp of the week linked to an event) with its sign-ups: raid buffs first, then classes and uncertain presences balanced (players already placed stay)"))
    fill:SetScript("OnClick", function() ns:Autofill(false) ns:Refresh() end)
    local scan = ns.Button(side, L("Scan guild"), bw(3), 26)
    scan:SetPoint("LEFT", fill, "RIGHT", GAP_B, 0)
    scan:SetScript("OnClick", function() ns:RequestRoster() end)
    -- Clear : balai ; 1er clic = balai rouge (confirmer), 2e clic = vide
    local clear = ns.Button(side, "", bw(4), 26)
    clear:SetPoint("BOTTOMRIGHT", -10, 9)
    clear.icon = clear:CreateTexture(nil, "OVERLAY")
    clear.icon:SetSize(16, 16)
    clear.icon:SetPoint("CENTER")
    clear.icon:SetTexture("Interface\\AddOns\\GuildTool\\media\\broom")
    tip(clear, L("Clear"), L("Empty the selected comp, or every comp of the week"))
    clear:SetScript("OnClick", function(b)
        if b.armed then
            b.armed = nil
            b.icon:SetVertexColor(1, 1, 1)
            ns:ClearComps()
            ns:Refresh()
        else
            b.armed = true
            b.icon:SetVertexColor(C.red[1], C.red[2], C.red[3])
            C_Timer.After(3, function() b.armed = nil b.icon:SetVertexColor(1, 1, 1) end)
        end
    end)
    local fl = ns.Tex(side, C.border, "ARTWORK")
    fl:SetPoint("BOTTOMLEFT", 1, 44) fl:SetPoint("BOTTOMRIGHT", 0, 44) fl:SetHeight(1)

    -- liste
    local sf = ns.ScrollArea(side)
    sf:SetPoint("TOPLEFT", 6, -106)
    sf:SetPoint("BOTTOMRIGHT", -2, 48)
    sf.child:SetWidth(ns.SIDE_W - 16)
    self.listArea = sf
    self.rows, self.heads = {}, {}
    self.emptyText = ns.Text(sf.child, 11.5, 400, C.mute)
    self.emptyText:SetPoint("TOPLEFT", 6, -12)
    self.emptyText:SetWidth(ns.SIDE_W - 30)
    self.emptyText:SetWordWrap(true)
end

-- Persos affichés : sans sélection, on masque ceux déjà placés dans la semaine ;
-- avec une compo sélectionnée, seulement ceux de cette compo (les autres portent « locked » / « already in »)
function ns:RefreshList()
    local ui, sel = self.db.ui, self:Selected()
    local units = self:GetUnits()
    local counts = { signed = 0, rest = 0 }
    local visible = {}
    for _, key in ipairs({ "signed", "rest" }) do
        for _, u in ipairs(units[key]) do
            local hidden
            if sel then hidden = self:FindInComp(sel, u.name) else hidden = self:IsPlaced(u.name) end
            if not hidden then
                counts[key] = counts[key] + 1
                if key == ui.tab then
                    visible[#visible + 1] = u
                    u.lock = sel and self:LockoutOf(u.name, sel.raid, sel) or nil
                    local a = self:AlreadyIn(u)
                    if a then
                        local label = self:CompLabel(a.comp, a.index)
                        u.already = ns.L("Already in {0} with {1}", label, self:UnitFor(a.name).display)
                        u.alreadyShort = ns.L("already in {0}", label)
                    else
                        u.already, u.alreadyShort = nil, nil
                    end
                end
            end
        end
    end
    for key, b in pairs(self.sideTabs) do
        b.count:SetText(counts[key])
        local on = key == ui.tab
        ns.ShowSelection(b, on)
        local c = on and C.white or C.mute
        b.label:SetTextColor(c[1], c[2], c[3])
    end
    if sel then
        self.selText:SetText(ns.L("Selected: {0} · {1}", self:CompLabel(sel), self:EventTitle(sel.event)))
    else
        self.selText:SetText(ns.L("All events of the week"))
    end
    self.selText:SetTextColor(sel and C.accent[1] or C.mute[1], sel and C.accent[2] or C.mute[2], sel and C.accent[3] or C.mute[3])
    self.chipBar:Layout()
    -- lignes
    ns.SortUnits(visible, ui.order)
    local child, y, ri, hi, last = self.listArea.child, 0, 0, 0, nil
    local primary = ui.order[1]
    local groupCount = {}
    for _, u in ipairs(visible) do
        local h = ns.SORT_HEAD[primary](u)
        groupCount[h] = (groupCount[h] or 0) + 1
    end
    for _, u in ipairs(visible) do
        local h = ns.SORT_HEAD[primary](u)
        if h ~= last then
            hi = hi + 1
            local hd = self.heads[hi] or newHeader(child)
            self.heads[hi] = hd
            hd:ClearAllPoints()
            hd:SetPoint("TOPLEFT", 0, -y)
            hd:SetPoint("TOPRIGHT", 0, -y)
            local icon = primary == "spec" and ns.ROLE_ICON[u.role or ""]
            hd.icon:SetShown(icon and true or false)
            if icon then hd.icon:SetTexture(icon) end
            hd.text:ClearAllPoints()
            hd.text:SetPoint("BOTTOMLEFT", icon and 26 or 6, 5)
            hd.text:SetText(primary == "player" and h or strupper(h))
            hd.count:SetText(groupCount[h])
            hd:Show()
            y = y + HEAD_H
            last = h
        end
        ri = ri + 1
        local r = self.rows[ri] or newRow(child)
        self.rows[ri] = r
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, -y)
        r:SetPoint("TOPRIGHT", 0, -y)
        fillRow(r, u)
        r:Show()
        y = y + ROW_H
    end
    for i = ri + 1, #self.rows do self.rows[i]:Hide() end
    for i = hi + 1, #self.heads do self.heads[i]:Hide() end
    if #visible == 0 then
        local msg
        if ui.tab == "rest" then msg = ns.L("No other level {0}+ in the guild roster.", self:MinLevel())
        elseif #self:EventsInWeek(self:CurrentWeek()) == 0 then msg = ns.L("No Raid-Helper event this lockout week.")
        else msg = ns.L("No sign-ups left. Link a comp to an event (arrow next to its title) to see its sign-ups.") end
        self.emptyText:SetText(msg)
        self.emptyText:Show()
    else
        self.emptyText:Hide()
    end
    child:SetHeight(math.max(y + 8, 1))
    self.listArea:UpdateThumb()
end
